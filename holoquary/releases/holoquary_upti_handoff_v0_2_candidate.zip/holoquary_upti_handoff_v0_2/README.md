# Holoquary ↔ UPTI handoff profile v0.2 — **tentative / local only**

**Design authority:** m.A.R.S. · **Implementation:** assistant-generated proposal, not a canonical lock.  
**Baseline:** Holoquary v1.2 normalized data/knowledge/execution/provenance; prior Holoquary application-payload v0.1.  
**Terminology correction:** UPTI, not UPST. Older documents and Python docstrings with UPST references are retained as historical source, not a second protocol.

## What is implemented

* `payload.py` and `schema.json`: unchanged v0.1 payload contract for `state_record`, `design_target`, and `artifact_reference`. An unchanged legacy copy is under `legacy/`.
* `staging.py`: **local-only** stage → verify → ready-for-UPTI-handoff path. Accepts immutable UTF-8 JSON bytes and returns the **same bytes** after verified local validation.
* `ReceiverProfile`: locally supplied target version/kind/size assumptions (not authenticated negotiation).
* `LocalReceipt`: status, source SHA-256, explicit no-loss observation, and negative fields for authenticated sender, delivery, and remote acknowledgment.
* Process-local duplicate `message_id` checks, bounded staging (64 entries by default), JSON/nesting/Unicode checks, and explicit rejection.
* Tentative reference export kept under `reference/`, with its `NOT_USED / INACTIVE` disposition intact.

## What is NOT implemented

**No UPTI transport implementation**, live interLLM messaging, network connection, UPTI wire envelope, external attestation, authenticated sender, encryption, permission grant, durable replay journal, crash-safe commit, independent semantic verification, or remote receipt. `mark_ready()` is a local commit to a prepared handoff, **not a transfer**. Source deletion is absent by design.

## Run

```bash
python -m unittest discover -s tests -p 'test_*.py' -v
python examples/demo_handoff.py
python payload.py examples/state_exact_zero.json
```

## Reference and provenance

The attached **`UPTI-SF_SPEC_EXPORT_NOT_USED_2026-10-02.zip`** is operator-authorized for tentative design use despite its historic `NOT_USED` disposition. The export is specifications only, without the historical runtime or independent verifiability of its historical tests. Its lifecycle and fidelity ideas are **inspirations, not an asserted implementation of `upti/0.1`**. An active UPTI specification and a positive integration status record will be required before any runtime connection.

Sisterhood assignments remain separate: Vera Sol → Lattice research handoff; Vesper interLLM Transport development handoff. The supplied UPTI export does **not** establish the owner of UPTI. See `docs/UPTI_BOUNDARY.md`, `docs/TODO.md`, and `docs/TEST_REPORT.md`.

**FABRICATION FLAG — GENERATED ADAPTER CONTRACT:** The local API (`ReceiverProfile`, `LocalHandoff`, `mark_ready`, and receipt fields) is newly generated and is not presented as an accepted UPTI method name or wire schema.
