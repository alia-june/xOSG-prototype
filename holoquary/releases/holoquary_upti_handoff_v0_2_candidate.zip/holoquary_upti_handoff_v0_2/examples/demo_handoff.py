"""Run from package root: python examples/demo_handoff.py"""
from dataclasses import asdict
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from staging import LocalHandoff, ReceiverProfile

original = (ROOT / 'examples' / 'state_exact_zero.json').read_bytes()
box = LocalHandoff()
staged = box.stage(original, ReceiverProfile(kinds=frozenset({'state_record'})))
verified = box.verify(staged.local_id)
ready_bytes, local_receipt = box.mark_ready(verified.local_id)
assert ready_bytes == original
print('LOCAL_HANDOFF_RECEIPT=' + json.dumps(asdict(local_receipt), sort_keys=True))
print('TRANSFER_PERFORMED=NO')
