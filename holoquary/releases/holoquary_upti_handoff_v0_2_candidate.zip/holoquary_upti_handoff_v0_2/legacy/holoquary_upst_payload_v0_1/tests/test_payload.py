import copy
import hashlib
import json
import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import payload


class LocalProtocolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.samples = {x.stem: payload.parse_packet(x.read_bytes()) for x in sorted((ROOT/'examples').glob('*.json'))}

    def test_golden_vectors(self):
        self.assertEqual(len(self.samples), 5)
        for sample in self.samples.values():
            b = payload.canonical_bytes(sample)
            self.assertEqual(payload.parse_packet(b), sample)
            self.assertEqual(hashlib.sha256(b).hexdigest(), payload.local_sha256(sample))
            self.assertEqual(len(b), len(payload.canonical_bytes(sample)))

    def rejects(self, obj):
        with self.assertRaises(payload.PacketError):
            payload.validate_packet(obj)

    def test_exact_zero_not_absent(self):
        p = copy.deepcopy(self.samples['state_exact_zero'])
        self.assertEqual(p['body']['data']['number'], 0)
        self.assertEqual(p['body']['knowledge']['possibilities'], 2)
        p['body']['data']['kind'] = 'ABSENT';p['body']['data']['number'] = None
        self.rejects(p)

    def test_kleene_unknown_is_exact(self):
        p = copy.deepcopy(self.samples['state_kleene_unknown'])
        self.assertEqual(p['body']['data']['logic'], 'UNKNOWN')
        self.assertEqual(p['body']['knowledge']['possibilities'], 4)
        p['body']['data'] = {'kind':'NUMBER','number':0,'logic':None}
        self.rejects(p)

    def test_grade_is_opaque_and_does_not_change_mask(self):
        original = self.samples['state_partial']
        for grade in (0,1,2,3):
            p = copy.deepcopy(original)
            p['body']['knowledge']['unknown_grade'] = grade
            payload.validate_packet(p)
            self.assertEqual(p['body']['knowledge']['possibilities'], 5)
        p['body']['knowledge']['unknown_grade'] = 4
        self.rejects(p)

    def test_exhaustive_balanced3_masks(self):
        for m in range(8):
            for grade in range(4):
                p = copy.deepcopy(self.samples['state_partial'])
                p['body']['knowledge']={'possibilities':m,'unknown_grade':grade}
                if m in (1,2,4):
                    p['body']['data']={'kind':'NUMBER','number':(-1,0,1)[(m.bit_length()-1)],'logic':None}
                elif m == 0:
                    p['body']['data']={'kind':'ABSENT','number':None,'logic':None}
                if grade and (m==0 or m in (1,2,4)):
                    self.rejects(p)
                else:
                    payload.validate_packet(p)

    def test_error_propagation_is_not_failure(self):
        p = copy.deepcopy(self.samples['state_partial'])
        p['body']['knowledge']={'possibilities':7,'unknown_grade':0}
        p['body']['execution']['marker'] = 'LEGACY_E_MARKER'
        payload.validate_packet(p)
        p['body']['execution']={'state':'FAILED','error_code':3,'marker':'LEGACY_E_MARKER'}
        self.rejects(p)
        p['body']['execution']['marker']='NONE'
        payload.validate_packet(p)
        p['body']['data']={'kind':'NUMBER','number':0,'logic':None}
        self.rejects(p)

    def test_radix9_semantics_unresolved(self):
        p = copy.deepcopy(self.samples['radix9_design_target'])
        p['body']['semantics_status'] = 'ACCEPTED'
        self.rejects(p)
        p = copy.deepcopy(self.samples['radix9_design_target'])
        p['body']['structure']['blocks']=[-1,0,2]
        self.rejects(p)

    def test_unsupported_or_malformed(self):
        p = copy.deepcopy(self.samples['state_partial'])
        for field,bad in [('version',2),('kind','executable'),('claim_class','GRANT')]:
            q=copy.deepcopy(p);q[field]=bad;self.rejects(q)
        q=copy.deepcopy(p);q['extensions']['upst:sender_authority']='yes'
        # Even well-formed extension data is inert: no authorization from it.
        payload.validate_packet(q)
        q=copy.deepcopy(p);q['extensions']['bad_name']='x';self.rejects(q)
        q=copy.deepcopy(p);q['body']['knowledge']['possibilities']=True;self.rejects(q)
        q=copy.deepcopy(p);q['body']['domain']=[];self.rejects(q)
        q=copy.deepcopy(p);q['body']['data']['logic']=[];self.rejects(q)
        q=copy.deepcopy(p);q['body']['knowledge']['possibilities']=8;self.rejects(q)
        q=copy.deepcopy(p);q['body']['execution']['error_code']=1;self.rejects(q)

    def test_json_hardening(self):
        with self.assertRaises(payload.PacketError):
            payload.parse_packet(b'{"a":1,"a":2}')
        with self.assertRaises(payload.PacketError):
            payload.parse_packet(b'{"bad":NaN}')
        with self.assertRaises(payload.PacketError):
            payload.parse_packet(b'\xff')
        with self.assertRaises(payload.PacketError):
            payload.parse_packet(b' '*65537)
        with self.assertRaises(payload.PacketError):
            payload.parse_packet(b'[]')
        with self.assertRaises(payload.PacketError):
            payload.parse_packet(b'{')
        p = copy.deepcopy(self.samples['state_partial']);p['extensions']={'x:huge':'X'*70000}
        with self.assertRaises(payload.PacketError):
            payload.canonical_bytes(p)

    def test_artifact_ref_not_material(self):
        ref = self.samples['artifact_reference']['body']
        self.assertTrue(len(ref['sha256'])==64)
        p = copy.deepcopy(self.samples['artifact_reference'])
        p['body']['filename']='../../other-file'
        self.rejects(p)


if __name__ == '__main__':
    unittest.main(verbosity=2)
