# Holoquary ↔ UPST application payload contract v0.1 (candidate)

**Purpose:** Give Holoquary a small, transport-independent, non-executable JSON packet format. UPST (under design) can treat each packet as opaque application bytes; there is **no presumed UPST API or delivery mechanism** here.

**Origin:** Operator requests flexibility, separate computational/epistemic/execution/provenance layers, simple contract fulfillment rather than creating another transport. Companion evidence: Holoquary v1.2 and the attached Vera Sol → Lattice research-engine handoff v0.2.0.

## Minimal interface

1. Producer forms a `holoquary.application-payload` version 1 JSON object with a stable caller-assigned `message_id`, a `kind`, an epistemic `claim_class`, advisory producer/consumer hints, `body`, and optional *namespaced* extensions.
2. Validate locally, then serialize to UTF-8 canonical JSON (`sort_keys=True`, compact separators, non-ASCII preserved) with a 64 KiB local limit.
3. Hand bytes to a future UPST adapter. **UPST owns** addressing/authentication, transport, retransmission, expiry, delivery receipts, and deduplication according to its eventual accepted contract. We do not claim these functions are presently implemented.
4. Receiving application first relies on UPST's actual validation result (when available), then validates the Holoquary payload *separately* and dispatches only recognized versions and kinds. Parsing does not imply acceptance of claims, code execution, logic-rule admission, permission grants, or canon changes.

`python payload.py examples/state_exact_zero.json` validates locally; it never transmits anything. See `docs/CONTRACT.md`, `docs/HANDOFF_MAP.md`, and `docs/TODO.md`.

## Supported body kinds, v0.1

- `state_record`: normalized Holoquary v1.2 `HQDRecord` with **data**, **knowledge**, **execution**, **provenance** separate. Only currently implemented numerical domains BALANCED3, PURE5, BALANCED7, and logical KLEENE3 are accepted.
- `design_target`: bounded descriptive target, including the authoritative radix-nine 3×3 topology with **unresolved meanings**; this cannot trigger code changes.
- `artifact_reference`: basename, SHA-256 and byte count for a file to be separately transferred or resolved; a hash verifies bytes, **not the identity or authority of the sender**.

**NOT IMPLEMENTED:** UPST adapter, network transport, cryptographic identity, authorization, live three-Sister delivery, body-level semantic acceptance, or Holoquary C encoding/decoding. This package defines and tests the *application payload* only.

**Design provenance:** m.A.R.S. supplied the requirement and architecture. This packaging and the exact JSON fields are assistant-generated proposals, not a canonical transport standard.
