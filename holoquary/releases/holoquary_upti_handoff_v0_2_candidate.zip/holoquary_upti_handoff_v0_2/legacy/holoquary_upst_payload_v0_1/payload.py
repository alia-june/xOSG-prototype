"""Holoquary v1.2 -> opaque UPST application payload, candidate v0.1.
This is ONLY a local shape/invariant validator. No network, authentication,
authorization, routing, transport, receipts or remotely supplied code execution.
"""
import hashlib
import json
from pathlib import Path

MAX_BYTES = 65536
KINDS = {"state_record", "design_target", "artifact_reference"}
CLAIMS = {"OBSERVATION", "INFERENCE", "PROPOSAL", "DECISION", "HYPOTHESIS", "UNKNOWN"}
DOMAINS = {"BALANCED3": (-1, 1), "PURE5": (0, 4), "BALANCED7": (-3, 3), "KLEENE3": (0, 2)}
LOGIC = {"FALSE": 0, "TRUE": 1, "UNKNOWN": 2}  # matches HQTruth in v1.2


class PacketError(ValueError):
    pass


def require(condition, reason):
    if not condition:
        raise PacketError(reason)


def keys(obj, names, context):
    require(type(obj) is dict and set(obj) == set(names), f"{context}: keys mismatch")


def nonblank(value, context, max_chars=160):
    require(type(value) is str and 0 < len(value) <= max_chars and value.strip() == value and value,
            f"{context}: invalid string")


def integer(value, lo, hi, context):
    require(type(value) is int and lo <= value <= hi, f"{context}: out of range")


def validate_record(rec):
    keys(rec, ["domain", "data", "knowledge", "execution", "provenance"], "record")
    d = rec["domain"]
    require(type(d) is str and d in DOMAINS, "invalid domain")
    lo, hi = DOMAINS[d]
    all_mask = (1 << (hi - lo + 1)) - 1
    data, knowledge, execution, provenance = (rec[x] for x in ("data", "knowledge", "execution", "provenance"))
    keys(data, ["kind", "number", "logic"], "data")
    keys(knowledge, ["possibilities", "unknown_grade"], "knowledge")
    keys(execution, ["state", "error_code", "marker"], "execution")
    keys(provenance, ["source_id", "scope_id", "generation", "origin"], "provenance")
    kind = data["kind"]
    require(type(kind) is str and kind in ("ABSENT", "NUMBER", "LOGIC"), "invalid data kind")
    mask, grade = knowledge["possibilities"], knowledge["unknown_grade"]
    integer(mask, 0, all_mask, "possibilities")
    integer(grade, 0, 3, "unknown_grade")
    state, error, marker = (execution[x] for x in ("state", "error_code", "marker"))
    require(type(state) is str and state in ("COMPLETE", "FAILED", "COMPLETION_UNKNOWN"), "invalid execution state")
    integer(error, 0, 0xffffffff, "error_code")
    require((state == "FAILED") == (error != 0), "error_code must be nonzero iff FAILED")
    require(type(marker) is str and marker in ("NONE", "LEGACY_E_MARKER"), "invalid marker")
    require(state == "COMPLETE" or marker == "NONE", "marker not valid on failed/incomplete execution")
    for field in ("source_id", "scope_id", "generation"):
        integer(provenance[field], 0, 0xffffffff, field)
    require(type(provenance["origin"]) is str and provenance["origin"] in ("UNATTESTED", "CALLER", "DERIVED"), "invalid origin")
    singleton = mask != 0 and (mask & (mask - 1)) == 0
    if kind == "ABSENT":
        require(data["number"] is None and data["logic"] is None, "ABSENT has payload")
        require(not singleton, "singleton must have exact data")
    elif kind == "NUMBER":
        require(d != "KLEENE3", "logical domain is not numerical")
        integer(data["number"], lo, hi, "number")
        require(data["logic"] is None, "number has logical payload")
        require(state == "COMPLETE" and marker == "NONE" and grade == 0, "exact number metadata mismatch")
        require(mask == (1 << (data["number"] - lo)), "number/possibilities mismatch")
    else:
        require(d == "KLEENE3" and data["number"] is None and type(data["logic"]) is str and data["logic"] in LOGIC,
                "invalid logical payload")
        require(state == "COMPLETE" and marker == "NONE" and grade == 0, "exact logic metadata mismatch")
        require(mask == (1 << LOGIC[data["logic"]]), "logic/possibilities mismatch")
    require(not singleton or grade == 0, "singleton cannot have U-grade")
    require(mask != 0 or grade == 0, "contradiction cannot have U-grade")
    if marker == "LEGACY_E_MARKER":
        require(kind == "ABSENT" and mask == all_mask and grade == 0,
                "propagated E marker is not a numerical result")


def validate_design(body):
    keys(body, ["target", "structure", "semantics_status", "notes"], "design_target")
    nonblank(body["target"], "target")
    require(type(body["semantics_status"]) is str and body["semantics_status"] in ("UNRESOLVED", "PROPOSED", "ACCEPTED"),
            "invalid design status")
    require(type(body["structure"]) is dict, "structure must be an object")
    require(type(body["notes"]) is list and len(body["notes"]) <= 16, "invalid notes")
    for note in body["notes"]: nonblank(note, "note", 2048)
    # No semantic inference from an arbitrary structural JSON body.
    if body["target"] == "RADIX9_3X3":
        s = body["structure"]
        keys(s, ["blocks", "states_per_block"], "radix9 structure")
        require(s["blocks"] == [-1, 0, 1] and s["states_per_block"] == [-1, 0, 1],
                "radix9 topology violates handoff")
        require(body["semantics_status"] == "UNRESOLVED", "radix9 semantics not approved by handoff")


def validate_artifact(body):
    keys(body, ["filename", "sha256", "bytes", "purpose"], "artifact_reference")
    nonblank(body["filename"], "filename", 200)
    require('/' not in body["filename"] and '\\' not in body["filename"] and
            body["filename"] not in ('.', '..'), "filename must be basename only")
    digest = body["sha256"]
    require(type(digest) is str and len(digest) == 64 and all(c in '0123456789abcdef' for c in digest),
            "invalid sha256")
    integer(body["bytes"], 0, 0xffffffff, "bytes")
    nonblank(body["purpose"], "purpose", 2048)


def validate_packet(packet):
    keys(packet, ["contract", "version", "message_id", "kind", "claim_class", "producer_hint",
                  "consumer_hint", "body", "extensions"], "packet")
    require(packet["contract"] == "holoquary.application-payload", "wrong contract")
    require(type(packet["version"]) is int and packet["version"] == 1, "unsupported version")
    for field in ("message_id", "producer_hint", "consumer_hint"):
        nonblank(packet[field], field)
    require(type(packet["kind"]) is str and packet["kind"] in KINDS, "unsupported kind")
    require(type(packet["claim_class"]) is str and packet["claim_class"] in CLAIMS, "unsupported claim class")
    require(type(packet["extensions"]) is dict and len(packet["extensions"]) <= 16,
            "invalid extensions")
    for k in packet["extensions"]:
        nonblank(k, "extension key")
        require(':' in k and len(k) < 130, "extension keys must be namespaced")
    if packet["kind"] == "state_record":
        validate_record(packet["body"])
    elif packet["kind"] == "design_target":
        validate_design(packet["body"])
    else:
        validate_artifact(packet["body"])
    return packet


def canonical_bytes(packet):
    validate_packet(packet)
    encoded = json.dumps(packet, ensure_ascii=False, sort_keys=True, separators=(',', ':'),
                         allow_nan=False).encode('utf-8')
    require(len(encoded) <= MAX_BYTES, "packet exceeds 64KiB local profile")
    return encoded


def local_sha256(packet):
    """Accidental-change identifier, NOT message authentication."""
    return hashlib.sha256(canonical_bytes(packet)).hexdigest()


def _no_duplicates(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, f"duplicate JSON field: {key}")
        out[key] = value
    return out


def _no_constant(value):
    raise PacketError(f"nonstandard numeric constant {value}")


def parse_packet(blob):
    require(type(blob) is bytes and len(blob) <= MAX_BYTES, "bytes or size invalid")
    try:
        packet = json.loads(blob.decode('utf-8'), object_pairs_hook=_no_duplicates,
                            parse_constant=_no_constant)
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise PacketError('invalid UTF-8 or JSON') from exc
    validate_packet(packet)
    return packet


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Local payload validation only; no UPST integration')
    parser.add_argument('json_path', type=Path)
    args = parser.parse_args()
    payload = parse_packet(args.json_path.read_bytes())
    print('VALID kind=' + payload['kind'] + ' canonical_sha256=' + local_sha256(payload))
