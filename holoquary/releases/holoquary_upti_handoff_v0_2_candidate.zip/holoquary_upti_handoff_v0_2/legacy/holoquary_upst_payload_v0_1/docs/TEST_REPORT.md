# Holoquary ↔ UPST application payload v0.1 — local test record

**Scope:** Standalone Python 3 standard-library validator and JSON payload samples. Not live UPST/interLLM Transport integration, sender authentication, end-to-end transfer, cryptographic signature verification or C99 runtime serialization.

**Positive:** exact BALANCED3 numerical zero and partial BALANCED3 masks; exact KLEENE3 logical UNKNOWN; design target RADIX9_3X3 with explicitly unresolved semantics; hash-bearing artifact reference. Local canonical UTF-8 serialization and sample round-trip.

**Negative:** zero vs absent mismatch, singleton-vs-grade mismatch, failed-vs-propagated-E confusion, inconsistent error codes, forged radix-nine semantics acceptance, unsupported versions, unknown body kinds, out-of-range possibility masks, bool-as-int, malformed or duplicate-key JSON, NaN, invalid UTF-8, >64KiB packets and artifact filename path traversal.

**Truth boundary:** Validation assures the *specified JSON form and selected local invariants*, not the truth of field contents, claim identity, source independence, transfer security, actual artifact existence at destination, logical acceptance, or completeness of tests. Application-level hashes identify bytes only; UPST must separately define any trusted sender/delivery evidence. `claim_class=DECISION` grants no action authority.

**Follow-on:** Actually integrate with the accepted UPST contract and add C99 codec, cross-language golden vectors and adversarial protocol fuzzing. Neither is covered by these tests.
