# UPST-facing application contract TODO (not the UPST project roadmap)

- [x] Preserve separate computation/knowledge/execution/provenance lanes from Holoquary v1.2.
- [x] Define small versioned JSON payload types, canonical local serialization, strict local validation and sample packets.
- [x] Preserve the Vera → Lattice radix-nine 3×3 structure and its unresolved semantics.
- [x] Identify Vesper's known interLLM Transport handoff without claiming unsupported UPST project ownership.
- [ ] Receive the **actual accepted UPST transport/attachment specification**, name its explicit implementer, map sender identity, message IDs, size limits, supported cryptographic/receipt contracts.
- [ ] Write adapter only against that accepted API; do not implement a competing router/transporter in Holoquary.
- [ ] Add C99 encoder/decoder for existing `HQDRecord` only after a memory/limits contract is selected; current Python validator is a protocol-reference aid, not proof of C integration.
- [ ] Add parser cross-language golden vectors, property-based mutation, fuzzing, maximum-size/UTF-8 tests and hostile-input isolation.
- [ ] Provide a provenance-preserving evidence graph, immutable data lineage, symbol correlation and independent attestation for consequential state changes.
- [ ] Define approved U1/U2/U3 epistemic semantics; keep current labels opaque.
- [ ] Formalize NINE/15 *only when separately accepted*; do not collapse source structure to a numeric scalar by default.
- [ ] Keep recursion deferred until nonrecursive interfaces and evidence contracts are accepted.
