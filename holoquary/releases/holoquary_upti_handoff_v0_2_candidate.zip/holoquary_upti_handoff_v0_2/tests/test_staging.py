"""Local UPTI-facing application handoff tests; NOT live transport conformance."""
import copy
import hashlib
import json
import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import payload
import staging


class LocalStagingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw_examples = {p.stem: p.read_bytes() for p in (ROOT / 'examples').glob('*.json')}

    def new_raw(self, which='state_exact_zero', message_id=None, **changes):
        p = payload.parse_packet(self.raw_examples[which])
        p = copy.deepcopy(p)
        if message_id is not None:
            p['message_id'] = message_id
        p.update(changes)
        return payload.canonical_bytes(p)

    def test_roundtrip_exact_bytes_no_rewrite(self):
        for i, (name, raw) in enumerate(sorted(self.raw_examples.items())):
            s = staging.LocalHandoff()
            stage = s.stage(raw)
            self.assertEqual(stage.raw_sha256, hashlib.sha256(raw).hexdigest())
            self.assertEqual(stage.length, len(raw))
            self.assertEqual(stage.state, 'STAGED')
            self.assertEqual(s.report(stage.local_id).local_validation, 'PASS')
            self.assertEqual(s.report(stage.local_id).local_verification, 'NOT_VERIFIED')
            self.assertEqual(s.verify(stage.local_id).state, 'VERIFIED')
            data, receipt = s.mark_ready(stage.local_id)
            self.assertEqual(data, raw)  # includes original whitespace / key order
            self.assertEqual(receipt.raw_sha256, hashlib.sha256(raw).hexdigest())
            self.assertEqual(receipt.final_state, 'READY_FOR_UPTI_HANDOFF')
            self.assertEqual(receipt.local_verification, 'PASS_AT_LOCAL_COMMIT')
            self.assertEqual(receipt.reported_losses, ())
            self.assertEqual(receipt.omitted_fields, ())
            self.assertEqual(receipt.changed_fields, ())
            self.assertFalse(receipt.bytes_changed)
            self.assertTrue(receipt.source_preserved)
            self.assertFalse(receipt.sender_authenticated)
            self.assertFalse(receipt.delivered)
            self.assertFalse(receipt.receiver_acknowledged)

    def test_staged_means_not_yet_verified(self):
        s = staging.LocalHandoff()
        h = s.stage(self.new_raw())
        with self.assertRaises(staging.HandoffError):s.mark_ready(h.local_id)
        self.assertEqual(s.report(h.local_id).final_state,'STAGED')

    def test_duplicate_identifiers_rejected_even_if_different_body(self):
        s = staging.LocalHandoff()
        raw = self.new_raw(message_id='stable-1')
        s.stage(raw)
        with self.assertRaises(staging.HandoffError): s.stage(raw)
        p = payload.parse_packet(raw)
        p['body']['data']={'kind':'NUMBER','number':1,'logic':None}
        p['body']['knowledge']={'possibilities':4,'unknown_grade':0}
        with self.assertRaises(staging.HandoffError): s.stage(payload.canonical_bytes(p))

    def test_duplicate_reservation_retained_after_reject(self):
        s = staging.LocalHandoff()
        h = s.stage(self.new_raw())
        receipt=s.reject(h.local_id,'operator rejected')
        self.assertEqual(receipt.final_state,'REJECTED')
        self.assertEqual(receipt.local_verification,'NOT_VERIFIED')
        self.assertTrue(receipt.source_preserved)
        with self.assertRaises(staging.HandoffError):s.stage(self.new_raw())
        with self.assertRaises(staging.HandoffError):s.verify(h.local_id)
        with self.assertRaises(staging.HandoffError):s.mark_ready(h.local_id)

    def test_explicit_reject_after_verification(self):
        s = staging.LocalHandoff()
        h = s.stage(self.new_raw())
        s.verify(h.local_id)
        result=s.reject(h.local_id,'fidelity review refused')
        self.assertEqual(result.final_state,'REJECTED')
        self.assertEqual(result.local_verification,'PASS_BEFORE_REJECTION')
        self.assertFalse(result.delivered)

    def test_capability_negotiation_kind(self):
        s=staging.LocalHandoff()
        profile=staging.ReceiverProfile(kinds=frozenset({'state_record'}))
        s.stage(self.new_raw(),profile)
        with self.assertRaises(staging.HandoffError):
            s.stage(self.new_raw('radix9_design_target'),profile)

    def test_capability_negotiation_version(self):
        with self.assertRaises(staging.HandoffError):
            staging.LocalHandoff().stage(self.new_raw(),staging.ReceiverProfile(versions=frozenset({2})))
        with self.assertRaises(staging.HandoffError):
            staging.LocalHandoff().stage(self.new_raw(),staging.ReceiverProfile(versions=frozenset({True})))

    def test_capability_size(self):
        raw=self.new_raw()
        with self.assertRaises(staging.HandoffError):
            staging.LocalHandoff().stage(raw,staging.ReceiverProfile(max_bytes=len(raw)-1))
        staging.LocalHandoff().stage(raw,staging.ReceiverProfile(max_bytes=len(raw)))

    def test_invalid_capability_profile(self):
        malformed=[
            staging.ReceiverProfile(require_byte_exact=False),
            staging.ReceiverProfile(max_bytes=True),
            staging.ReceiverProfile(max_bytes=payload.MAX_BYTES+1),
            staging.ReceiverProfile(versions=frozenset()),
            staging.ReceiverProfile(kinds=frozenset()),
        ]
        for cap in malformed:
            with self.subTest(cap=cap):
                with self.assertRaises(staging.HandoffError):
                    staging.LocalHandoff().stage(self.new_raw(),cap)
        with self.assertRaises(staging.HandoffError):
            staging.LocalHandoff().stage(self.new_raw(),None)

    def test_no_mutable_payload(self):
        raw=self.new_raw()
        mutable=bytearray(raw)
        with self.assertRaises(staging.HandoffError):
            staging.LocalHandoff().stage(mutable)
        s=staging.LocalHandoff()
        h=s.stage(bytes(mutable))
        mutable[0] ^= 1
        s.verify(h.local_id)
        data,_=s.mark_ready(h.local_id)
        self.assertEqual(data,raw)

    def test_claim_and_hints_are_not_authority(self):
        p=payload.parse_packet(self.new_raw())
        p['claim_class']='DECISION'
        p['producer_hint']='Admin'
        p['consumer_hint']='System'
        p['extensions']['candidate:sender_authenticated']=True
        s=staging.LocalHandoff()
        h=s.stage(payload.canonical_bytes(p))
        s.verify(h.local_id)
        _, receipt=s.mark_ready(h.local_id)
        self.assertFalse(receipt.sender_authenticated)
        self.assertFalse(receipt.delivered)

    def test_invalid_new_semantics_refused(self):
        p=payload.parse_packet(self.new_raw('radix9_design_target'))
        p['body']['semantics_status']='ACCEPTED'
        with self.assertRaises(staging.HandoffError):
            staging.LocalHandoff().stage(json.dumps(p).encode())

    def test_invalid_state_refused(self):
        p=payload.parse_packet(self.new_raw())
        p['body']['data']={'kind':'NUMBER','number':None,'logic':None}
        with self.assertRaises(staging.HandoffError):
            staging.LocalHandoff().stage(json.dumps(p).encode())

    def test_modified_after_verification_rejected(self):
        s=staging.LocalHandoff()
        h=s.stage(self.new_raw())
        s.verify(h.local_id)
        # Simulate corruption of process-local private state; not an adversarial model.
        s._entries[h.local_id].raw=b'broken'
        with self.assertRaises(staging.HandoffError):s.mark_ready(h.local_id)
        self.assertEqual(s.report(h.local_id).final_state,'REJECTED')

    def test_modified_before_verification_rejected(self):
        s=staging.LocalHandoff()
        h=s.stage(self.new_raw())
        s._entries[h.local_id].raw=b'broken'
        with self.assertRaises(staging.HandoffError):s.verify(h.local_id)
        self.assertEqual(s.report(h.local_id).final_state,'REJECTED')

    def test_packet_changed_same_digest_metadata_reject(self):
        s=staging.LocalHandoff()
        h=s.stage(self.new_raw())
        s._entries[h.local_id].packet['claim_class']='HYPOTHESIS'
        with self.assertRaises(staging.HandoffError):s.verify(h.local_id)

    def test_bound_capacity(self):
        s=staging.LocalHandoff(max_entries=2)
        s.stage(self.new_raw(message_id='one'))
        s.stage(self.new_raw(message_id='two'))
        with self.assertRaises(staging.HandoffError):s.stage(self.new_raw(message_id='three'))
        for bad in (0,-1,4097,True,'10'):
            with self.assertRaises(staging.HandoffError):staging.LocalHandoff(max_entries=bad)

    def test_invalid_json_and_oversize(self):
        s=staging.LocalHandoff()
        for bad in (b'{',b'\xff',b'{"x":1,"x":2}',b'{"bad":Infinity}',b' '*65537):
            with self.subTest(bad=bad[:20]):
                with self.assertRaises(staging.HandoffError):s.stage(bad)

    def test_errors_are_not_executed(self):
        s=staging.LocalHandoff()
        with self.assertRaises(staging.HandoffError):s.mark_ready('absent-id')
        with self.assertRaises(staging.HandoffError):s.verify('absent-id')
        with self.assertRaises(staging.HandoffError):s.reject('absent-id','reason')
        h=s.stage(self.new_raw())
        for bad in ('', ' '*3, None, 1, 'x'*513):
            with self.assertRaises(staging.HandoffError):s.reject(h.local_id,bad)

    def test_receipt_read_only_and_no_remote_claims(self):
        s=staging.LocalHandoff()
        h=s.stage(self.new_raw())
        s.verify(h.local_id)
        _,receipt=s.mark_ready(h.local_id)
        with self.assertRaises((AttributeError,TypeError)):
            receipt.delivered=True
        with self.assertRaises(staging.HandoffError):s.mark_ready(h.local_id)
        with self.assertRaises(staging.HandoffError):s.reject(h.local_id,'reason')

    def test_local_replay_only(self):
        raw=self.new_raw()
        a=staging.LocalHandoff()
        b=staging.LocalHandoff()
        a.stage(raw)
        # A different fresh process-local store cannot know this message was seen.
        b.stage(raw)

    def test_wide_inputs_inside_limit(self):
        p=payload.parse_packet(self.new_raw('state_partial'))
        p['extensions']['candidate:opaque']='a'*25000
        raw=payload.canonical_bytes(p)
        s=staging.LocalHandoff()
        h=s.stage(raw)
        s.verify(h.local_id)
        self.assertEqual(s.mark_ready(h.local_id)[0],raw)


if __name__=='__main__':
    unittest.main(verbosity=2)

class AdditionalHardeningTests(unittest.TestCase):
    def test_deep_structure_fails_cleanly(self):
        import staging
        from pathlib import Path
        root=Path(__file__).resolve().parent.parent
        p=payload.parse_packet((root/'examples'/'state_exact_zero.json').read_bytes())
        # JSON depth beyond Python parsing limit but below 64 KiB.
        base=payload.canonical_bytes(p)
        bad=base.replace(b'"extensions":{}', b'"extensions":{"candidate:deep":'+b'['*1300+b'0'+b']'*1300+b'}')
        with self.assertRaises(staging.HandoffError):staging.LocalHandoff().stage(bad)

    def test_invalid_surrogate_fails_cleanly(self):
        import staging
        from pathlib import Path
        root=Path(__file__).resolve().parent.parent
        raw=(root/'examples'/'state_exact_zero.json').read_bytes()
        valid=payload.parse_packet(raw)
        valid['extensions']={'candidate:text':'bad'+chr(0xd800)}
        # JSON escape is syntactically valid; Unicode scalar value is not.
        bad=json.dumps(valid,ensure_ascii=True).encode('utf8')
        with self.assertRaises(staging.HandoffError):staging.LocalHandoff().stage(bad)
