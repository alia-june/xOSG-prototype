"""Provisional LOCAL Holoquary payload staging for future UPTI transfer.

No UPTI wire protocol, network, independent verification, access control,
persistent replay defense, remote receipt or external effects are implemented.
The original, validated UTF-8 JSON bytes are kept byte-for-byte unchanged.
"""
from dataclasses import dataclass
from hashlib import sha256
from typing import FrozenSet
import payload


class HandoffError(ValueError):
    """Local handoff cannot be prepared; not a transport delivery error."""


@dataclass(frozen=True)
class ReceiverProfile:
    """Locally supplied capability assumptions, not authenticated peer claims."""
    versions: FrozenSet[int] = frozenset({1})
    kinds: FrozenSet[str] = frozenset(payload.KINDS)
    max_bytes: int = payload.MAX_BYTES
    require_byte_exact: bool = True


@dataclass(frozen=True)
class StageInfo:
    local_id: str
    message_id: str
    kind: str
    raw_sha256: str
    length: int
    state: str


@dataclass(frozen=True)
class LocalReceipt:
    local_id: str
    message_id: str
    kind: str
    raw_sha256: str
    source_preserved: bool
    bytes_changed: bool
    omitted_fields: tuple
    changed_fields: tuple
    reported_losses: tuple
    local_validation: str
    local_verification: str
    final_state: str
    sender_authenticated: bool
    delivered: bool
    receiver_acknowledged: bool
    note: str


@dataclass
class _Candidate:
    raw: bytes
    packet: dict
    profile: ReceiverProfile
    source_sha256: str
    local_id: str
    state: str
    note: str
    verified_once: bool = False


class LocalHandoff:
    """Bounded, process-local stage->verify->mark-ready implementation.

    None of these calls establishes the identity or authority of the sender.
    No actual endpoint is invoked. Local IDs and receipts are non-cryptographic.
    """
    def __init__(self, max_entries: int = 64):
        if type(max_entries) is not int or not (1 <= max_entries <= 4096):
            raise HandoffError('invalid local capacity')
        self._limit = max_entries
        self._entries = {}
        self._message_ids = set()
        self._counter = 0

    @staticmethod
    def _parse_hardened(raw: bytes) -> dict:
        try:
            packet = payload.parse_packet(raw)
            # An opaque extension may still contain hostile nesting. Enforce
            # bounded structural depth and node count without executing it.
            stack = [(packet, 0)]
            nodes = 0
            while stack:
                node, depth = stack.pop()
                nodes += 1
                if nodes > 8192 or depth > 64:
                    raise HandoffError('payload nesting/node budget exceeded')
                if type(node) is dict:
                    stack.extend((k, depth + 1) for k in node.keys())
                    stack.extend((v, depth + 1) for v in node.values())
                elif type(node) is list:
                    stack.extend((v, depth + 1) for v in node)
            payload.canonical_bytes(packet)  # check Unicode/finite canonical representation; DO NOT transmit it
            return packet
        except (payload.PacketError, HandoffError, UnicodeError, RecursionError,
                OverflowError, TypeError, ValueError) as exc:
            raise HandoffError(f'application validation rejected: {exc}') from exc

    @staticmethod
    def _check_profile(profile: ReceiverProfile, packet: dict, raw: bytes) -> None:
        if type(profile) is not ReceiverProfile:
            raise HandoffError('invalid local capability profile')
        if (type(profile.max_bytes) is not int or not (0 < profile.max_bytes <= payload.MAX_BYTES)
                or type(profile.require_byte_exact) is not bool or not profile.require_byte_exact):
            raise HandoffError('unsupported local capability profile')
        if (type(profile.versions) is not frozenset or not profile.versions
                or any(type(x) is not int for x in profile.versions)
                or type(profile.kinds) is not frozenset or not profile.kinds
                or any(type(x) is not str for x in profile.kinds)):
            raise HandoffError('invalid capability declarations')
        if packet['version'] not in profile.versions:
            raise HandoffError('unsupported application payload version')
        if packet['kind'] not in profile.kinds:
            raise HandoffError('unsupported payload class')
        if len(raw) > profile.max_bytes:
            raise HandoffError('receiver size cap exceeded')

    def stage(self, raw: bytes, profile: ReceiverProfile = ReceiverProfile()) -> StageInfo:
        if type(raw) is not bytes:
            raise HandoffError('immutable bytes required; explicitly copy mutable sources')
        if len(self._entries) >= self._limit:
            raise HandoffError('local staging capacity exhausted')
        packet = self._parse_hardened(raw)
        self._check_profile(profile, packet, raw)
        mid = packet['message_id']
        if mid in self._message_ids:
            raise HandoffError('message identifier already staged/processed this session')
        self._counter += 1
        lid = f'local-{self._counter:06d}'
        data = bytes(raw)  # raw is immutable, retained without JSON reserialization
        entry = _Candidate(data, packet, profile, sha256(data).hexdigest(), lid, 'STAGED', '')
        self._entries[lid] = entry
        self._message_ids.add(mid)
        return StageInfo(lid, mid, packet['kind'], entry.source_sha256, len(data), entry.state)

    def verify(self, local_id: str) -> StageInfo:
        entry = self._get(local_id)
        if entry.state != 'STAGED':
            raise HandoffError('cannot verify this state')
        try:
            if sha256(entry.raw).hexdigest() != entry.source_sha256:
                raise HandoffError('staged source bytes changed')
            current = self._parse_hardened(entry.raw)
            self._check_profile(entry.profile, current, entry.raw)
            if current != entry.packet:
                raise HandoffError('staged source meaning changed')
            if current['message_id'] not in self._message_ids:
                raise HandoffError('local replay reservation missing')
        except HandoffError as exc:
            entry.state = 'REJECTED'
            entry.note = str(exc)
            raise HandoffError(f'verification rejected: {exc}') from exc
        entry.state = 'VERIFIED'
        entry.verified_once = True
        return StageInfo(local_id, current['message_id'], current['kind'], entry.source_sha256,
                         len(entry.raw), entry.state)

    def mark_ready(self, local_id: str) -> tuple[bytes, LocalReceipt]:
        """Local commit only: returns opaque bytes, never delivers them."""
        entry = self._get(local_id)
        if entry.state != 'VERIFIED':
            raise HandoffError('local commit requires completed verification')
        # Recheck the locally stored source to prevent stale / changed-state commit.
        if sha256(entry.raw).hexdigest() != entry.source_sha256:
            entry.state = 'REJECTED'
            entry.note = 'source modified after verification'
            raise HandoffError(entry.note)
        try:
            current = self._parse_hardened(entry.raw)
            self._check_profile(entry.profile, current, entry.raw)
            if current != entry.packet or current['message_id'] not in self._message_ids:
                raise HandoffError('payload or replay reservation changed')
        except HandoffError as exc:
            entry.state = 'REJECTED'
            entry.note = str(exc)
            raise HandoffError(f'local commit rejected: {exc}') from exc
        entry.state = 'READY_FOR_UPTI_HANDOFF'
        return entry.raw, self._receipt(entry)

    def reject(self, local_id: str, reason: str) -> LocalReceipt:
        entry = self._get(local_id)
        if entry.state not in ('STAGED', 'VERIFIED'):
            raise HandoffError('cannot reject a terminal state')
        if type(reason) is not str or not reason.strip() or len(reason) > 512:
            raise HandoffError('rejection reason required')
        entry.state = 'REJECTED'
        entry.note = reason
        return self._receipt(entry)

    def report(self, local_id: str) -> LocalReceipt:
        return self._receipt(self._get(local_id))

    def _get(self, local_id: str) -> _Candidate:
        if type(local_id) is not str or local_id not in self._entries:
            raise HandoffError('unknown local handoff id')
        return self._entries[local_id]

    @staticmethod
    def _receipt(entry: _Candidate) -> LocalReceipt:
        ready = entry.state == 'READY_FOR_UPTI_HANDOFF'
        return LocalReceipt(
            local_id=entry.local_id,
            message_id=entry.packet['message_id'],
            kind=entry.packet['kind'],
            raw_sha256=entry.source_sha256,
            source_preserved=True,
            bytes_changed=False,
            omitted_fields=(),
            changed_fields=(),
            reported_losses=(),
            local_validation='PASS',
            local_verification=('PASS_AT_LOCAL_COMMIT' if ready else
                                'PASS' if entry.state == 'VERIFIED' else
                                'PASS_BEFORE_REJECTION' if entry.verified_once else 'NOT_VERIFIED'),
            final_state=entry.state,
            sender_authenticated=False,
            delivered=False,
            receiver_acknowledged=False,
            note=entry.note or 'Local only; no active UPTI delivery or independent attestation'
        )
