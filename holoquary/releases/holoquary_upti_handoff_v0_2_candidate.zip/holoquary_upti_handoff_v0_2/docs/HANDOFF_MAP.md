# Known Sisterhood handoff map — evidence-limited

- **Vera Sol → Lattice:** Uploaded research-engine handoff `VERA_SOL_LATTICE_RESEARCH_ENGINE_HANDOFF_v0_2_0.zip`, v0.2.0, identifies `source_identity: Vera Sol`, `target_identity: Lattice`. It requests structural and radix-nine semantic analysis; it is not a transport implementation assignment.
- **Vesper:** Prior interLLM Transport development handoff was addressed to Vesper, the Sisterhood's orchestrator. This does **not** establish that Vesper authored or owns UPST.
- **UPST:** Universal Protocol Safe Transfer is described by the operator as *being designed*. No document reviewed here assigns its design to a specific Sister or supplies an accepted UPST API/schema. Do not fill this gap by inventing ownership.
- **Holoquary:** An application producer/consumer only; it does not decide recipient authenticity or transport success.

## Integration once an actual UPST contract arrives

Map UPST's supported opaque-payload API to `canonical_bytes(packet)`, and require the corresponding accepted receive/authentication result before considering a packet's claimed author. Bind external authenticated identity to a distinct verified field outside the JSON body. Do not let `producer_hint`, packet hashes or the advisory `claim_class` stand in for that binding. Test replay, deduplication, wrong recipient, changed body, unsupported version and refusal to execute payload content.
