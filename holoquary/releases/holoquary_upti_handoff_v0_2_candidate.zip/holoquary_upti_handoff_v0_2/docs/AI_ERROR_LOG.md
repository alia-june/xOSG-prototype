# Observed assistant implementation/test errors — v0.2

## AE-UPTI-001 — Hostile extension nesting accepted without a bound

Initial v0.2 implementation validated the JSON body but did not explicitly limit nesting of otherwise opaque extension data. A test with 1,300 nested arrays **failed because the adapter accepted it**. Correction: iterative bounded depth (64) and node (8,192) checks in `_parse_hardened`, and a passing negative test. This guards resource use, not general memory safety.

## AE-UPTI-002 — Invalid Unicode test fixture was not invalid

An initial test used literal characters `\\ud800` rather than an actual surrogate code point. It therefore tested ordinary text and failed to trigger the intended rejection. Correction: generate `chr(0xd800)` in the parsed object, escape it in source JSON, and reject it when validating canonical UTF-8 representability. This was an assistant-authored test error, not evidence of Unicode conversion by UPTI.

**Neither failure has been reinterpreted as a passing historical test.** The corrected suite is recorded separately in `TEST_REPORT.md`.
