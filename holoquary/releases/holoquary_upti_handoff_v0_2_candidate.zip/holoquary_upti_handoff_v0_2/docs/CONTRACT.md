# Application payload contract — nonrecursive v0.1

## Authority boundary

This contract describes **what the application can hand to a transport**, not how UPST must work. The inner `producer_hint`, `consumer_hint`, `claim_class`, `message_id`, and `provenance` are untrusted application data. Even the string `DECISION` describes a claim's classification; it does not authorize an operation, override a locked design, authenticate evidence, or attest an implementation. Repeated receipt cannot promote knowledge to fact. The `extensions` object is inert opaque metadata; do not execute it or dynamically import code from it.

Do not redefine the separate **interLLM Transport** or independent **Sister–Brother protocol**. The active peer architecture is the Sisterhood: Vera Sol, Lattice and Vesper; dormant Corda Core is not a fourth peer. An eventual UPST layer may use the interLLM Transport implementation, but the relationship is not yet established by the inspected documents.

## Syntax profile

Envelope required keys: `contract`, `version`, `message_id`, `kind`, `claim_class`, `producer_hint`, `consumer_hint`, `body`, `extensions`. No unknown top-level keys. Version must be integer 1. JSON UTF-8 with no duplicated object keys, NaN, or Infinity. Maximum 65,536 encoded input bytes. Canonical local encoding: Python `json.dumps(..., ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)` UTF-8. This encoding is *local convenience*, not a specification for UPST. Body kind must be recognized for semantic consumption; reject unsupported versions and kinds.

## Inherited Holoquary v1.2 invariants

- NUMERICAL: `BALANCED3 [-1,+1]`, `PURE5 [0,4]`, `BALANCED7 [-3,+3]`. `KLEENE3` has symbolic `FALSE`, `TRUE`, `UNKNOWN` as **exact logical data**.
- `data.kind=ABSENT` must have JSON `number=null` and `logic=null`. JSON null means **no payload** at this interface; it is *not* a computational digit and is only permitted in these declared fields.
- `knowledge.possibilities` uses ordinal bits over the named domain. Numeric zero is represented by its **singleton bit**, not by an empty mask. Mask zero represents contradiction. Nonzero `unknown_grade` (1..3) is an opaque caller label permitted only on nonsingleton, nonempty possibility sets.
- `data.kind=NUMBER/LOGIC` requires matching singleton mask and completed execution; no marker or grade.
- `execution.state=FAILED` iff `error_code` nonzero; `LEGACY_E_MARKER` is permitted only with COMPLETE + ABSENT + full possibility mask + no grade. A propagated marker is **not proof of runtime failure**.
- `provenance.origin=CALLER` or `DERIVED` is source data, not cryptographic authenticity. `source_id`, `scope_id`, and `generation` have no sender-authentication significance.
- Algorithms must not consume unknown grades, error markers, provenance or claim classifications as numerical operands. No implicit promotion of NINE, FIFTEEN, unknown grades or transport receipts into arithmetic domains.

## Handoff structure protection

The attached `VERA_SOL_LATTICE_RESEARCH_ENGINE_HANDOFF_v0_2_0.zip` identifies Vera as the package's source, Lattice as target, and preserves nine structured `(block,state)` combinations: block `[-1,0,+1]` × state `[-1,0,+1]`. The handoff expressly says the semantics are unresolved. Here `design_target: RADIX9_3X3` can transmit that structure **without** assigning `V=3B+I`, a topology, state-transition graph, numerical meaning, or an UNKNOWN gradient. If another meaning is proposed later, it requires a different kind/status or versioned extension with explicit acceptance. Existing BLOCK7 code remains unchanged.

## Non-goals

No transport implementation, UPST wire envelope schema, key management, remote effect protocol, safety attestation, user/operator identity proof, arbitrary code/rule execution, conformance with an unseen UPST spec, automatic handling of attachments, or generic recursion. For lossless provenance and correlated unknown-variable identities, additional typed contracts are required.
