# UPTI-facing handoff TODO (not a roadmap for UPTI itself)

- [x] Correct UPST terminology to UPTI in the new package, leaving legacy sources byte-preserved and labeled.
- [x] Inspect the supplied UPTI-SF historical export; record its NOT_USED/INACTIVE disposition without discarding tentative design value.
- [x] Preserve the v0.1 Holoquary payload schema and separate numerical data/knowledge/execution/provenance lanes.
- [x] Bound local staging, payload validation, nontransforming byte-level fidelity, verification, and READY_FOR_UPTI_HANDOFF state.
- [x] Emit explicitly local receipts that deny unauthenticated delivery/receiver acceptance.
- [x] Add local version/kind/size capacity checking, session-local replay checks, and hostile nesting/Unicode regression.
- [ ] Obtain the **accepted UPTI** design: wire envelope, attachment acquisition, authorization, encryption/signature options, authenticated recipient and sender claims, size quotas, effect policies, persistent receipts, and reactivation status if any.
- [ ] Assign an **actual** UPTI owner from verified design source. Do not infer one from Vera→Lattice or Vesper/interLLM Transport.
- [ ] Build an adapter only against accepted UPTI API; no speculative `upti/0.1` encode/decode claimed here.
- [ ] Define durable replay/freshness under the actual trusted operating environment; session-local duplicate checking is insufficient.
- [ ] Specify immutable trusted source capture and independent attestation for consequential data movement.
- [ ] Map transfer failures, declared loss, rollback, recovery and source release to UPTI's accepted receipt schema. Source deletion remains forbidden in this profile.
- [ ] Decide explicit authority for applying received content; never authorize based on in-band hints or local acceptance.
- [ ] Choose target C99 and storage bounds, then implement C encoder/decoder against v1.2 `HQDRecord` with cross-language vectors, fuzz and ownership tests.
- [ ] Keep NINE/FIFTEEN and U1/U2/U3 semantic questions unresolved until independently specified and accepted. Recursion remains deferred.
