# Holoquary ↔ UPTI tentative handoff — executed tests

**Date:** 2026-10-02. **Environment:** hosted Python 3, local filesystem and in-memory state. **Scope:** application payload and LOCAL staging only.

## Execution recorded

```bash
cd holoquary_upti_handoff_v0_2
python -m unittest discover -s tests -p 'test_*.py' -v
python examples/demo_handoff.py
```

**34/34 unit tests PASS** on the final working-tree suite. The 10 original v0.1 payload validator tests are included unchanged. New tests cover:

- Exact original input bytes reproduced at the handoff boundary, including noncanonical JSON ordering and whitespace.
- Local `stage → verify → mark_ready` behavior; rejection of premature, duplicate, invalid, and terminal transitions.
- Locally declared receiver kind/version/size/profile checks (not an authenticated peer capability exchange).
- Per-session duplicate-message-ID rejection, including conflicting payloads with the same ID. Local store capacity limits.
- Explicit `sender_authenticated=False`, `delivered=False`, `receiver_acknowledged=False` regardless of source hints, `DECISION` claims or extension contents.
- Invalid computational state, unsupported NINE semantic promotion, stale/mutated staged source and invalid UTF-8/JSON.
- Nesting budget (64 levels), node budget (8192), and unpaired surrogate rejection.
- A previously verified packet that is later rejected reports `PASS_BEFORE_REJECTION`; this does not count as final success.
- No source deletion, no signature check, no transport network or UPTI runtime invoked.

## Ceilings

* Tests demonstrate bounded behavior for tested cases only; they are not independent protocol attestation, secure deserialization proof or authentication.
* SHA-256 is used as ordinary corruption detection and manifest checking, without keyed trust.
* The packet schema is the previous Holoquary application-payload v0.1, not an accepted UPTI-SF 0.1 runtime/wire conformance target.
* The tentative UPTI-SF zip contains a historical validation account (25/25 etc.) but no runnable historical implementation; **none of those claims was rerun** here.
* The session-local replay store is reset by process restart; the test suite explicitly demonstrates this limitation.
* The archived application-payload v0.1 documents include the obsolete `UPST` spelling, intentionally preserved for provenance. New v0.2 top-level docs supersede that terminology only.

See `AI_ERROR_LOG.md` for two assistant-originated negative-test failures discovered and corrected during this implementation.
