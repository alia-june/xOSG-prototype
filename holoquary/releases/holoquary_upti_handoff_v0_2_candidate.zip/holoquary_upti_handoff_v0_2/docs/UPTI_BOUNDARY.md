# Provisional Holoquary ↔ UPTI boundary / v0.2

## Evidence tiers

1. **Operator direction:** use UPTI name and treat supplied archived UPTI-SF spec as **tentative**, not accepted or active. Do not turn the source filename's `NOT_USED` into a refusal to consult it, and do not treat consultation as activation.
2. **Observed source:** `reference/UPTI-SF_SPEC_EXPORT_NOT_USED_2026-10-02.zip` records historic `upti/0.1`, `NOT_USED`, `INACTIVE`, `EXCLUDED_FROM_CURRENT_ARCHITECTURE` and a conceptual stage → verify → commit lifecycle. Its historic test claims are records, not rerun evidence. It has **no executable transport**.
3. **Generated proposal:** `staging.py` implements a bounded, process-local application handoff profile. It is independent of the actual UPTI wire protocol and makes no transport conformance claim.
4. **Observed implementation checks:** see `TEST_REPORT.md` for local test receipt only; no authenticated external verification is claimed.

## Contract

```text
Holoquary v1.2 normalized state
         │ (application semantics only)
         ▼
Holoquary payload.py — immutable UTF-8 JSON input / validation
         │
         ▼
LocalHandoff.stage(raw, locally_supplied_profile)
         │ checks capability assumptions, message_id reservation, payload and size
         ▼
LocalHandoff.verify(id)
         │ checks same original bytes and payload contract again
         ▼
LocalHandoff.mark_ready(id)
         │ same raw bytes + in-memory local receipt (delivered=False)
         ▼
       [future explicitly accepted UPTI adapter boundary]
         │
         ▼
     interLLM Transport and/or other independently defined transport
     (relationship not yet contractually resolved)
```

**No executable receiver/transport call occurs.** The API returns the original bytes. The receipt is not a transport receipt. `claim_class='DECISION'`, `producer_hint`, `consumer_hint`, message ID, source SHA-256, and local validation PASS are **untrusted assertions, not identity, authorization, consensus or independent attestation**. A future trusted receiver identity must be supplied as an independent verified channel.

## Fidelity model

* `source`: exact raw packet bytes captured; no normalization, rewriting, or omission in this version.
* `transformation`: NONE (while parsed structure is validated); no conversion to an `upti/0.1` envelope.
* `omitted_fields`: empty for local byte-preserving output.
* `changed_fields`: empty for local byte-preserving output.
* `reported_losses`: empty for this specific local operation; **not** a claim of downstream semantic equivalence.
* `artifact_reference`: metadata only. Its named file is never opened/copied automatically.
* Hash: SHA-256 of captured bytes for ordinary integrity comparisons; **not** a MAC, signature, or source authentication.
* Unsupported capability, invalid payload, improper promotion of NINE semantics and replayed session-local `message_id` → REJECTED locally. The caller's original source bytes are not deleted.

## Conformance and error ceilings

- `stage()` and `verify()` are only locally checked against payload v0.1; no actual capability handshake occurred. Capabilities are **assumptions**, not verified remote claims.
- `mark_ready()` is a local one-way state change and returns a *handoff candidate*. It does not certify that any other machine received or validated the data.
- Replay reservation is in-memory only; re-instantiating the adapter forgets identifiers. For strong anti-replay, UPTI requires durable, trustworthy nonces/IDs or protected journals and independently verified identity/freshness.
- Session-local staged data, private dictionaries, returned receipts, and SHA-256 cannot resist malicious mutation by code with the same process privilege. The test suite injects corruption to verify detection in the **nonadversarial** model only.
- `ReceiverProfile` does not validate receiver identity, permissions or remote capabilities; it only checks locally declared size/version/kind limits.
- JSON extension objects are **inert** data and have no executable or permission semantics. The profile caps byte size and nesting; omitted or unknown optional semantic fields remain unreconciled.
- `ERROR` in execution records remains distinct from balanced-ternary numerical digits and from strong-Kleene `UNKNOWN`. `U1/U2/U3` are opaque grades. The radix-nine `3×3` meaning stays UNRESOLVED.
- Neither this package nor the tentative reference asserts that the dormant UPTI-SF wrapper has been reactivated.

## Known ownership evidence

* The earlier handoff package `VERA_SOL_LATTICE_RESEARCH_ENGINE_HANDOFF_v0_2_0.zip` addresses Lattice for research analysis from Vera Sol.
* Prior interLLM Transport development handoff was directed to Vesper. That does **not** establish UPTI ownership.
* Holoquary remains the application producer/consumer; it is not a transport authority.
