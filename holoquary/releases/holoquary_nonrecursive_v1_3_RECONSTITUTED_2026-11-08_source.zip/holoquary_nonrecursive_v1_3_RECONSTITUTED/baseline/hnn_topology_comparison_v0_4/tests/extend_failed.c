#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "topology_nn.h"
typedef struct {const char *name;unsigned dims[5];unsigned layers;} Shape;
static const Shape shapes[]={
    {"2-2-2-1",{2,2,2,1,0},3},
    {"2-3-3-1",{2,3,3,1,0},3},
    {"2-2-2-2-1",{2,2,2,2,1},4},
    {"2-2-4-2-1",{2,2,4,2,1},4},
    {"2-3-5-3-1",{2,3,5,3,1},4},
    {"2-8-1",{2,8,1,0,0},2},
    {"2-3-3-3-1",{2,3,3,3,1},4}
};
int main(int argc,char **argv){FILE *f;char line[256],name[60],mode[32],population[32];unsigned rowseed,seed,epochs,pass,first,limit=1000000,seen=0,late=0,stuck=0;
    float max_error,loss;
    if(argc<3 || argc>4 || !(f=fopen(argv[1],"r")))return 2;
    if(argc==4)limit=(unsigned)strtoul(argv[3],NULL,10);
    if(!fgets(line,sizeof(line),f)){fclose(f);return 3;}
    while(fgets(line,sizeof(line),f)){
        unsigned i,e;DNNModel m;DNNGrad g;float e30=0.0f,e120;
        if(sscanf(line,"%59[^,],%31[^,],%31[^,],%u,%u,%u,%u,%f,%f,%u",name,mode,population,&rowseed,&seed,&epochs,&pass,&max_error,&loss,&first)!=10){fclose(f);return 4;}
        if(strcmp(name,argv[2])!=0||pass)continue;
        if(seen>=limit)break;
        for(i=0;i<sizeof(shapes)/sizeof(shapes[0]);++i)if(strcmp(shapes[i].name,name)==0)break;
        if(i==sizeof(shapes)/sizeof(shapes[0]) || !dnn_init(&m,shapes[i].dims,shapes[i].layers,seed,strcmp(mode,"scaled")==0?DNN_SCALED:DNN_UNIFORM)){fclose(f);return 5;}
        for(e=0;e<120000u;++e){(void)dnn_batch_gradient(&m,&g);dnn_step(&m,&g,.15f);
            if(e==29999u)e30=dnn_max_error(&m);
        }
        e120=dnn_max_error(&m);
        if(!(e30>.10f)){fprintf(stderr,"REPRO_MISMATCH %s seed=%u err=%.9g\n",name,seed,(double)e30);fclose(f);return 6;}
        ++seen;
        if(e120<=.10f)++late;else ++stuck;
        printf("EXTEND architecture=%s raw_seed=%u seed=%u e30=%.9g e120=%.9g recovered=%u\n",name,rowseed,seed,(double)e30,(double)e120,e120<=.10f);
    }
    fclose(f);
    printf("EXTEND_SUMMARY architecture=%s examined=%u recovered_by_120k=%u missed_120k=%u\n",argv[2],seen,late,stuck);
    return 0;
}
