#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "topology_nn.h"
typedef struct {const char *name; unsigned dims[5]; unsigned layers; unsigned params;} Shape;
static const Shape shapes[]={
    {"2-2-2-1",{2,2,2,1,0},3,15},
    {"2-3-3-1",{2,3,3,1,0},3,25},
    {"2-2-2-2-1",{2,2,2,2,1},4,21},
    {"2-2-4-2-1",{2,2,4,2,1},4,31},
    {"2-3-5-3-1",{2,3,5,3,1},4,51},
    {"2-8-1",{2,8,1,0,0},2,33},
    {"2-3-3-3-1",{2,3,3,3,1},4,37}
};
static unsigned scramble(unsigned x){x^=0xA5A5A5A5u;x^=x>>16;x*=0x7feb352du;x^=x>>15;x*=0x846ca68bu;x^=x>>16;return x?x:1u;}
static unsigned firstpass(const DNNModel *m, float threshold){return dnn_max_error(m)<=threshold;}
int main(int argc,char **argv){
    unsigned n=256,hashed=0,mode=1,epochs=30000,i,s,e;
    if(argc>1)n=(unsigned)strtoul(argv[1],0,10);
    if(argc>2)hashed=(unsigned)strtoul(argv[2],0,10);
    if(argc>3)mode=(unsigned)strtoul(argv[3],0,10);
    if(argc>4)epochs=(unsigned)strtoul(argv[4],0,10);
    if(n==0 || epochs==0 || mode>1){fputs("invalid arguments\n",stderr);return 2;}
    puts("architecture,initialization,seed_population,raw_seed,seed,updates,pass,max_abs_error,loss,first_pass_check");
    for(i=0;i<sizeof(shapes)/sizeof(shapes[0]);++i){
        unsigned count=0, check_min=0, earliest=0, failed_first=0;
        clock_t start=clock();const Shape *shape=&shapes[i];
        for(s=1;s<=n;++s){DNNModel m; DNNGrad g;unsigned first=0;unsigned actual=hashed?scramble(s):s;
            if(!dnn_init(&m,shape->dims,shape->layers,actual,(DNNInit)mode)){
                fprintf(stderr,"init failure topology=%s seed=%u\n",shape->name,s);return 3;
            }
            if(m.used!=shape->params){fprintf(stderr,"param count mismatch for %s\n",shape->name);return 4;}
            for(e=0;e<epochs;++e){(void)dnn_batch_gradient(&m,&g);dnn_step(&m,&g,0.15f);
                if((e+1)%1000u==0 && !first && firstpass(&m,.10f)){first=e+1;}
            }
            {float err=dnn_max_error(&m);int pass=err<=.10f;float loss=dnn_loss(&m);
                count+=(unsigned)pass;earliest+=first;failed_first+=(!first);
                printf("%s,%s,%s,%u,%u,%u,%d,%.9g,%.9g,%u\n",shape->name,mode?"scaled":"uniform",hashed?"scrambled":"consecutive",s,actual,epochs,pass,(double)err,(double)loss,first);
            }
        }
        fprintf(stderr,"SUMMARY architecture=%s mode=%s pop=%s count=%u pass=%u rate=%.5f cpu_sec=%.3f zero_checks=%u\n",
                shape->name,mode?"scaled":"uniform",hashed?"scrambled":"consecutive",n,count,(double)count/(double)n,(double)(clock()-start)/CLOCKS_PER_SEC,failed_first);
        (void)check_min;(void)earliest;
        fflush(stderr);fflush(stdout);
    }
    return 0;
}
