#include <math.h>
#include <stdio.h>
#include "topology_nn.h"
typedef struct {const char *name;unsigned dims[5];unsigned layers,params;} Shape;
static const Shape shapes[]={
    {"2-2-2-1",{2,2,2,1,0},3,15},
    {"2-3-3-1",{2,3,3,1,0},3,25},
    {"2-2-2-2-1",{2,2,2,2,1},4,21},
    {"2-2-4-2-1",{2,2,4,2,1},4,31},
    {"2-3-5-3-1",{2,3,5,3,1},4,51},
    {"2-8-1",{2,8,1,0,0},2,33},
    {"2-3-3-3-1",{2,3,3,3,1},4,37}
};
static int exact_xor(const Shape *sh){
    const float inputs[4][2]={{0,0},{0,1},{1,0},{1,1}};
    const float targets[4]={0,1,1,0};
    DNNModel m;DNNContext c;unsigned i,l,j;
    float slope_power=0.05f;
    if(!dnn_init(&m,sh->dims,sh->layers,1u,DNN_SCALED))return 0;
    for(i=0;i<m.used;++i)m.p[i]=0.0f;
    /* First hidden stage computes x0-x1 and x1-x0. */
    m.p[m.offset[0]+0]=1.0f;
    m.p[m.offset[0]+1]=-1.0f;
    m.p[m.offset[0]+2]=-1.0f;
    m.p[m.offset[0]+3]=1.0f;
    /* Later hidden stages forward the two lanes unchanged. */
    for(l=1;l<sh->layers-1;++l){unsigned from=m.dims[l],base=m.offset[l];
        m.p[base+0*from+0]=1.0f;
        m.p[base+1*from+1]=1.0f;
        slope_power*=.05f;
    }
    /* For 01/10 the positive lane is 1, the other lane is -slope^H. */
    m.p[m.offset[sh->layers-1]+0]=1.0f/(1.0f-slope_power);
    m.p[m.offset[sh->layers-1]+1]=m.p[m.offset[sh->layers-1]+0];
    for(j=0;j<4;++j){float y=dnn_forward(&m,inputs[j],&c);
        if(fabsf(y-targets[j])>.000001f){fprintf(stderr,"XOR_REP_FAIL %s input=%u got=%.9g\n",sh->name,j,(double)y);return 0;}
    }
    printf("XOR_REP_PASS %s\n",sh->name);
    return 1;
}
int main(void){unsigned t,s,checked;float maxdiff=0.0f;const float eps=.003f;
    for(t=0;t<sizeof(shapes)/sizeof(shapes[0]);++t){const Shape *sh=&shapes[t];checked=0;
        if(!exact_xor(sh))return 4;
        for(s=1;s<=1024 && checked<10;++s){DNNModel m;DNNGrad g;unsigned l,j,p,near=0;
            if(!dnn_init(&m,sh->dims,sh->layers,s,DNN_SCALED)||m.used!=sh->params)return 2;
            for(j=0;j<4;j++){static const float xs[4][2]={{0,0},{0,1},{1,0},{1,1}};DNNContext c;
                (void)dnn_forward(&m,xs[j],&c);
                for(l=0;l<sh->layers-1;++l){unsigned k;for(k=0;k<sh->dims[l+1];++k)if(fabsf(c.preactivation[l][k])<.04f)near=1;}
            }
            if(near)continue;
            (void)dnn_batch_gradient(&m,&g);
            for(p=0;p<m.used;++p){float old=m.p[p],plus,minus,diff;
                m.p[p]=old+eps;plus=dnn_loss(&m);
                m.p[p]=old-eps;minus=dnn_loss(&m);
                m.p[p]=old;diff=fabsf((plus-minus)/(2*eps)-g.g[p]);
                if(diff>maxdiff)maxdiff=diff;
                if(!(diff<.004f)){fprintf(stderr,"GRAD_FAIL %s seed=%u param=%u diff=%.9g\n",sh->name,s,p,(double)diff);return 1;}
            }
            {float x[2]={.35f,.15f},dx[2];DNNContext c;DNNGrad inputg;
                float y=dnn_forward(&m,x,&c);unsigned inputk,near_input=0;
                for(l=0;l<sh->layers-1;++l){unsigned k;
                    for(k=0;k<sh->dims[l+1];++k)if(fabsf(c.preactivation[l][k])<.04f)near_input=1;
                }
                if(!near_input){
                    dnn_grad_clear(&inputg);
                    dnn_backward_add(&m,&c,y-.73f,&inputg,dx);
                    for(inputk=0;inputk<2u;++inputk){float old=x[inputk],plus,minus,diff;
                        x[inputk]=old+eps;{DNNContext temp;float error=dnn_forward(&m,x,&temp)-.73f;plus=.5f*error*error;}
                        x[inputk]=old-eps;{DNNContext temp;float error=dnn_forward(&m,x,&temp)-.73f;minus=.5f*error*error;}
                        x[inputk]=old;
                        diff=fabsf((plus-minus)/(2.0f*eps)-dx[inputk]);
                        if(!(diff<.004f)){fprintf(stderr,"INPUT_GRAD_FAIL %s seed=%u input=%u diff=%.9g\n",sh->name,s,inputk,(double)diff);return 5;}
                    }
                }
            }
            ++checked;
        }
        printf("GRAD_CHECK %s samples=%u parameters=%u\n",sh->name,checked,sh->params);
        if(checked<10u){fprintf(stderr,"insufficient off-kink checks for %s\n",sh->name);return 3;}
    }
    printf("ALL_GRAD_CHECKS_PASS max_abs_difference=%.9g\n",(double)maxdiff);
    printf("MEMORY sizeof_model=%lu sizeof_gradient=%lu sizeof_context=%lu\n",(unsigned long)sizeof(DNNModel),(unsigned long)sizeof(DNNGrad),(unsigned long)sizeof(DNNContext));
    return 0;
}
