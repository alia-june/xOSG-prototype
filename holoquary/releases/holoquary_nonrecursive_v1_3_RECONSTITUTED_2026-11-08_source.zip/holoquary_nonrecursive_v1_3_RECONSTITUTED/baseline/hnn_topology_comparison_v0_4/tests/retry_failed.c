#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "topology_nn.h"
typedef struct {const char *name;unsigned dims[5];unsigned layers,initial_ok,recovered,exhausted;} Shape;
static Shape shapes[]={
    {"2-2-2-1",{2,2,2,1,0},3,0,0,0},
    {"2-3-3-1",{2,3,3,1,0},3,0,0,0},
    {"2-2-2-2-1",{2,2,2,2,1},4,0,0,0},
    {"2-2-4-2-1",{2,2,4,2,1},4,0,0,0},
    {"2-3-5-3-1",{2,3,5,3,1},4,0,0,0},
    {"2-8-1",{2,8,1,0,0},2,0,0,0},
    {"2-3-3-3-1",{2,3,3,3,1},4,0,0,0}
};
static unsigned scramble(unsigned x){x^=0xA5A5A5A5u;x^=x>>16;x*=0x7feb352du;x^=x>>15;x*=0x846ca68bu;x^=x>>16;return x?x:1u;}
int main(int argc,char **argv){char line[256],name[60],mode[32],population[32];FILE *fp;unsigned raw_seed,seed,epochs,passed,first,i;
    float max_error,loss;
    if(argc!=2 || !(fp=fopen(argv[1],"r")))return 2;
    if(!fgets(line,sizeof(line),fp)){fclose(fp);return 3;}
    while(fgets(line,sizeof(line),fp)){
        DNNModel m;DNNGrad g;int ok=0;
        if(sscanf(line,"%59[^,],%31[^,],%31[^,],%u,%u,%u,%u,%f,%f,%u",name,mode,population,&raw_seed,&seed,&epochs,&passed,&max_error,&loss,&first)!=10){fputs("invalid CSV record\n",stderr);fclose(fp);return 4;}
        if(strcmp(mode,"scaled")!=0 || strcmp(population,"scrambled")!=0){fputs("unexpected population\n",stderr);fclose(fp);return 5;}
        for(i=0;i<sizeof(shapes)/sizeof(shapes[0]);++i)if(strcmp(shapes[i].name,name)==0){ok=1;break;}
        if(!ok){fputs("unknown topology\n",stderr);fclose(fp);return 6;}
        if(passed){++shapes[i].initial_ok;continue;}
        if(!dnn_init(&m,shapes[i].dims,shapes[i].layers,scramble(seed^0x9e3779b9u),DNN_SCALED))return 7;
        for(unsigned e=0;e<30000u;++e){(void)dnn_batch_gradient(&m,&g);dnn_step(&m,&g,.15f);}
        if(dnn_max_error(&m)<=.10f)++shapes[i].recovered;
        else {++shapes[i].exhausted;printf("EXHAUSTED architecture=%s first_seed=%u second_seed=%u max_error=%.9g\n",name,seed,scramble(seed^0x9e3779b9u),(double)dnn_max_error(&m));}
    }
    fclose(fp);
    for(i=0;i<sizeof(shapes)/sizeof(shapes[0]);++i)printf("RETRY_SUMMARY architecture=%s first_pass=%u recovered=%u exhausted=%u total=%u\n",shapes[i].name,shapes[i].initial_ok,shapes[i].recovered,shapes[i].exhausted,shapes[i].initial_ok+shapes[i].recovered+shapes[i].exhausted);
    return 0;
}
