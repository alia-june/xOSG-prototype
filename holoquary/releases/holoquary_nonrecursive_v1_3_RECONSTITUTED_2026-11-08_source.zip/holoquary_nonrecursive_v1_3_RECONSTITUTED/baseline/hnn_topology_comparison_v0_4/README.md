# HNN-001 v0.4 — Five-topology XOR controlled comparison

This source package experimentally compares five distinct user-specified shapes: `2-2-2-1`, `2-3-3-1`, `2-2-2-2-1`, `2-2-4-2-1`, and `2-3-5-3-1`. The input repeated `2-2-2-1` twice; it is tested once. Earlier models `2-8-1` and `2-3-3-3-1` are included as controls. A number denotes the count of **scalar neurons in a layer**; each adjacent pair of layers is fully connected. These are not nine independently defined hidden-layer holons.

## What changed relative to HNN v0.3

The source core derives from v0.3's `deep_nn.c` / `.h`, with the include name changed and the fixed-capacity parameter array enlarged from 37 to 51. The forward, backward, update, initialization, and loss equations are otherwise unchanged. All seven shapes use this one C99 kernel, no neural-network frameworks, heap allocations, or required operating-system services in the numerical source.

## Reproduce

Requires GCC or Clang, a C99 compiler, and a hosted library for test runners only.

```sh
make CC=gcc all retry_failed extend_failed freestanding
./test_grad
./survey 512 0 1 30000 > logs/consecutive512_scaled.csv 2> logs/consecutive512_scaled.summary
./survey 512 1 1 30000 > logs/scrambled512_scaled.csv 2> logs/scrambled512_scaled.summary
./survey 512 0 0 30000 > logs/consecutive512_uniform.csv 2> logs/consecutive512_uniform.summary
./survey 512 1 0 30000 > logs/scrambled512_uniform.csv 2> logs/scrambled512_uniform.summary
./retry_failed logs/scrambled512_scaled.csv > logs/retry512_scaled_scrambled.txt
./extend_failed logs/scrambled512_scaled.csv 2-3-5-3-1 > logs/extend_23531_scaled_scrambled.txt
```

The survey's positional arguments are: `<seed_count> <scrambled:0|1> <initialization:uniform=0|scaled=1> <steps>`. Its result CSV is written to standard output, and topology summaries to standard error. The comma-separated files are generated test records, not input datasets. Windows can use MinGW-w64 GCC, substituting `.exe` for executable names.

## Experiment configuration

- XOR truth table: `00->0, 01->1, 10->1, 11->0`.
- Hidden layers: leaky ReLU, negative slope 0.05; output: linear.
- Loss: averaged half-mean-squared-error; optimizer: full-batch gradient descent.
- Learning rate: 0.15; updates: exactly 30,000 for every primary attempt.
- Accept only when all four output errors are <= 0.10 after training.
- Two deterministic seed populations: 1 through 512, and a reproducible scrambled transform of those 512 values. Each topology has its own parameter draw sequence; using the same seed is not an identical weight configuration.
- `uniform`: weights and biases from a deterministic approximately `[-1,1]` generator.
- `scaled`: same hidden weights, hidden biases multiplied by 0.25, output bias set to zero, and output weights scaled using the width-dependent factor in `topology_nn.c`. This is not a claim of conventional layerwise Xavier/He initialization.
- Float32 arithmetic. Seed surveys are deterministic on the tested host/compiler environment; exact floating-point trajectories need not match all target processors.

## Files

- `src/topology_nn.c`, `src/topology_nn.h`: numerical reference kernel (max 4 transformations, max width 8, max 51 parameters, fixed 2-input, 1-output task).
- `tests/survey.c`: all seven topologies, two initializers, two populations.
- `tests/test_grad.c`: hand-constructed XOR for each topology, centered finite-difference parameter-gradient checks, input-gradient checks away from activation kinks.
- `tests/retry_failed.c`: deterministic second attempt on failed `scrambled/scaled` seeds.
- `tests/extend_failed.c`: recreates 30,000-update failed runs and extends training to 120,000 updates.
- `logs/`: the four complete survey populations, raw CSV, summaries, retry diagnostics, extended-training diagnostics, and compiler test records.
- `docs/EXPERIMENT_REPORT.md`: consolidated measurements, interpretation, limits, and research disposition.
- `docs/AI_ERROR_LOG.md`: implementation and test-harness errors observed in this pass.

## Scope limits

This is a topology experiment and a *freestanding-compilable host object*, not proof of firmware execution on physical hardware. A physical target, startup, linker configuration, runtime math and I/O need a separate hardware test. This design does not yet implement arbitrary holon graphs, recurrence, shared parameter banks, graph scheduling, or runtime tensor shape inference. It is a fully-connected **sequential** fixed-capacity prototype.
