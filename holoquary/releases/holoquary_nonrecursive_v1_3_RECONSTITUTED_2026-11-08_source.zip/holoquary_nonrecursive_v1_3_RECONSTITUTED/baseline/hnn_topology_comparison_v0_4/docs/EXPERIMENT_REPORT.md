# HNN-001 v0.4 — Experimental topology report

## Provenance and method

This package extends the preserved HNN v0.3 experimental engine. It modifies only fixed-capacity limits and header naming in the numerical kernel; topology enumeration and experiments live in separate hosted test drivers. Each requested shape represents a fully connected layer-width sequence. The user listed `2-2-2-1` twice; it was tested once. Two earlier designs (`2-8-1` and `2-3-3-3-1`) were included as reference controls.

All topologies used the same two-input, one-output XOR dataset, binary32 parameters, leaky ReLU hidden activation (negative slope 0.05), linear output, averaged half-MSE loss, and full-batch gradient descent with learning rate 0.15. Every primary run executed exactly 30,000 updates. Success means each final XOR prediction differs from its target by no more than 0.10. The two initialization policies differ in hidden bias scale and output-layer weight/bias configuration, not in a universal fan-in transform across every layer.

Four completed populations each contain 512 deterministic seeds per shape: original integers 1..512 and a fixed scramble of that set, independently under each initialization policy. They are deterministic, predefined experiment inputs, not claims of exhaustive or representative random sampling. Seed numbers are comparable as labels; the networks draw different counts of parameter values, so equal seed does not mean equal parameters.

## Recorded primary results

| Shape | Hidden stages | Parameters | Raw FP32 parameter bytes | Scaled sequential | Scaled scrambled | Uniform sequential | Uniform scrambled |
|:--|--:|--:|--:|--:|--:|--:|--:|
| 2-2-2-1 | 2 | 15 | 60 | 366/512 | 386/512 | 348/512 | 314/512 |
| 2-3-3-1 | 2 | 25 | 100 | 482/512 | 485/512 | 448/512 | 444/512 |
| 2-2-2-2-1 | 3 | 21 | 84 | 370/512 | 359/512 | 322/512 | 297/512 |
| 2-2-4-2-1 | 3 | 31 | 124 | 441/512 | 436/512 | 373/512 | 365/512 |
| 2-3-5-3-1 | 3 | 51 | 204 | 502/512 | 503/512 | 466/512 | 469/512 |
| 2-8-1 | 1 | 33 | 132 | 512/512 | 512/512 | 502/512 | 497/512 |
| 2-3-3-3-1 | 3 | 37 | 148 | 480/512 | 485/512 | 461/512 | 453/512 |

### Aggregated by initialization policy

| Shape | Scaled: 1,024 seeds | Uniform: 1,024 seeds |
|:--|--:|--:|
| 2-2-2-1 | 752/1,024 (73.44%) | 662/1,024 (64.65%) |
| 2-3-3-1 | 967/1,024 (94.43%) | 892/1,024 (87.11%) |
| 2-2-2-2-1 | 729/1,024 (71.19%) | 619/1,024 (60.45%) |
| 2-2-4-2-1 | 877/1,024 (85.64%) | 738/1,024 (72.07%) |
| 2-3-5-3-1 | 1005/1,024 (98.14%) | 935/1,024 (91.31%) |
| 2-8-1 | 1024/1,024 (100.00%) | 999/1,024 (97.56%) |
| 2-3-3-3-1 | 965/1,024 (94.24%) | 914/1,024 (89.26%) |

## Verification

- **Direct representability:** A hand-constructed parameter set solved all four XOR inputs for each of seven layer-width shapes. These representational proofs do not imply gradient descent will discover the solutions.
- **Derivatives:** Centered finite differences matched analytical batch parameter gradients for ten non-kink configurations per shape, with worst absolute difference approximately `2.01e-5`. The same test driver checks per-input gradients away from activation kinks.
- **Toolchain:** GCC and Clang compiled the hosted gradient/test harness. GCC's undefined-behavior and bounds instrumentation reported no faults in executed tests. A GCC `-ffreestanding -fno-builtin` host-object build had no unresolved external symbols.
- **Log audit:** The four complete survey CSVs each have 3,584 data rows (seven architectures × 512 seeds), no nonfinite loss or maximum output error, unique seeds within each group, and pass flags consistent with the <=0.10 criterion. All four returned exit code zero.
- **Numerical assumptions:** `FLT_RADIX==2`, `FLT_MANT_DIG==24`, and a 32-bit `unsigned int` are compile-time prerequisites. Floating-point bitwise identity across processors is not asserted.

## Bounded restart experiment (scaled/scrambled only)

The original unsuccessful seeds were each given **one** additional attempt with a deterministically derived new seed, 30,000 additional updates, unchanged topology and training policy. The initial attempt is counted only once. The results are not universal convergence guarantees.

| Shape | First attempt | Recovered by second | Still exhausted |
|:--|--:|--:|--:|
| 2-2-2-1 | 386/512 | 95 | 31 |
| 2-3-3-1 | 485/512 | 26 | 1 |
| 2-2-2-2-1 | 359/512 | 101 | 52 |
| 2-2-4-2-1 | 436/512 | 69 | 7 |
| 2-3-5-3-1 | 503/512 | 9 | 0 |
| 2-8-1 | 512/512 | 0 | 0 |
| 2-3-3-3-1 | 485/512 | 27 | 0 |

## Prolonged-training diagnostic

The same failed initialization was rerun from its original seed for 120,000 updates (four times the primary budget). For `2-3-5-3-1`, all nine failed scaled/scrambled seeds were examined: one recovered by 120k and eight were still outside the acceptance threshold. For `2-3-3-1`, all 27 failed cases were examined: eight recovered, 19 still failed. For `2-2-4-2-1` and `2-2-2-2-1`, only the first 20 failed cases in the input logs were examined per shape: five recovered and 15 remained outside the threshold for each. The latter are ordered subsets, not unbiased random samples. See `logs/extend_*.txt` for the individual outputs and replay checks.

## Interpretation

Holding the depth at two hidden layers, the `2-3-3-1` topology is more consistently trainable under these specific settings than `2-2-2-1`. Holding depth at three hidden layers, inserting a four-unit middle stage (`2-2-4-2-1`) improves the recorded rate over `2-2-2-2-1`; the wider `2-3-5-3-1` improves it further, while using more weights. The added two-unit layer in `2-2-2-2-1` did not, by itself, improve convergence relative to `2-2-2-1`. None of these observations proves a general theorem about depth or width: their parameter counts, capacity, and optimization geometry also differ.

The legacy `2-8-1` reference remained highly reliable on this dataset, while its computational structure is shallower. The experiment supports representing layer widths as compiled metadata and preserving a separate training controller. It does **not** establish an arbitrary holonic graph runtime or physical bare-metal execution.

## Compute and storage boundaries

Numbers of forward weight multiply-accumulates (not full train-time FLOP counts): `2-2-2-1`: 10; `2-3-3-1`: 18; `2-2-2-2-1`: 14; `2-2-4-2-1`: 22; `2-3-5-3-1`: 39; `2-8-1`: 24; `2-3-3-3-1`: 27. Raw parameter sizes are listed above; additional gradient, activation, runtime stack, test data, and executable storage are excluded. On the tested x86-64 host the fixed-capacity `DNNModel` is 248 bytes, `DNNGrad` is 204 bytes, and `DNNContext` is 288 bytes. These figures represent capacity-reserved structures, not an independently measured entire hardware RAM/flash footprint. Run-to-run host CPU measurements are in `logs/*.summary` and should not be treated as target-hardware benchmarks.

## Open boundaries

Physical board, instruction set, float support, linker script, startup, and I/O have not been selected or validated. There is no automatic differentiation graph, fan-out scheduler, arbitrary input/output dimensions, dynamic heap, or parameter-sharing runtime in this artifact. The derivative is piecewise and gradient checks intentionally exclude samples at the leaky-ReLU kink. Failure causes beyond the observed training criterion require per-seed trajectory analysis and must not be asserted from aggregate rates alone.
