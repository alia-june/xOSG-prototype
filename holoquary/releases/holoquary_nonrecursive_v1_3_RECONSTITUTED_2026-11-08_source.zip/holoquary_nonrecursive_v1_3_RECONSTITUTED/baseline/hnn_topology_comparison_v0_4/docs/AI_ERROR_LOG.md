# AI Error Log — HNN-001 v0.4

## HNN-AI-ERR-001 — Incorrect survey invocation argument order

The assistant's first invocation supplied `./survey 32 0 30000 1` while `survey` expects the initialization mode before the training-step count. The harness correctly rejected this with `invalid arguments` and a nonzero status. No data from that rejected invocation was accepted or included in an experiment summary. The command was corrected to `./survey 32 0 1 30000`, and the accepted results were verified independently.

## Scope of this log

These are assistant-generated implementation/invocation issues, not all training failures. Network convergence failures are experimental observations and are preserved separately in the CSV result logs. An unsupported terminal streaming-session operation returned an environment error, and the work was instead executed through explicitly awaited checks within this turn; that environment limitation was not counted as a neural-network defect.
