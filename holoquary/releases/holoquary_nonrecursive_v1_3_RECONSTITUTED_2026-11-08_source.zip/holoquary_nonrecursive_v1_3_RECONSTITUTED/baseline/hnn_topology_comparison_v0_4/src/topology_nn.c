#include "topology_nn.h"
#include <float.h>
#include <limits.h>
#if UINT_MAX != 4294967295u
#error "Expected 32-bit unsigned int"
#endif
#if FLT_RADIX != 2 || FLT_MANT_DIG != 24
#error "Expected binary32 float"
#endif
static unsigned int advance(unsigned int *s) {unsigned int x=*s;x^=x<<13;x^=x>>17;x^=x<<5;*s=x;return x;}
static float draw(unsigned int *s){return 2.0f*(float)((advance(s)>>16)&65535u)/65535.0f-1.0f;}
static float output_scale(unsigned int n) {return n==8u?0.35355339f:n==3u?0.57735027f:n==2u?0.70710678f:1.0f;}
static float absolute(float x){return x<0?-x:x;}
static float activation(float z){return z>0.0f?z:0.05f*z;}
static float derivative(float z){return z>0.0f?1.0f:0.05f;}
int dnn_init(DNNModel *m,const unsigned int *dims,unsigned int layers,unsigned int seed,DNNInit mode){
    unsigned int l,i,j,off=0,s=seed?seed:1u;
    if(!m || !dims || !layers || layers>DNN_MAX_LAYERS || dims[0]!=DNN_INPUTS || dims[layers]!=1u || (mode!=DNN_UNIFORM && mode!=DNN_SCALED))return 0;
    for(l=0;l<=layers;++l)if(!dims[l]||dims[l]>DNN_MAX_WIDTH)return 0;
    for(l=0;l<layers;++l){
        unsigned int from=dims[l],to=dims[l+1],required=from*to+to;
        if(off+required>DNN_MAX_PARAMS)return 0;
        m->dims[l]=from;m->offset[l]=off;off+=required;
    }
    m->dims[layers]=dims[layers];m->layers=layers;m->used=off;
    for(i=0;i<DNN_MAX_PARAMS;++i)m->p[i]=0.0f;
    for(l=0;l<layers;++l){
        unsigned int from=dims[l],to=dims[l+1],base=m->offset[l];
        for(j=0;j<to;++j)for(i=0;i<from;++i)m->p[base+j*from+i]=draw(&s);
        for(j=0;j<to;++j)m->p[base+from*to+j]=draw(&s);
        if(mode==DNN_SCALED){
            for(j=0;j<to;++j){
                if(l==layers-1){for(i=0;i<from;++i)m->p[base+j*from+i]*=output_scale(from);m->p[base+from*to+j]=0.0f;}
                else m->p[base+from*to+j]*=0.25f;
            }
        }
    }
    return 1;
}
float dnn_forward(const DNNModel *m,const float x[DNN_INPUTS],DNNContext *ctx){
    unsigned int l,i,j;
    for(i=0;i<DNN_INPUTS;++i)ctx->activation[0][i]=x[i];
    for(l=0;l<m->layers;++l){unsigned int from=m->dims[l],to=m->dims[l+1],base=m->offset[l];
        for(j=0;j<to;++j){float z=m->p[base+from*to+j];
            for(i=0;i<from;++i)z+=m->p[base+j*from+i]*ctx->activation[l][i];
            ctx->preactivation[l][j]=z;
            ctx->activation[l+1][j]=(l+1==m->layers)?z:activation(z);
        }
    }
    return ctx->activation[m->layers][0];
}
void dnn_grad_clear(DNNGrad *g){unsigned int i;for(i=0;i<DNN_MAX_PARAMS;++i)g->g[i]=0.0f;}
void dnn_backward_add(const DNNModel *m,const DNNContext *ctx,float upstream,DNNGrad *g,float dx[DNN_INPUTS]){
    unsigned int l,i,j;float next[DNN_MAX_WIDTH]={0},current[DNN_MAX_WIDTH]={0};
    next[0]=upstream;
    for(l=m->layers;l>0u;){unsigned int from,to,base;--l;
        from=m->dims[l];to=m->dims[l+1];base=m->offset[l];
        for(i=0;i<from;++i)current[i]=0.0f;
        for(j=0;j<to;++j){float delta=next[j]*((l+1u==m->layers)?1.0f:derivative(ctx->preactivation[l][j]));
            g->g[base+from*to+j]+=delta;
            for(i=0;i<from;++i){g->g[base+j*from+i]+=delta*ctx->activation[l][i];current[i]+=delta*m->p[base+j*from+i];}
        }
        for(i=0;i<from;++i)next[i]=current[i];
    }
    for(i=0;i<DNN_INPUTS;++i)dx[i]=next[i];
}
void dnn_step(DNNModel *m,const DNNGrad *g,float lr){unsigned int k;for(k=0;k<m->used;++k)m->p[k]-=lr*g->g[k];}
static const float samples[4][3]={{0,0,0},{0,1,1},{1,0,1},{1,1,0}};
float dnn_loss(const DNNModel *m){unsigned int t;float total=0.0f;
    for(t=0;t<4u;++t){DNNContext c;float e=dnn_forward(m,samples[t],&c)-samples[t][2];total+=0.5f*e*e;}
    return total*0.25f;
}
float dnn_batch_gradient(const DNNModel *m,DNNGrad *g){unsigned int t,k;float total=0.0f;
    dnn_grad_clear(g);
    for(t=0;t<4u;++t){DNNContext c;float dx[DNN_INPUTS];float e=dnn_forward(m,samples[t],&c)-samples[t][2];
        total+=0.5f*e*e;dnn_backward_add(m,&c,e,g,dx);
    }
    for(k=0;k<m->used;++k)g->g[k]*=0.25f;
    return total*0.25f;
}
float dnn_max_error(const DNNModel *m){unsigned int t;float max=0.0f;
    for(t=0;t<4u;++t){DNNContext c;float y=dnn_forward(m,samples[t],&c);
        float e=absolute(y-samples[t][2]);if(!(e<=FLT_MAX))return FLT_MAX;if(e>max)max=e;
    }return max;
}
