#ifndef DEEP_NN_H
#define DEEP_NN_H
/* Fixed-capacity C99 dense network. No heap or standard-library runtime calls.
   This test kernel supports up to 4 transformations and 51 trainable values. */
enum { DNN_MAX_LAYERS=4, DNN_MAX_WIDTH=8, DNN_MAX_PARAMS=51, DNN_INPUTS=2 };
typedef enum { DNN_UNIFORM=0, DNN_SCALED=1 } DNNInit;
typedef struct {
    unsigned int layers, dims[DNN_MAX_LAYERS+1], offset[DNN_MAX_LAYERS], used;
    float p[DNN_MAX_PARAMS];
} DNNModel;
typedef struct {
    float activation[DNN_MAX_LAYERS+1][DNN_MAX_WIDTH];
    float preactivation[DNN_MAX_LAYERS][DNN_MAX_WIDTH];
} DNNContext;
typedef struct { float g[DNN_MAX_PARAMS]; } DNNGrad;
int dnn_init(DNNModel *m, const unsigned int *dims, unsigned int layers, unsigned int seed, DNNInit mode);
float dnn_forward(const DNNModel *m, const float x[DNN_INPUTS], DNNContext *ctx);
void dnn_grad_clear(DNNGrad *g);
void dnn_backward_add(const DNNModel *m, const DNNContext *ctx,
                      float upstream, DNNGrad *g, float dx[DNN_INPUTS]);
void dnn_step(DNNModel *m, const DNNGrad *g, float lr);
float dnn_loss(const DNNModel *m);
float dnn_batch_gradient(const DNNModel *m, DNNGrad *g);
float dnn_max_error(const DNNModel *m);
#endif
