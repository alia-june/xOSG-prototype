#ifndef HQ_LESSONS_H
#define HQ_LESSONS_H

#include "holoquary.h"

/* Fixed-size, caller-owned optional service. Rules/facts are externally admitted:
   this module does not independently authenticate or verify their sources. */
#define HQ_MAX_LESSON_FACTS 8u
#define HQ_MAX_LESSON_RULES 16u
#define HQ_MAX_LESSON_ROUNDS 16u

typedef struct {
    unsigned int input_port;
    HQTruth value;          /* TRUE or FALSE; never UNKNOWN or error */
    unsigned int source_id; /* Required nonzero provenance handle, not proof */
} HQFact;

typedef struct {
    unsigned int premise_port;
    HQTruth premise_value;  /* TRUE or FALSE */
    unsigned int result_port;
    HQTruth result_value;   /* TRUE or FALSE */
    unsigned int source_id;
} HQRule;

typedef struct {
    unsigned int scope_id;  /* Application-assigned immutable context key */
    unsigned int fact_count;
    unsigned int rule_count;
    HQFact facts[HQ_MAX_LESSON_FACTS];
    HQRule rules[HQ_MAX_LESSON_RULES];
} HQLessonBank;

typedef enum {
    HQ_LESSON_STABLE = 0,       /* No further known implications in this bank */
    HQ_LESSON_EXHAUSTED = 1,    /* Bound reached; partial facts are not truth */
    HQ_LESSON_CONFLICT = 2      /* Contradictory evidence: public result UNKNOWN */
} HQLessonDisposition;

typedef struct {
    unsigned int rounds;
    unsigned int new_facts;
    unsigned int conflicts;
    unsigned int unresolved_inputs;
    HQLessonDisposition disposition;
} HQLessonTrace;

/* The bank does not mutate program or inputs. Add operations are atomic on error. */
HQStatus hq_lessons_init(HQLessonBank *bank, unsigned int scope_id);
HQStatus hq_lesson_add_fact(HQLessonBank *bank, unsigned int input_port,
                            HQTruth value, unsigned int source_id);
HQStatus hq_lesson_add_rule(HQLessonBank *bank,
                            unsigned int premise_port, HQTruth premise_value,
                            unsigned int result_port, HQTruth result_value,
                            unsigned int source_id);

/* QUICK mode remains hq_eval(), unchanged from v0.1.
   EXTENDED uses at most max_rounds synchronous rounds. Only same-scope,
   explicitly supplied facts/rules may add known input values. On conflicts or
   an incomplete bound, outputs are UNKNOWN (fail-closed). On runtime error,
   caller outputs and trace are unchanged. */
HQStatus hq_eval_extended(const HQProgram *program,
                          const HQTruth *inputs, unsigned int input_count,
                          const HQLessonBank *bank, unsigned int scope_id,
                          unsigned int max_rounds,
                          HQTruth *outputs, unsigned int output_capacity,
                          HQLessonTrace *trace);

#endif
