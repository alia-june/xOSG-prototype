#include "hq_lessons.h"

static int known(HQTruth v) { return v == HQ_TRUE || v == HQ_FALSE; }
static int valid(HQTruth v) { return known(v) || v == HQ_UNKNOWN; }
static unsigned int bit_for(HQTruth v) { return v == HQ_TRUE ? 2u : 1u; }

HQStatus hq_lessons_init(HQLessonBank *bank, unsigned int scope_id) {
    unsigned int i;
    if (bank == 0) return HQ_ERR_NULL;
    if (scope_id == 0u) return HQ_ERR_SCOPE;
    bank->scope_id = scope_id;
    bank->fact_count = 0u;
    bank->rule_count = 0u;
    for (i = 0u; i < HQ_MAX_LESSON_FACTS; ++i) {
        bank->facts[i].input_port = 0u;
        bank->facts[i].value = HQ_UNKNOWN;
        bank->facts[i].source_id = 0u;
    }
    for (i = 0u; i < HQ_MAX_LESSON_RULES; ++i) {
        bank->rules[i].premise_port = 0u;
        bank->rules[i].premise_value = HQ_UNKNOWN;
        bank->rules[i].result_port = 0u;
        bank->rules[i].result_value = HQ_UNKNOWN;
        bank->rules[i].source_id = 0u;
    }
    return HQ_OK;
}

HQStatus hq_lesson_add_fact(HQLessonBank *bank, unsigned int input_port,
                            HQTruth value, unsigned int source_id) {
    HQFact *f;
    if (bank == 0) return HQ_ERR_NULL;
    if (bank->scope_id == 0u || bank->fact_count > HQ_MAX_LESSON_FACTS ||
        bank->rule_count > HQ_MAX_LESSON_RULES) return HQ_ERR_GRAPH;
    if (input_port >= HQ_MAX_INPUTS) return HQ_ERR_REF;
    if (!known(value) || source_id == 0u) return HQ_ERR_VALUE;
    if (bank->fact_count == HQ_MAX_LESSON_FACTS) return HQ_ERR_CAPACITY;
    f = &bank->facts[bank->fact_count];
    f->input_port = input_port;
    f->value = value;
    f->source_id = source_id;
    ++bank->fact_count;
    return HQ_OK;
}

HQStatus hq_lesson_add_rule(HQLessonBank *bank,
                            unsigned int premise_port, HQTruth premise_value,
                            unsigned int result_port, HQTruth result_value,
                            unsigned int source_id) {
    HQRule *r;
    if (bank == 0) return HQ_ERR_NULL;
    if (bank->scope_id == 0u || bank->fact_count > HQ_MAX_LESSON_FACTS ||
        bank->rule_count > HQ_MAX_LESSON_RULES) return HQ_ERR_GRAPH;
    if (premise_port >= HQ_MAX_INPUTS || result_port >= HQ_MAX_INPUTS)
        return HQ_ERR_REF;
    if (!known(premise_value) || !known(result_value) || source_id == 0u)
        return HQ_ERR_VALUE;
    if (bank->rule_count == HQ_MAX_LESSON_RULES) return HQ_ERR_CAPACITY;
    r = &bank->rules[bank->rule_count];
    r->premise_port = premise_port;
    r->premise_value = premise_value;
    r->result_port = result_port;
    r->result_value = result_value;
    r->source_id = source_id;
    ++bank->rule_count;
    return HQ_OK;
}

static HQStatus check_bank(const HQLessonBank *bank, unsigned int n,
                           unsigned int scope_id) {
    unsigned int i;
    if (bank->scope_id == 0u || bank->scope_id != scope_id) return HQ_ERR_SCOPE;
    if (bank->fact_count > HQ_MAX_LESSON_FACTS ||
        bank->rule_count > HQ_MAX_LESSON_RULES) return HQ_ERR_GRAPH;
    for (i = 0u; i < bank->fact_count; ++i) {
        const HQFact *f = &bank->facts[i];
        if (f->input_port >= n) return HQ_ERR_REF;
        if (!known(f->value) || f->source_id == 0u) return HQ_ERR_VALUE;
    }
    for (i = 0u; i < bank->rule_count; ++i) {
        const HQRule *r = &bank->rules[i];
        if (r->premise_port >= n || r->result_port >= n) return HQ_ERR_REF;
        if (!known(r->premise_value) || !known(r->result_value) ||
            r->source_id == 0u) return HQ_ERR_VALUE;
    }
    return HQ_OK;
}

HQStatus hq_eval_extended(const HQProgram *program,
                          const HQTruth *inputs, unsigned int input_count,
                          const HQLessonBank *bank, unsigned int scope_id,
                          unsigned int max_rounds,
                          HQTruth *outputs, unsigned int output_capacity,
                          HQLessonTrace *trace) {
    HQTruth effective[HQ_MAX_INPUTS];
    HQTruth pending[HQ_MAX_OUTPUTS];
    HQLessonTrace t;
    unsigned int round, i, proposals[HQ_MAX_INPUTS];
    HQStatus s;
    int stable = 0;
    if (program == 0 || inputs == 0 || bank == 0 ||
        outputs == 0 || trace == 0) return HQ_ERR_NULL;
    if (max_rounds == 0u || max_rounds > HQ_MAX_LESSON_ROUNDS)
        return HQ_ERR_BUDGET;
    s = hq_validate(program);
    if (s != HQ_OK) return s;
    if (input_count != program->input_count) return HQ_ERR_INPUT_COUNT;
    if (output_capacity < program->output_count) return HQ_ERR_CAPACITY;
    for (i = 0u; i < input_count; ++i) {
        if (!valid(inputs[i])) return HQ_ERR_VALUE;
        effective[i] = inputs[i];
    }
    s = check_bank(bank, input_count, scope_id);
    if (s != HQ_OK) return s;
    t.rounds = 0u;
    t.new_facts = 0u;
    t.conflicts = 0u;
    t.unresolved_inputs = 0u;
    t.disposition = HQ_LESSON_STABLE;
    for (round = 0u; round < max_rounds; ++round) {
        unsigned int changes = 0u;
        ++t.rounds;
        for (i = 0u; i < input_count; ++i) proposals[i] = 0u;
        for (i = 0u; i < bank->fact_count; ++i) {
            const HQFact *f = &bank->facts[i];
            proposals[f->input_port] |= bit_for(f->value);
        }
        for (i = 0u; i < bank->rule_count; ++i) {
            const HQRule *r = &bank->rules[i];
            if (effective[r->premise_port] == r->premise_value)
                proposals[r->result_port] |= bit_for(r->result_value);
        }
        /* Check ALL proposals before committing any change (synchronous round). */
        for (i = 0u; i < input_count; ++i) {
            unsigned int existing = known(effective[i]) ? bit_for(effective[i]) : 0u;
            if (proposals[i] == 3u ||
                (existing != 0u && proposals[i] != 0u &&
                 proposals[i] != existing)) ++t.conflicts;
        }
        if (t.conflicts != 0u) {
            t.disposition = HQ_LESSON_CONFLICT;
            /* Conservative initial policy: any conflict blocks every export. */
            for (i = 0u; i < program->output_count; ++i)
                pending[i] = HQ_UNKNOWN;
            for (i = 0u; i < input_count; ++i)
                if (effective[i] == HQ_UNKNOWN) ++t.unresolved_inputs;
            for (i = 0u; i < program->output_count; ++i) outputs[i] = pending[i];
            *trace = t;
            return HQ_OK;
        }
        for (i = 0u; i < input_count; ++i) {
            if (effective[i] == HQ_UNKNOWN && proposals[i] != 0u) {
                effective[i] = proposals[i] == 2u ? HQ_TRUE : HQ_FALSE;
                ++changes;
                ++t.new_facts;
            }
        }
        if (changes == 0u) { stable = 1; break; }
    }
    if (!stable) t.disposition = HQ_LESSON_EXHAUSTED;
    for (i = 0u; i < input_count; ++i)
        if (effective[i] == HQ_UNKNOWN) ++t.unresolved_inputs;
    if (t.disposition == HQ_LESSON_EXHAUSTED) {
        /* A proof may be incomplete. Returning UNKNOWN is deliberately strict. */
        for (i = 0u; i < program->output_count; ++i) pending[i] = HQ_UNKNOWN;
    } else {
        s = hq_eval(program, effective, input_count,
                    pending, HQ_MAX_OUTPUTS);
        if (s != HQ_OK) return s;
    }
    for (i = 0u; i < program->output_count; ++i) outputs[i] = pending[i];
    *trace = t;
    return HQ_OK;
}
