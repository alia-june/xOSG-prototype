#include "holoquary.h"

static int hq_value_valid(HQTruth value) {
    return value == HQ_FALSE || value == HQ_TRUE || value == HQ_UNKNOWN;
}

static int hq_ref_valid(const HQProgram *p, HQRef r, unsigned int available_gates) {
    if (r.kind == HQ_REF_INPUT) return r.index < p->input_count;
    if (r.kind == HQ_REF_GATE) return r.index < available_gates;
    return 0;
}

static HQTruth hq_nand_valid(HQTruth a, HQTruth b) {
    if (a == HQ_FALSE || b == HQ_FALSE) return HQ_TRUE;
    if (a == HQ_TRUE && b == HQ_TRUE) return HQ_FALSE;
    return HQ_UNKNOWN;
}

HQStatus hq_nand(HQTruth a, HQTruth b, HQTruth *out) {
    if (out == 0) return HQ_ERR_NULL;
    if (!hq_value_valid(a) || !hq_value_valid(b)) return HQ_ERR_VALUE;
    *out = hq_nand_valid(a, b);
    return HQ_OK;
}

HQRef hq_input(unsigned int index) {
    HQRef r;
    r.kind = HQ_REF_INPUT;
    r.index = index;
    return r;
}

HQStatus hq_init(HQProgram *p, unsigned int input_count) {
    unsigned int i;
    if (p == 0) return HQ_ERR_NULL;
    if (input_count == 0u || input_count > HQ_MAX_INPUTS) return HQ_ERR_INPUT_COUNT;
    p->input_count = input_count;
    p->gate_count = 0u;
    p->output_count = 0u;
    for (i = 0u; i < HQ_MAX_GATES; ++i) {
        p->gates[i].a = hq_input(0u);
        p->gates[i].b = hq_input(0u);
    }
    for (i = 0u; i < HQ_MAX_OUTPUTS; ++i) p->outputs[i] = hq_input(0u);
    return HQ_OK;
}

HQStatus hq_add_nand(HQProgram *p, HQRef a, HQRef b, HQRef *out_ref) {
    HQRef next;
    if (p == 0 || out_ref == 0) return HQ_ERR_NULL;
    if (p->input_count == 0u || p->input_count > HQ_MAX_INPUTS ||
        p->gate_count > HQ_MAX_GATES || p->output_count > HQ_MAX_OUTPUTS)
        return HQ_ERR_GRAPH;
    if (!hq_ref_valid(p, a, p->gate_count) ||
        !hq_ref_valid(p, b, p->gate_count)) return HQ_ERR_REF;
    if (p->gate_count == HQ_MAX_GATES) return HQ_ERR_CAPACITY;
    next.kind = HQ_REF_GATE;
    next.index = p->gate_count;
    p->gates[p->gate_count].a = a;
    p->gates[p->gate_count].b = b;
    ++p->gate_count;
    *out_ref = next;
    return HQ_OK;
}

HQStatus hq_export(HQProgram *p, HQRef source) {
    if (p == 0) return HQ_ERR_NULL;
    if (p->input_count == 0u || p->input_count > HQ_MAX_INPUTS ||
        p->gate_count > HQ_MAX_GATES || p->output_count > HQ_MAX_OUTPUTS)
        return HQ_ERR_GRAPH;
    if (!hq_ref_valid(p, source, p->gate_count)) return HQ_ERR_REF;
    if (p->output_count == HQ_MAX_OUTPUTS) return HQ_ERR_CAPACITY;
    p->outputs[p->output_count++] = source;
    return HQ_OK;
}

HQStatus hq_validate(const HQProgram *p) {
    unsigned int i;
    if (p == 0) return HQ_ERR_NULL;
    if (p->input_count == 0u || p->input_count > HQ_MAX_INPUTS ||
        p->gate_count > HQ_MAX_GATES || p->output_count > HQ_MAX_OUTPUTS)
        return HQ_ERR_GRAPH;
    for (i = 0u; i < p->gate_count; ++i) {
        if (!hq_ref_valid(p, p->gates[i].a, i) ||
            !hq_ref_valid(p, p->gates[i].b, i)) return HQ_ERR_REF;
    }
    if (p->output_count == 0u) return HQ_ERR_NO_OUTPUT;
    for (i = 0u; i < p->output_count; ++i) {
        if (!hq_ref_valid(p, p->outputs[i], p->gate_count)) return HQ_ERR_REF;
    }
    return HQ_OK;
}

HQStatus hq_emit_xor(HQProgram *p, HQRef a, HQRef b, HQRef *out_ref) {
    HQRef t, left, right, result;
    if (p == 0 || out_ref == 0) return HQ_ERR_NULL;
    if (p->input_count == 0u || p->input_count > HQ_MAX_INPUTS ||
        p->gate_count > HQ_MAX_GATES || p->output_count > HQ_MAX_OUTPUTS)
        return HQ_ERR_GRAPH;
    if (!hq_ref_valid(p, a, p->gate_count) ||
        !hq_ref_valid(p, b, p->gate_count)) return HQ_ERR_REF;
    if (HQ_MAX_GATES - p->gate_count < 4u) return HQ_ERR_CAPACITY;
    /* Preflight guarantees every append below succeeds. */
    (void)hq_add_nand(p, a, b, &t);
    (void)hq_add_nand(p, a, t, &left);
    (void)hq_add_nand(p, b, t, &right);
    (void)hq_add_nand(p, left, right, &result);
    *out_ref = result;
    return HQ_OK;
}

static HQTruth hq_read_ref(HQRef r, const HQTruth *inputs, const HQTruth *nodes) {
    return r.kind == HQ_REF_INPUT ? inputs[r.index] : nodes[r.index];
}

HQStatus hq_eval(const HQProgram *p,
                 const HQTruth *inputs, unsigned int input_count,
                 HQTruth *outputs, unsigned int output_capacity) {
    HQTruth nodes[HQ_MAX_GATES];
    HQTruth pending[HQ_MAX_OUTPUTS];
    HQStatus status;
    unsigned int i;
    if (p == 0 || inputs == 0 || outputs == 0) return HQ_ERR_NULL;
    status = hq_validate(p);
    if (status != HQ_OK) return status;
    if (input_count != p->input_count) return HQ_ERR_INPUT_COUNT;
    if (output_capacity < p->output_count) return HQ_ERR_CAPACITY;
    for (i = 0u; i < p->input_count; ++i) {
        if (!hq_value_valid(inputs[i])) return HQ_ERR_VALUE;
    }
    for (i = 0u; i < p->gate_count; ++i) {
        HQTruth a = hq_read_ref(p->gates[i].a, inputs, nodes);
        HQTruth b = hq_read_ref(p->gates[i].b, inputs, nodes);
        nodes[i] = hq_nand_valid(a, b);
    }
    for (i = 0u; i < p->output_count; ++i) {
        pending[i] = hq_read_ref(p->outputs[i], inputs, nodes);
    }
    for (i = 0u; i < p->output_count; ++i) outputs[i] = pending[i];
    return HQ_OK;
}
