#ifndef HOLOQUARY_H
#define HOLOQUARY_H

/* Holoquary v0.2: original v0.1 API retained; optional lessons in separate module. */
#define HQ_MAX_INPUTS 8u
#define HQ_MAX_GATES 16u
#define HQ_MAX_OUTPUTS 4u

typedef enum {
    HQ_FALSE = 0,
    HQ_TRUE = 1,
    HQ_UNKNOWN = 2
} HQTruth;

typedef enum {
    HQ_OK = 0,
    HQ_ERR_NULL,
    HQ_ERR_CAPACITY,
    HQ_ERR_INPUT_COUNT,
    HQ_ERR_VALUE,
    HQ_ERR_REF,
    HQ_ERR_GRAPH,
    HQ_ERR_NO_OUTPUT,
    HQ_ERR_SCOPE,
    HQ_ERR_BUDGET
} HQStatus;

typedef enum {
    HQ_REF_INPUT = 0,
    HQ_REF_GATE = 1
} HQRefKind;

typedef struct {
    HQRefKind kind;
    unsigned int index;
} HQRef;

typedef struct {
    HQRef a;
    HQRef b;
} HQNandGate;

typedef struct {
    unsigned int input_count;
    unsigned int gate_count;
    unsigned int output_count;
    HQNandGate gates[HQ_MAX_GATES];
    HQRef outputs[HQ_MAX_OUTPUTS];
} HQProgram;

/* Direct primitive. A computation error is NOT a truth value. */
HQStatus hq_nand(HQTruth a, HQTruth b, HQTruth *out);

/* Builder. Each gate references input ports or earlier gates, enforcing a DAG. */
HQStatus hq_init(HQProgram *p, unsigned int input_count);
HQRef hq_input(unsigned int index);
HQStatus hq_add_nand(HQProgram *p, HQRef a, HQRef b, HQRef *out_ref);
HQStatus hq_export(HQProgram *p, HQRef source);
HQStatus hq_validate(const HQProgram *p);

/* Template expansion: XOR = exactly four NAND gates. On failure p is unchanged. */
HQStatus hq_emit_xor(HQProgram *p, HQRef a, HQRef b, HQRef *out_ref);

/* Caller owns buffers. On error, output values are NOT modified. */
HQStatus hq_eval(const HQProgram *p,
                 const HQTruth *inputs, unsigned int input_count,
                 HQTruth *outputs, unsigned int output_capacity);

#endif
