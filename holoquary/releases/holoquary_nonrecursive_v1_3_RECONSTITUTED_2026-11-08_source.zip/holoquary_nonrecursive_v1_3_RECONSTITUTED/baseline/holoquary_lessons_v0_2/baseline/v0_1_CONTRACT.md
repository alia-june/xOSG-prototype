# Holoquary v0.1 contracts (proposed; not canonical locks)

1. **Truth type:** `HQ_FALSE`, `HQ_TRUE`, `HQ_UNKNOWN` are the only valid computational values.
2. **Status type:** `HQ_OK` and the error statuses are separate from truth; no numerical coercion from error to unknown.
3. **Atomic operator:** `NAND` is strong-Kleene NAND: FALSE dominates conjunction; negate the resulting AND.
4. **Port boundary:** An `HQRef` explicitly names either an external input or an earlier gate output.
5. **Static graph:** Gates must reference earlier gate indices; cycles and unresolved references are structurally invalid.
6. **Local state:** Nodes are recalculated into call-local scratch on every evaluation, rather than retaining values across calls.
7. **Output atomicity:** Any evaluation error leaves the caller output array unchanged; no partially published outputs.
8. **Builder atomicity:** Insufficient capacity or invalid inputs to `hq_emit_xor` do not append any gates.
9. **Compositional semantics:** A NAND DAG is evaluated in index order. Expanded XOR and nested XOR must agree with independent strong-Kleene truth tables.
10. **Non-authority:** A logical result is not evidence that a source observation is true. Independent provenance and truth-attestation are outside the core.
11. **Explicit scope:** No fuzzy degrees, probabilities, contradictions-as-fourth-value, rule search, recursion, neural training, or physical bare-metal verification in v0.1.
12. **Semantic distinction:** Same-signal duplication under K3 does not imply Boolean excluded-middle/tautological simplifications for `UNKNOWN`.

## Error reporting

- `HQ_ERR_NULL`: required pointer omitted.
- `HQ_ERR_INPUT_COUNT`: unsupported or wrong number of runtime inputs.
- `HQ_ERR_CAPACITY`: bounded nodes/exports/output buffer exceeded.
- `HQ_ERR_VALUE`: an input truth enum is invalid.
- `HQ_ERR_REF`: source port is invalid or creates an illegal forward/self-dependency.
- `HQ_ERR_GRAPH`: graph header/capacity fields corrupted.
- `HQ_ERR_NO_OUTPUT`: evaluation attempted before exporting a result.

## Deferred design questions

- Named composite definitions and multiple explicit instances versus template expansion.
- Cross-program typed port binding (not automatically implied by structural containment).
- Provenance, immutable identity, versioning, and external attestation.
- Additional semantics for contradictory evidence (e.g., Belnap four-valued), a *separate* extension rather than overloading UNKNOWN.
- Fuzzy truth membership as a distinct typed module with documented connectives.
- Timing/state registers for recurrent or sequential logic.
- Host-generated static execution plans for target hardware and measured performance.
