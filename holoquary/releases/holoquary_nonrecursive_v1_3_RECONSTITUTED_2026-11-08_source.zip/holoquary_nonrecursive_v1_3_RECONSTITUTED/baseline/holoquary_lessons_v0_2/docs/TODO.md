# Follow-on tasks — not implemented

- [ ] Independent lesson source authentication/admission mechanism, including authorization, audit and revocation.
- [ ] Explicit lesson validity interval, versioned scope, stale-evidence handling and proof lineage.
- [ ] Dependency-aware conflict propagation (v0.2 conservatively invalidates all exports).
- [ ] Independent oracle tests for multi-output graphs; additional random rule-graph differential tests.
- [ ] Persistent storage and recoverable lesson ledger with crash-safe receipts.
- [ ] Optional system-level recovery controller, no privilege increase on failed evaluations.
- [ ] True extended research/lesson mining or theorem proving: not claimed by simple Horn-like implication closure.
- [ ] Integration adapter between separately typed neural predictions and logical evidence; no implicit truth promotion.
- [ ] Larger static graph compiler and target-specific freestanding boot/runtime test.
- [ ] Benchmark latency and memory on an identified processor; host object size is not firmware size.
