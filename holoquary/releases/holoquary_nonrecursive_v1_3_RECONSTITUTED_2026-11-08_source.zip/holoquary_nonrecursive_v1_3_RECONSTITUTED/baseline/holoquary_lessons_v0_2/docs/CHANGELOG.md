# Changelog

## 0.2 — optional LESSONS prototype

- Preserves v0.1 NAND, three-valued truth, composition and quick evaluation code.
- Appends `HQ_ERR_SCOPE` and `HQ_ERR_BUDGET` to the original error enum without renumbering earlier values.
- Adds bounded, static, caller-owned contextual lesson bank with source handles and two record kinds (facts and conditional implications).
- Adds extended evaluator with synchronous rule rounds and explicit stable/exhausted/conflict traces.
- Makes QUICK mode fully independent of LESSONS.
- Implements conservative fail-closed public UNKNOWN for contradictions and incomplete iteration.
- Adds context isolation and a v0.1 compatibility regression suite.

The term TILT is superseded in the proposed architecture by LESSONS. Numeric weighting semantics are not imported implicitly.
