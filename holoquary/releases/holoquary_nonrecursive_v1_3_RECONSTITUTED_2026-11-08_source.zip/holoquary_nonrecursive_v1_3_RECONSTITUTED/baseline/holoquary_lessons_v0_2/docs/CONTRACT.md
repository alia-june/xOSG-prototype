# Holoquary-001 v0.2 — candidate LESSONS contract

**Status:** GENERATED PROPOSAL / TESTED PROTOTYPE; not a canonical lock.

## Scope

An atomic NAND evaluator remains deterministic. The optional LESSONS service operates on immutable input snapshots and admitted same-scope conditional rules and contextual facts. It is not an independent source of truth. `hq_eval` is the unchanged QUICK behavior.

## Definitions

`TRUE`, `FALSE`, `UNKNOWN`: values in the existing strong-Kleene NAND logic. Invalid caller representations return an error, not a fourth truth value.

`HQStatus`: execution/validation result. `HQ_OK` means the evaluation routine completed within its declared semantics; it does not mean a TRUE proposition or valid source evidence.

`HQ_LESSON_STABLE`: a fixed point was observed. It may contain unresolved inputs and UNKNOWN results.

`HQ_LESSON_EXHAUSTED`: additional permitted rule application could still be required; fail closed to UNKNOWN, without calling it a runtime failure.

`HQ_LESSON_CONFLICT`: mutually contradictory admitted constraints or conflict with already-known input. v0.2 fails closed on all outputs, preserving rule/fact source IDs in the bank.

`source_id`: a nonzero external reference supplied by the caller; it is not attestation. `scope_id`: exact contextual matching key, not a secret, user identity, credential or authority grant.

## Algorithmic specification

1. Validate pointers, program, supplied input values, lesson bank, scope and budget. On any error, do not mutate output or trace buffers.
2. Copy the input array to bounded local storage. The given definite TRUE/FALSE inputs are immutable for this invocation.
3. For each round, using only the previous round's input snapshot, gather each externally asserted fact and each rule whose definite premise matches.
4. If a port receives opposing proposed values, or a proposal opposes an already-known input, stop and return UNKNOWN for each output with `HQ_LESSON_CONFLICT`.
5. Otherwise add newly determined values to the local snapshot. If nothing changes, mark `HQ_LESSON_STABLE` and evaluate the compiled Holoquary graph on the local snapshot.
6. If the bounded loop stops immediately following a change, mark `HQ_LESSON_EXHAUSTED`; the public output is UNKNOWN, even if some partial outputs could be computed.
7. Commit the outputs and trace atomically after successful completion. Do not commit new facts to the bank; all additions are per-evaluation only.

## Invariants

- QUICK is independent of LESSONS.
- The logic truth table cannot be changed by LESSONS.
- Lessons are never silently applied across context-key boundaries.
- False/true source data cannot be elevated to authority by mere execution.
- Known inputs cannot be overwritten by asserted rules or facts; conflict is visible.
- Unstable or conflicting derivations cannot assert a definite exported result.
- Input ordering does not change results for an identical set of rules.
- Source records and contradictions are retained in the caller-owned bank; no recovery action erases evidence.
- No repeated evaluation can guarantee eventual TRUE or FALSE without new applicable evidence or rules.

## Boundary decisions intentionally open

Authentication, admission governance, typed evidence weights, uncertainty model, staleness and revision control, source retraction, automatic lesson mining, durable storage, recovery policy, dependency-aware conflict tracking, parallel inference and hardware deployment remain open.
