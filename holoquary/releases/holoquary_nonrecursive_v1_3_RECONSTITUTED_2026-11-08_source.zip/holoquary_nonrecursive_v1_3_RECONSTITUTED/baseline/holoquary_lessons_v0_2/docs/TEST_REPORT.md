# Holoquary v0.2 — executed test report

All results below come from execution in the current hosted x86-64 container environment. They are not physical bare-metal execution or independent attestation.

## Functional results

- Preserved v0.1 tests: `OVERALL=PASS`, 20,191 assertions.
- Extended LESSONS tests: `LESSONS_TESTS=PASS`, 31,175 assertions.
- All 9 ternary XOR inputs agree with the original QUICK evaluator for an empty lesson bank.
- Two-step chain resolves at 3 rounds; max 1 and 2 rounds conservatively return UNKNOWN with BUDGET disposition.
- Scope mismatch produces runtime error without modifying outputs/trace.
- Known caller inputs are never overwritten; contradictory rules/facts preserve uncertainty and report conflict.
- Saturation, source-ID validation, malformed graphs, invalid inputs and zero/excess budgets tested.
- 9,000 repeated contextual evaluations agree with the reference result.
- Rule insertion order does not alter the tested fixed-point result; consistent rule cycles stabilize; contradictory cycles report conflict.
- Example demonstration prints QUICK UNKNOWN and EXTENDED UNKNOWN/UNKNOWN/FALSE for budgets 1/2/3.

## Compilation and numeric footprint

- GCC C99 with `-O0`, `-O2`, warnings-as-errors: PASS for tested LESSONS suite.
- Clang 17 C99 with `-O0`, `-O2`, warnings-as-errors: PASS for tested LESSONS suite.
- GCC UBSan + array-bounds sanitizer on new suite: PASS for executed paths.
- GCC freestanding object compilation of both source modules: PASS.
- Relocatable linking of both modules: PASS; `nm -u` on combined core reports **0** unresolved symbols in the tested host build.
- Host `sizeof(HQProgram)=300`, `sizeof(HQLessonBank)=428`, `sizeof(HQLessonTrace)=20` bytes (on tested x86-64 ABI). Does not include stack/scratch/code.
- Host combined freestanding object `size` reported **4,193 bytes `.text`**, 0 bytes `.data`, 0 bytes `.bss` (object sections, not firmware size).

## Limitations

- The module cannot verify that caller-submitted lessons are true, admitted, independent, current, or authentic; nonzero source handles do not establish such properties.
- Its lessons are explicit facts and conditional rules; no autonomous experience mining or machine learning is claimed.
- Exhaustive graph- and rule-space validation is not claimed; testing is bounded.
- Conservative whole-output UNKNOWN on any detected rule contradiction is an explicit policy, not dependency-aware conflict handling.
- The absence of external symbols in a host object does not prove a complete firmware image boots or executes on an embedded target.
- No authenticated lesson ledger, durable recovery, physical processor benchmark, or security guarantee established.
