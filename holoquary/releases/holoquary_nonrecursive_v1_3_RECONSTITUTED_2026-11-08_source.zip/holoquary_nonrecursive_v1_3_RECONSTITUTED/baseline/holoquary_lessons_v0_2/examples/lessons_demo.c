#include "hq_lessons.h"
#include <stdio.h>

static const char *name(HQTruth v) {
    if (v == HQ_TRUE) return "TRUE";
    if (v == HQ_FALSE) return "FALSE";
    return "UNKNOWN";
}

int main(void) {
    HQProgram program;
    HQLessonBank bank;
    HQLessonTrace trace;
    HQRef y;
    HQTruth input[3] = {HQ_TRUE,HQ_UNKNOWN,HQ_UNKNOWN};
    HQTruth output[1];
    unsigned int budget;
    if (hq_init(&program,3u)!=HQ_OK ||
        hq_emit_xor(&program,hq_input(0u),hq_input(2u),&y)!=HQ_OK ||
        hq_export(&program,y)!=HQ_OK ||
        hq_lessons_init(&bank,9u)!=HQ_OK ||
        hq_lesson_add_rule(&bank,0u,HQ_TRUE,1u,HQ_FALSE,101u)!=HQ_OK ||
        hq_lesson_add_rule(&bank,1u,HQ_FALSE,2u,HQ_TRUE,102u)!=HQ_OK)
        return 1;
    if(hq_eval(&program,input,3u,output,1u)!=HQ_OK) return 2;
    printf("QUICK: %s\n",name(output[0]));
    for (budget=1u;budget<=3u;++budget) {
        if(hq_eval_extended(&program,input,3u,&bank,9u,budget,
                            output,1u,&trace)!=HQ_OK) return 3;
        printf("EXTENDED rounds_max=%u => %s (%s, new_facts=%u, rounds=%u)\n",
               budget,name(output[0]),
               trace.disposition==HQ_LESSON_STABLE?"STABLE":
               trace.disposition==HQ_LESSON_EXHAUSTED?"BUDGET":"CONFLICT",
               trace.new_facts,trace.rounds);
    }
    /* This program demonstrates conditional reasoning under GIVEN rule premises;
       it does not certify that the source claims are true. */
    return 0;
}
