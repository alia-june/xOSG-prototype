# Holoquary-001 v0.2 — optional LESSONS proof of concept

**Status:** hosted C99 proof of concept, freestanding-object compilation tested on host. Not booted on bare-metal hardware. The Holoquary v0.1 NAND logic and `hq_eval` entry point are preserved. This is a proposed interface, not a canonical lesson-learning policy.

## Core architecture

- `src/holoquary.h`, `src/holoquary.c`: original three-valued NAND, static DAG builder, four-NAND XOR composite. `HQ_OK` indicates computation completed; an `HQ_UNKNOWN` output is not an execution error.
- `src/hq_lessons.h`, `src/hq_lessons.c`: **optional**, caller-owned lesson bank and an extended evaluator. No heap allocation or standard-library use in either module.
- `QUICK`: call `hq_eval(...)` directly. Does not consult the lesson bank.
- `EXTENDED`: call `hq_eval_extended(...)` with an exact nonzero scope key, same-scope bank, explicit budget, and caller-owned result/trace. It propagates admitted facts and rules in synchronous rounds until a fixed point, contradiction, or budget exhaustion.
- `ERROR`: an `HQStatus` non-OK return is a runtime or validation failure. `HQ_LESSON_CONFLICT` and `HQ_LESSON_EXHAUSTED` are **completed, but non-conclusive** logical evaluations that return `UNKNOWN` under the conservative policy.

**Provenance is not attestation:** Each fact/rule needs a nonzero `source_id`. This is an opaque provenance handle provided by the caller, **not proof of authenticity, accuracy, approval, or independent attestation**. The caller is responsible for verifying and authorizing lessons before inserting them. Scope ID is a matching key, not access control, authentication or an authorization token.

**No automatic truth-by-repetition:** A rule may produce a new value only from a definite matching premise. Neither repeating an evaluation nor increasing its computation budget invents additional rules, evidence, or facts. The result can remain UNKNOWN forever. A positive derived result is valid *relative to the admitted premises and logic*, not necessarily an externally established fact.

## Build and execute

```sh
make test           # original v0.1 regression suite + new lessons tests
make demo           # 3-input, two-step rule chain under 1/2/3 round budgets
make freestanding   # freestanding C objects + combined-object external-symbol check
make sanitized      # GCC UBSan/bounds checks of lessons suite
```

On Windows, use MinGW-w64 GCC with the same sources and commands, or compile directly:

```sh
gcc -std=c99 -O2 -Wall -Wextra -Wpedantic -Werror -Isrc \
    src/holoquary.c src/hq_lessons.c tests/test_lessons.c -o test_lessons.exe
```

For bare-metal integration, include both `src/` implementation files (or only `holoquary.c` for QUICK), own their buffers, and supply startup/linker/runtime support appropriate to the device. No physical target has been specified or tested.

## Demonstrated evolution

The example answers `XOR(A,C)` given `A=TRUE`, `B=UNKNOWN`, `C=UNKNOWN`, with externally admitted rules `A=TRUE ⇒ B=FALSE` and `B=FALSE ⇒ C=TRUE`.

| Call | Output | Trace |
|---|---|---|
| QUICK | UNKNOWN | No lessons consulted |
| EXTENDED, max 1 round | UNKNOWN | One new fact; budget exhausted |
| EXTENDED, max 2 rounds | UNKNOWN | Two new facts; closure not yet verified |
| EXTENDED, max 3 rounds | FALSE | Two new facts; fixed point confirmed |

The third pass intentionally checks that implications newly activated by the second pass do not conflict. Exhaustion returns UNKNOWN even if a partial derivation could already produce a definitive output. The original caller inputs remain unchanged.

## Failure and disagreement semantics

| Situation | `HQStatus` | Logical output | Trace |
|---|---|---|---|
| Valid evaluation with definite result | `HQ_OK` | TRUE/FALSE | STABLE |
| Valid evaluation without enough information | `HQ_OK` | UNKNOWN | STABLE |
| Contextual contradictions | `HQ_OK` | UNKNOWN | CONFLICT |
| Budget exhausted before fixed-point check | `HQ_OK` | UNKNOWN | EXHAUSTED |
| Bad graph, invalid value, scope mismatch, etc. | Error code | Output buffer unchanged | Trace unchanged |

All contradictions in v0.2 block **all** exported outputs, not just those transitively dependent on the contradictory slot. This is deliberately conservative and can be refined after dependency-aware conflict tracing is implemented and tested.

## Constraints and non-goals

- Existing program limits: 8 input ports, 16 NAND gates, 4 outputs. Optional lessons bank: 8 facts, 16 rules, up to 16 evaluation rounds. The caller chooses a lower budget when necessary.
- All lesson facts and rule consequences are Boolean definite values (TRUE/FALSE). UNKNOWN cannot be inserted as a fact, and an execution error is not a logical premise.
- Inputs are not silently overwritten; conflicting admitted facts/rules lead to UNKNOWN with conflict trace.
- Rule evaluation is order-independent by design: all proposals in a round are computed from the previous round's input snapshot.
- This is monotonic fixed-point inference over an externally supplied rule set; it is **not automatic lesson extraction, statistical training, predictive coding, fuzzy logic, or a universal theorem prover**.
- No persistence, digital signatures, lesson revocation, automated source authentication, dependency-specific contradiction propagation, general logical backward chaining, dynamic storage, or autonomous recovery actions yet.
- ERROR detection is mandatory at API boundaries; *recovery* remains optional at a higher controller layer and is not implemented here.

## Project files

- `docs/CONTRACT.md` — formal proposed protocol and scope/authority boundaries.
- `docs/TEST_REPORT.md` — verified testing matrix, diagnostics, limitations.
- `docs/ERROR_LOG.md` — observed implementation issues only (not hypothetical bugs).
- `docs/TODO.md` — follow-on hardening and optional recovery.
- `baseline/v0_1_CONTRACT.md` — preserved source contract, unmodified.
