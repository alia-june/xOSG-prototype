#include "holoquary.h"
#include <stdio.h>
#include <stdlib.h>

static unsigned long checks = 0ul;
#define CHECK(x) do { ++checks; if (!(x)) { \
    fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #x); exit(1); \
} } while (0)

static HQTruth reference_nand(HQTruth a, HQTruth b) {
    if (a == HQ_FALSE || b == HQ_FALSE) return HQ_TRUE;
    if (a == HQ_UNKNOWN || b == HQ_UNKNOWN) return HQ_UNKNOWN;
    return HQ_FALSE;
}

static HQTruth reference_xor(HQTruth a, HQTruth b) {
    if (a == HQ_UNKNOWN || b == HQ_UNKNOWN) return HQ_UNKNOWN;
    return a == b ? HQ_FALSE : HQ_TRUE;
}

static void primitives(void) {
    unsigned int a, b;
    HQTruth result = HQ_UNKNOWN;
    for (a = 0u; a < 3u; ++a) for (b = 0u; b < 3u; ++b) {
        CHECK(hq_nand((HQTruth)a, (HQTruth)b, &result) == HQ_OK);
        CHECK(result == reference_nand((HQTruth)a, (HQTruth)b));
    }
    result = HQ_TRUE;
    CHECK(hq_nand((HQTruth)7, HQ_FALSE, &result) == HQ_ERR_VALUE);
    CHECK(result == HQ_TRUE);
    CHECK(hq_nand(HQ_TRUE, HQ_FALSE, 0) == HQ_ERR_NULL);
}

static void xor_program(HQProgram *p) {
    HQRef result;
    CHECK(hq_init(p, 2u) == HQ_OK);
    CHECK(hq_emit_xor(p, hq_input(0u), hq_input(1u), &result) == HQ_OK);
    CHECK(hq_export(p, result) == HQ_OK);
    CHECK(p->gate_count == 4u);
    CHECK(p->output_count == 1u);
    CHECK(hq_validate(p) == HQ_OK);
}

static void xor_exhaustive(void) {
    HQProgram p;
    HQTruth in[2], out[1];
    unsigned int a, b;
    xor_program(&p);
    for (a = 0u; a < 3u; ++a) for (b = 0u; b < 3u; ++b) {
        in[0] = (HQTruth)a;
        in[1] = (HQTruth)b;
        out[0] = HQ_UNKNOWN;
        CHECK(hq_eval(&p, in, 2u, out, 1u) == HQ_OK);
        CHECK(out[0] == reference_xor(in[0], in[1]));
    }
    puts("XOR: 4 NAND gates; all 9 ternary inputs pass");
}

static void nesting_exhaustive(void) {
    HQProgram p;
    HQRef ab, abc;
    HQTruth in[3], out[2];
    unsigned int a, b, c;
    CHECK(hq_init(&p, 3u) == HQ_OK);
    CHECK(hq_emit_xor(&p, hq_input(0u), hq_input(1u), &ab) == HQ_OK);
    CHECK(hq_emit_xor(&p, ab, hq_input(2u), &abc) == HQ_OK);
    CHECK(hq_export(&p, ab) == HQ_OK);
    CHECK(hq_export(&p, abc) == HQ_OK);
    CHECK(p.gate_count == 8u);
    for (a=0u; a<3u; ++a) for (b=0u; b<3u; ++b) for (c=0u; c<3u; ++c) {
        in[0]=(HQTruth)a;
        in[1]=(HQTruth)b;
        in[2]=(HQTruth)c;
        CHECK(hq_eval(&p, in, 3u, out, 2u) == HQ_OK);
        CHECK(out[0] == reference_xor(in[0], in[1]));
        CHECK(out[1] == reference_xor(reference_xor(in[0], in[1]), in[2]));
    }
    puts("NESTED XOR: 8 NAND gates; all 27 ternary inputs pass");
}

static void invalid_operations(void) {
    HQProgram p;
    HQRef result, ref_guard;
    HQTruth in[2] = {HQ_TRUE, HQ_FALSE};
    HQTruth out[HQ_MAX_OUTPUTS] = {HQ_TRUE, HQ_TRUE, HQ_TRUE, HQ_TRUE};
    unsigned int i;
    CHECK(hq_init(0,2u) == HQ_ERR_NULL);
    CHECK(hq_init(&p,0u) == HQ_ERR_INPUT_COUNT);
    CHECK(hq_init(&p,HQ_MAX_INPUTS+1u) == HQ_ERR_INPUT_COUNT);
    CHECK(hq_init(&p,2u) == HQ_OK);
    CHECK(hq_validate(&p) == HQ_ERR_NO_OUTPUT);
    CHECK(hq_export(&p, hq_input(2u)) == HQ_ERR_REF);
    CHECK(hq_add_nand(&p,hq_input(0u),hq_input(2u),&result) == HQ_ERR_REF);
    CHECK(p.gate_count == 0u);
    CHECK(hq_emit_xor(&p,hq_input(0u),hq_input(99u),&result) == HQ_ERR_REF);
    CHECK(p.gate_count == 0u);
    CHECK(hq_add_nand(&p,hq_input(0u),(HQRef){HQ_REF_GATE,0u},&result)==HQ_ERR_REF);
    CHECK(hq_emit_xor(&p,hq_input(0u),hq_input(1u),&result)==HQ_OK);
    CHECK(hq_export(&p,result)==HQ_OK);
    for(i=0u;i<HQ_MAX_OUTPUTS-1u;++i) CHECK(hq_export(&p,hq_input(0u))==HQ_OK);
    CHECK(hq_export(&p,hq_input(0u))==HQ_ERR_CAPACITY);
    CHECK(hq_eval(&p,in,2u,out,3u)==HQ_ERR_CAPACITY);
    for(i=0u;i<HQ_MAX_OUTPUTS;++i) CHECK(out[i]==HQ_TRUE);
    in[0]=(HQTruth)12;
    CHECK(hq_eval(&p,in,2u,out,HQ_MAX_OUTPUTS)==HQ_ERR_VALUE);
    for(i=0u;i<HQ_MAX_OUTPUTS;++i) CHECK(out[i]==HQ_TRUE);
    in[0]=HQ_TRUE;
    CHECK(hq_eval(&p,in,1u,out,HQ_MAX_OUTPUTS)==HQ_ERR_INPUT_COUNT);
    for(i=0u;i<HQ_MAX_OUTPUTS;++i) CHECK(out[i]==HQ_TRUE);
    p.gates[0].a.kind = HQ_REF_GATE;
    p.gates[0].a.index = 0u; /* forged self-cycle */
    CHECK(hq_validate(&p)==HQ_ERR_REF);
    CHECK(hq_eval(&p,in,2u,out,HQ_MAX_OUTPUTS)==HQ_ERR_REF);
    for(i=0u;i<HQ_MAX_OUTPUTS;++i) CHECK(out[i]==HQ_TRUE);
    /* Saturated builder must fail without partial four-node expansion. */
    CHECK(hq_init(&p,2u)==HQ_OK);
    for(i=0u;i<HQ_MAX_GATES-3u;++i) {
        CHECK(hq_add_nand(&p,hq_input(0u),hq_input(1u),&result)==HQ_OK);
    }
    ref_guard.kind=HQ_REF_INPUT; ref_guard.index=87u;
    CHECK(hq_emit_xor(&p,hq_input(0u),hq_input(1u),&ref_guard)==HQ_ERR_CAPACITY);
    CHECK(p.gate_count==HQ_MAX_GATES-3u);
    CHECK(ref_guard.kind==HQ_REF_INPUT && ref_guard.index==87u);
    for(i=p.gate_count;i<HQ_MAX_GATES;++i) {
        CHECK(hq_add_nand(&p,hq_input(0u),hq_input(1u),&result)==HQ_OK);
    }
    CHECK(hq_add_nand(&p,hq_input(0u),hq_input(1u),&result)==HQ_ERR_CAPACITY);
    puts("VALIDATION: invalid inputs, forged cycle, capacity, atomic builder pass");
}

static void reproducible_fuzz(void) {
    unsigned int n;
    unsigned int seed = 0xC0FFEEu;
    HQProgram p;
    HQRef a,b,r;
    HQTruth in[3], out[1];
    for(n=0u;n<4000u;++n) {
        seed=seed*1664525u+1013904223u;
        CHECK(hq_init(&p,3u)==HQ_OK);
        a=hq_input(seed%3u);
        seed=seed*1664525u+1013904223u;
        b=hq_input(seed%3u);
        CHECK(hq_add_nand(&p,a,b,&r)==HQ_OK);
        CHECK(hq_export(&p,r)==HQ_OK);
        seed=seed*1664525u+1013904223u; in[0]=(HQTruth)(seed%3u);
        seed=seed*1664525u+1013904223u; in[1]=(HQTruth)(seed%3u);
        seed=seed*1664525u+1013904223u; in[2]=(HQTruth)(seed%3u);
        CHECK(hq_eval(&p,in,3u,out,1u)==HQ_OK);
        CHECK(out[0]==reference_nand(in[a.index],in[b.index]));
    }
    puts("FUZZ: 4,000 deterministic one-gate compositions pass");
}

int main(void) {
    primitives();
    xor_exhaustive();
    nesting_exhaustive();
    invalid_operations();
    reproducible_fuzz();
    printf("OVERALL=PASS checks=%lu\n",checks);
    printf("HOST_SIZES bytes program=%lu gate=%lu ref=%lu truth=%lu\n",
           (unsigned long)sizeof(HQProgram),
           (unsigned long)sizeof(HQNandGate),
           (unsigned long)sizeof(HQRef),
           (unsigned long)sizeof(HQTruth));
    return 0;
}
