#include "hq_lessons.h"
#include <stdio.h>
#include <stdlib.h>

static unsigned long checks = 0ul;
#define CHECK(expr) do { ++checks; if (!(expr)) { \
    fprintf(stderr,"FAIL %s:%d %s\n",__FILE__,__LINE__,#expr); exit(1); \
} } while(0)

static HQProgram program_xor(unsigned int count, unsigned int a, unsigned int b) {
    HQProgram p;
    HQRef r;
    CHECK(hq_init(&p, count) == HQ_OK);
    CHECK(hq_emit_xor(&p, hq_input(a), hq_input(b), &r) == HQ_OK);
    CHECK(hq_export(&p, r) == HQ_OK);
    return p;
}

static void empty_bank_equals_quick(void) {
    HQProgram p = program_xor(2u, 0u, 1u);
    HQLessonBank bank;
    HQLessonTrace trace;
    HQTruth input[2], quick[1], extended[1];
    unsigned int i, j;
    CHECK(hq_lessons_init(&bank, 101u) == HQ_OK);
    for (i = 0u; i < 3u; ++i) for (j = 0u; j < 3u; ++j) {
        input[0] = (HQTruth)i; input[1] = (HQTruth)j;
        CHECK(hq_eval(&p,input,2u,quick,1u) == HQ_OK);
        CHECK(hq_eval_extended(&p,input,2u,&bank,101u,4u,extended,1u,&trace)==HQ_OK);
        CHECK(extended[0] == quick[0]);
        CHECK(trace.disposition == HQ_LESSON_STABLE);
        CHECK(trace.new_facts == 0u && trace.rounds == 1u);
    }
    puts("EMPTY LESSONS: all 9 ternary XOR cases agree with QUICK");
}

static void chaining_and_budget(void) {
    HQProgram p = program_xor(3u,0u,2u);
    HQLessonBank bank;
    HQLessonTrace trace;
    HQTruth input[3] = {HQ_TRUE,HQ_UNKNOWN,HQ_UNKNOWN};
    HQTruth out[1] = {HQ_TRUE};
    CHECK(hq_lessons_init(&bank,777u)==HQ_OK);
    CHECK(hq_lesson_add_rule(&bank,0u,HQ_TRUE,1u,HQ_FALSE,1001u)==HQ_OK);
    CHECK(hq_lesson_add_rule(&bank,1u,HQ_FALSE,2u,HQ_TRUE,1002u)==HQ_OK);
    CHECK(hq_eval(&p,input,3u,out,1u)==HQ_OK && out[0]==HQ_UNKNOWN);
    out[0]=HQ_TRUE;
    CHECK(hq_eval_extended(&p,input,3u,&bank,777u,1u,out,1u,&trace)==HQ_OK);
    CHECK(trace.disposition==HQ_LESSON_EXHAUSTED && trace.rounds==1u);
    CHECK(trace.new_facts==1u && out[0]==HQ_UNKNOWN);
    CHECK(hq_eval_extended(&p,input,3u,&bank,777u,2u,out,1u,&trace)==HQ_OK);
    CHECK(trace.disposition==HQ_LESSON_EXHAUSTED && trace.rounds==2u);
    CHECK(trace.new_facts==2u && out[0]==HQ_UNKNOWN);
    CHECK(hq_eval_extended(&p,input,3u,&bank,777u,3u,out,1u,&trace)==HQ_OK);
    CHECK(trace.disposition==HQ_LESSON_STABLE && trace.rounds==3u);
    CHECK(trace.new_facts==2u && trace.unresolved_inputs==0u);
    CHECK(out[0]==HQ_FALSE);
    CHECK(input[1]==HQ_UNKNOWN && input[2]==HQ_UNKNOWN); /* no mutation */
    /* A contextual fact resolves unknown in a separate branch. */
    CHECK(hq_lesson_add_fact(&bank,2u,HQ_FALSE,1003u)==HQ_OK);
    CHECK(hq_eval_extended(&p,input,3u,&bank,777u,5u,out,1u,&trace)==HQ_OK);
    CHECK(trace.disposition==HQ_LESSON_CONFLICT);
    CHECK(out[0]==HQ_UNKNOWN); /* fact contradicts chain */
    puts("CHAIN: 2 inferences require 3 checked rounds; incomplete or conflicting means UNKNOWN");
}

static void scoped_facts_and_quick(void) {
    HQProgram p=program_xor(2u,0u,1u);
    HQLessonBank bank;
    HQLessonTrace trace;
    HQTruth in[2]={HQ_TRUE,HQ_UNKNOWN};
    HQTruth out[1]={HQ_FALSE};
    CHECK(hq_lessons_init(&bank,43u)==HQ_OK);
    CHECK(hq_lesson_add_fact(&bank,1u,HQ_FALSE,11u)==HQ_OK);
    CHECK(hq_eval_extended(&p,in,2u,&bank,43u,2u,out,1u,&trace)==HQ_OK);
    CHECK(out[0]==HQ_TRUE && trace.new_facts==1u);
    CHECK(hq_eval(&p,in,2u,out,1u)==HQ_OK && out[0]==HQ_UNKNOWN);
    out[0]=HQ_TRUE;
    trace.rounds=99u;
    CHECK(hq_eval_extended(&p,in,2u,&bank,44u,2u,out,1u,&trace)==HQ_ERR_SCOPE);
    CHECK(out[0]==HQ_TRUE && trace.rounds==99u);
    /* Different known caller truth cannot be overwritten by a lesson. */
    in[1]=HQ_TRUE;
    CHECK(hq_eval_extended(&p,in,2u,&bank,43u,2u,out,1u,&trace)==HQ_OK);
    CHECK(out[0]==HQ_UNKNOWN && trace.disposition==HQ_LESSON_CONFLICT);
    puts("SCOPE: lessons never leak across scope keys or override known inputs");
}

static void conflicting_sources(void) {
    HQProgram p=program_xor(2u,0u,1u);
    HQLessonBank bank;
    HQLessonTrace trace;
    HQTruth in[2]={HQ_TRUE,HQ_UNKNOWN};
    HQTruth out[1]={HQ_TRUE};
    CHECK(hq_lessons_init(&bank,88u)==HQ_OK);
    CHECK(hq_lesson_add_fact(&bank,1u,HQ_TRUE,51u)==HQ_OK);
    CHECK(hq_lesson_add_fact(&bank,1u,HQ_FALSE,52u)==HQ_OK);
    CHECK(bank.fact_count==2u); /* retain both sources; do not resolve via priority */
    CHECK(hq_eval_extended(&p,in,2u,&bank,88u,4u,out,1u,&trace)==HQ_OK);
    CHECK(trace.disposition==HQ_LESSON_CONFLICT);
    CHECK(trace.conflicts==1u && out[0]==HQ_UNKNOWN);
    puts("CONFLICT: contradictory recorded lessons retained; no automatic vote");
}

static void errors_transactional(void) {
    HQProgram p=program_xor(2u,0u,1u);
    HQLessonBank bank;
    HQLessonTrace trace;
    HQTruth in[2]={HQ_TRUE,HQ_UNKNOWN};
    HQTruth out[1]={HQ_FALSE};
    unsigned int i;
    CHECK(hq_lessons_init(0,1u)==HQ_ERR_NULL);
    CHECK(hq_lessons_init(&bank,0u)==HQ_ERR_SCOPE);
    CHECK(hq_lessons_init(&bank,1u)==HQ_OK);
    CHECK(hq_lesson_add_fact(&bank,1u,HQ_UNKNOWN,1u)==HQ_ERR_VALUE);
    CHECK(hq_lesson_add_fact(&bank,1u,HQ_TRUE,0u)==HQ_ERR_VALUE);
    CHECK(hq_lesson_add_fact(&bank,HQ_MAX_INPUTS,HQ_TRUE,1u)==HQ_ERR_REF);
    CHECK(hq_lesson_add_rule(&bank,0u,HQ_UNKNOWN,1u,HQ_TRUE,1u)==HQ_ERR_VALUE);
    CHECK(hq_lesson_add_rule(&bank,0u,HQ_TRUE,1u,HQ_FALSE,0u)==HQ_ERR_VALUE);
    CHECK(hq_lesson_add_rule(&bank,0u,HQ_TRUE,HQ_MAX_INPUTS,HQ_FALSE,1u)==HQ_ERR_REF);
    CHECK(bank.fact_count==0u && bank.rule_count==0u);
    trace.rounds=123u;
    CHECK(hq_eval_extended(&p,in,2u,&bank,1u,0u,out,1u,&trace)==HQ_ERR_BUDGET);
    CHECK(out[0]==HQ_FALSE && trace.rounds==123u);
    CHECK(hq_eval_extended(&p,in,2u,&bank,1u,HQ_MAX_LESSON_ROUNDS+1u,out,1u,&trace)==HQ_ERR_BUDGET);
    CHECK(out[0]==HQ_FALSE && trace.rounds==123u);
    CHECK(hq_eval_extended(&p,in,1u,&bank,1u,2u,out,1u,&trace)==HQ_ERR_INPUT_COUNT);
    CHECK(out[0]==HQ_FALSE && trace.rounds==123u);
    in[0]=(HQTruth)23;
    CHECK(hq_eval_extended(&p,in,2u,&bank,1u,2u,out,1u,&trace)==HQ_ERR_VALUE);
    CHECK(out[0]==HQ_FALSE && trace.rounds==123u);
    in[0]=HQ_TRUE;
    CHECK(hq_lesson_add_fact(&bank,6u,HQ_TRUE,1u)==HQ_OK); /* valid bound, not valid for program */
    CHECK(hq_eval_extended(&p,in,2u,&bank,1u,2u,out,1u,&trace)==HQ_ERR_REF);
    CHECK(out[0]==HQ_FALSE && trace.rounds==123u);
    CHECK(hq_lessons_init(&bank,1u)==HQ_OK);
    for (i=0u;i<HQ_MAX_LESSON_FACTS;++i)
        CHECK(hq_lesson_add_fact(&bank,1u,HQ_TRUE,10u+i)==HQ_OK);
    CHECK(hq_lesson_add_fact(&bank,1u,HQ_TRUE,99u)==HQ_ERR_CAPACITY);
    for (i=0u;i<HQ_MAX_LESSON_RULES;++i)
        CHECK(hq_lesson_add_rule(&bank,0u,HQ_TRUE,1u,HQ_TRUE,100u+i)==HQ_OK);
    CHECK(hq_lesson_add_rule(&bank,0u,HQ_TRUE,1u,HQ_TRUE,1000u)==HQ_ERR_CAPACITY);
    CHECK(bank.fact_count==HQ_MAX_LESSON_FACTS);
    CHECK(bank.rule_count==HQ_MAX_LESSON_RULES);
    CHECK(hq_eval_extended(&p,in,2u,&bank,1u,2u,out,1u,&trace)==HQ_OK);
    CHECK(out[0]==HQ_FALSE);
    /* Forcing malformed graph must not corrupt caller-visible result. */
    p.gates[0].a.kind=HQ_REF_GATE;
    p.gates[0].a.index=0u;
    trace.rounds=123u;
    out[0]=HQ_TRUE;
    CHECK(hq_eval_extended(&p,in,2u,&bank,1u,2u,out,1u,&trace)==HQ_ERR_REF);
    CHECK(out[0]==HQ_TRUE && trace.rounds==123u);
    puts("ERRORS: failures preserve outputs and trace; bounds and provenance handles enforced");
}

static void deterministic_exhaustive(void) {
    HQProgram p=program_xor(2u,0u,1u);
    HQLessonBank bank;
    HQLessonTrace trace;
    HQTruth in[2], out[1], reference[1];
    unsigned int i,j,k;
    CHECK(hq_lessons_init(&bank,890u)==HQ_OK);
    /* Exact-context validated facts may fill absent inputs. No fuzzy/probable values. */
    CHECK(hq_lesson_add_fact(&bank,0u,HQ_TRUE,1u)==HQ_OK);
    CHECK(hq_lesson_add_fact(&bank,1u,HQ_FALSE,2u)==HQ_OK);
    for (k=0u;k<1000u;++k) {
        for (i=0u;i<3u;++i) for(j=0u;j<3u;++j) {
            in[0]=(HQTruth)i; in[1]=(HQTruth)j;
            CHECK(hq_eval_extended(&p,in,2u,&bank,890u,3u,out,1u,&trace)==HQ_OK);
            if (in[0]==HQ_FALSE || in[1]==HQ_TRUE) {
                CHECK(trace.disposition==HQ_LESSON_CONFLICT);
                CHECK(out[0]==HQ_UNKNOWN);
            } else {
                HQTruth known_input[2]={HQ_TRUE,HQ_FALSE};
                CHECK(hq_eval(&p,known_input,2u,reference,1u)==HQ_OK);
                CHECK(trace.disposition==HQ_LESSON_STABLE);
                CHECK(out[0]==reference[0]);
            }
        }
    }
    puts("DETERMINISM: 9,000 repeated contextual checks agree with reference");
}


static void order_and_cycles(void) {
    HQProgram p=program_xor(3u,0u,2u);
    HQLessonBank x,y;
    HQLessonTrace tx,ty;
    HQTruth in[3]={HQ_TRUE,HQ_UNKNOWN,HQ_UNKNOWN};
    HQTruth ox[1],oy[1];
    CHECK(hq_lessons_init(&x,50u)==HQ_OK);
    CHECK(hq_lessons_init(&y,50u)==HQ_OK);
    CHECK(hq_lesson_add_rule(&x,0u,HQ_TRUE,1u,HQ_FALSE,3u)==HQ_OK);
    CHECK(hq_lesson_add_rule(&x,1u,HQ_FALSE,2u,HQ_TRUE,4u)==HQ_OK);
    CHECK(hq_lesson_add_rule(&y,1u,HQ_FALSE,2u,HQ_TRUE,4u)==HQ_OK);
    CHECK(hq_lesson_add_rule(&y,0u,HQ_TRUE,1u,HQ_FALSE,3u)==HQ_OK);
    CHECK(hq_eval_extended(&p,in,3u,&x,50u,3u,ox,1u,&tx)==HQ_OK);
    CHECK(hq_eval_extended(&p,in,3u,&y,50u,3u,oy,1u,&ty)==HQ_OK);
    CHECK(ox[0]==oy[0] && ox[0]==HQ_FALSE);
    CHECK(tx.new_facts==ty.new_facts && tx.rounds==ty.rounds);
    /* A cycle that does not contradict reaches a fixed point. */
    CHECK(hq_lesson_add_rule(&x,2u,HQ_TRUE,0u,HQ_TRUE,5u)==HQ_OK);
    CHECK(hq_eval_extended(&p,in,3u,&x,50u,4u,ox,1u,&tx)==HQ_OK);
    CHECK(ox[0]==HQ_FALSE && tx.disposition==HQ_LESSON_STABLE);
    /* A contradictory cycle is retained as conflicting evidence. */
    CHECK(hq_lesson_add_rule(&x,2u,HQ_TRUE,0u,HQ_FALSE,6u)==HQ_OK);
    CHECK(hq_eval_extended(&p,in,3u,&x,50u,4u,ox,1u,&tx)==HQ_OK);
    CHECK(ox[0]==HQ_UNKNOWN && tx.disposition==HQ_LESSON_CONFLICT);
    puts("ORDER/CYCLES: synchronous rules are order-independent; contradictions block exports");
}

int main(void) {
    empty_bank_equals_quick();
    chaining_and_budget();
    scoped_facts_and_quick();
    conflicting_sources();
    errors_transactional();
    deterministic_exhaustive();
    order_and_cycles();
    printf("LESSONS_TESTS=PASS assertions=%lu\n",checks);
    printf("HOST_SIZES bytes lesson_bank=%lu lesson_trace=%lu\n",
           (unsigned long)sizeof(HQLessonBank),
           (unsigned long)sizeof(HQLessonTrace));
    return 0;
}
