#include "holon_types.h"
#include <stdio.h>
#include <string.h>

int main(void) {
    DNNModel m0,m1;
    HCINeuralAdapter a,b;
    HCILogicAdapter logic;
    HCIFrame fa,fb,fl;
    HCIClassifiedSignal sa,sb;
    HCIThreshold policy={0.25f,0.75f,701u};
    HQProgram p;
    HQRef xor_ref;
    unsigned int dims[2]={2u,1u},i;
    if (!dnn_init(&m0,dims,1u,1u,DNN_UNIFORM) ||
        !dnn_init(&m1,dims,1u,2u,DNN_UNIFORM)) return 1;
    /* Deterministic preconfigured numerical selectors; NOT trained controllers. */
    m0.p[0]=1.f;m0.p[1]=0.f;m0.p[2]=0.f;
    m1.p[0]=0.f;m1.p[1]=1.f;m1.p[2]=0.f;
    memset(&a,0,sizeof a);memset(&b,0,sizeof b);
    a.model=&m0;a.identity=(HCIIdentity){11u,111u,1u,1u,1u};
    b.model=&m1;b.identity=(HCIIdentity){12u,112u,1u,1u,1u};
    if(hq_init(&p,2u)!=HQ_OK ||
       hq_emit_xor(&p,hq_input(0u),hq_input(1u),&xor_ref)!=HQ_OK ||
       hq_export(&p,xor_ref)!=HQ_OK) return 2;
    logic.program=&p;logic.identity=(HCIIdentity){20u,120u,1u,0u,1u};
    printf("numA numB | signalA signalB | XOR\n");
    for (i=0u;i<4u;++i) {
        float input[2]={(float)(i&1u),(float)((i>>1)&1u)};
        if(hci_observe_neural(&a,input,2u,&fa)!=HCI_OK ||
           hci_observe_neural(&b,input,2u,&fb)!=HCI_OK ||
           hci_classify_signal(&fa,&policy,&sa)!=HCI_OK ||
           hci_classify_signal(&fb,&policy,&sb)!=HCI_OK) return 3;
        { HCIClassifiedSignal incoming[2]={sa,sb};
          if(hci_observe_classified_logic(&logic,incoming,2u,policy.conversion_id,2u,&fl)!=HCI_OK) return 4;
        }
        printf(" %u    %u   |    %u       %u     |  %u\n",
               i&1u,(i>>1)&1u,(unsigned)sa.value,(unsigned)sb.value,(unsigned)fl.truth);
        a.identity.snapshot_id++;
        b.identity.snapshot_id++;
        logic.identity.snapshot_id++;
    }
    puts("Classification outputs are NOT independently verified facts.");
    return 0;
}
