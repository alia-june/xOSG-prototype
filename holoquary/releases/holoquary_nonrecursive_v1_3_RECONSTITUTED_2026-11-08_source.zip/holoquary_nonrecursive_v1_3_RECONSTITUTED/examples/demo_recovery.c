#include "hci_recovery.h"
#include <stdio.h>

typedef struct {HCILogicAdapter *a;HQTruth in[2];} Ctx;
static HCIStatus reeval(const HCIFrame *prior,unsigned int next,
                        const void *arg,HCIFrame *out) {
    Ctx *c=(Ctx*)arg;
    HCILogicAdapter new_adapter=*c->a;
    (void)prior;
    new_adapter.identity.snapshot_id=next;
    return hci_observe_logic(&new_adapter,c->in,2u,2u,out);
}
int main(void) {
    HQProgram p;
    HQRef gate;
    HQTruth bad[2]={HQ_TRUE,(HQTruth)55};
    HCILogicAdapter adapter;
    HCIFrame observed;
    HCIRecoveryStore store;
    HCIRecoveryEvent event;
    HCIRecoveryGrant grant={0};
    Ctx ctx;
    if(hq_init(&p,2u)!=HQ_OK ||
       hq_add_nand(&p,hq_input(0u),hq_input(1u),&gate)!=HQ_OK ||
       hq_export(&p,gate)!=HQ_OK) return 1;
    adapter.program=&p;
    adapter.identity=(HCIIdentity){7u,9u,1u,0u,101u};
    if(hci_observe_logic(&adapter,bad,2u,3u,&observed)!=HCI_ERR_SOURCE) return 2;
    if(hci_recovery_init(&store,10u,1u)!=HCI_OK ||
       hci_recovery_record(&store,201u,&observed,HCI_ERR_INVALID,HCI_EFFECT_PURE,&event)!=HCI_OK)
        return 3;
    printf("original error recorded: code=%d count=%u\n",(int)event.native_error,store.count);
    ctx.a=&adapter;
    ctx.in[0]=HQ_TRUE;ctx.in[1]=HQ_FALSE; /* new *declared* fixture input */
    grant.policy_id=1u;grant.scope_id=10u;grant.parent_failure_id=201u;
    grant.exact_origin=observed.identity;grant.max_attempts=1u;grant.permit_pure_reeval=1u;
    if(hci_recovery_attempt(&store,202u,102u,&grant,reeval,&ctx,&event)!=HCI_OK) return 4;
    printf("NEW-INPUT reevaluation (not original-input recovery): %s; logical result=%d; prior error retained=%d\n",
           event.outcome==HCI_REC_REEVAL_COMPLETED?"COMPLETED":"FAILED",
           (int)event.observed.truth,(int)store.events[0].native_error);
    /* Does not prove original bad input was repaired: demo injects new fixture input. */
    return 0;
}
