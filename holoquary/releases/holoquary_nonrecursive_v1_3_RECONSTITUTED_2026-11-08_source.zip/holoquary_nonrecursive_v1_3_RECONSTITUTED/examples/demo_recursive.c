#include "hci_recursive.h"
#include <stdio.h>
static void set(HCIRecNode *n,unsigned int i) {
    n->identity=(HCIIdentity){i+1u,i+10u,1u,0u,1u};
    n->kind=HCI_RECUR_INPUT;n->input_port=0u;n->left=0;n->right=0;
}
static void gate(HCIRecNode *n,const HCIRecNode *a,const HCIRecNode *b) {
    n->kind=HCI_RECUR_NAND;n->input_port=0u;n->left=a;n->right=b;
}
int main(void) {
    HCIRecNode n[6];
    HCIRecTrace t;
    HQTruth in[2]={HQ_TRUE,HQ_FALSE},result;
    unsigned int i;
    for(i=0;i<6u;++i)set(&n[i],i);
    n[1].input_port=1u;
    gate(&n[2],&n[0],&n[1]);gate(&n[3],&n[0],&n[2]);
    gate(&n[4],&n[1],&n[2]);gate(&n[5],&n[3],&n[4]);
    if(hci_recursive_evaluate(&n[5],in,2u,4u,&result,&t)!=HCI_OK) return 1;
    printf("recursive XOR(T,F)=%d, unique_nodes=%u, nand_calls=%u, cached_reuse=%u\n",
           (int)result,t.visited,t.nand_evaluated,t.cache_hits);
    return 0;
}
