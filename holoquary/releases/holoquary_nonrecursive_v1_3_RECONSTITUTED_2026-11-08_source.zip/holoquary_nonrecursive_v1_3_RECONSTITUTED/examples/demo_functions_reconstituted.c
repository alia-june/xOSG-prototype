#include <stdio.h>
#include "hqd_functions.h"
int main(void){
    HQDRecord x,lo,hi,r;
    unsigned xmask=(1u<<1)|(1u<<2); /* balanced3 {0,+1} */
    if(hqd_possibilities(HQD_BALANCED3,xmask,0,&x)!=HQD_OK)return 1;
    if(hqd_exact_number(HQD_BALANCED3,1,&lo)!=HQD_OK)return 1;
    if(hqd_exact_number(HQD_BALANCED3,0,&hi)!=HQD_OK)return 1;
    if(hqdn_between(&x,&lo,&hi,&r)!=HQD_OK)return 1;
    printf("BETWEEN {0,+1}, +1, 0 -> kleene-mask=0x%x (FALSE-only expected)\n",r.knowledge.possibilities);
    return 0;
}
