/* Demonstrates synthetic, fixture-checked rule admission; not factual verification. */
#include "hci_feedback.h"
#include <stdio.h>

typedef struct { unsigned int rule_a; unsigned int rule_b; } Fixture;
static HCIStatus verify_fixture(const HCICandidate *c,const void *ctx,
                                HCIVerification *v) {
    const Fixture *f=(const Fixture *)ctx;
    int pass=0;
    if(!f) return HCI_ERR_NULL;
    if(c->kind==HCI_CAND_RULE && c->scope_id==44u &&
       c->premise_port==0u && c->premise_value==HQ_TRUE &&
       c->result_port==1u && c->result_value==HQ_FALSE &&
       c->evidence_id==f->rule_a) pass=1;
    if(c->kind==HCI_CAND_RULE && c->scope_id==44u &&
       c->premise_port==1u && c->premise_value==HQ_FALSE &&
       c->result_port==2u && c->result_value==HQ_TRUE &&
       c->evidence_id==f->rule_b) pass=1;
    v->verdict=pass?HCI_VERDICT_ACCEPT:HCI_VERDICT_REJECT;
    v->verifier_id=800u;
    v->checked_candidate_id=c->candidate_id;
    v->checked_evidence_id=c->evidence_id;
    v->proof_ref=900u+c->evidence_id;
    return HCI_OK;
}
static HCICandidate propose(const HCIFrame *frame,unsigned int n,
                             unsigned int evidence,unsigned int premise,
                             HQTruth premise_value,unsigned int result,
                             HQTruth result_value) {
    HCICandidate c={0};
    c.candidate_id=n;c.proposer_id=501u;c.source_id=n+100u;
    c.evidence_id=evidence;c.scope_id=44u;c.observed=frame->identity;
    c.kind=HCI_CAND_RULE;c.premise_port=premise;
    c.premise_value=premise_value;c.result_port=result;
    c.result_value=result_value;
    return c;
}
int main(void) {
    HQProgram p;
    HQRef xor;
    HQTruth input[3]={HQ_TRUE,HQ_UNKNOWN,HQ_UNKNOWN};
    HCILogicAdapter a;
    HCIFrame frame;
    HCIFeedbackStore store;
    HCICandidate c;
    HCIEvent event;
    Fixture fixture={101u,102u};
    unsigned int rounds;
    if(hq_init(&p,3u)!=HQ_OK ||
       hq_emit_xor(&p,hq_input(0),hq_input(2),&xor)!=HQ_OK ||
       hq_export(&p,xor)!=HQ_OK) return 1;
    a.program=&p;
    a.identity.holon_id=7u;a.identity.instance_id=107u;
    a.identity.graph_gen=1u;a.identity.param_gen=0u;a.identity.snapshot_id=19u;
    if(hci_observe_logic(&a,input,3u,4u,&frame)!=HCI_OK ||
       hci_feedback_init(&store,44u)!=HCI_OK) return 2;
    printf("QUICK truth=%d (UNKNOWN=%d)\n",(int)frame.truth,(int)HQ_UNKNOWN);
    c=propose(&frame,1u,101u,0u,HQ_TRUE,1u,HQ_FALSE);
    if(hci_feedback_submit(&store,&frame,3u,&c,verify_fixture,&fixture,&event)!=HCI_OK)
        return 3;
    printf("lesson #1 outcome=%d, bank_rules=%u\n",event.outcome,store.bank.rule_count);
    c=propose(&frame,2u,102u,1u,HQ_FALSE,2u,HQ_TRUE);
    if(hci_feedback_submit(&store,&frame,3u,&c,verify_fixture,&fixture,&event)!=HCI_OK)
        return 4;
    printf("lesson #2 outcome=%d, bank_rules=%u\n",event.outcome,store.bank.rule_count);
    for(rounds=1u;rounds<=3u;++rounds) {
        if(hci_observe_extended(&a,input,3u,hci_feedback_bank(&store),
                                44u,rounds,4u,&frame)!=HCI_OK) return 5;
        printf("EXTENDED rounds=%u truth=%d disposition=%d new_facts=%u\n",
               rounds,(int)frame.truth,(int)frame.disposition,frame.new_facts);
    }
    printf("feedback_events=%u generation=%u\n",store.count,store.generation);
    return 0;
}
