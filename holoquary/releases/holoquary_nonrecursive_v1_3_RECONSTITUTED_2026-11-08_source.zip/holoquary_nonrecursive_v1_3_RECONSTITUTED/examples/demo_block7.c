#include "hq_block7.h"
#include <stdio.h>
int main(void)
{
    HQ7Set positive,exact,result,unknown={HQ7_ALL};
    HQ7Knowledge kind;
    int8_t d,c,b,i;
    if(hq7_block(1,&positive)!=HQ7_OK || hq7_exact(2,&exact)!=HQ7_OK ||
       hq7_refine(positive,exact,&result)!=HQ7_OK ||
       hq7_knowledge(result,&kind)!=HQ7_OK ||
       hq7_digit_to_pair(2,&b,&i)!=HQ7_OK ||
       hq7_add_exact(3,1,0,&d,&c)!=HQ7_OK) return 1;
    printf("BLOCK+1 possibilities mask=0x%02x\n",positive.mask);
    printf("REFINE block+1 with exact +2 => mask=0x%02x kind=%d\n",result.mask,(int)kind);
    printf("EXACT +2 => block=%d inner=%d\n",(int)b,(int)i);
    printf("BALANCED7 +3 + +1 => digit=%d carry=%d\n",(int)d,(int)c);
    if(hq7_refine(positive,(HQ7Set){HQ7_NEGATIVE_BLOCK},&result)!=HQ7_OK ||
       hq7_knowledge(result,&kind)!=HQ7_OK) return 1;
    printf("REFINE positive with negative => mask=0x%02x kind=%d (contradiction)\n",result.mask,(int)kind);
    HQ7Outcome joint;HQ7Set digits;uint8_t carries;
    if(hq7_mul_sets((HQ7Set){8u},unknown,&joint)!=HQ7_OK ||
       hq7_outcome_project(joint,&digits,&carries)!=HQ7_OK) return 1;
    printf("ZERO * UNKNOWN => digit_mask=0x%02x carry_mask=0x%02x\n",digits.mask,carries);
    return 0;
}
