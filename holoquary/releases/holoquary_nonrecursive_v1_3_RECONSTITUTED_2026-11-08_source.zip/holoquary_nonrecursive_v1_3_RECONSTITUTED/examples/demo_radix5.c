#include "hq_radix5.h"
#include <stdio.h>
int main(void) {
    HQ5Value d,balanced,carry,product,unknown= {HQ5_DOMAIN_TERNARY_UE,HQ5_U};
    unsigned outcarry;
    HQ5Cell cell;
    hq5_add_pure((HQ5Value){HQ5_DOMAIN_PURE5,4},
                 (HQ5Value){HQ5_DOMAIN_PURE5,3},0,&d,&outcarry);
    printf("PURE5: 4 + 3 = %u (digit %u, carry %u)\n",4u+3u,(unsigned)d.symbol,outcarry);
    hq5_add_balanced((HQ5Value){HQ5_DOMAIN_TERNARY_UE,HQ5_P},
                     (HQ5Value){HQ5_DOMAIN_TERNARY_UE,HQ5_P},
                     (HQ5Value){HQ5_DOMAIN_TERNARY_UE,HQ5_Z},&balanced,&carry);
    printf("TERNARY_UE: +1 + +1 => digit %d, carry %d\n",
           (int)balanced.symbol-1,(int)carry.symbol-1);
    hq5_mul_balanced((HQ5Value){HQ5_DOMAIN_TERNARY_UE,HQ5_Z},unknown,&product);
    printf("TERNARY_UE: 0 * UNKNOWN => ordinal %u (1 means ZERO)\n",
           (unsigned)product.symbol);
    hq5_mul_balanced((HQ5Value){HQ5_DOMAIN_TERNARY_UE,HQ5_Z},
                     (HQ5Value){HQ5_DOMAIN_TERNARY_UE,HQ5_E},&product);
    printf("TERNARY_UE: 0 * ERROR => ordinal %u (4 means ERROR marker)\n",
           (unsigned)product.symbol);
    hq5_cell_init(&cell,unknown);
    hq5_cell_tick(&cell,0,HQ5_WRITE,
                  (HQ5Value){HQ5_DOMAIN_TERNARY_UE,HQ5_P},&balanced);
    printf("TERNARY_UE cell: write +1 => ordinal %u, generation %u\n",
           (unsigned)balanced.symbol,(unsigned)cell.generation);
    return 0;
}
