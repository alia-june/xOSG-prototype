#include "hqd_separation.h"
#include <stdio.h>
int main(void) {
    HQDRecord zero,unknown,digit,carry,error;
    HQDAddResult sum;
    HQ5Value legacy={HQ5_DOMAIN_TERNARY_UE,HQ5_E};
    if(hqd_exact_number(HQD_BALANCED3,0,&zero)!=HQD_OK ||
       hqd_possibilities(HQD_BALANCED3,7u,3u,&unknown)!=HQD_OK ||
       hqd_add_digits(&zero,&unknown,&sum)!=HQD_OK ||
       hqd_add_project(&sum,&digit,&carry)!=HQD_OK ||
       hqd_from_hq5(legacy,&error)!=HQD_OK) return 1;
    printf("ZERO is NUMBER=%d value=%d; UNKNOWN is ABSENT=%d mask=%u grade=%u\n",
           zero.data.kind==HQD_NUMBER,(int)zero.data.number,
           unknown.data.kind==HQD_ABSENT,(unsigned)unknown.knowledge.possibilities,
           (unsigned)unknown.knowledge.unknown_grade);
    printf("ZERO + UNKNOWN => digit possibilities=%u, carry numeric=%d; E marker=%d execution=COMPLETED=%d\n",
           (unsigned)digit.knowledge.possibilities,(int)carry.data.number,
           error.execution.marker==HQD_LEGACY_E_MARKER,
           error.execution.state==HQD_EXEC_COMPLETE);
    return 0;
}
