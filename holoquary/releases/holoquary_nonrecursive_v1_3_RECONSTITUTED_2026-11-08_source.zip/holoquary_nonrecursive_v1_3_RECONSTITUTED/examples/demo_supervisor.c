#include "hci_supervisor.h"
#include <stdio.h>
int main(void) {
    HCINeuralSupervisor s;
    HCIFrame f={0};
    HCIProposal p;
    HCIGrant grant={0};
    float score;
    if(hci_supervisor_init(&s,1u)!=HCI_OK ||
       hci_supervisor_train_imitation(&s,3000u,0.15f)!=HCI_OK) return 1;
    f.identity=(HCIIdentity){9u,8u,1u,0u,19u};
    f.kind=HCI_LOGIC;f.execution=HCI_COMPLETED;f.result_kind=HCI_RESULT_LOGIC;
    f.source_status=HQ_OK;f.disposition=HCI_UNCHECKED;
    f.truth=HQ_UNKNOWN;f.input_count=2u;f.compute_remaining=2u;
    grant.target_holon_id=9u;grant.max_budget=2u;
    grant.action_mask=HCI_ACTION_BIT(HCI_ACT_ANSWER)|HCI_ACTION_BIT(HCI_ACT_APPLY_LESSON)|
                      HCI_ACTION_BIT(HCI_ACT_RETURN_UNKNOWN);
    if(hci_supervisor_propose(&s,&f,1u,&p,&score)!=HCI_OK) return 2;
    printf("trained toy score=%.4f action=%d permitted=%d\n",(double)score,
           (int)p.action,(int)hci_supervisor_gate(&p,&f,&grant,1u));
    printf("This imitates a four-case deterministic policy; it does not show improvement or generalization.\n");
    return 0;
}
