#include "hq_higher.h"
#include <stdio.h>
static HQ5Value B(unsigned n){HQ5Value v={HQ5_DOMAIN_TERNARY_UE,(uint8_t)n};return v;}
static const char *symbol(HQ5Value x){static const char *v[]={"-1","0","+1","UNKNOWN","ERROR"};return x.symbol<5?v[x.symbol]:"INVALID";}
static const char *condition(HQXCondition c){static const char *v[]={"FALSE","TRUE","UNKNOWN","ERROR"};return (unsigned)c<4?v[c]:"INVALID";}
int main(void){
    HQXCondition c;
    HQ5Value value;
    hqx_test(HQX_GE,B(HQ5_P),B(HQ5_U),&c);
    printf("(+1 >= U): %s [all possible numeric completions]\n",condition(c));
    hqx_test(HQX_EQ,B(HQ5_U),B(HQ5_U),&c);
    printf("(U == U): %s [independent unknowns]\n",condition(c));
    hqx_balanced_order(HQX_MIN,B(HQ5_U),B(HQ5_N),&value);
    printf("min(U, -1): %s\n",symbol(value));
    hqx_balanced_order(HQX_MAX,B(HQ5_U),B(HQ5_P),&value);
    printf("max(U, +1): %s\n",symbol(value));
    hqx_select_condition(HQX_UNKNOWN,B(HQ5_P),B(HQ5_P),&value);
    printf("case(U, +1, +1): %s\n",symbol(value));
    hqx_connect(HQX_AND,HQX_FALSE,HQX_ERROR,&c);
    printf("FALSE AND ERROR (strict diagnostic): %s\n",condition(c));
    return 0;
}
