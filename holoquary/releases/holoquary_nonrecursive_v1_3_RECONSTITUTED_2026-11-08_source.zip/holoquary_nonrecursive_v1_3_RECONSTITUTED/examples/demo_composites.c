#include "hq_composites.h"
#include "hq_cells.h"
#include <stdio.h>
static const char *truth(HQTruth v) {
    return v==HQ_TRUE ? "TRUE" : v==HQ_FALSE ? "FALSE" : "UNKNOWN";
}
int main(void) {
    HQProgram program;
    HQRef switched,locked;
    HQTruth in[4]={HQ_TRUE,HQ_FALSE,HQ_UNKNOWN,HQ_TRUE},out[2];
    HQBitCell memory;
    HQTruth memout;
    if(hq_init(&program,4u)!=HQ_OK) return 1;
    if(hq_emit_mux(&program,hq_input(0u),hq_input(1u),hq_input(2u),&switched)!=HQ_OK) return 1;
    if(hq_emit_guarded_lock(&program,hq_input(0u),hq_input(2u),hq_input(3u),&locked)!=HQ_OK) return 1;
    if(hq_export(&program,switched)!=HQ_OK || hq_export(&program,locked)!=HQ_OK) return 1;
    if(hq_eval(&program,in,4u,out,2u)!=HQ_OK) return 1;
    printf("SWITCH(TRUE,FALSE,UNKNOWN)=%s\n",truth(out[0]));
    printf("GUARD(TRUE,UNKNOWN,TRUE)=%s ACTUATE=%d\n",truth(out[1]),hq_guard_allows(out[1]));
    if(hq_bit_init(&memory,HQ_UNKNOWN)!=HQ_CELL_OK) return 1;
    if(hq_bit_tick(&memory,0u,HQ_TRUE,HQ_TRUE,&memout)!=HQ_CELL_OK) return 1;
    printf("MEMORY WRITE TRUE: %s generation=%u\n",truth(memout),memory.generation);
    if(hq_bit_tick(&memory,1u,HQ_FALSE,HQ_FALSE,&memout)!=HQ_CELL_OK) return 1;
    printf("MEMORY HOLD: %s generation=%u\n",truth(memout),memory.generation);
    if(hq_bit_tick(&memory,2u,HQ_UNKNOWN,HQ_FALSE,&memout)!=HQ_CELL_OK) return 1;
    printf("MEMORY UNCERTAIN WRITE: %s generation=%u\n",truth(memout),memory.generation);
    return 0;
}
