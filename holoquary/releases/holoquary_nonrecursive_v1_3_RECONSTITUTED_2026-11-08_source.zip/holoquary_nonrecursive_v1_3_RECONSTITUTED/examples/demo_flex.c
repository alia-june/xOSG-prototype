#include "hci_flex.h"
#include <stdio.h>

int main(void) {
    HQProgram graph;
    HQRef xor_output;
    HCILogicAdapter logic;
    HCIIdentity id={100u,101u,1u,0u,12u};
    HCIFlexPort inputs[2]={{0}};
    HCIFlexSnapshot snapshot;
    HCIThreshold policy[2]={{0.25f,0.75f,7u},{0.25f,0.75f,8u}};
    HCIFrame output;
    if(hq_init(&graph,2u)!=HQ_OK ||
       hq_emit_xor(&graph,hq_input(0u),hq_input(1u),&xor_output)!=HQ_OK ||
       hq_export(&graph,xor_output)!=HQ_OK) return 1;
    logic.program=&graph;logic.identity=id;
    inputs[0].type=HCI_FLEX_NUMERIC;
    inputs[0].source=(HCIIdentity){1u,2u,1u,4u,12u};
    inputs[0].numeric=0.9f;
    inputs[0].origin=HCI_INPUT_UNATTESTED;
    inputs[1].type=HCI_FLEX_LOGIC;
    inputs[1].source=(HCIIdentity){3u,4u,1u,0u,12u};
    inputs[1].logic=HQ_FALSE;
    inputs[1].origin=HCI_INPUT_UNATTESTED;
    if(hci_flex_capture(&snapshot,&logic.identity,inputs,2u)!=HCI_OK ||
       hci_flex_eval_logic(&snapshot,&logic,policy,2u,4u,&output)!=HCI_OK)
        return 2;
    printf("MIXED_XOR score=0.90 classified_TRUE XOR FALSE => %s\n",
           output.truth==HQ_TRUE?"TRUE":"UNEXPECTED");
    snapshot.port[0].numeric=0.1f; /* accidental mutation, checksum unchanged */
    printf("MUTATED_SNAPSHOT => %s\n",
           hci_flex_eval_logic(&snapshot,&logic,policy,2u,4u,&output)==HCI_ERR_STALE?
           "REJECTED":"UNEXPECTED");
    return output.truth==HQ_TRUE?0:3;
}
