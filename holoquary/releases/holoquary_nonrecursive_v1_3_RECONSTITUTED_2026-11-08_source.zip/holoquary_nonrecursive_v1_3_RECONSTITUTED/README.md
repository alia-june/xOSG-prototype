# Holoquary v1.3 — RECONSTITUTED nonrecursive baseline

**Reconstitution date:** 2026-11-08  
**Direction authority:** m.A.R.S.  
**Status:** reconstructed C99 source candidate, not byte-identical recovery of the lost original v1.3 archive.

This package was rebuilt from the complete preserved v1.2 source plus the surviving v1.3 function contract, historical test report, error log, and TODO material. The original v1.3 source ZIP was unavailable in the active runtime. See `docs/V13_RECONSTITUTION_REPORT.md` before treating this archive as historical source evidence.

Current reconstruction verification:

- GCC/Clang strict C99: `V13_RECONSTITUTED_PASS assertions=187861`.
- GCC targeted undefined/bounds sanitizer: PASS.
- Complete inherited functional suites: PASS under GCC and Clang.
- GCC/Clang freestanding host relocatable object: no unresolved symbols.

The preserved historical report records `857664` assertions for the lost October 2 implementation. That number is historical evidence only; it is not relabeled as a current reconstruction result.

## Preserved predecessor README

# Holoquary v1.1 — BLOCK7 (3–1–3 structural seven-state substrate)

**Status:** assistant-generated, hosted-tested additive C99 prototype; not adopted canon, independently attested system, or physical seven-state hardware.
**Source authority:** m.A.R.S. provided outer blocks `−1:[−1,0,+1]`, `0:[0]`, `+1:[−1,0,+1]`.
**Proposed numeric interpretation:** `digit=2*block+inner` maps seven valid pairs to balanced `−3..+3`; do not silently lock the user’s 3–1–3 scheme to arithmetic.

### New source and tests

- `src/hq_block7.h`, `src/hq_block7.c`: exact pair/digit conversion, structural block/inner predicates, 7-bit partial-knowledge sets, refinement, signed 7-digit arithmetic, joint (digit,carry) outcome masks, comparisons, block selection, 1-cell volatile state, bounded exact word addition.
- `tests/test_block7.c`, `examples/demo_block7.c`: exhaustive mathematical and state tests, reproducible demonstration.
- `docs/BLOCK7_CONTRACT.md`, `docs/BLOCK7_TEST_REPORT.md`, `docs/BLOCK7_STAGE_LOG.md`, `docs/BLOCK7_ERROR_LOG.md`: source/vs/proposal policy, test evidence and open work.
- `docs/RADIX5_TODO.md`: BLOCK7 TODO register; earlier open work remains intact.

### Quick build

```sh
make CC=gcc block7_test
make CC=gcc block7_demo
make CC=gcc baseline
make CC=gcc test
make CC=clang test
make CC=gcc sanitized
make CC=gcc freestanding
make CC=clang freestanding
```

**Critical distinction:** UNKNOWN is mask `0x7F` (all seven possibilities), while contradiction is `0x00` (none); neither is an arithmetic digit or an execution failure. A shared unresolved variable across different fields is not modeled merely by repeating a bitmask. The package does not extend general recursive runtime composition.

---

# Holoquary v1.0 — Higher logic before recursion

**Status:** GENERATED / HOST-TESTED PROTOTYPE. Existing v0.9 numerical and logic kernels are unmodified; higher logic is a separate source module. This is not a canonical lock, a newly trained neural supervisor, external attestation, or deployed firmware.

## New higher functions

- `src/hq_higher.h`, `src/hq_higher.c`: distinct typed `HQXCondition` (FALSE/TRUE/UNKNOWN/ERROR); numerical predicates EQ/NE/LT/LE/GT/GE, IS_ZERO, IS_KNOWN, IS_UNKNOWN, IS_ERROR across two named domains.
- Strong-Kleene T/F/U logic with **strict E-dominant** diagnostics: NOT, AND, OR, XOR, material implication, equivalence. This is a failure-preserving profile, **not** a complete four-valued logical algebra.
- Balanced ternary with U/E: exact uncertainty-aware MIN/MAX and comparisons; TRUE when all concrete completions agree, UNKNOWN otherwise; in-band E propagates under the chosen strict profile.
- Independent multi-trit order and exact digit-based equality; up to 32 symbols. PURE5 comparison is overflow-safe and never manufactures numerical UNKNOWN digits.
- Inclusive BETWEEN, majority-of-three conditions, condition-controlled balanced selection, and fully validated PURE5 25-entry predicate tables.
- No modifications to v0.9 source algorithms, no recursive/runtime graph changes, no learning or recovery policy changes.

## Build

```sh
make CC=gcc higher_test higher_demo
make CC=clang higher_test
make CC=gcc test sanitized freestanding
make CC=clang test freestanding
```

Run the standalone example: `make CC=gcc higher_demo`. The existing v0.9 test commands remain applicable. `src/hq_higher.*` has no OS/heap/I/O requirements; freestanding compilation is a **host object**, not execution on a board.

## Documentation

- `docs/HIGHER_LOGIC_CONTRACT.md`: exact semantics and authority boundaries.
- `docs/RESEARCH_STAGE_AND_MINE.md`: online background, patterns, anti-patterns, reusable atomics/molecules.
- `docs/HIGHER_LOGIC_ERROR_LOG.md`: observed interval-equality error and correction.
- `docs/HIGHER_LOGIC_TEST_REPORT.md`: executed test evidence and limitations.
- `docs/RADIX5_TODO.md`: original open work plus new higher-logic TODO.

---

# Holoquary v0.9 — Pure Base-Five + Balanced Ternary U/E

**Status:** additive C99 hosted-tested candidate; not canonical, not independently attested, not physically deployed. Project authority: m.A.R.S.; new technical implementation generated by ChatGPT.

## Two distinct five-symbol profiles

1. **PURE5:** `0,1,2,3,4` — a genuine radix-5 numeric representation. Includes digit addition/multiplication with carries, comparison, five-way selector, full 5×5 LUT and 1–32-digit addition.
2. **TERNARY_UE:** `-1,0,+1,UNKNOWN,ERROR` — balanced ternary arithmetic plus **two nonnumeric markers**. Includes normalized digit addition with balanced carry, multiplication, negation, comparison, three-way selection, and 1–32-digit addition. E is in-band error propagation; `HQ5Status` still distinguishes invalid function execution.

The types share storage cardinality but **not a mathematical radix**. The legacy strong-Kleene `FALSE/UNKNOWN/TRUE` logic and original neural kernels remain unmodified; no automatic cross-domain casts have been introduced.

## New files

- `src/hq_radix5.h` and `src/hq_radix5.c` — two tagged domains and operations, standalone/no heap.
- `tests/test_radix5.c` — exhaustive digit/domain/selector checks plus deterministic multi-word and atomicity tests.
- `examples/demo_radix5.c` — addition, U/E propagation and ticked memory.
- `docs/RADIX5_CONTRACT.md` — precise rules and what remains unproved.
- `docs/RADIX5_TODO.md` — future tasks without superseding historical TODO.
- `docs/RADIX5_TEST_REPORT.md` — executed validation receipt (**220,147** new assertions per tested GCC/Clang configuration).

## Build from the extracted archive

```sh
make radix5_test        # new suite
make radix5_demo        # new standalone example
make test CC=gcc       # all integrated suites
make test CC=clang
make sanitized CC=gcc
make freestanding CC=gcc
make freestanding CC=clang
make baseline          # original Holoquary/neural kernels
```

## Design-critical examples

```
PURE5:       4 + 3 => digit 2, carry +1 (12_5)
TERNARY_UE: +1 + +1 => digit -1, carry +1
TERNARY_UE: 0 * UNKNOWN => 0
TERNARY_UE: 0 * ERROR   => E (preserve observed fault marker)
```

The U/E propagation rules are explicit initial policy decisions and can be revised only with updated specifications/tests. A successful C99 function that returns in-band E does not imply recovery, error provenance authentication, or that the function itself failed.

---

## Preserved historical readme (v0.8 and earlier)

# Holoquary v0.7 — Base Flexibility & Resilience (Candidate)

**Attribution:** m.A.R.S. (project direction) · assistant-generated implementation. **Status:** bounded prototype, not canonical or independently attested.

**New in v0.7:** typed logical/numeric ports; immutable-by-convention input snapshots with unkeyed accidental-change checksum; per-port conversion policies; stale-generation rejection; atomic result publication on new entry points; read-only numeric/logical adapters; constrained pure-logic reevaluation callback. **All six future paths are registered in `docs/TODO.md`.**

Quick commands from the extracted directory: `make baseline`, `make test`, `make sanitized`, `make freestanding`, `make flex_demo`. Documentation: `docs/FLEX_CONTRACT.md`, `docs/FLEX_TEST_REPORT.md`, `docs/BASE_ERROR_LOG.md`, `docs/V07_STAGE_LOG.md`, `docs/TODO.md`. The full v0.6 source material below is preserved as historical baseline.

---

# Holoquary-006 — Staged Integration Through the First Hard Wall

**Date:** 2026-10-02  
**Attribution:** m.A.R.S. (design authority); implementation and synthesis by ChatGPT.  
**Status:** GENERATED / HOST-TESTED PROTOTYPE. Not accepted canon, independently attested software, or deployed firmware.  
**Source lineage:** v0.4 integration -> v0.5 LESSONS feedback -> v0.6 bounded recovery, experimental neural-action imitation, recursive NAND DAGs.

## Scope and stage result

| Stage | Actual result | Caveat |
|---|---|---|
| I-00–I-04 | Original standalone kernels, typed neural/logic bridge and deterministic controller: preserved and regression-tested | No new general mixed graph runtime |
| I-05 | Optional candidate/verifier/lesson-admission subsystem: preserved and regression-tested | Caller-provided verifier is not independently authenticated |
| I-06 | New recovery event ledger and bounded pure-operation *reevaluation*: HOST TESTED | Caller purity and replay of original input bytes cannot be independently proved |
| I-07 | New independent 2-8-1 neural controller: four-case *imitation* training and typed action proposal: HOST TESTED | 128/128 in-sample decisions across 32 seeds; **not generalization or improvement** |
| I-08 | New recursive runtime **logic-only** pure NAND-DAG evaluator with fan-out memoization: HOST TESTED | Not generic mixed neural/logic recursion or arbitrary mutable graph |
| I-09 | Firmware boot and physical timing/power checks: NOT STARTED | No hardware ISA, board, memory map or linker/startup specification |

**Reached wall:** Neither physical hardware deployment nor trustworthy automatic recovery/lesson admission can be validated with the currently available target/evidence contracts. Stop rather than extrapolate from hosted tests. The I-07 model has not passed the benefit-vs-deterministic-baseline gate.

## What's new

- `src/hci_recovery.{h,c}`: `hci_recovery_record()` and `hci_recovery_attempt()` with original-error retention, at-most-three pure reevaluations per recorded failure, typed blocked events, and completion/effect checks.
- `src/hci_supervisor.{h,c}`: optional trainable 2-8-1 toy action proposer (its parameters are **not** the children's parameters), plus an action-specific deterministic gate. Training is candidate-copy + commit; the model imitates an externally specified four-case rule.
- `src/hci_recursive.{h,c}`: bounded recursive evaluation of pure NAND DAGs against the unchanged source `hq_eval` for every NAND; cycle and duplicate-instance rejection; cached shared subtree results and a per-call source map.
- `src/hci_freestanding_memory.c`: standalone memcpy/memset fallback compiled **only** into the host freestanding-object profile, because Clang lowers structure copies into these symbols even with `-ffreestanding`.
- New isolated regression suites and example programs under `tests/` and `examples/`, including a freestanding memory-shim semantics test.

## How to build (GCC/Clang on a hosted development system)

```sh
make CC=gcc baseline
make CC=gcc test
make CC=gcc sanitized
make CC=gcc freestanding
make CC=gcc shim_test
make CC=gcc recovery_demo
make CC=gcc supervisor_demo
make CC=gcc recursive_demo
```

The `freestanding` target builds a **relocatable host object** and checks `nm -u` for unresolved symbols. No firmware image, interrupt handlers, board I/O, hardware recovery, cryptographic identity, host-process isolation or real-processor timings are established.

## Type and truth boundaries

- **Internal NAND logic:** `HQ_FALSE`, `HQ_TRUE`, `HQ_UNKNOWN` using source strong-Kleene truth semantics.
- **Execution:** `HCI_COMPLETED`, `HCI_FAILED`, `HCI_COMPLETION_UNKNOWN` separate from logical truth.
- **Error reporting:** a typed failure may enter a recovery ledger; `UNKNOWN` is not an error.
- **LESSONS:** existing v0.2 facts/rules, externally admitted by v0.5 callback; v0.6 does not confer new verification authority.
- **Controller:** its neural output is a proposal, not verification or an action grant. Invalid/stale/unauthorized actions remain denied by a deterministic gate.

## Important limitations

1. `HCIFrame` lacks a verified immutable input-value hash. Thus even a 'pure reevaluation' callback can supply different inputs; a successful reevaluation **must not** be called proof of original-input repair. `examples/demo_recovery.c` deliberately demonstrates this trust boundary using new fixture inputs.
2. Function pointers, policy IDs, scope IDs, instance IDs, and source IDs do not authenticate independent parties or enforce memory isolation in C. A malicious/inconsistent callback remains out of scope.
3. Recovery and LESSONS event ledgers are RAM-only; `init()` resets them. No restart continuity, storage authentication, or externally attested provenance.
4. The trained controller sees just two Boolean features: `unresolved` and `admitted lessons available with budget`; its 4-case success comes from training examples. No unseen reasoning task or held-out problem family was demonstrated. Deterministic imitation alone does not justify replacing the baseline.
5. Recursive execution supports a pure, read-only **logic DAG** of at most 16 input/NAND nodes and depth 8. It does not yet instantiate arbitrary mixed neural/logical holons, shared trainable parameter banks, cyclic/stateful computation, or identity/capability isolation.
6. Source and build contracts are single-writer/trusted-process only. Sanitizers do not establish pointer-safety against malicious callers or absence of untested bugs.

## Documentation map

- `docs/RECOVERY_CONTRACT.md`: exact error semantics and unproved same-input constraint.
- `docs/SUPERVISOR_EXPERIMENT.md`: the controlled toy imitation study and missing benefit evidence.
- `docs/RECURSIVE_CONTRACT.md`: pure logic DAG, memoization, traces and capacity limits.
- `docs/TEST_REPORT.md`: reproducible current-turn executed validations.
- `docs/STAGE_LOG.md`: S00/S06/S07/S08/S09 staged continuation with explicit stop conditions.
- `docs/TODO.md`: remaining blockers and dependencies.
- `docs/AI_ERROR_LOG.md`: assistant-originated observed corrections (append-only log).
- `docs/FEEDBACK_CONTRACT.md`, `docs/CONTRACT.md`, `reference/`, `baseline/`: preserved earlier context and computational sources.

**FABRICATION FLAG — GENERATED IMPLEMENTATION:** All new APIs and policies in this v0.6 package are generated proposals. Passing local tests does not grant acceptance, evidence authenticity or independent attestation.

## v0.7 candidate addendum: base flexibility and resilience

This source branch **adds** `src/hci_flex.{h,c}` without changing the v0.6 baseline kernels or existing source modules. It proposes typed, fixed-capacity logical/numerical ports, per-port numeric classification, invocation-bound input snapshots, checksum checks for accidental modification and an optional pure-logic replay adapter. Its unkeyed checksum and caller-declared source identity are **not** authentication, provenance attestation, or proof of original-input capture. See `docs/FLEX_CONTRACT.md`, `docs/TODO.md` and the v0.7 `docs/FLEX_TEST_REPORT.md` for actual stage dispositions.

## v0.8 candidate — NAND-composed gates, switches, guarded locks, stateful memory

**Added without modifying existing kernels:**

- `src/hq_composites.h`, `.c`: pure NAND-derived NOT/AND/OR/NOR/XNOR; `hq_emit_switch` (enabled gate); `hq_emit_mux` (consensus three-valued two-way selector); `hq_emit_demux` (two outputs); `hq_emit_guarded_lock` (logical data/key/permission conjunction).
- `src/hq_cells.h`, `.c`: optional caller-owned, single-bit TRUE/FALSE/UNKNOWN memory cell. Explicit tick, expected-generation check, hold/write/reset, no graph cycles.
- `tests/test_composites.c`, `examples/demo_composites.c`, and `docs/COMPOSITES_CONTRACT.md`.

Run `make composites_test`, `make composites_demo`, `make test`, `make sanitized`, and `make freestanding`. Memory persists only in the caller-owned C struct for the current runtime. A logical guard is **not** authenticated access control or a physical safety interlock. The existing physical hardware, neural benefit, mixed recursive runtime and trusted historical replay limitations remain open.

## v1.2 candidate — Data/metadata separation (operator correction)

This stage wraps unchanged legacy numerical/logical engines with an **additive normalized record**: `HQDRecord { domain, data, knowledge, execution, provenance }`. A numeric value is always declared by domain; `ABSENT` and graded uncertainty belong to metadata. Strong-Kleene logical UNKNOWN remains a valid *logical symbol*. Execution failure and legacy propagated error markers are separate. The three proposed UNKNOWN grades have **no inferred strength or ordering** until an operator-approved semantics exists. Legacy in-band U/E APIs are preserved for regression, not silently redefined.

New `src/hqd_separation.{h,c}`, `tests/test_separation.c`, `examples/demo_separation.c`. Build with `make separation_test separation_demo`, `make test`, `make sanitized`, `make freestanding`, `make baseline`. See `docs/V12_PLAN.md`, `docs/V12_SEPARATION_CONTRACT.md`, `docs/V12_MIGRATION.md`, `docs/V12_TEST_REPORT.md` and TODO. Existing general recursion unchanged; neither NINE arithmetic nor FIFTEEN metadata presentation implemented. **Prototype, not independently attested or accepted canon.**
