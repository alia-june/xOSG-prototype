# Source and Provenance Register

**Retrieval class 1 — Project artifacts (actual file content inspected for this documentation).**

- `holoquary_lessons_v0_2/README.md` — describes preserved NAND/QUICK, optional LESSONS, explicit non-goals, capacity limits and source-handle limitations.
- `holoquary_lessons_v0_2/docs/CONTRACT.md` — fixed-point algorithm, conflict/exhaustion semantics, immutability and open admission/authentication decisions.
- `holoquary_lessons_v0_2/docs/TEST_REPORT.md` — reported C99 hosted tests and freestanding-host object compile. This is a prior artifact's reported result, not a new execution for this documentation pack.
- `hnn_topology_comparison_v0_4/docs/EXPERIMENT_REPORT.md` — fixed XOR experimental protocol, gradients and convergence by topology; does not establish controller training.
- Prior Holoquary/HNN conversation — user instruction to rename optional TILT to LESSONS, retain optional recovery/QUICK, ask for subholon inputs/weights access, and carry out staged research.
- `blue-key-contract-mining-chunk-04-lifecycle-control-v0.1-draft.md` — **proposed** `SAFE-CONDITION` public four-outcome `TRUE/FALSE/UNKNOWN/ERROR`; not authoritative for changing Holoquary's three-valued kernel, and not a project-wide accepted lock.

**Retrieval class 2 — External literature, checked via online source search on 2026-10-02.** Claims here are limited to the research mechanisms described; they do not convey operational implementation status for Holoquary.

| ID | Primary source | Extractable pattern | Caveat |
|---|---|---|---|
| R01 | [Switch Transformers — Fedus et al., JMLR 2022](https://www.jmlr.org/papers/v23/21-0998.html) | sparse expert selection, conditional computation | large transformer MoE, not a tiny C routing benchmark |
| R02 | [Learning to learn by gradient descent by gradient descent — Andrychowicz et al., NeurIPS 2016](https://proceedings.neurips.cc/paper/2016/hash/fb87582825f9d28a8d42c5e5e5e8b23d-Abstract.html) | learned optimizer; coordinate-wise state in paper's method | does not require learned optimization for Holoquary v0.3 |
| R03 | [HyperNetworks — Ha, Dai & Le, 2016](https://arxiv.org/abs/1609.09106) | distinct network generates another network's weights | parameter proposals require validation and authority |
| R04 | [Permutation Equivariant Neural Functionals — Zhou et al., 2023](https://arxiv.org/abs/2302.14040) | permutation symmetry in weight-space processing | applicability depends on target topology |
| R05 | [Adaptive Computation Time — Graves, 2016](https://arxiv.org/abs/1603.08983) | variable number of computation steps | no guaranteed correctness from pondering alone |
| R06 | [PonderNet — Banino, Balaguer & Blundell, 2021](https://arxiv.org/abs/2107.05407) | learned halting/compute allocation | learned halting is not a source of truth |
| R07 | [AlphaGeometry — Trinh et al., Nature 2024](https://www.nature.com/articles/s41586-023-06747-5) | neural proposal plus symbolic deduction | symbolic entailment assumes admitted premises/rules |
| R08 | [DeepProbLog — Manhaeve et al., NeurIPS 2018](https://proceedings.neurips.cc/paper/2018/hash/dc5d637ed5e62c36ecb73b654b05ba2a-Abstract.html) | neural predicates integrated with probabilistic logic | not equivalent to 3-valued Kleene NAND |
| R09 | [Relational inductive biases, deep learning and Graph Networks — Battaglia et al., 2018](https://research.google/pubs/relational-inductive-biases-deep-learning-and-graph-networks/) | nodes/edges/global state and relational architecture | not an authorization framework |
| R10 | [AI models collapse when trained on recursively generated data — Shumailov et al., Nature 2024](https://www.nature.com/articles/s41586-024-07566-y) | risks from recursive generated-data training | not proof that all generated examples are unusable |

**Provenance distinctions:** external paper = precedent; project artifact = statement about archived experiment; research synthesis = candidate architecture; executable test = not performed for this pack; independent attestation = not performed.

**Source reuse rules:** retain attribution; extract lesson/pattern/constraint, not wholesale external project code; independently validate any adapted implementation; recheck canonical/permission status before merging with an existing project.
