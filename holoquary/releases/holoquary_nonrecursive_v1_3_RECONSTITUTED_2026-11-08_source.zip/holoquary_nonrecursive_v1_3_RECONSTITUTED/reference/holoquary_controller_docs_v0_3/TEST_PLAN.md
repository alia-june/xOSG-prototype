# Holoquary-003 — Validation and Experimental Test Plan

**Status: NOT EXECUTED FOR THIS DOCUMENT PACK.** All cases and thresholds here are **proposed tests**, not retrospective claims that an interface or controller has passed. Prior kernel test results are cited separately in the source artifacts.

## 1. Strategy

The testing sequence explicitly separates algorithmic correctness, controller benefit, interface integrity, memory/compute behavior, feedback validity, and target hardware. A controller's improved output cannot compensate for a broken logical truth table or missing error evidence.

**Reference baselines:** (B0) unmodified Holoquary v0.2 QUICK; (B1) unmodified bounded EXTENDED; (B2) deterministic state-frame router with no neural policy; (B3) neural router on the same state frames; (B4) weight-level diagnostic model when separately enabled. Use identical source snapshots, rule-bank scopes, held-out problem families and hard budgets. Never compare differently provisioned controllers without recording the difference.

## 2. Acceptance ladder

| Gate | Objective | Minimum evidence required | Status |
|---|---|---|---|
| T0 | Reproduce v0.2 behavior | pre-existing test suite, checksums, exit codes, truth tables | Not rerun in this documentation task |
| T1 | Verify state-frame types | encode/decode roundtrips; reject invalid/omitted/stale fields; fixed budgets | Unimplemented |
| T2 | Verify views L0–L3 | view masks, authorization, snapshot identity and exact generation | Unimplemented |
| T3 | Verify deterministic policy | legal actions run; illegal actions rejected without mutations | Unimplemented |
| T4 | Verify LESSONS pipeline | candidate/admit/reject flows, provenance and scope, replay stability | Unimplemented |
| T5 | Verify ERROR/RECOVERY feedback | unknown vs fault vs contradiction; no uncontrolled repeats | Unimplemented |
| T6 | Measure controller contribution | held-out comparison B2 vs B3 at equal budgets | Unimplemented |
| T7 | Verify recursive composition | nested state frames, mapping, ownership, bounded inspection | Unimplemented |
| T8 | Check compiler/runtime | freestanding object, external dependencies, ABI layout, instrumented hosted paths | Unimplemented for controller |
| T9 | Verify physical hardware | board/ABI, startup, linker, I/O, measured memory/latency/power | No target selected |

Proposed default success condition: all **mandatory correctness/security invariants** pass, **and** optional neural optimization must show measurable improvement on a predeclared metric without worsening the verified-false-answer rate relative to a deterministic baseline. Acceptance thresholds require operator approval *before* benchmark execution; this pack intentionally does not invent numeric performance requirements.

## 3. Functional truth and boundary tests

### F01–F04: Existing logic isolation
- F01: Exhaust all 9 input pairs for 3-valued NAND, including `NAND(FALSE, UNKNOWN)=TRUE`.
- F02: Exhaust all 9 3-valued XOR combinations; preserve the exact source v0.2 semantics.
- F03: For UNKNOWN inputs with a successful `hq_eval`, verify `HQ_OK` and `HQ_UNKNOWN` remain distinct from evaluator failures.
- F04: For invalid graph/scope/input, verify non-OK error and no partial changes to external output arrays.

### F05–F08: Extended inference
- F05: Original chain `A=T, B=U, C=U; A=T=>B=F; B=F=>C=T`, query `XOR(A,C)`. QUICK => U; extended budgets 1/2 => U and EXHAUSTED; budget 3 => F with STABLE.
- F06: Reordered rule insertion yields identical results under same snapshots.
- F07: Contradictory admitted facts do not overwrite known inputs or emit a definite exported answer.
- F08: Cyclic rules either stabilize with an explicit fixed point or stop with conflict/budget outcome; infinite loops forbidden.

Existing source packages report variants of these tests; the test suite above must be rerun after any integration or source change.

## 4. Controller tests: explicit counterfactuals

| ID | Given state | Proposed action | Expected behavior |
|---|---|---|---|
| C01 | completed, checked definite result | ANSWER | return without further computation |
| C02 | completed logical UNKNOWN, admitted rules available | APPLY_LESSON | only under exact matching scope/budget |
| C03 | completed logical UNKNOWN, no applicable rules | RETURN_UNKNOWN | no fabricated certainty |
| C04 | source validation error | RECOVER | only if recovery profile authorizes it; preserve original error |
| C05 | unknown whether side effect occurred | RETRY | reject until effect state resolved or governed termination |
| C06 | L0 frame only, weight-related diagnosis requested | INSPECT L3 | authorize or deny; do not pretend L0 included full weights |
| C07 | parameter generation changed since snapshot | TRAIN/EDIT | stale generation rejection; no mutation |
| C08 | neural score high, action forbidden by policy | forbidden action | deterministic rejection regardless of score |
| C09 | exhausted budget | CONTINUE | return typed exhaustion; no recursive re-entry |
| C10 | candidate lesson without evidence | ADMIT | reject or pending verification; never silently admit |
| C11 | lesson source revoked/stale | APPLY_LESSON | deny under declared staleness policy; preserve audit record |
| C12 | conflicting evidence on unrelated outputs | ANSWER | current v0.2 remains whole-output UNKNOWN; dependency-aware alternative must be separately specified/tested |
| C13 | same network after hidden-unit permutation | weight-controller decision | action invariance or documented equivariance under semantically equivalent weights |
| C14 | same child twice, shared parameter bank | training | gradient aggregation once before one update transaction |
| C15 | parent lacks child L3 privilege | INSPECT WEIGHTS | no disclosure; typed denial and audit event |
| C16 | child exposes no weights (logic holon) | INSPECT WEIGHTS | NOT_APPLICABLE rather than fabricated zero array |

## 5. Controlled ablations

| Study | Compared conditions | Main outcome | Confounds to hold constant |
|---|---|---|---|
| A01 Visibility | L0, L1, L2 and L3 routing (if eligible) | checked result rate, bytes inspected, latency | identical problem set and controller budget |
| A02 Supervision | deterministic router vs trained router | accuracy/compute frontier | equal permitted actions and state fields |
| A03 Extended steps | fixed-step vs adaptive bounded | verified answer rate, cost, exhaustion | same total max budget |
| A04 LESSONS | empty/admitted/stale/contradictory banks | correctness, abstention, conflict detection | provenance and scope |
| A05 Feedback | no training vs verifier-admitted training vs unchecked generated feedback (test-only quarantined case) | regression, invalid lessons, false positives | independent held-out verifier |
| A06 Error visibility | typed error event vs error hidden from controller (controlled test only) | classification/diagnosis and action mistakes | same raw underlying failures |
| A07 Weight access | summaries vs raw arrays vs symmetry-aware (if implemented) | invariant decisions across weight permutations | identical functional networks |
| A08 Recursion | one level vs nested 2/3 levels | memory, stack, link depth, source mapping | identical flattened logical graph |
| A09 Recovery | no retry vs one validated retry vs exhaustion | recovery rate and retained error evidence | same initial failures and seed mapping |
| A10 Shared parameter bank | duplicate copies vs explicit alias | correct updates and state versions | identical mathematical function |

No performance conclusion may be claimed without recorded sample size, randomization/seed mapping, variance or confidence interval as appropriate, source/build hash, and predeclared acceptance criterion.

## 6. Error and negative tests

N01 Invalid pointer/length; N02 malformed/unknown enum value; N03 corrupted or out-of-range port ref; N04 stale graph generation; N05 stale parameter snapshot; N06 bank scope mismatch; N07 invalid missing provenance; N08 intentional contradictory facts; N09 exhaustion at zero or maximum budget; N10 failed verification; N11 rejected lesson admission; N12 loss/gradient containing nonfinite values; N13 unauthorized parameter edit; N14 illegal side-effect repetition; N15 torn state frame; N16 concurrent read while write; N17 replay event with mismatched run ID; N18 nested recursion beyond depth bound; N19 controller suggests unknown action; N20 no available eligible action.

Each test asserts **both** (a) correct outward result/status and (b) no unauthorized mutation or lost audit evidence. Security/privacy properties need separately threat-modeled tests; ordinary C sanitizer success does not prove them.

## 7. Memory and latency instrumentation

Measure per target/toolchain:

```text
core_code_bytes, core_static_bytes
holon_parameter_bytes, controller_parameter_bytes
state_frame_bytes, evidence_memory_bytes
peak_execution_scratch, peak_stack_bytes
input_copy_bytes, inspection_bytes, route_count
per_action_latency, peak_latency, total_eval_latency
fixed_point_rounds, retry_count, verifier_time
```

Do not double-count one parameter bank merely because multiple holons reference it. Source Holoquary v0.2 host ABI sizes are contextual examples and not target-board RAM guarantees.

## 8. Verification authority and independent attestation

- Unit/integration tests prove only the tested implementation behavior under their exact environment and build.
- Deterministic logic checking derives consequences *relative to admitted premises and specified truth semantics*.
- Evidence-source validation is distinct from logic derivation.
- A neural model's claimed confidence is not independent attestation.
- An external attester, if later built, must consume externally inspectable schematics, versioned manifests and test evidence without depending on the target to certify itself.

## 9. Completion receipt template

```text
TEST_RECEIPT
  subject_commit_or_digest:
  source_version:
  environment_and_toolchain:
  exact_configuration:
  seed_set_or_fixture:
  expected_behavior:
  observed_behavior:
  tests_passed / tests_failed / tests_inconclusive:
  code_or_memory_safety_tools:
  deviations:
  unresolved_gaps:
  evidence_artifacts:
  decision_status: PROPOSED | ACCEPTED | REJECTED
```

This protocol prevents source-generated, proposed, compiled, executed, validated and independently attested claims from being collapsed into one status.
