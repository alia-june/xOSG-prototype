# Decision, Authority, and Gap Register

**Document status:** generated reconciliation for Holoquary-003; not an independent authorization or canonical lock. Historical source statements are retained with their narrower evidence ceilings. The user may explicitly settle any open design item.

## 1. Recovered user directions (not a substitute for a full canonical source corpus)

| ID | Direction visible in current conversation | Documentation interpretation |
|---|---|---|
| U01 | Build a bare-metal neural proof of concept | Preserve standalone kernel and explicit host-versus-hardware distinction |
| U02 | Investigate holonic scaling and composition | Parent-child separation, typed ports, mapped flattened execution |
| U03 | Compare multiple neural topologies on XOR | Treat experiment as topology/optimization evidence, not as neural supervisor training |
| U04 | Develop minimal Holoquary logic engine | Keep deterministic NAND/XOR substrate |
| U05 | Four outcomes TRUE/FALSE/UNKNOWN/ERROR and distinct execution status | Expose public 4-outcome adapter without silently changing 3-valued truth table |
| U06 | Make TILT and detailed error/recovery optional; preserve QUICK | Do not force weighting, recovery, or neural control into every atomic holon |
| U07 | Replace proposed TILT with LESSONS | LESSONS denotes bounded iterative learning/inference; obsolete numeric tilt is not silently preserved |
| U08 | Consider neural supervision and feedback for LESSONS/ERROR | Controller observes feedback and may propose actions under deterministic gate |
| U09 | Controller may need subordinate inputs and weights | Support scoped and versioned inspectability; do not assume always-on complete ingestion |
| U10 | Research by probe → plan → test plan → refinement → iterate → mine patterns/anti-patterns/atomics/molecules | The current architecture is a staged research outcome, not a performed controller benchmark |

## 2. Source artifact facts

| ID | Status | Evidence from original artifact |
|---|---|---|
| S01 | IMPLEMENTED / HOST-TESTED (reported) | Holoquary v0.1 static NAND DAG, 3-valued truth, four-NAND XOR |
| S02 | IMPLEMENTED / HOST-TESTED (reported) | Holoquary v0.2 bounded LESSONS closure under given facts/rules, scope, contradiction, exhaustion |
| S03 | NOT IMPLEMENTED | Automatic lesson mining/admission, autonomous recovery, neural supervisor |
| S04 | NOT TESTED | Actual physical bare-metal deployment of Holoquary or neural supervisor |
| S05 | IMPLEMENTED / HOST-TESTED (reported) | HNN v0.4 parameterized small topology comparison and gradient tests, not full graph/holon runtime |
| S06 | PROPOSED, NOT CANONICAL | Blue Key `SAFE-CONDITION` four *outcomes*, not a substitute Holoquary logic algebra |

## 3. Architectural candidate decisions, not yet accepted

| ID | Proposed decision | Evidence rationale | Open verification |
|---|---|---|---|
| D01 | Three planes: computation, control, evidence | prevents cross-coupled ownership/authority | integration test |
| D02 | Four visibility levels L0–L3 | route without parameter flooding, inspect deeply when appropriate | byte and latency measurement |
| D03 | Scope + generation on all state frames | prevent stale, cross-context action | race and stale-snapshot tests |
| D04 | Neural proposer behind deterministic gate | prevent model score becoming action permission | forbidden-action tests |
| D05 | Evidence checker separate from lesson generator | avoid circular promotion | invented-lesson injection |
| D06 | QUICK source API preserved | avoids regression and mandatory learning overhead | baseline replay |
| D07 | EXTENDED bounded and truth-conservative | source v0.2 closure semantics | exhaustion/conflict tests |
| D08 | Optional separate diagnostic, optimizer and weight-edit functions | learned controller not forced into full-weight hot path | functional and performance ablation |
| D09 | Shared-recovery controller, not one recovery engine per holon | local primitives stay minimal | fault-isolation test |
| D10 | Anti-lessons are scoped failure records | negative evidence without universalizing | recall and overgeneralization tests |

## 4. Material open decisions

**O01 — Holon/Holoquary formal definition.** The conversation uses them operationally; a complete accepted cross-project schema has not been verified. Do not overwrite another project's definition by default.

**O02 — 4-outcome public projection.** Whether to implement a generic `Result<T>` adapter or preserve all `HQStatus` members as external status codes needs a concrete API/ABI decision.

**O03 — COMPLETION_UNKNOWN.** Detection/evidence requirements for unobserved or partial execution are unimplemented; never infer that non-response means a known execution error.

**O04 — Permission model.** Who can inspect L1–L3, authorize training, request side-effectful recovery, or admit lessons is undetermined; capabilities are not permissions.

**O05 — Weight encoding.** Raw arrays, summary statistics, graph-based encoders and symmetry-aware models have different costs. No controller architecture or training dataset has been selected.

**O06 — Learning source.** Whether supervisory policy uses supervised examples, bandit feedback, reinforcement learning, or deterministic rules is open. Existing XOR weights are not pretrained for supervision.

**O07 — Reward and accuracy.** Reward definition, hard thresholds, abstention costs, fairness/coverage and hold-out set are open. Verified correctness must not be reduced to count of definite answers.

**O08 — Lesson lifecycle.** Source authentication, independent admission, revocation, expiry, retention, corrections and historical replay are unresolved. An opaque source handle does not prove authenticity.

**O09 — Anti-lesson scope.** Formal precondition matching, time decay and causal attribution must be defined; one failure does not support a universal rule.

**O10 — Error recovery.** Recovery authority, effect-unknown policy, bounded retry schedule and receipt format require acceptance prior to consequential execution.

**O11 — Concurrency and transactionality.** Snapshot isolation, locks, exact generation check, shared parameter banking and atomic commitment need an implementation plan.

**O12 — Graph semantics.** Stateful/recurrent holons, cycles, dependency-aware contradictions, dynamic nested instances and cross-parent membership remain outside v0.2.

**O13 — External attestation.** External schematics/test evidence versus Holoquary internal checks remain distinct; no attester implementation exists here.

**O14 — Physical hardware target.** ISA, compiler, memory, linker, startup, timing and I/O remain unselected.

**O15 — Evidence privacy.** Input/weight exposure may reveal confidential data or intellectual property; no classification/redaction policy is selected.

## 5. Discrepancy and error ledger

| ID | Observation | Disposition |
|---|---|---|
| E01 | Earlier conversational v0.2 summary quoted 31,156 assertions for the LESSONS suite; the actual attached `docs/TEST_REPORT.md` reports 31,175. | Cite the actual test-report figure as *artifact-reported*, do not claim new independent rerun. The discrepancy requires reconciliation if assertion count is used for release attestation. |
| E02 | An earlier answer visually suggested four logical states in discussions of ERROR even though source v0.2 implements three-valued `HQTruth`. | Explicitly preserve existing T/F/U plus separately typed `HQStatus`; four public *outcomes* are a proposed projection. |
| E03 | Earlier claims of 'tests' of controller architecture in research stages were qualitative comparisons, not executable A/B measurements. | Label as conceptual/architectural test; all new controller experiments remain NOT EXECUTED. |
| E04 | The user said 'tilt' is no longer the desired name or static weighting mechanism. | Use LESSONS for accumulated, evidence-bound experience; do not equate this to bias, scalar weight, probability, or automatic truth. |
| E05 | Source `source_id` and `scope_id` might be confused with attested identity or access control. | Mark both as opaque handles/matching keys, not authentication or permission. |

The discrepancy ledger includes only observations supported by the available material; it is not an invented log of runtime faults.

## 6. Non-collapse and revision rule

Keep separate: observed source fact; generated design inference; explicit human acceptance; implementation; executed unit/integration test; external verification; independent attestation. Do not report a *planned* test as a *passed* test. Preserve original source packages and append future accepted amendments with specific source/commit IDs.
