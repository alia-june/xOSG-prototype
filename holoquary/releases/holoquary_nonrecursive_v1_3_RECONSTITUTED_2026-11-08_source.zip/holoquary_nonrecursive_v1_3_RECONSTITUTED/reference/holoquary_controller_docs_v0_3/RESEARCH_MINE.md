# Research Mine — Probe, Plan, Tests, Refinement, Patterns, Antipatterns

**Version:** 0.3-DRAFT. **Method:** source-guided qualitative architecture comparison, not an implementation benchmark. Bibliography and primary URLs are in `SOURCES.md`. The links cited below identify published mechanisms; their existence does not imply transfer of measured performance to Holoquary.

## 1. Research object and criteria

**Question:** What information from subordinate neural, logical and composite holons does a parent controller need, when does direct weight access help, and what must be separated to prevent an unsafe or self-confirming feedback loop?

**Success criteria for a *design strategy*:** (1) primitive logic remains deterministic; (2) local state remains locally owned; (3) parents can obtain information sufficient for each task without unconditional global copies; (4) decisions and parameter updates have explicit authorization; (5) lessons require evidence-aware admission; (6) controller halting and recovery are bounded; (7) no tested result is attributed to untested code.

**Limits:** This is a source synthesis and qualitative contract exercise; the L0–L3 controller has not been implemented or subjected to throughput, accuracy, safety, or target-board tests.

## 2. Stage P0 — Probe

Initial hypothesis: a supervisory network might require *all* child inputs and *all* child weights at each control step.

Probe finding: published methods specialize supervision by task. Sparse MoE routers choose computational experts based on input-dependent routing; learned optimizers use gradients and local parameter state; hypernetworks generate target parameters; weight-space neural models process complete parameter structures but must address hidden-neuron permutation invariances; adaptive-computation systems choose how long to compute; neuro-symbolic systems couple a learned proposer to a symbolic checking/deduction mechanism.

**Decision from probe (proposed):** universal always-on weight ingestion is not justified. Retain on-demand weight inspection as a distinct capacity.

## 3. Stage P1 — Research plan

| Family | Representative paper | Extractable concern | Non-transferable claim |
|---|---|---|---|
| Sparse routing | Switch Transformers (Fedus et al., 2022) | sparse conditional execution; router load balance | no guarantee a miniature C controller receives analogous performance |
| Learned optimization | Andrychowicz et al. (2016) | parameter-local gradient/optimizer state | no guarantee it outperforms fixed optimizers on our tiny kernel |
| Parameter generation | HyperNetworks (Ha et al., 2016) | supervised weight modification as separate job | generated weights are not automatically valid or admissible |
| Symmetry-aware weight input | Zhou et al. (2023) | hidden-neuron permutation equivariance | not necessary for a pure state-frame router |
| Adaptive stopping | ACT (Graves, 2016), PonderNet (2021) | variable computation cost, learned halting | longer computation does not guarantee true output |
| Symbolic verification | AlphaGeometry (Trinh et al., 2024) | proposal/deduction separation | deduction relative to admitted premises is not external fact attestation |
| Relational hierarchy | Graph Networks (Battaglia et al., 2018) | node, edge and global state separation | does not itself define our access-control or memory ABI |
| Neuro-probabilistic composition | DeepProbLog (Manhaeve et al., 2018) | structured neural predicates and logical reasoning | probability is not the same as strong-Kleene UNKNOWN |
| Recursive data feedback | Shumailov et al. (2024) | risk of recursively generated training-data degradation | not every generated lesson must cause collapse |

## 4. Stage P2 — Test plan as an architecture matrix

The original staged plan compared four visibility contracts against six tasks. This was a **qualitative sufficiency check**, not measured code execution.

| Task | Proposed default access | Escalation when needed | Rejection criterion |
|---|---|---|---|
| QUICK/route | L0 with relevant L1 summaries | scoped L1 | requires unrelated descendant weight copies |
| Allocate more compute | L0 status, budget and progress evidence | L1 | unbounded loops or confidence=>truth |
| Diagnose runtime or logic issue | L0 event then L1 | L2/L3 as appropriate | conflates UNKNOWN, CONFLICT, ERROR |
| Apply lessons | admitted, scope-matching references | evidence/provenance inspection | generated rule auto-admitted |
| Train/update child | L2 gradient and optimizer state | L3 specialized write when authorized | edit without generation gate or valid gradient context |
| Regenerate child parameters | L3 with topology and alias map | specialized encoder/hypernetwork | treats all weight orderings as semantically distinct or self-validating |

## 5. Stage P3 — First refinement

### R1: Weight-array flattening

**Issue:** A feedforward network may represent the same function under a consistent permutation of hidden neurons. A controller consuming a raw positional vector can inadvertently learn arbitrary ordering conventions rather than functional features.

**Refinement:** keep complete weights accessible through explicit L3 inspection; do not make them universal hot-path features. For learned weight-space processing, use structural or permutation-aware representations and test with hidden-neuron reorderings. Supported as a relevant research concern by Zhou et al. (2023); implementation choice remains open.

### R2: Self-confirming LESSONS

**Issue:** A model that generates a candidate lesson, labels its own suggestion as correct, and trains on that label creates a circular validation route. Recursive synthetic-data degradation and reward-specification concerns make this a credible failure mode.

**Refinement:** proposal -> independent check -> scoped admission -> optional training datum. A failed check remains retained as a negative event, not simply forgotten.

## 6. Stage P4 — Refinement test

Against the six tasks, L0–L3 access plus an external gate can represent the required data/authority boundary. Crucially, this is a **design sufficiency finding**: it does not show that the controller is performant, secure, trained, or better than a deterministic scheduler. These remain empirical questions for `TEST_PLAN.md`.

## 7. Stage P5 — Recursive refinement

**Issue:** A parent that copies all descendant inputs, gradients, weights and lessons every cycle defeats encapsulation and grows observation bandwidth with the entire descendant graph.

**Refinement:** each child publishes a state frame; parents request deeper snapshots when necessary, with explicit depth/budget limits. Graph-network literature provides a structural precedent for local and global state aggregation. The source-mapped compiled execution plan can be flattened without flattening *ownership* or *authority*.

**Strategy status:** stable research candidate. The iteration ceases because the qualitative jobs have distinct, noncontradictory interfaces; this does not substitute for executable integration or target-hardware validation.

---

# 8. Reusable patterns

Each item specifies **atomics** (small independently typed units), a **molecule** (a useful composition), evidence type and an implementation caution.

## P01. Sparse routing
- **Research:** Fedus et al., Switch Transformers.
- **Atomics:** child ID, eligible-set, route score, input/state summary, dispatch budget.
- **Molecule:** `state frame + router + deterministic eligibility gate -> selected child`.
- **Use:** avoid executing every child for every request.
- **Caution:** route score is not permission; monitor starvation and availability.

## P02. Adaptive pondering
- **Research:** Graves ACT; Banino et al., PonderNet.
- **Atomics:** compute remaining, outcome status, progress event, halt proposal.
- **Molecule:** `QUICK -> (continue / answer / unknown) -> bounded EXTENDED`.
- **Use:** spend more steps when they can produce additional checked work.
- **Caution:** no claim of truth-by-time; always permit UNKNOWN/exhaustion.

## P03. Local optimizer
- **Research:** Andrychowicz et al. learned optimizers.
- **Atomics:** weight/gradient coordinate, parameter generation, optimizer state, update proposal.
- **Molecule:** `gradient view + update rule + checked parameter transaction`.
- **Use:** child training without sending every value through one giant dense controller.
- **Caution:** parameter write authority separate from inspector rights.

## P04. Weight synthesis or editing
- **Research:** Ha et al. HyperNetworks; Zhou et al. neural functionals.
- **Atomics:** architecture identifier, parameter slot map, weights, invariance profile, update proposal.
- **Molecule:** `explicit L3 view + structural encoder/generator + validator + commit gate`.
- **Use:** specialized diagnostics or regeneration.
- **Caution:** preserve parameter identity and check functional behavior after edits; do not grant direct control by default.

## P05. Proposer + formal checker
- **Research:** AlphaGeometry; DeepProbLog (different integration semantics).
- **Atomics:** candidate inference/action, admitted premises, checker result, trace.
- **Molecule:** `neural proposal + symbolic evaluator + evidence record`.
- **Use:** leverage heuristic search without granting it logical authority.
- **Caution:** verifier proves only what its own semantics and premises entail.

## P06. Explicit external memory
- **Research:** neural/external-memory systems and source Holoquary v0.2 lesson bank.
- **Atomics:** scoped rule, source ref, admission state, timestamp/generation, retrieval key.
- **Molecule:** `validated experience + lesson store + retrieval + bounded reevaluation`.
- **Use:** replay knowledge without forcing every lesson into weights.
- **Caution:** provenance handle alone is not admission; stale facts need revocation semantics (open).

## P07. Graph-state publication
- **Research:** Battaglia et al. Graph Networks.
- **Atomics:** node/edge/global descriptors, generation, parent/child relationship, aggregation policy.
- **Molecule:** `local holon state -> published frame -> parent decision`.
- **Use:** recursive composition.
- **Caution:** topology relation does not itself grant execution or read access.

## P08. Verifiable feedback
- **Research:** verified symbolic learning and synthetic-data contamination risk.
- **Atomics:** execution event, candidate lesson, checked outcome, source refs, admission receipt.
- **Molecule:** `attempt -> evaluator -> evidence -> admission -> optional training`.
- **Use:** controller improvement without self-authorized assertions.
- **Caution:** independent checker failure must block promotion even if neural prediction is confident.

---

# 9. Anti-patterns and anti-lessons

**Anti-lesson definition:** a scoped, provenance-linked record of an observed or demonstrated unsuccessful method. It is *not* an inverted logical proposition or a universal prohibition.

| ID | Anti-pattern | Counter-pattern | What would demonstrate the problem locally |
|---|---|---|---|
| A01 | All subordinate weights copied every control tick | L0/L1 hot path, L3 scoped pull | throughput/memory grows with every inactive descendant |
| A02 | Raw weight positions treated as neuron identity | permutation-aware encoding or behavioral features | same network function, changed controller response after hidden-unit permutation |
| A03 | Model accepts its own generated lesson as ground truth | external check and source admission | fabricated rule causes unjustified TRUE, then self-reinforces |
| A04 | UNKNOWN rewarded as failure, definite answers always rewarded | score verified correctness and abstention | invalid definite guesses outperform honest UNKNOWN by reward |
| A05 | Logic conflict converted to training residual | typed conflict/trace channel | logical contradiction misclassified as gradient information |
| A06 | Reattempts with unknowable external effects | effect-state check and bounded recovery | duplicate unintended side effects after crash/timeout |
| A07 | Every child trains whenever parent trains | selective, versioned training rights | unrelated child weights change across an inference-only action |
| A08 | Unbounded extended reasoning | finite budget and stop condition | cyclic lessons exhaust resources without terminal result |
| A09 | Controller edits verifier or reward | independent immutable checker policy | answer status changes when controller rewrites acceptance criteria |
| A10 | Routing starves rarely selected children | eligible-set coverage, dispatch metrics | routing count for some eligible children approaches zero despite relevant work |
| A11 | Evidence overwritten after successful retry | append-only original error and disposition | original failure disappears from subsequent inspection |
| A12 | Summaries presented as full observation | `returned_fields` and `omitted_fields` | parent makes a weight-level claim based on L0 only |
| A13 | Snapshot mixes child generations | immutable snapshots and expected-generation checks | stale gradient applied to a newer parameter bank |
| A14 | Treat a valid Holoquary UNKNOWN as runtime error | separate truth/disposition/status | QUICK generates recovery for normal three-valued NAND uncertainty |

## 10. Atomic construction vocabulary

**Identity/provenance:** `HolonID`, `DefinitionID`, `InstanceID`, `Generation`, `SnapshotID`, `ScopeRef`, `SourceRef`, `VerifierRef`.

**Numerical:** `InputRef`, `ActivationView`, `WeightView`, `GradientView`, `Residual`, `Loss`, `ParameterVersion`, `ParameterSummary`.

**Logic:** `HQTruth`, `HQStatus`, `EvaluationDisposition`, `LogicRuleRef`, `ConflictRef`.

**Control:** `StateFrame`, `Budget`, `ActionProposal`, `EligibilityResult`, `InspectionRequest`, `InspectionResult`, `HaltReason`.

**Evidence:** `Observation`, `EvidenceEvent`, `LessonCandidate`, `AntiLessonCandidate`, `AdmissionReceipt`, `RecoveryReceipt`.

They are candidate *types*, not known C ABI definitions. Every type needs a shape, scope, ownership and validity policy before implementing it.

## 11. Molecular assemblies

| Molecule | Atomics / services | Output contract |
|---|---|---|
| QUICK | source Holoquary `hq_eval` | T/F/U with separately checked `HQStatus` |
| EXTENDED (existing) | `hq_eval_extended` + admitted bank + budget | T/F/U + STABLE/CONFLICT/EXHAUSTED trace |
| Proposed neural router | state frames + controller weights + eligibility gate | permitted child request or typed rejection |
| Proposed diagnostic | event + L1/L2 + optional L3 | bounded diagnosis with omitted-evidence record |
| Proposed training | gradients + optimizer + versioned bank | checked update or failure; no hidden mutation |
| Proposed LESSONS feedback | event + source + verifier + admission | admitted/rejected scoped record |
| Proposed anti-lesson | unsuccessful attempt + scope + evidence | bounded negative recommendation evidence |
| Proposed recovery | error + effect classification + authorization + single attempt | outcome receipt, including unresolved effects |
| Proposed recursive parent | children state frames + parent state + selected inspection | bounded action proposal without descendant flattening |

## 12. Transfer conditions

Do not import external implementations wholesale. A source pattern becomes a project component only after its required types, resource bounds, error behavior, provenance, authority checks, test oracle and interface are independently specified. An interesting literature paper is not evidence that our C engine implements the paper's method.
