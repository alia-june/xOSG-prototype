# Holoquary-003 — Controller and Feedback Architecture

**Version:** 0.3-DRAFT; **status:** generated proposal, not implemented.  
**Relation to source:** Holoquary-001 v0.2 and HNN-001 v0.4 remain unmodified existing reference artifacts.

## 1. System boundaries

The *holon* is an addressable computational unit, which may be primitive or composite. A subordinate may be a deterministic logic gate, a trainable neural block, or a bounded composite. An *Holoquary* is the proposed organization/logic environment coordinating its child holons. This is an architectural usage, not evidence that the word has a previously accepted universal definition.

Three **planes** are separate:

| Plane | Owns | Does not establish |
|---|---|---|
| Data/computation | Holon inputs, outputs, weights where applicable, activations, gradients, local execution | Proposition truth outside declared semantics; authority for global actions |
| Control | State frames, routing/stop decisions, budget allocation, inspection requests, action proposals, deterministic gates | Independent evidence or right to modify a subordinate merely from observing it |
| Evidence | Event records, scope-bound lessons, anti-lessons, admitted sources, verifier results, error/recovery audit | Automatic admission or truth by repeated assertion |

Subordinate parameter ownership remains local or explicitly shared. Inference may remain operable with the supervisory layer absent. Optional controllers may be neural, deterministic, or combined. The original NAND and neural kernels must remain usable without the parent system.

## 2. Behavioral invariants (proposed)

- **HNN-C01 Locality:** No required per-step copy of all descendants' weights into each ancestor.
- **HNN-C02 Versioning:** Observed state identifies the exact holon and parameter/graph generation from which it came.
- **HNN-C03 Types:** Logical UNKNOWN, execution-failure, execution-completion-UNKNOWN, numeric residual, conflict, and fuzzy membership are non-interchangeable typed values.
- **HNN-C04 Source authority:** A `source_id` is a pointer, not proof, independent verification or authorization.
- **HNN-C05 Proposal boundary:** Learned controllers propose; gates authorize and execute; verifier/evidence pipeline determines admission.
- **HNN-C06 No self-certification:** The controller cannot change its own verifier, reward oracle, success criteria or historic error evidence as part of answering.
- **HNN-C07 Immutable evaluation:** Evaluations consume versioned input snapshots. Training/parameter mutation cannot occur between a forward pass and its corresponding backward pass without explicit re-evaluation.
- **HNN-C08 Explicit sharing:** Shared parameter banks have one identity and accumulate relevant gradients before update.
- **HNN-C09 Bounded action:** EXTENDED loops and recovery have finite action/round/compute budgets, scoped authority and a terminal disposition.
- **HNN-C10 Retain negative evidence:** Conflicts, exhaustion, failed proposed actions and rejected lessons cannot be erased by successful later runs.
- **HNN-C11 Truth invariance:** Neural proposals and lessons may select premises/rules or computation strategy; they do not rewrite established NAND semantics or convert UNKNOWN into TRUE by confidence alone.
- **HNN-C12 Access split:** Observe, inspect, train, edit, admit a lesson, verify, and recover are separate privileges.
- **HNN-C13 Atomic commit:** Invalid inspection/evaluation/admission attempts must not partially mutate externally visible accepted state.
- **HNN-C14 Source mapping:** A compiled/flattened execution plan maintains an externally available map back to its holon definitions and invocation instances.

These are *acceptance requirements for a proposed design*, not claims that existing code enforces them.

## 3. Four controller visibility tiers

| Tier | Minimum contents | Appropriate uses | Caveat |
|---|---|---|---|
| **L0** Published frame | holon ID, graph generation, output/result, status, budget, counts, input/parameter references | normal routing, QUICK, high-level composition | summary omits internals |
| **L1** Operational inspection | L0 + typed input view, activations, intermediate outputs and residuals | localized reasoning/debug, feedback diagnosis | access may expose private/sensitive inputs; must be authorized |
| **L2** Training inspection | L1 + parameter gradients, loss, optimizer state, parameter summaries | learning coordination, diagnosing stagnation | gradients must correspond to the same model generation |
| **L3** Complete parameter inspection | L2 + full weight/bias arrays and detailed parameter maps | explicit weight diagnostics, editing or hypernetwork-like generation | costly; has symmetry/aliasing issues; read is not write |

These tiers are requests/permissions, not mandatory physical buffers. For a three-parameter scalar holon, the implementation may inline all values cheaply; for large composites, lazy inspection avoids catastrophic expansion.

A `state_frame` is a stable *observation of a particular generation*, not a capability token. A child may publish L0 voluntarily; it must not be assumed that the parent can inspect arbitrary L3 content.

## 4. Proposed wire-level records

The following **schema sketch is noncanonical** and omits representation encoding, ABI padding, authentication and persistence format.

```text
HolonStateFrame {
    holon_id               : StableID
    definition_id          : StableID
    instance_id            : StableID
    graph_generation       : U64
    parameter_generation   : U64?             // absent for nonparametric logic
    input_ref              : TypedRef?        // not all values copied
    input_summary_ref      : TypedRef?
    output_ref             : TypedRef?
    truth_value            : T | F | U | NOT_APPLICABLE
    evaluation_disposition : STABLE | CONFLICT | EXHAUSTED | NOT_RUN
    execution_status       : COMPLETED | FAILED | COMPLETION_UNKNOWN
    error_event_ref        : EventRef?
    lesson_refs            : BoundedRefList
    anti_lesson_refs       : BoundedRefList
    parameter_count        : U32?
    parameter_summary_ref  : TypedRef?
    gradient_summary_ref   : TypedRef?
    budget_used            : U64
    budget_remaining       : U64
    snapshot_id            : StableID
    provenance_ref         : TypedRef?
}
```

`COMPLETION_UNKNOWN` is proposed for situations in which the outer controller cannot establish that a requested operation completed. It must **not** be manufactured by converting a known internal failure to UNKNOWN. For source v0.2 the current `HQStatus` remains authoritative; the proposed enum is a higher-level adapter.

```text
InspectionRequest {
    target_instance        : StableID
    expected_graph_gen     : U64
    expected_param_gen     : U64?
    requested_tier         : L0 | L1 | L2 | L3
    fields                 : FieldMask
    scope                  : ScopeRef
    authority_ref          : AuthorityRef
    max_bytes              : U32
    max_compute            : U64
}
InspectionResult {
    status                 : OK | DENIED | STALE | INVALID | PARTIAL | ERROR
    actual_generations     : VersionPair
    returned_fields        : FieldMask
    omitted_fields         : FieldMask
    immutable_snapshot_ref : TypedRef?
    evidence_ref           : TypedRef?
}
```

If fields are omitted or stale, the controller must not act as though it received the complete child state. L3 reads may need paging or immutable snapshots and should never silently exceed declared budgets.

## 5. Distinct truth, status and evidence domains

| Domain | Example values | Meaning |
|---|---|---|
| Logic `HQTruth` (existing) | TRUE, FALSE, UNKNOWN | Strong-Kleene logical result |
| Execution `HQStatus` (existing) | HQ_OK or typed non-OK code | Did the evaluator itself execute validly? |
| Extended trace (existing) | STABLE, CONFLICT, EXHAUSTED | Why a valid extended evaluation was conclusive or not |
| Public condition outcome (proposed adapter) | TRUE, FALSE, UNKNOWN, ERROR | Simplified interface mapping a failed evaluation to ERROR |
| Outer completion accounting (proposed) | COMPLETED, FAILED, COMPLETION_UNKNOWN | Whether an attempt's completion is known |
| Numerical model | loss, residual, gradient | Scalar/tensor training or predictive signal, not Boolean truth |
| Fuzzy reasoning (not implemented) | membership value under named fuzzy-set semantics | Membership, not probability or truth without explicit grounding |
| Evidence | ADMITTED, PROPOSED, REJECTED, CONFLICTED, STALE | Evidence governance, not the raw NAND value |

Do not merge execution ERROR into a four-valued *logical* algebra without explicitly selecting that algebra and its operators. A source-system draft may expose four condition *outcomes* without changing the Holoquary's internal 3-valued truth table. See `DECISIONS.md`.

## 6. Candidate controller actions

```text
ANSWER               publish checked result (or UNKNOWN)
CONTINUE             allocate bounded additional evaluation
ROUTE                choose an eligible child holon
INSPECT              request a scoped L1/L2/L3 snapshot
APPLY_LESSON         apply an existing admitted lesson under matching scope
REQUEST_EVIDENCE     request more available, admissible evidence
VERIFY               invoke independent rule/result checker
RECOVER              request an authorized recovery procedure
RETURN_UNKNOWN       terminate without invented answer
```

Every action includes target IDs, scope, expected generations, budget and a trace ID; a neural score is a recommendation, not authorization. Operations that affect state require stronger checks than `ANSWER` on a pure snapshot.

```text
ActionProposal {
    proposer_id          : StableID
    parent_snapshot      : StableID
    action               : ActionEnum
    target_id            : StableID?
    expected_generation  : U64?
    requested_budget     : U64
    suggested_priority   : Numeric?    // not truth probability by default
    supporting_refs      : RefList
}
```

The deterministic gate validates: operation supported; legal target; identity/scope; exact generation; permissions; side effects; compute/time/memory budget; replay and state mutation safety. Invalid or stale action => no mutation, typed failure evidence.

## 7. QUICK/EXTENDED control loop

**QUICK** calls the source `hq_eval(...)` directly in Holoquary v0.2. It remains independent of lessons and neural supervision. The controller may provide a separately defined shortcut policy in a future version; it must not redefine the existing quick API.

**EXTENDED** in v0.2 calls `hq_eval_extended(...)` using externally admitted facts/rules, same-scope identifiers, caller-owned buffers and a bounded number of synchronous closure rounds. That routine is deterministic and does *not* mine new lessons.

**Proposed supervised extension (not implemented):**

```text
observe immutable state frame
while within budget:
    if output is checked and policy permits publication: ANSWER
    propose action via optional controller (or deterministic fallback)
    validate proposed action through deterministic gate
    if denied/stale: record event and choose permitted fallback or stop
    execute permitted action on immutable snapshot/transaction
    obtain typed outcome and independent verification where required
    append evidence event; do not silently mutate admitted lesson bank
    refresh state frame with exact generation, cycle and budget
    if no valid progress or exhaustion: return UNKNOWN / typed ERROR
```

**No-progress detection** must not treat an unchanged truth value as proof that no new evidence or useful diagnostic information was gained; it must use explicit state/event deltas under a named criterion. Conversely, repeated cycles without new admitted information must not automatically promote UNKNOWN to TRUE.

## 8. LESSONS and ANTI-LESSONS

Existing v0.2 LESSONS are only caller-admitted Boolean facts and conditional rules, evaluated under scope keys. `source_id != 0` identifies a source handle; it is *not* authentication or independent attestation. Existing contradiction handling turns **all** exported results UNKNOWN under a valid `HQ_OK` trace=CONFLICT; budget exhaustion likewise returns UNKNOWN/EXHAUSTED. These v0.2 facts must not be replaced silently by new learning records.

The new candidate supervisory memory layer may hold:

```text
LessonCandidate {
    lesson_id            : StableID
    precondition         : TypedPredicate
    action               : ActionEnum
    observed_outcome     : TypedOutcome
    source_refs          : RefList
    target_scope         : ScopeRef
    prior_generation     : U64
    verification_record  : OptionalRef
    admission_state      : CANDIDATE | ADMITTED | REJECTED | STALE
}
AntiLessonCandidate {
    scope                : ScopeRef
    state_signature      : TypedPattern
    failed_action        : ActionEnum
    observed_failure     : TypedOutcome
    causal_claim         : UNPROVEN | SUPPORTED
    provenance_refs      : RefList
    admission_state      : CANDIDATE | ADMITTED | REJECTED | STALE
}
```

An *anti-lesson* documents negative scoped experience; it does not assert that an action is always wrong. A lesson is not necessarily a formal theorem and does not have to be encoded into neural parameters. Candidate lessons go through external admission; accepted lessons can become training examples only under a separately defined data/training policy.

### Feedback transaction

```text
ChildOutcome -> EvidenceEvent -> CandidateLesson
             -> IndependentCheck -> AdmissionDecision
             -> AdmittedLessonMemory -> OptionalTrainingData
```

A failed check yields an auditable rejected/contradicted candidate. The learned controller must not edit checker policy, oracle outputs, or its own success record.

## 9. ERROR, RECOVERY, and completion

Distinguish (a) numerical training error, (b) unresolved logic, (c) contextual contradiction, (d) computation failure, (e) unknowable external side effect. They require different types and controls. A valid logical UNKNOWN is **not** a fault. Conflict/exhaustion in the source v0.2 are `HQ_OK` evaluations with an UNKNOWN output and a trace.

Recovery is **optional** but cannot suppress mandatory typed failure reporting. It is not automatically invoked by UNKNOWN and cannot retry external effects whose completion state is unproved. A proposed recovery transaction is:

```text
classify -> snapshot -> identify allowable bounded recovery
         -> propose -> authorize -> execute once -> verify
         -> retain old error + new evidence -> terminate
```

The actual system-wide recovery procedure, trust boundary, error taxonomy and authorization model are **not yet implemented or locked**. The previous Blue Key materials provide potentially reusable distinctions but do not automatically govern Holoquary without explicit adoption.

## 10. Neural supervisor: input and weight access

A controller has its own parameters `Theta_C`, separate from child parameter banks `Theta_i`. Normal operation:

`Controller(StateFrame, Theta_C) -> ActionProposal`.

L3 access is appropriate only for a weight-specific diagnostic or parameter-editing operation. Under training coordination, gradient/optimizer information may be sufficient without encoding all child weights as neural input features. Equal-valued permutations of hidden-neuron order can represent the same function, so direct weight-space models should consider permutation symmetries (see SOURCES.md). Parameter inspection, parameter use by a child, and authorization to modify parameters are non-equivalent.

The trained HNN XOR model is a *mathematical test case* only; it was not trained as a Holoquary controller. No architecture, labels, reward definition or controller training results are established by this document.

## 11. Recursion, flattening and parameter sharing

A parent sees a child composite through published typed ports and a state frame. It may request inspection recursively only under explicit permissions and bounded depth/bytes. `CONTAINS` is structural and does not imply `INPUT_TO`; `SHARES_PARAMETERS_WITH` is an explicit reference, never name-based aliasing. A compiled execution graph may flatten child operations, but the source map preserves identity and definition/instance lineage.

Concurrent reads/writes require generation checking or immutable snapshots. No ancestor obtains implicit permission to rewrite child weights or to modify lessons merely because it can route work to that child.

## 12. Resource model

Proposed costs: `state_frame_bytes + optional inspection bytes + controller parameter/activation bytes + evidence/event bytes + child execution scratch + bounded retry memory`. Do not add raw child parameter bytes again for each ancestor merely because it can inspect them. For current source reference, v0.2 reports `sizeof(HQProgram)=300`, `sizeof(HQLessonBank)=428`, `sizeof(HQLessonTrace)=20` **on the tested x86-64 ABI**; these are not overall deployed memory usage. A freestanding object compile on a host does not establish physical target boot, timing or memory safety.

## 13. Explicitly out of scope

- Autonomous lesson mining/admission and self-training in the existing C modules.
- General four-valued truth logic automatically derived from an ERROR status.
- Automatic hardware recovery or external side-effect replay.
- A universal controller that already understands arbitrary network topologies.
- Any claim that more computation must reduce error or reach definite truth.
- Physical bare-metal target selection, integration, or testing.
