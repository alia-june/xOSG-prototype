#ifndef HQD_SEPARATION_H
#define HQD_SEPARATION_H
/* v1.2 additive, nonrecursive domain / knowledge / execution separation.
 * Historical HQ5_TERNARY_UE and HQX_ERROR interfaces are NOT modified.
 * No automatic authority or authenticity arises from any metadata field.
 */
#include <stdint.h>
#include "holoquary.h"
#include "hq_radix5.h"
#include "hq_higher.h"
#include "hq_block7.h"

typedef enum { HQD_BALANCED3=1, HQD_PURE5=2, HQD_BALANCED7=3,
               HQD_KLEENE3=4 } HQDDomain;
typedef enum { HQD_ABSENT=0, HQD_NUMBER=1, HQD_LOGIC=2 } HQDValueKind;
typedef enum { HQD_EXEC_COMPLETE=1, HQD_EXEC_FAILED=2,
               HQD_EXEC_COMPLETION_UNKNOWN=3 } HQDExecutionState;
typedef enum { HQD_NO_MARKER=0, HQD_LEGACY_E_MARKER=1 } HQDMarker;
typedef enum { HQD_ORIGIN_UNATTESTED=0, HQD_ORIGIN_CALLER=1,
               HQD_ORIGIN_DERIVED=2 } HQDOrigin;
typedef enum { HQD_OK=0, HQD_NULL, HQD_BAD_DOMAIN, HQD_BAD_VALUE,
               HQD_BAD_METADATA, HQD_BAD_OPERATION, HQD_DENIED,
               HQD_UNSUPPORTED } HQDStatus;
typedef enum { HQD_LT=1u, HQD_EQ=2u, HQD_GT=4u } HQDRelation;
/* A single value field contains only a mathematical value, or ABSENT.
 * For KLEENE3, logical UNKNOWN is a legitimate exact logical value.
 * Numeric UNKNOWN never occupies number; it is a possibility mask. */
typedef struct {
    HQDValueKind kind;
    int8_t number;
    HQTruth logic;
} HQDData;
/* Each bit is one POSSIBLE mathematical value in the named domain.
 * GRADE 0=unspecified, 1..3=caller-declared classifications only;
 * no grade ordering, evidence independence or truth authority is inferred. */
typedef struct {
    uint16_t possibilities;
    uint8_t unknown_grade;
} HQDKnowledge;
typedef struct {
    HQDExecutionState state;
    uint32_t error_code;
    HQDMarker marker;
} HQDExecution;
typedef struct {
    uint32_t source_id, scope_id, generation;
    HQDOrigin origin;
} HQDProvenance;
typedef struct {
    HQDDomain domain;
    HQDData data;
    HQDKnowledge knowledge;
    HQDExecution execution;
    HQDProvenance provenance;
} HQDRecord;
/* Pair (carry,digit) kept JOINT, not independent marginal masks.
 * Bit index: carry_ordinal * radix + digit_ordinal.
 * PURE5 carries 0,1; balanced3/7 carries -1,0,+1. */
typedef struct {
    HQDDomain domain;
    uint32_t joint;
    HQDExecution execution;
    HQDProvenance provenance;
} HQDAddResult;
/* Only explicitly requested lossy bridges may return legacy U/E.
 * They are never allowed to turn actual execution failure into HQ5_E. */
typedef enum { HQD_BRIDGE_EXACT=0, HQD_BRIDGE_ALLOW_U=1u,
               HQD_BRIDGE_ALLOW_E=2u } HQDBridgePolicy;

HQDStatus hqd_validate(const HQDRecord *record);
HQDStatus hqd_exact_number(HQDDomain domain, int value, HQDRecord *out);
HQDStatus hqd_exact_logic(HQTruth value, HQDRecord *out);
HQDStatus hqd_possibilities(HQDDomain domain, unsigned mask,
                            unsigned grade, HQDRecord *out);
HQDStatus hqd_refine(const HQDRecord *a, const HQDRecord *constraint,
                     HQDRecord *out);
HQDStatus hqd_add_digits(const HQDRecord *a, const HQDRecord *b,
                          HQDAddResult *out);
HQDStatus hqd_add_project(const HQDAddResult *pairs, HQDRecord *digit,
                           HQDRecord *carry);
HQDStatus hqd_compare(const HQDRecord *a, const HQDRecord *b,
                       uint8_t *out_relations);
HQDStatus hqd_relation_truth(uint8_t possible_relations, HQDRelation requested,
                              HQDRecord *out);
/* A mathematical truth is not a permission grant. This is an advisory
 * signal only, never external side-effect authorization. */
HQDStatus hqd_guard_proposal(const HQDRecord *logical, int *out_allow);
HQDStatus hqd_get_number(const HQDRecord *record, int *out_value);
HQDStatus hqd_from_hq5(HQ5Value legacy, HQDRecord *out);
HQDStatus hqd_to_hq5(const HQDRecord *record, unsigned policy, HQ5Value *out);
HQDStatus hqd_from_hq7(HQ7Set legacy, HQDRecord *out);
HQDStatus hqd_to_hq7(const HQDRecord *record, HQ7Set *out);
HQDStatus hqd_from_hqx(HQXCondition legacy, HQDRecord *out);
HQDStatus hqd_to_hqx(const HQDRecord *record, unsigned policy,
                      HQXCondition *out);
#endif
