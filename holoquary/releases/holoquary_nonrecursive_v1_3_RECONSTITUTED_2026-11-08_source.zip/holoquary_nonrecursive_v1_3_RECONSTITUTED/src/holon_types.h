#ifndef HOLON_TYPES_H
#define HOLON_TYPES_H
/* Holoquary-004 v0.4 integration candidate. New adapter ABI, not canonical. */
#include "holoquary.h"
#include "hq_lessons.h"
#include "topology_nn.h"

typedef enum { HCI_OK=0, HCI_ERR_NULL, HCI_ERR_INVALID,
               HCI_ERR_NUMERIC, HCI_ERR_SOURCE, HCI_ERR_STALE,
               HCI_ERR_DENIED, HCI_ERR_CAPACITY, HCI_ERR_BUDGET,
               HCI_ERR_NOT_APPLICABLE } HCIStatus;
typedef enum { HCI_NEURAL=1, HCI_LOGIC=2 } HCIKind;
typedef enum { HCI_COMPLETED=1, HCI_FAILED=2, HCI_COMPLETION_UNKNOWN=3 } HCIExec;
typedef enum { HCI_UNCHECKED=0, HCI_STABLE=1, HCI_CONFLICT=2,
               HCI_EXHAUSTED=3, HCI_NOT_APPLICABLE=4 } HCIDisposition;
typedef enum { HCI_RESULT_NONE=0, HCI_RESULT_LOGIC=1,
               HCI_RESULT_NUMERIC=2 } HCIResultKind;
typedef enum { HCI_CLASSIFICATION=1 } HCIConversionDomain;
typedef enum { HCI_INPUT_UNATTESTED=0, HCI_INPUT_CLASSIFIED=1 } HCIInputOrigin;

typedef struct {
    unsigned int holon_id;       /* 0 is invalid */
    unsigned int instance_id;    /* 0 is invalid */
    unsigned int graph_gen;      /* application-owned generation */
    unsigned int param_gen;      /* 0 for parameter-free logic */
    unsigned int snapshot_id;    /* caller provides a unique run identifier */
} HCIIdentity;

typedef struct {
    HCIIdentity identity;
    HCIKind kind;
    HCIExec execution;
    HCIResultKind result_kind;
    HCIDisposition disposition;
    HQTruth truth;               /* valid ONLY if result_kind==HCI_RESULT_LOGIC */
    float number;                /* valid ONLY if result_kind==HCI_RESULT_NUMERIC */
    HQStatus source_status;      /* native Holoquary result, or HQ_OK for neural */
    unsigned int input_count;
    unsigned int parameter_count;
    HCIInputOrigin input_origin;
    unsigned int input_conversion_id; /* conversion policy, NOT evidence attestation */
    unsigned int lesson_rounds;
    unsigned int new_facts;
    unsigned int conflict_count;
    unsigned int compute_remaining;
} HCIFrame;

typedef struct {
    const HQProgram *program;
    HCIIdentity identity;
} HCILogicAdapter;

typedef struct {
    const DNNModel *model;
    HCIIdentity identity;
    float observed_input[DNN_INPUTS];
    unsigned int observed_snapshot;
    unsigned int has_observation;
} HCINeuralAdapter;

typedef struct {
    float false_max;
    float true_min;
    unsigned int conversion_id;
} HCIThreshold;

typedef struct {
    HQTruth value;
    unsigned int source_holon_id;
    unsigned int source_snapshot_id;
    unsigned int conversion_id;
    HCIConversionDomain domain;  /* signal classification, NOT independently attested fact */
} HCIClassifiedSignal;

#define HCI_VIEW_L0 1u
#define HCI_VIEW_L1 2u
#define HCI_VIEW_L2 4u
#define HCI_VIEW_L3 8u

typedef enum { HCI_ACT_ANSWER=0, HCI_ACT_RETURN_UNKNOWN,
               HCI_ACT_APPLY_LESSON, HCI_ACT_CONTINUE,
               HCI_ACT_ROUTE, HCI_ACT_REPORT_ERROR,
               HCI_ACT_REQUEST_EVIDENCE, HCI_ACT_INSPECT,
               HCI_ACT_COUNT } HCIAction;
#define HCI_ACTION_BIT(a) (1u << (unsigned int)(a))

typedef struct {
    HCIAction action;
    unsigned int target_holon_id;
    unsigned int observed_graph_gen;
    unsigned int observed_param_gen;
    unsigned int observed_snapshot_id;
    unsigned int requested_budget;
} HCIProposal;

typedef struct {
    unsigned int action_mask;     /* explicit control gate grants */
    unsigned int max_budget;
    unsigned int target_holon_id; /* exact binding */
} HCIGrant;

HCIStatus hci_validate_identity(const HCIIdentity *id);
HCIStatus hci_observe_logic(const HCILogicAdapter *adapter,
                            const HQTruth *inputs, unsigned int count,
                            unsigned int budget_left, HCIFrame *frame);
HCIStatus hci_observe_classified_logic(const HCILogicAdapter *adapter,
                                       const HCIClassifiedSignal *signals,
                                       unsigned int count,
                                       unsigned int conversion_id,
                                       unsigned int budget_left, HCIFrame *frame);
HCIStatus hci_observe_extended(const HCILogicAdapter *adapter,
                               const HQTruth *inputs, unsigned int count,
                               const HQLessonBank *bank, unsigned int scope_id,
                               unsigned int rounds, unsigned int budget_left,
                               HCIFrame *frame);
HCIStatus hci_observe_neural(HCINeuralAdapter *adapter,
                             const float inputs[DNN_INPUTS],
                             unsigned int budget_left, HCIFrame *frame);
HCIStatus hci_classify_signal(const HCIFrame *neural,
                              const HCIThreshold *threshold,
                              HCIClassifiedSignal *out);
HCIStatus hci_inspect_neural_inputs(const HCINeuralAdapter *adapter,
                                    unsigned int expected_snapshot,
                                    unsigned int expected_param_gen,
                                    unsigned int view_mask,
                                    float out[DNN_INPUTS]);
HCIStatus hci_inspect_neural_weights(const HCINeuralAdapter *adapter,
                                     unsigned int expected_graph_gen,
                                     unsigned int expected_param_gen,
                                     unsigned int view_mask,
                                     float *out, unsigned int capacity,
                                     unsigned int *used);
HCIStatus hci_controller_propose(const HCIFrame *frame,
                                  unsigned int applicable_lessons,
                                  HCIProposal *out);
HCIStatus hci_gate_proposal(const HCIProposal *proposal,
                            const HCIFrame *current,
                            const HCIGrant *grant);
#endif
