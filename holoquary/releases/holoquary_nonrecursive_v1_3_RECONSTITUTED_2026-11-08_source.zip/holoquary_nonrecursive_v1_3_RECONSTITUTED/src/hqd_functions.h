#ifndef HQD_FUNCTIONS_H
#define HQD_FUNCTIONS_H
/* Reconstituted Holoquary v1.3 nonrecursive higher functions.
 * Rebuilt 2026-11-08 from preserved v1.2 source plus preserved v1.3 contract.
 * This is not claimed byte-identical to the lost historical v1.3 module.
 */
#include <stdint.h>
#include "hqd_separation.h"

#define HQDN_MAX_TICKS 4u

typedef enum {
    HQDN_NOT=0,
    HQDN_AND,
    HQDN_OR,
    HQDN_XOR,
    HQDN_IMPLIES,
    HQDN_EQUIV,
    HQDN_MAJORITY
} HQDNLogicOp;

typedef struct {
    uint32_t instance_id;
    uint32_t generation;
    HQDRecord state;
} HQDNCell;

typedef struct {
    HQDNCell *cell;
    uint32_t expected_generation;
    HQDRecord selector;
    HQDRecord write;
} HQDNTick;

typedef struct {
    uint32_t instance_id;
    uint32_t before_generation;
    uint32_t after_generation;
    uint16_t before_mask;
    uint16_t after_mask;
} HQDNTickReceipt;

HQDStatus hqdn_logic(HQDNLogicOp op,
                     const HQDRecord *a,
                     const HQDRecord *b,
                     const HQDRecord *c,
                     HQDRecord *out);
HQDStatus hqdn_guard(const HQDRecord *a,
                     const HQDRecord *b,
                     const HQDRecord *c,
                     HQDRecord *out);
HQDStatus hqdn_compare_set(HQDRelation relation,
                           const HQDRecord *a,
                           const HQDRecord *b,
                           HQDRecord *out);
HQDStatus hqdn_between(const HQDRecord *value,
                       const HQDRecord *lower,
                       const HQDRecord *upper,
                       HQDRecord *out);
HQDStatus hqdn_select(const HQDRecord *selector,
                      const HQDRecord *when_false,
                      const HQDRecord *when_true,
                      HQDRecord *out);
HQDStatus hqdn_cell_init(HQDNCell *cell,
                         uint32_t instance_id,
                         const HQDRecord *initial);
HQDStatus hqdn_cell_read(const HQDNCell *cell,
                         HQDRecord *out_state,
                         uint32_t *out_generation);
HQDStatus hqdn_tick_transaction(const HQDNTick *ticks,
                                unsigned count,
                                HQDNTickReceipt *receipts);
#endif
