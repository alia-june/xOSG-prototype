#include "holon_types.h"
#include <float.h>

static int finite_f32(float x) { return x==x && x<=FLT_MAX && x>=-FLT_MAX; }
static int valid_model(const DNNModel *m) {
    unsigned int l,k,off=0;
    if (!m || !m->layers || m->layers>DNN_MAX_LAYERS ||
        m->dims[0]!=DNN_INPUTS || m->dims[m->layers]!=1u ||
        !m->used || m->used>DNN_MAX_PARAMS) return 0;
    for (l=0;l<m->layers;++l) {
        unsigned int from=m->dims[l],to=m->dims[l+1];
        if (!from || !to || from>DNN_MAX_WIDTH || to>DNN_MAX_WIDTH ||
            m->offset[l]!=off || from*to+to>DNN_MAX_PARAMS-off) return 0;
        off+=from*to+to;
    }
    if (off!=m->used) return 0;
    for (k=0;k<m->used;++k) if (!finite_f32(m->p[k])) return 0;
    return 1;
}
static HCIFrame setup(const HCINeuralAdapter *a,unsigned int left) {
    HCIFrame f={0};
    f.identity=a->identity;
    f.kind=HCI_NEURAL;
    f.execution=HCI_FAILED;
    f.result_kind=HCI_RESULT_NONE;
    f.disposition=HCI_NOT_APPLICABLE;
    f.truth=HQ_UNKNOWN;
    f.input_count=DNN_INPUTS;
    f.compute_remaining=left;
    if (a->model) f.parameter_count=a->model->used;
    return f;
}
HCIStatus hci_observe_neural(HCINeuralAdapter *a,const float x[DNN_INPUTS],
                             unsigned int left,HCIFrame *frame) {
    HCIFrame f;
    DNNContext ctx;
    float y;
    unsigned int i;
    if (!a || !frame) return HCI_ERR_NULL;
    if (hci_validate_identity(&a->identity)!=HCI_OK || !a->identity.param_gen)
        return HCI_ERR_INVALID;
    f=setup(a,left);
    if (!x || !a->model) { *frame=f; return HCI_ERR_NULL; }
    if (!valid_model(a->model)) { *frame=f; return HCI_ERR_INVALID; }
    for(i=0;i<DNN_INPUTS;++i) if(!finite_f32(x[i])) { *frame=f; return HCI_ERR_NUMERIC; }
    y=dnn_forward(a->model,x,&ctx);
    if(!finite_f32(y)) { *frame=f; return HCI_ERR_NUMERIC; }
    f.number=y;
    f.execution=HCI_COMPLETED;
    f.result_kind=HCI_RESULT_NUMERIC;
    for (i=0;i<DNN_INPUTS;++i) a->observed_input[i]=x[i];
    a->observed_snapshot=a->identity.snapshot_id;
    a->has_observation=1u;
    *frame=f;
    return HCI_OK;
}
HCIStatus hci_classify_signal(const HCIFrame *f,const HCIThreshold *t,
                              HCIClassifiedSignal *out) {
    HCIClassifiedSignal value;
    if (!f || !t || !out) return HCI_ERR_NULL;
    if (f->kind!=HCI_NEURAL || f->execution!=HCI_COMPLETED ||
        f->result_kind!=HCI_RESULT_NUMERIC ||
        hci_validate_identity(&f->identity)!=HCI_OK) return HCI_ERR_INVALID;
    if (!finite_f32(t->false_max) || !finite_f32(t->true_min) ||
        !(t->false_max<t->true_min) || !t->conversion_id ||
        !finite_f32(f->number)) return HCI_ERR_INVALID;
    value.value=f->number<=t->false_max?HQ_FALSE:
                f->number>=t->true_min?HQ_TRUE:HQ_UNKNOWN;
    value.source_holon_id=f->identity.holon_id;
    value.source_snapshot_id=f->identity.snapshot_id;
    value.conversion_id=t->conversion_id;
    value.domain=HCI_CLASSIFICATION;
    *out=value;
    return HCI_OK;
}
HCIStatus hci_inspect_neural_inputs(const HCINeuralAdapter *a,
                                    unsigned int snapshot,unsigned int param_gen,
                                    unsigned int access,float out[DNN_INPUTS]) {
    unsigned int i;
    if (!a || !out) return HCI_ERR_NULL;
    if (!(access&HCI_VIEW_L1)) return HCI_ERR_DENIED;
    if (snapshot!=a->identity.snapshot_id || param_gen!=a->identity.param_gen ||
        !a->has_observation || a->observed_snapshot!=snapshot) return HCI_ERR_STALE;
    for(i=0;i<DNN_INPUTS;++i) out[i]=a->observed_input[i];
    return HCI_OK;
}
HCIStatus hci_inspect_neural_weights(const HCINeuralAdapter *a,
                                     unsigned int graph_gen,unsigned int param_gen,
                                     unsigned int access,float *out,
                                     unsigned int capacity,unsigned int *used) {
    unsigned int i;
    if (!a || !out || !used) return HCI_ERR_NULL;
    if (!(access&HCI_VIEW_L3)) return HCI_ERR_DENIED;
    if (graph_gen!=a->identity.graph_gen || param_gen!=a->identity.param_gen)
        return HCI_ERR_STALE;
    if (!valid_model(a->model)) return HCI_ERR_INVALID;
    if (capacity<a->model->used) return HCI_ERR_CAPACITY;
    for(i=0;i<a->model->used;++i) out[i]=a->model->p[i];
    *used=a->model->used;
    return HCI_OK;
}
