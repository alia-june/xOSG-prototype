#include "hq_radix5.h"
#include <stdint.h>

static int good_domain(HQ5Domain d) {
    return d == HQ5_DOMAIN_PURE5 || d == HQ5_DOMAIN_TERNARY_UE;
}
static HQ5Status checked_pair(HQ5Value a, HQ5Value b, HQ5Domain d) {
    if (!good_domain(a.domain) || !good_domain(b.domain)) return HQ5_BAD_DOMAIN;
    if (a.domain != d || b.domain != d) return HQ5_BAD_DOMAIN;
    if (a.symbol > 4u || b.symbol > 4u) return HQ5_BAD_VALUE;
    return HQ5_OK;
}
static HQ5Value value_of(HQ5Domain domain, unsigned s) {
    HQ5Value v; v.domain = domain; v.symbol = (uint8_t)s; return v;
}
static int as_int(HQ5Value v) { return (int)v.symbol - 1; }

HQ5Status hq5_make(HQ5Domain domain, unsigned symbol, HQ5Value *out) {
    if (!out) return HQ5_NULL;
    if (!good_domain(domain)) return HQ5_BAD_DOMAIN;
    if (symbol > 4u) return HQ5_BAD_VALUE;
    *out = value_of(domain, symbol);
    return HQ5_OK;
}
HQ5Status hq5_validate(HQ5Value v) {
    if (!good_domain(v.domain)) return HQ5_BAD_DOMAIN;
    return v.symbol <= 4u ? HQ5_OK : HQ5_BAD_VALUE;
}
HQ5Status hq5_add_pure(HQ5Value a, HQ5Value b, unsigned carry_in,
                       HQ5Value *out_digit, unsigned *out_carry) {
    HQ5Status s;
    unsigned sum;
    if (!out_digit || !out_carry) return HQ5_NULL;
    if ((void *)out_digit == (void *)out_carry) return HQ5_BAD_OPERATION;
    s = checked_pair(a,b,HQ5_DOMAIN_PURE5);
    if (s != HQ5_OK) return s;
    if (carry_in > 1u) return HQ5_BAD_CARRY;
    sum = (unsigned)a.symbol + (unsigned)b.symbol + carry_in;
    *out_digit = value_of(HQ5_DOMAIN_PURE5, sum % 5u);
    *out_carry = sum / 5u;
    return HQ5_OK;
}
HQ5Status hq5_mul_pure(HQ5Value a, HQ5Value b, unsigned carry_in,
                       HQ5Value *out_digit, unsigned *out_carry) {
    HQ5Status s;
    unsigned product;
    if (!out_digit || !out_carry) return HQ5_NULL;
    if ((void *)out_digit == (void *)out_carry) return HQ5_BAD_OPERATION;
    s = checked_pair(a,b,HQ5_DOMAIN_PURE5);
    if (s != HQ5_OK) return s;
    if (carry_in > 4u) return HQ5_BAD_CARRY;
    product = (unsigned)a.symbol * (unsigned)b.symbol + carry_in;
    *out_digit = value_of(HQ5_DOMAIN_PURE5, product % 5u);
    *out_carry = product / 5u;
    return HQ5_OK;
}
HQ5Status hq5_cmp_pure(HQ5Value a, HQ5Value b, int *out_sign) {
    HQ5Status s;
    if (!out_sign) return HQ5_NULL;
    s = checked_pair(a,b,HQ5_DOMAIN_PURE5);
    if (s != HQ5_OK) return s;
    *out_sign = (a.symbol > b.symbol) - (a.symbol < b.symbol);
    return HQ5_OK;
}
HQ5Status hq5_select_pure(HQ5Value selector, const HQ5Value branches[5],
                          HQ5Value *out) {
    unsigned k;
    HQ5Status s;
    if (!out || !branches) return HQ5_NULL;
    if (selector.domain != HQ5_DOMAIN_PURE5) return HQ5_BAD_DOMAIN;
    if (selector.symbol > 4u) return HQ5_BAD_VALUE;
    for (k=0; k<5u; ++k) {
        s = hq5_validate(branches[k]);
        if (s != HQ5_OK) return s;
        if (branches[k].domain != HQ5_DOMAIN_PURE5) return HQ5_BAD_DOMAIN;
    }
    *out = branches[selector.symbol]; return HQ5_OK;
}
HQ5Status hq5_table2_pure(const HQ5PureTable2 *table, HQ5Value a,
                          HQ5Value b, HQ5Value *out) {
    unsigned k;
    HQ5Status s;
    if (!table || !out) return HQ5_NULL;
    s = checked_pair(a,b,HQ5_DOMAIN_PURE5);
    if (s != HQ5_OK) return s;
    if (table->domain != HQ5_DOMAIN_PURE5) return HQ5_BAD_DOMAIN;
    /* Validate the entire proposed function, including unused entries. */
    for (k=0; k<25u; ++k) if (table->symbols[k] > 4u) return HQ5_BAD_VALUE;
    *out = value_of(HQ5_DOMAIN_PURE5,
                    table->symbols[(unsigned)a.symbol*5u+(unsigned)b.symbol]);
    return HQ5_OK;
}
HQ5Status hq5_add_balanced(HQ5Value a, HQ5Value b, HQ5Value carry_in,
                           HQ5Value *out_digit, HQ5Value *out_carry) {
    HQ5Status s;
    unsigned kind;
    int sum, carry=0, digit;
    HQ5Value v1,v2;
    if (!out_digit || !out_carry) return HQ5_NULL;
    if (out_digit == out_carry) return HQ5_BAD_OPERATION;
    s = checked_pair(a,b,HQ5_DOMAIN_TERNARY_UE);
    if (s != HQ5_OK) return s;
    if (carry_in.domain != HQ5_DOMAIN_TERNARY_UE) return HQ5_BAD_DOMAIN;
    if (carry_in.symbol > 4u) return HQ5_BAD_VALUE;
    if (a.symbol == HQ5_E || b.symbol == HQ5_E || carry_in.symbol == HQ5_E)
        kind = HQ5_E;
    else if (a.symbol == HQ5_U || b.symbol == HQ5_U || carry_in.symbol == HQ5_U)
        kind = HQ5_U;
    else kind = 5u;
    if (kind != 5u) {
        v1=value_of(HQ5_DOMAIN_TERNARY_UE,kind);
        v2=v1;
    } else {
        sum=as_int(a)+as_int(b)+as_int(carry_in);
        if (sum >= 2) carry=1;
        else if (sum <= -2) carry=-1;
        digit=sum-3*carry;
        v1=value_of(HQ5_DOMAIN_TERNARY_UE,(unsigned)(digit+1));
        v2=value_of(HQ5_DOMAIN_TERNARY_UE,(unsigned)(carry+1));
    }
    *out_digit=v1; *out_carry=v2;
    return HQ5_OK;
}
HQ5Status hq5_mul_balanced(HQ5Value a, HQ5Value b, HQ5Value *out) {
    HQ5Status s;
    unsigned res;
    if (!out) return HQ5_NULL;
    s=checked_pair(a,b,HQ5_DOMAIN_TERNARY_UE);
    if (s != HQ5_OK) return s;
    if (a.symbol==HQ5_E || b.symbol==HQ5_E) res=HQ5_E;
    else if (a.symbol==HQ5_Z || b.symbol==HQ5_Z) res=HQ5_Z;
    else if (a.symbol==HQ5_U || b.symbol==HQ5_U) res=HQ5_U;
    else res=(unsigned)(as_int(a)*as_int(b)+1);
    *out=value_of(HQ5_DOMAIN_TERNARY_UE,res);
    return HQ5_OK;
}
HQ5Status hq5_neg_balanced(HQ5Value a, HQ5Value *out) {
    if (!out) return HQ5_NULL;
    if (a.domain != HQ5_DOMAIN_TERNARY_UE) return HQ5_BAD_DOMAIN;
    if (a.symbol > 4u) return HQ5_BAD_VALUE;
    *out=value_of(HQ5_DOMAIN_TERNARY_UE,
                  a.symbol <= HQ5_P ? 2u-(unsigned)a.symbol : a.symbol);
    return HQ5_OK;
}
HQ5Status hq5_cmp_balanced(HQ5Value a, HQ5Value b, HQ5Value *out_sign) {
    HQ5Status s;
    unsigned res;
    if (!out_sign) return HQ5_NULL;
    s=checked_pair(a,b,HQ5_DOMAIN_TERNARY_UE);
    if (s != HQ5_OK) return s;
    if (a.symbol==HQ5_E || b.symbol==HQ5_E) res=HQ5_E;
    else if (a.symbol==HQ5_U || b.symbol==HQ5_U) res=HQ5_U;
    else res=(unsigned)((as_int(a)>as_int(b))-(as_int(a)<as_int(b))+1);
    *out_sign=value_of(HQ5_DOMAIN_TERNARY_UE,res);
    return HQ5_OK;
}
HQ5Status hq5_select_balanced(HQ5Value selector, const HQ5Value branches[3],
                              HQ5Value *out) {
    HQ5Status s;
    unsigned k, res;
    if (!out || !branches) return HQ5_NULL;
    if (selector.domain != HQ5_DOMAIN_TERNARY_UE) return HQ5_BAD_DOMAIN;
    if (selector.symbol > 4u) return HQ5_BAD_VALUE;
    for (k=0;k<3u;k++) {
        s=hq5_validate(branches[k]);
        if (s != HQ5_OK) return s;
        if (branches[k].domain != HQ5_DOMAIN_TERNARY_UE) return HQ5_BAD_DOMAIN;
    }
    if (selector.symbol <= HQ5_P) res=branches[selector.symbol].symbol;
    else if (selector.symbol == HQ5_E) res=HQ5_E;
    else if (branches[0].symbol==branches[1].symbol &&
             branches[1].symbol==branches[2].symbol) res=branches[0].symbol;
    else if (branches[0].symbol==HQ5_E || branches[1].symbol==HQ5_E ||
            branches[2].symbol==HQ5_E) res=HQ5_E;
    else res=HQ5_U;
    *out=value_of(HQ5_DOMAIN_TERNARY_UE,res);
    return HQ5_OK;
}
HQ5Status hq5_cell_init(HQ5Cell *cell, HQ5Value value) {
    HQ5Status s;
    if (!cell) return HQ5_NULL;
    s=hq5_validate(value);
    if (s != HQ5_OK) return s;
    cell->value=value; cell->generation=0;
    return HQ5_OK;
}
HQ5Status hq5_cell_read(const HQ5Cell *cell, HQ5Value *out_value,
                        uint32_t *out_generation) {
    HQ5Status s;
    if (!cell || !out_value || !out_generation) return HQ5_NULL;
    s=hq5_validate(cell->value);
    if (s != HQ5_OK) return s;
    *out_value=cell->value; *out_generation=cell->generation;
    return HQ5_OK;
}
HQ5Status hq5_cell_tick(HQ5Cell *cell, uint32_t expected_generation,
                        HQ5Tick command, HQ5Value write_value,
                        HQ5Value *out_value) {
    HQ5Status s;
    HQ5Value next;
    if (!cell || !out_value) return HQ5_NULL;
    s=hq5_validate(cell->value);
    if (s != HQ5_OK) return s;
    if (cell->generation != expected_generation) return HQ5_STALE;
    if (cell->generation == UINT32_MAX) return HQ5_EXHAUSTED;
    if (command == HQ5_HOLD) next=cell->value;
    else if (command == HQ5_RESET) {
        next=value_of(cell->value.domain,
                      cell->value.domain == HQ5_DOMAIN_PURE5 ? 0u : HQ5_Z);
    } else if (command == HQ5_WRITE) {
        s=hq5_validate(write_value);
        if (s != HQ5_OK) return s;
        if (write_value.domain != cell->value.domain) return HQ5_BAD_DOMAIN;
        next=write_value;
    } else return HQ5_BAD_OPERATION;
    cell->value=next; cell->generation++;
    *out_value=next; return HQ5_OK;
}
HQ5Status hq5_add_word_pure(const HQ5Value *a, const HQ5Value *b,
                            unsigned length, unsigned carry_in,
                            HQ5Value *out, unsigned *out_carry) {
    HQ5Value staged[HQ5_MAX_WORD];
    unsigned i,carry=carry_in;
    HQ5Status s;
    if (!a || !b || !out || !out_carry) return HQ5_NULL;
    if (!length || length > HQ5_MAX_WORD) return HQ5_BAD_OPERATION;
    if (carry > 1u) return HQ5_BAD_CARRY;
    for (i=0;i<length;i++) {
        s=checked_pair(a[i],b[i],HQ5_DOMAIN_PURE5);
        if (s != HQ5_OK) return s;
    }
    for (i=0;i<length;i++) {
        s=hq5_add_pure(a[i],b[i],carry,&staged[i],&carry);
        if (s != HQ5_OK) return s;
    }
    for (i=0;i<length;i++) out[i]=staged[i];
    *out_carry=carry;
    return HQ5_OK;
}
HQ5Status hq5_add_word_balanced(const HQ5Value *a, const HQ5Value *b,
                                unsigned length, HQ5Value carry_in,
                                HQ5Value *out, HQ5Value *out_carry) {
    HQ5Value staged[HQ5_MAX_WORD],carry=carry_in;
    unsigned i;
    HQ5Status s;
    if (!a || !b || !out || !out_carry) return HQ5_NULL;
    if (!length || length > HQ5_MAX_WORD) return HQ5_BAD_OPERATION;
    if (carry.domain != HQ5_DOMAIN_TERNARY_UE) return HQ5_BAD_DOMAIN;
    if (carry.symbol > 4u) return HQ5_BAD_VALUE;
    for (i=0;i<length;i++) {
        s=checked_pair(a[i],b[i],HQ5_DOMAIN_TERNARY_UE);
        if (s != HQ5_OK) return s;
    }
    for (i=0;i<length;i++) {
        s=hq5_add_balanced(a[i],b[i],carry,&staged[i],&carry);
        if (s != HQ5_OK) return s;
    }
    for (i=0;i<length;i++) out[i]=staged[i];
    *out_carry=carry;
    return HQ5_OK;
}
