#ifndef HQ_HIGHER_H
#define HQ_HIGHER_H
/* v1.0: higher logic over two DISJOINT HQ5 data domains. No recursive runtime.
 * Conditions are NOT radix-5 numbers or balanced trits.
 * E in a completed condition is an in-band ERROR marker, not HQ5Status.
 * All public outputs change only on HQ5_OK.
 */
#include "hq_radix5.h"

typedef enum {
    HQX_FALSE = 0,
    HQX_TRUE = 1,
    HQX_UNKNOWN = 2,
    HQX_ERROR = 3
} HQXCondition;

typedef enum {
    HQX_EQ = 0,
    HQX_NE,
    HQX_LT,
    HQX_LE,
    HQX_GT,
    HQX_GE,
    HQX_IS_ZERO,
    HQX_IS_KNOWN,
    HQX_IS_UNKNOWN,
    HQX_IS_ERROR
} HQXPredicate;

typedef enum {
    HQX_AND = 0,
    HQX_OR,
    HQX_XOR,
    HQX_IMPLIES,
    HQX_EQUIV
} HQXConnective;

typedef enum {
    HQX_MIN = 0,
    HQX_MAX
} HQXOrder;

/* Pure base-five inputs produce classical binary comparisons. TERNARY_UE
 * comparisons use independent completions for each U operand. E dominates.
 * IS_UNKNOWN and IS_ERROR inspect a symbol intentionally; IS_UNKNOWN(E) = E
 * while IS_ERROR(E) = TRUE; IS_KNOWN(E) = E. */
HQ5Status hqx_test(HQXPredicate pred, HQ5Value a, HQ5Value b,
                   HQXCondition *out);
/* Strong Kleene on T/F/U, strict E propagation for every connective.
 * E is never short-circuited, including FALSE AND E = E. */
HQ5Status hqx_not(HQXCondition a, HQXCondition *out);
HQ5Status hqx_connect(HQXConnective op, HQXCondition a,
                      HQXCondition b, HQXCondition *out);
/* Input numeric order N=-1 < Z=0 < P=+1. For U compute ALL 3x3
 * possible outcomes; if all agree, retain the value, else U. E dominates. */
HQ5Status hqx_balanced_order(HQXOrder op, HQ5Value a, HQ5Value b,
                             HQ5Value *out);
/* Conditional data selection, balanced ternary only. If condition U and
 * both branches agree, preserve value; else E dominates, otherwise U.
 * Only selected branch matters for definite condition. */
HQ5Status hqx_select_condition(HQXCondition cond, HQ5Value when_false,
                               HQ5Value when_true, HQ5Value *out);
/* Higher functions: inclusive range check and 3-condition majority.
 * BETWEEN uses mathematical conjunction of >=low and <=high.
 * Three-condition majority is U unless every known completion agrees.
 * Both preserve E strictly, even where ordinary Boolean output is forced. */
HQ5Status hqx_between(HQ5Value value, HQ5Value low, HQ5Value high,
                       HQXCondition *out);
HQ5Status hqx_majority3(HQXCondition a, HQXCondition b,
                        HQXCondition c, HQXCondition *out);
/* Pure base-5 comparisons over little-endian words; TERNARY_UE uses exact
 * whole-number intervals and 64-bit arithmetic (3^32 < INT64_MAX).
 * E anywhere in a TERNARY_UE word produces an in-band ERROR condition.
 * U positions represent independent unresolved trits; repeated U symbols
 * do not assert shared unknown identity. No partial array overlap allowed. */
HQ5Status hqx_test_word(HQXPredicate pred, HQ5Domain domain,
                        const HQ5Value *a, const HQ5Value *b,
                        unsigned length, HQXCondition *out);
/* Programmable two-input PURE5 predicate table, full 25-entry validation.
 * No generic five-valued arithmetic is inferred from these outputs. */
typedef struct {
    HQ5Domain domain;
    uint8_t outcomes[25];
} HQXPurePredicateTable;
HQ5Status hqx_table_pure(const HQXPurePredicateTable *table, HQ5Value a,
                         HQ5Value b, HQXCondition *out);
#endif
