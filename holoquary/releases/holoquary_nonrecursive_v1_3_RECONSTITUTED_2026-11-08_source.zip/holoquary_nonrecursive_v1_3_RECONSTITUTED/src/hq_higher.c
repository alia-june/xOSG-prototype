#include "hq_higher.h"
#include <stdint.h>

static int valid_cond(HQXCondition c) { return c >= HQX_FALSE && c <= HQX_ERROR; }
static int valid_domain(HQ5Domain d) { return d == HQ5_DOMAIN_PURE5 || d == HQ5_DOMAIN_TERNARY_UE; }
static int good_pred(HQXPredicate p) { return p >= HQX_EQ && p <= HQX_IS_ERROR; }
static HQ5Value as_value(HQ5Domain d, unsigned s) { HQ5Value x; x.domain=d; x.symbol=(uint8_t)s; return x; }
static int exact_value(HQ5Value a) { return a.domain == HQ5_DOMAIN_TERNARY_UE && a.symbol <= HQ5_P; }
static HQ5Status check_pair(HQ5Value a, HQ5Value b) {
    HQ5Status s = hq5_validate(a);
    if (s!=HQ5_OK) return s;
    s=hq5_validate(b);
    if (s!=HQ5_OK) return s;
    return a.domain == b.domain ? HQ5_OK : HQ5_BAD_DOMAIN;
}
static HQXCondition binary_pred(HQXPredicate pred, int a, int b) {
    int yes=0;
    switch (pred) {
        case HQX_EQ: yes=(a==b); break;
        case HQX_NE: yes=(a!=b); break;
        case HQX_LT: yes=(a<b); break;
        case HQX_LE: yes=(a<=b); break;
        case HQX_GT: yes=(a>b); break;
        case HQX_GE: yes=(a>=b); break;
        default: return HQX_ERROR;
    }
    return yes ? HQX_TRUE : HQX_FALSE;
}
static HQXCondition interval_pred(HQXPredicate p,int64_t al,int64_t ah,
                                 int64_t bl,int64_t bh) {
    int yes=0,no=0;
    switch(p) {
        case HQX_EQ: yes=al==ah && bl==bh && al==bl; no=(ah<bl || bh<al); break;
        case HQX_NE: no=al==ah && bl==bh && al==bl; yes=(ah<bl || bh<al); break;
        case HQX_LT: yes=ah<bl; no=al>=bh; break;
        case HQX_LE: yes=ah<=bl; no=al>bh; break;
        case HQX_GT: yes=al>bh; no=ah<=bl; break;
        case HQX_GE: yes=al>=bh; no=ah<bl; break;
        default: return HQX_ERROR;
    }
    return yes ? HQX_TRUE : (no ? HQX_FALSE : HQX_UNKNOWN);
}
HQ5Status hqx_test(HQXPredicate pred,HQ5Value a,HQ5Value b,HQXCondition *out) {
    HQ5Status s;
    HQXCondition result;
    if (!out) return HQ5_NULL;
    if (!good_pred(pred)) return HQ5_BAD_OPERATION;
    if (pred<=HQX_GE) {
        s=check_pair(a,b); if (s!=HQ5_OK) return s;
        if (a.domain==HQ5_DOMAIN_PURE5)
            result=binary_pred(pred,a.symbol,b.symbol);
        else if (a.symbol==HQ5_E || b.symbol==HQ5_E)
            result=HQX_ERROR;
        else {
            int64_t al=a.symbol==HQ5_U ? -1 : (int)a.symbol-1;
            int64_t ah=a.symbol==HQ5_U ?  1 : (int)a.symbol-1;
            int64_t bl=b.symbol==HQ5_U ? -1 : (int)b.symbol-1;
            int64_t bh=b.symbol==HQ5_U ?  1 : (int)b.symbol-1;
            result=interval_pred(pred,al,ah,bl,bh);
        }
    } else {
        s=hq5_validate(a); if (s!=HQ5_OK) return s;
        if (pred==HQX_IS_ERROR) result=a.domain==HQ5_DOMAIN_TERNARY_UE && a.symbol==HQ5_E ? HQX_TRUE : HQX_FALSE;
        else if (a.domain==HQ5_DOMAIN_TERNARY_UE && a.symbol==HQ5_E) result=HQX_ERROR;
        else if (pred==HQX_IS_UNKNOWN) result=a.domain==HQ5_DOMAIN_TERNARY_UE && a.symbol==HQ5_U ? HQX_TRUE : HQX_FALSE;
        else if (pred==HQX_IS_KNOWN) result=a.domain==HQ5_DOMAIN_TERNARY_UE && a.symbol==HQ5_U ? HQX_FALSE : HQX_TRUE;
        else if (a.domain==HQ5_DOMAIN_PURE5) result=a.symbol==0 ? HQX_TRUE : HQX_FALSE;
        else if (a.symbol==HQ5_U) result=HQX_UNKNOWN;
        else result=a.symbol==HQ5_Z ? HQX_TRUE : HQX_FALSE;
    }
    *out=result; return HQ5_OK;
}
HQ5Status hqx_not(HQXCondition a,HQXCondition *out) {
    if (!out) return HQ5_NULL;
    if (!valid_cond(a)) return HQ5_BAD_VALUE;
    *out=a==HQX_TRUE ? HQX_FALSE : (a==HQX_FALSE ? HQX_TRUE : a);
    return HQ5_OK;
}
HQ5Status hqx_connect(HQXConnective op,HQXCondition a,HQXCondition b,HQXCondition *out) {
    HQXCondition result;
    if (!out) return HQ5_NULL;
    if (!valid_cond(a) || !valid_cond(b)) return HQ5_BAD_VALUE;
    if (op < HQX_AND || op > HQX_EQUIV) return HQ5_BAD_OPERATION;
    if (a==HQX_ERROR || b==HQX_ERROR) result=HQX_ERROR;
    else if (op==HQX_AND)
        result=(a==HQX_FALSE || b==HQX_FALSE) ? HQX_FALSE :
               ((a==HQX_UNKNOWN || b==HQX_UNKNOWN) ? HQX_UNKNOWN : HQX_TRUE);
    else if (op==HQX_OR)
        result=(a==HQX_TRUE || b==HQX_TRUE) ? HQX_TRUE :
               ((a==HQX_UNKNOWN || b==HQX_UNKNOWN) ? HQX_UNKNOWN : HQX_FALSE);
    else if (op==HQX_XOR || op==HQX_EQUIV)
        result=(a==HQX_UNKNOWN || b==HQX_UNKNOWN) ? HQX_UNKNOWN :
               ((a!=b)==(op==HQX_XOR) ? HQX_TRUE : HQX_FALSE);
    else /* material implication ~a OR b in Kleene K3 */
        result=(a==HQX_FALSE || b==HQX_TRUE) ? HQX_TRUE :
               ((a==HQX_UNKNOWN || b==HQX_UNKNOWN) ? HQX_UNKNOWN : HQX_FALSE);
    *out=result; return HQ5_OK;
}
HQ5Status hqx_balanced_order(HQXOrder op,HQ5Value a,HQ5Value b,HQ5Value *out) {
    unsigned i,j,count=0,first=0;
    HQ5Status s;
    if (!out) return HQ5_NULL;
    if (op!=HQX_MIN && op!=HQX_MAX) return HQ5_BAD_OPERATION;
    s=check_pair(a,b); if (s!=HQ5_OK) return s;
    if (a.domain!=HQ5_DOMAIN_TERNARY_UE) return HQ5_BAD_DOMAIN;
    if (a.symbol==HQ5_E || b.symbol==HQ5_E) { *out=as_value(a.domain,HQ5_E); return HQ5_OK; }
    for(i=0;i<3u;i++) {
        if (exact_value(a) && i!=a.symbol) continue;
        for(j=0;j<3u;j++) {
            unsigned result;
            if (exact_value(b) && j!=b.symbol) continue;
            result=op==HQX_MIN ? (i<j?i:j) : (i>j?i:j);
            if (count && result!=first) { *out=as_value(a.domain,HQ5_U); return HQ5_OK; }
            first=result; ++count;
        }
    }
    *out=as_value(a.domain,first); return HQ5_OK;
}
HQ5Status hqx_select_condition(HQXCondition cond,HQ5Value when_false,
                               HQ5Value when_true,HQ5Value *out) {
    HQ5Status s;
    if (!out) return HQ5_NULL;
    if (!valid_cond(cond)) return HQ5_BAD_VALUE;
    s=check_pair(when_false,when_true); if (s!=HQ5_OK) return s;
    if (when_false.domain!=HQ5_DOMAIN_TERNARY_UE) return HQ5_BAD_DOMAIN;
    if (cond==HQX_TRUE) *out=when_true;
    else if (cond==HQX_FALSE) *out=when_false;
    else if (cond==HQX_ERROR) *out=as_value(HQ5_DOMAIN_TERNARY_UE,HQ5_E);
    else if (when_false.symbol==when_true.symbol) *out=when_false;
    else if (when_false.symbol==HQ5_E || when_true.symbol==HQ5_E)
        *out=as_value(HQ5_DOMAIN_TERNARY_UE,HQ5_E);
    else *out=as_value(HQ5_DOMAIN_TERNARY_UE,HQ5_U);
    return HQ5_OK;
}
HQ5Status hqx_between(HQ5Value value,HQ5Value low,HQ5Value high,
                      HQXCondition *out) {
    HQXCondition lo,hi;
    HQ5Status s;
    if(!out) return HQ5_NULL;
    s=check_pair(value,low); if(s!=HQ5_OK) return s;
    s=check_pair(value,high); if(s!=HQ5_OK) return s;
    s=hqx_test(HQX_GE,value,low,&lo);if(s!=HQ5_OK)return s;
    s=hqx_test(HQX_LE,value,high,&hi);if(s!=HQ5_OK)return s;
    return hqx_connect(HQX_AND,lo,hi,out);
}
HQ5Status hqx_majority3(HQXCondition a,HQXCondition b,
                        HQXCondition c,HQXCondition *out) {
    unsigned t,f;
    if(!out)return HQ5_NULL;
    if(!valid_cond(a) || !valid_cond(b) || !valid_cond(c))return HQ5_BAD_VALUE;
    if(a==HQX_ERROR||b==HQX_ERROR||c==HQX_ERROR){*out=HQX_ERROR;return HQ5_OK;}
    t=(a==HQX_TRUE)+(b==HQX_TRUE)+(c==HQX_TRUE);
    f=(a==HQX_FALSE)+(b==HQX_FALSE)+(c==HQX_FALSE);
    *out=t>=2u?HQX_TRUE:f>=2u?HQX_FALSE:HQX_UNKNOWN;
    return HQ5_OK;
}
HQ5Status hqx_test_word(HQXPredicate pred,HQ5Domain domain,const HQ5Value *a,
                        const HQ5Value *b,unsigned length,HQXCondition *out) {
    unsigned i;
    HQXCondition result;
    int64_t al=0,ah=0,bl=0,bh=0,power=1;
    if (!a || !b || !out) return HQ5_NULL;
    if (!valid_domain(domain)) return HQ5_BAD_DOMAIN;
    if (length==0 || length>HQ5_MAX_WORD) return HQ5_BAD_OPERATION;
    if (pred>HQX_GE || pred<HQX_EQ) return HQ5_BAD_OPERATION;
    /* Validate all cells first, including otherwise unused lower digits. */
    for(i=0;i<length;i++) {
        HQ5Status s=check_pair(a[i],b[i]); if(s!=HQ5_OK) return s;
        if(a[i].domain!=domain) return HQ5_BAD_DOMAIN;
    }
    if(domain==HQ5_DOMAIN_PURE5) {
        int sign=0;
        for(i=length;i>0;i--) if (a[i-1].symbol!=b[i-1].symbol) {
            sign=a[i-1].symbol>b[i-1].symbol ? 1 : -1;
            break;
        }
        result=binary_pred(pred,sign,0);
    } else {
        for(i=0;i<length;i++) if(a[i].symbol==HQ5_E || b[i].symbol==HQ5_E) {
            *out=HQX_ERROR; return HQ5_OK;
        }
        /* Every balanced-ternary whole number has one unique digit string.
         * Numeric intervals have gaps: interval overlap does NOT imply
         * possible equality. Compare exact per-position constraints instead. */
        if(pred==HQX_EQ || pred==HQX_NE) {
            int impossible=0,all_definite=1;
            for(i=0;i<length;i++) {
                if(a[i].symbol==HQ5_U || b[i].symbol==HQ5_U)
                    all_definite=0;
                else if(a[i].symbol!=b[i].symbol) impossible=1;
            }
            if(impossible) result=pred==HQX_EQ ? HQX_FALSE : HQX_TRUE;
            else if(all_definite) result=pred==HQX_EQ ? HQX_TRUE : HQX_FALSE;
            else result=HQX_UNKNOWN;
            *out=result; return HQ5_OK;
        }
        for(i=0;i<length;i++) {
            int64_t aa=a[i].symbol==HQ5_U ? -1 : (int)a[i].symbol-1;
            int64_t az=a[i].symbol==HQ5_U ? 1 : (int)a[i].symbol-1;
            int64_t bb=b[i].symbol==HQ5_U ? -1 : (int)b[i].symbol-1;
            int64_t bz=b[i].symbol==HQ5_U ? 1 : (int)b[i].symbol-1;
            al+=power*aa;ah+=power*az;bl+=power*bb;bh+=power*bz;
            power*=3;
        }
        result=interval_pred(pred,al,ah,bl,bh);
    }
    *out=result; return HQ5_OK;
}
HQ5Status hqx_table_pure(const HQXPurePredicateTable *table,HQ5Value a,
                         HQ5Value b,HQXCondition *out) {
    HQ5Status s;
    unsigned i;
    if (!table || !out) return HQ5_NULL;
    s=check_pair(a,b); if(s!=HQ5_OK) return s;
    if(a.domain!=HQ5_DOMAIN_PURE5 || table->domain!=HQ5_DOMAIN_PURE5)
        return HQ5_BAD_DOMAIN;
    for(i=0;i<25u;i++) if(table->outcomes[i]>HQX_UNKNOWN) return HQ5_BAD_VALUE;
    *out=(HQXCondition)table->outcomes[a.symbol*5u+b.symbol];
    return HQ5_OK;
}
