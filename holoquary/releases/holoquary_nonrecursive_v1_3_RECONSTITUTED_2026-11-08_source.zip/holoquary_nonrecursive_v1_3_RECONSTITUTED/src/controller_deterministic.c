#include "holon_types.h"

static int action_valid(HCIAction a) {
    return (int)a>=(int)HCI_ACT_ANSWER && (int)a<(int)HCI_ACT_COUNT;
}
HCIStatus hci_controller_propose(const HCIFrame *frame,
                                  unsigned int lessons,HCIProposal *out) {
    HCIProposal p={0};
    if (!frame || !out) return HCI_ERR_NULL;
    if (hci_validate_identity(&frame->identity)!=HCI_OK) return HCI_ERR_INVALID;
    p.target_holon_id=frame->identity.holon_id;
    p.observed_graph_gen=frame->identity.graph_gen;
    p.observed_param_gen=frame->identity.param_gen;
    p.observed_snapshot_id=frame->identity.snapshot_id;
    if (frame->execution==HCI_FAILED) p.action=HCI_ACT_REPORT_ERROR;
    else if (frame->execution==HCI_COMPLETION_UNKNOWN) p.action=HCI_ACT_REQUEST_EVIDENCE;
    else if (frame->execution!=HCI_COMPLETED) return HCI_ERR_INVALID;
    else if (frame->result_kind==HCI_RESULT_NUMERIC && frame->kind==HCI_NEURAL)
        p.action=HCI_ACT_ROUTE;
    else if (frame->result_kind==HCI_RESULT_LOGIC && frame->kind==HCI_LOGIC) {
        if (frame->truth!=HQ_TRUE && frame->truth!=HQ_FALSE && frame->truth!=HQ_UNKNOWN)
            return HCI_ERR_INVALID;
        if (frame->truth!=HQ_UNKNOWN &&
            frame->disposition!=HCI_CONFLICT && frame->disposition!=HCI_EXHAUSTED)
            p.action=HCI_ACT_ANSWER;
        else if (frame->disposition==HCI_CONFLICT)
            p.action=HCI_ACT_REQUEST_EVIDENCE;
        else if (frame->disposition==HCI_EXHAUSTED && frame->compute_remaining)
            { p.action=HCI_ACT_CONTINUE; p.requested_budget=1u; }
        else if (frame->disposition==HCI_UNCHECKED && lessons && frame->compute_remaining)
            { p.action=HCI_ACT_APPLY_LESSON; p.requested_budget=1u; }
        else if (frame->disposition==HCI_STABLE && frame->truth==HQ_UNKNOWN)
            p.action=HCI_ACT_REQUEST_EVIDENCE;
        else p.action=HCI_ACT_RETURN_UNKNOWN;
    } else return HCI_ERR_INVALID;
    *out=p;
    return HCI_OK;
}
HCIStatus hci_gate_proposal(const HCIProposal *p, const HCIFrame *current,
                            const HCIGrant *grant) {
    if (!p || !current || !grant) return HCI_ERR_NULL;
    if (!action_valid(p->action) ||
        hci_validate_identity(&current->identity)!=HCI_OK) return HCI_ERR_INVALID;
    if (p->target_holon_id!=current->identity.holon_id ||
        p->target_holon_id!=grant->target_holon_id) return HCI_ERR_DENIED;
    if (p->observed_graph_gen!=current->identity.graph_gen ||
        p->observed_param_gen!=current->identity.param_gen ||
        p->observed_snapshot_id!=current->identity.snapshot_id) return HCI_ERR_STALE;
    if (!(grant->action_mask&HCI_ACTION_BIT(p->action))) return HCI_ERR_DENIED;
    if (p->requested_budget>grant->max_budget ||
        p->requested_budget>current->compute_remaining) return HCI_ERR_BUDGET;
    if ((p->action==HCI_ACT_CONTINUE || p->action==HCI_ACT_APPLY_LESSON) &&
        !p->requested_budget) return HCI_ERR_BUDGET;
    if ((p->action==HCI_ACT_ANSWER) &&
        (current->kind!=HCI_LOGIC || current->execution!=HCI_COMPLETED ||
         current->source_status!=HQ_OK || current->result_kind!=HCI_RESULT_LOGIC ||
         (current->truth!=HQ_TRUE && current->truth!=HQ_FALSE) ||
         current->disposition==HCI_CONFLICT ||
         current->disposition==HCI_EXHAUSTED)) return HCI_ERR_DENIED;
    if ((p->action==HCI_ACT_ROUTE) &&
        (current->kind!=HCI_NEURAL || current->execution!=HCI_COMPLETED ||
         current->result_kind!=HCI_RESULT_NUMERIC))
        return HCI_ERR_DENIED;
    if ((p->action==HCI_ACT_REPORT_ERROR) && current->execution!=HCI_FAILED)
        return HCI_ERR_DENIED;
    return HCI_OK; /* validation only; no side-effect execution in this slice */
}
