#ifndef HCI_RECOVERY_H
#define HCI_RECOVERY_H
/* Holoquary-006 I-06: bounded, in-memory error accounting and pure-operation
 * reevaluation. No authentication, durable journal, or external-effect retry. */
#include "holon_types.h"
#define HCI_REC_MAX_EVENTS 32u
#define HCI_REC_MAX_ATTEMPTS 3u

typedef enum {
    HCI_EFFECT_PURE=1, /* certified by caller's execution contract, not library */
    HCI_EFFECT_EXTERNAL=2,
    HCI_EFFECT_UNKNOWN=3
} HCIEffect;

typedef enum {
    HCI_REC_FAILURE=1, HCI_REC_REEVAL_COMPLETED=2,
    HCI_REC_REEVAL_FAILED=3, HCI_REC_BLOCKED=4
} HCIRecoveryOutcome;

typedef struct {
    unsigned int event_id;     /* unique per live store */
    unsigned int parent_failure_id; /* zero for original failure */
    unsigned int scope_id;
    HCIFrame observed;         /* immutable recorded snapshot */
    HCIStatus native_error;    /* non-OK for a known failure */
    HCIEffect effect;
    HCIRecoveryOutcome outcome;
    unsigned int policy_id;    /* opaque caller-supplied handle, not authentication */
    unsigned int generation_after;
} HCIRecoveryEvent;

typedef struct {
    unsigned int scope_id;
    unsigned int generation;
    unsigned int count;
    unsigned int per_failure_limit;
    HCIRecoveryEvent events[HCI_REC_MAX_EVENTS];
} HCIRecoveryStore;

typedef struct {
    unsigned int policy_id;
    unsigned int scope_id;
    unsigned int parent_failure_id;
    HCIIdentity exact_origin; /* all five fields bound */
    unsigned int max_attempts;
    unsigned int permit_pure_reeval;
} HCIRecoveryGrant;

/* Caller-held pure operation: must re-evaluate the same immutable inputs and
 * immutable parameter/graph generation. A distinct snapshot ID names attempt. */
typedef HCIStatus (*HCIReeval)(const HCIFrame *original,
                                unsigned int new_snapshot_id,
                                const void *context,HCIFrame *new_observation);

HCIStatus hci_recovery_init(HCIRecoveryStore *store,unsigned int scope_id,
                            unsigned int per_failure_limit);
HCIStatus hci_recovery_record(HCIRecoveryStore *store,
                              unsigned int event_id,const HCIFrame *frame,
                              HCIStatus native_error,HCIEffect effect,
                              HCIRecoveryEvent *receipt);
HCIStatus hci_recovery_attempt(HCIRecoveryStore *store,
                               unsigned int new_event_id,
                               unsigned int new_snapshot_id,
                               const HCIRecoveryGrant *grant,
                               HCIReeval evaluator,const void *context,
                               HCIRecoveryEvent *receipt);
#endif
