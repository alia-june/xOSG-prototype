#include "hci_feedback.h"

static int definite(HQTruth v) { return v==HQ_TRUE || v==HQ_FALSE; }
static int same_id(const HCIIdentity *a,const HCIIdentity *b) {
    return a->holon_id==b->holon_id && a->instance_id==b->instance_id &&
           a->graph_gen==b->graph_gen && a->param_gen==b->param_gen &&
           a->snapshot_id==b->snapshot_id;
}
static int existing(const HCIFeedbackStore *s,unsigned int id) {
    unsigned int i;
    for(i=0u;i<s->count;++i) if(s->events[i].candidate.candidate_id==id) return 1;
    return 0;
}
/* Only exact syntactic duplicates and directly opposite same-premise rules.
 * This is NOT general consistency checking or evidence validation. */
static unsigned int overlapping(const HQLessonBank *b,const HCICandidate *c) {
    unsigned int i;
    if(c->kind==HCI_CAND_FACT) {
        for(i=0u;i<b->fact_count;++i)
            if(b->facts[i].input_port==c->result_port)
                return b->facts[i].value==c->result_value?1u:2u;
    } else if(c->kind==HCI_CAND_RULE) {
        for(i=0u;i<b->rule_count;++i)
            if(b->rules[i].premise_port==c->premise_port &&
               b->rules[i].premise_value==c->premise_value &&
               b->rules[i].result_port==c->result_port)
                return b->rules[i].result_value==c->result_value?1u:2u;
    }
    return 0u;
}
HCIStatus hci_feedback_init(HCIFeedbackStore *s,unsigned int scope) {
    HQStatus status;
    if(!s) return HCI_ERR_NULL;
    if(!scope) return HCI_ERR_INVALID;
    status=hq_lessons_init(&s->bank,scope);
    if(status!=HQ_OK) return HCI_ERR_SOURCE;
    s->scope_id=scope;
    s->count=0u;
    s->generation=1u;
    return HCI_OK;
}
const HQLessonBank *hci_feedback_bank(const HCIFeedbackStore *s) {
    return s ? &s->bank : (const HQLessonBank *)0;
}
HCIStatus hci_feedback_submit(HCIFeedbackStore *s,const HCIFrame *observation,
                              unsigned int input_count,const HCICandidate *c,
                              HCIVerifier verifier,const void *oracle_ctx,
                              HCIEvent *receipt) {
    HCIVerification v={0};
    HCIEvent e={0};
    HCIStatus status;
    unsigned int overlap;
    unsigned int saved_gen, saved_count,saved_facts,saved_rules;
    HQStatus core_status;
    if(!s || !observation || !c || !verifier || !receipt) return HCI_ERR_NULL;
    if(!s->scope_id || s->scope_id!=s->bank.scope_id || !s->generation ||
       s->count>HCI_MAX_FEEDBACK_EVENTS ||
       s->bank.fact_count>HQ_MAX_LESSON_FACTS ||
       s->bank.rule_count>HQ_MAX_LESSON_RULES)
        return HCI_ERR_INVALID;
    if(s->count==HCI_MAX_FEEDBACK_EVENTS) return HCI_ERR_CAPACITY;
    if(!c->candidate_id || !c->proposer_id || !c->source_id ||
       !c->evidence_id || !c->scope_id ||
       c->scope_id!=s->scope_id || input_count==0u ||
       input_count>HQ_MAX_INPUTS || input_count!=observation->input_count ||
       hci_validate_identity(&c->observed)!=HCI_OK ||
       hci_validate_identity(&observation->identity)!=HCI_OK ||
       !same_id(&c->observed,&observation->identity) ||
       existing(s,c->candidate_id) || s->generation==(unsigned int)-1)
        return HCI_ERR_INVALID;
    if(observation->execution!=HCI_COMPLETED &&
       observation->execution!=HCI_FAILED) return HCI_ERR_INVALID;
    if(c->kind==HCI_CAND_FACT) {
        if(observation->kind!=HCI_LOGIC ||
           observation->execution!=HCI_COMPLETED ||
           observation->source_status!=HQ_OK ||
           observation->result_kind!=HCI_RESULT_LOGIC ||
           c->result_port>=input_count || !definite(c->result_value))
            return HCI_ERR_INVALID;
        if(s->bank.fact_count==HQ_MAX_LESSON_FACTS) return HCI_ERR_CAPACITY;
    } else if(c->kind==HCI_CAND_RULE) {
        if(observation->kind!=HCI_LOGIC ||
           observation->execution!=HCI_COMPLETED ||
           observation->source_status!=HQ_OK ||
           observation->result_kind!=HCI_RESULT_LOGIC ||
           c->premise_port>=input_count || c->result_port>=input_count ||
           !definite(c->premise_value) || !definite(c->result_value))
            return HCI_ERR_INVALID;
        if(s->bank.rule_count==HQ_MAX_LESSON_RULES) return HCI_ERR_CAPACITY;
    } else if(c->kind==HCI_CAND_ANTI) {
        if(!c->action_code || !c->failure_code) return HCI_ERR_INVALID;
    } else return HCI_ERR_INVALID;
    /* The caller is responsible for making the verifier independent and pure.
     * Numeric identity checks cannot authenticate independent authority. */
    saved_gen=s->generation;
    saved_count=s->count;
    saved_facts=s->bank.fact_count;
    saved_rules=s->bank.rule_count;
    status=verifier(c,oracle_ctx,&v);
    if(s->generation!=saved_gen || s->count!=saved_count ||
       s->bank.fact_count!=saved_facts || s->bank.rule_count!=saved_rules ||
       s->bank.scope_id!=s->scope_id)
        return HCI_ERR_INVALID;
    if(status!=HCI_OK) return status;
    if((v.verdict!=HCI_VERDICT_ACCEPT && v.verdict!=HCI_VERDICT_REJECT &&
        v.verdict!=HCI_VERDICT_DEFER) || !v.verifier_id ||
       v.verifier_id==c->proposer_id ||
       v.checked_candidate_id!=c->candidate_id ||
       v.checked_evidence_id!=c->evidence_id || !v.proof_ref)
        return HCI_ERR_INVALID;
    e.candidate=*c;
    e.verification=v;
    if(v.verdict==HCI_VERDICT_REJECT) e.outcome=HCI_EVENT_REJECTED;
    else if(v.verdict==HCI_VERDICT_DEFER) e.outcome=HCI_EVENT_DEFERRED;
    else if(c->kind==HCI_CAND_ANTI) e.outcome=HCI_EVENT_ANTI_ADMITTED;
    else {
        overlap=overlapping(&s->bank,c);
        e.outcome=overlap==2u?HCI_EVENT_CONFLICT:
                  overlap==1u?HCI_EVENT_REJECTED:HCI_EVENT_ADMITTED;
        if(e.outcome==HCI_EVENT_ADMITTED) {
            core_status=c->kind==HCI_CAND_FACT?
                hq_lesson_add_fact(&s->bank,c->result_port,c->result_value,c->source_id):
                hq_lesson_add_rule(&s->bank,c->premise_port,c->premise_value,
                                   c->result_port,c->result_value,c->source_id);
            if(core_status!=HQ_OK) return HCI_ERR_SOURCE;
        }
    }
    e.generation_after=s->generation+1u;
    s->events[s->count]=e;
    ++s->count;
    ++s->generation;
    *receipt=e;
    return HCI_OK;
}
