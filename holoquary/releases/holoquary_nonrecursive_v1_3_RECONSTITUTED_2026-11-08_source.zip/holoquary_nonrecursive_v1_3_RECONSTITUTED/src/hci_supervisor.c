#include "hci_supervisor.h"
#include <float.h>
/* Oracle comes from deterministic controller on an intentionally tiny finite
 * domain: known => ANSWER, unresolved+lessons => APPLY_LESSON, else UNKNOWN.
 * These supervised labels are procedural, not claims about external truth. */
static const float samples[4][3]={
  {0.0f,0.0f,0.0f},{0.0f,1.0f,0.0f},
  {1.0f,0.0f,0.5f},{1.0f,1.0f,1.0f}
};
static int finite_value(float x) {return x==x && x<=FLT_MAX && x>=-FLT_MAX;}
HCIStatus hci_supervisor_init(HCINeuralSupervisor *s,unsigned int seed) {
    const unsigned int dims[3]={2u,8u,1u};
    if(!s) return HCI_ERR_NULL;
    if(!dnn_init(&s->model,dims,2u,seed,DNN_SCALED)) return HCI_ERR_INVALID;
    s->generation=1u;
    s->trained_steps=0u;
    return HCI_OK;
}
HCIStatus hci_supervisor_train_imitation(HCINeuralSupervisor *s,
                                         unsigned int steps,float lr) {
    unsigned int iter,j,k;
    DNNModel next;
    if(!s) return HCI_ERR_NULL;
    if(!s->generation || s->model.layers!=2u || s->model.dims[0]!=2u ||
       s->model.dims[1]!=8u || s->model.dims[2]!=1u || s->model.used!=33u)
        return HCI_ERR_INVALID;
    if(!steps || steps>20000u || !finite_value(lr) || lr<=0.0f || lr>0.5f ||
       s->trained_steps>50000u-steps || s->generation==(unsigned int)-1)
        return HCI_ERR_INVALID;
    next=s->model; /* Commit only once all requested updates pass numeric checks. */
    for(iter=0u;iter<steps;++iter) {
        DNNGrad g;
        dnn_grad_clear(&g);
        for(j=0u;j<4u;++j) {
            DNNContext c;
            float dx[2],prediction=dnn_forward(&next,samples[j],&c);
            if(!finite_value(prediction)) return HCI_ERR_NUMERIC;
            dnn_backward_add(&next,&c,0.25f*(prediction-samples[j][2]),&g,dx);
        }
        for(k=0u;k<next.used;++k) if(!finite_value(g.g[k]))
            return HCI_ERR_NUMERIC;
        /* Training uses independent model storage; no subordinate is mutated. */
        dnn_step(&next,&g,lr);
        for(k=0u;k<next.used;++k) if(!finite_value(next.p[k]))
            return HCI_ERR_NUMERIC;
    }
    s->model=next;
    s->trained_steps+=steps;
    ++s->generation;
    return HCI_OK;
}
HCIStatus hci_supervisor_propose(const HCINeuralSupervisor *s,
                                 const HCIFrame *frame,unsigned int lessons,
                                 HCIProposal *out,float *score) {
    float x[2],y;
    DNNContext context;
    HCIProposal p={0};
    if(!s || !frame || !out || !score) return HCI_ERR_NULL;
    if(!s->generation || !s->trained_steps ||
       hci_validate_identity(&frame->identity)!=HCI_OK ||
       frame->kind!=HCI_LOGIC || frame->execution!=HCI_COMPLETED ||
       frame->source_status!=HQ_OK || frame->result_kind!=HCI_RESULT_LOGIC ||
       frame->disposition!=HCI_UNCHECKED ||
       (frame->truth!=HQ_TRUE && frame->truth!=HQ_FALSE && frame->truth!=HQ_UNKNOWN))
        return HCI_ERR_INVALID;
    x[0]=frame->truth==HQ_UNKNOWN?1.0f:0.0f;
    x[1]=lessons && frame->compute_remaining?1.0f:0.0f;
    y=dnn_forward(&s->model,x,&context);
    if(!finite_value(y)) return HCI_ERR_NUMERIC;
    p.action=y<0.25f?HCI_ACT_ANSWER:y<0.75f?HCI_ACT_RETURN_UNKNOWN:HCI_ACT_APPLY_LESSON;
    p.target_holon_id=frame->identity.holon_id;
    p.observed_graph_gen=frame->identity.graph_gen;
    p.observed_param_gen=frame->identity.param_gen;
    p.observed_snapshot_id=frame->identity.snapshot_id;
    p.requested_budget=p.action==HCI_ACT_APPLY_LESSON?1u:0u;
    *score=y;
    *out=p;
    return HCI_OK;
}
HCIStatus hci_supervisor_gate(const HCIProposal *p,const HCIFrame *f,
                              const HCIGrant *g,unsigned int lessons) {
    HCIStatus status=hci_gate_proposal(p,f,g);
    if(status!=HCI_OK) return status;
    if(!p || !f) return HCI_ERR_NULL;
    if(f->kind!=HCI_LOGIC || f->execution!=HCI_COMPLETED ||
       f->source_status!=HQ_OK || f->result_kind!=HCI_RESULT_LOGIC ||
       f->disposition!=HCI_UNCHECKED)
        return HCI_ERR_DENIED;
    if(p->action==HCI_ACT_APPLY_LESSON)
        return f->truth==HQ_UNKNOWN && lessons && f->compute_remaining?
               HCI_OK:HCI_ERR_DENIED;
    if(p->action==HCI_ACT_RETURN_UNKNOWN)
        return f->truth==HQ_UNKNOWN?HCI_OK:HCI_ERR_DENIED;
    if(p->action==HCI_ACT_ANSWER)
        return f->truth==HQ_TRUE || f->truth==HQ_FALSE?HCI_OK:HCI_ERR_DENIED;
    return HCI_ERR_DENIED;
}
