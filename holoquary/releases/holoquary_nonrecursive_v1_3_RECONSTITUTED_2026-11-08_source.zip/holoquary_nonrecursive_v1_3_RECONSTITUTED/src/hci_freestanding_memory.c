/* Standalone memcpy/memset for toolchains that lower large aggregate copies to
 * these symbols even under -ffreestanding. This file is linked only in the
 * freestanding-object profile; hosted test executables use their own runtime.
 * Volatile byte accesses prevent this implementation from recursively being
 * optimized into calls to the very symbols being supplied here. */
#include <stddef.h>
void *memcpy(void *destination,const void *source,size_t count) {
    volatile unsigned char *d=(volatile unsigned char*)destination;
    const volatile unsigned char *s=(const volatile unsigned char*)source;
    size_t i;
    for(i=0u;i<count;++i) d[i]=s[i];
    return destination;
}
void *memset(void *destination,int byte,size_t count) {
    volatile unsigned char *d=(volatile unsigned char*)destination;
    size_t i;
    for(i=0u;i<count;++i) d[i]=(unsigned char)byte;
    return destination;
}
