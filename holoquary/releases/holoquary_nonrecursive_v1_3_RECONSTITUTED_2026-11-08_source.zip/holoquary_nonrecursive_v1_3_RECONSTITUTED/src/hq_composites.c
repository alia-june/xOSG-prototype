#include "hq_composites.h"

/* Work on a local copy. No partially written program or output reference
 * survives a failed append. This is a build-time buffer, not per-gate heap. */
HQStatus hq_emit_not(HQProgram *p, HQRef a, HQRef *out) {
    HQProgram q; HQRef r; HQStatus s;
    if (!p || !out) return HQ_ERR_NULL;
    q = *p;
    s = hq_add_nand(&q,a,a,&r);
    if (s != HQ_OK) return s;
    *p=q; *out=r; return HQ_OK;
}
HQStatus hq_emit_and(HQProgram *p, HQRef a, HQRef b, HQRef *out) {
    HQProgram q; HQRef t,r; HQStatus s;
    if (!p || !out) return HQ_ERR_NULL;
    q=*p;
    s=hq_add_nand(&q,a,b,&t); if (s != HQ_OK) return s;
    s=hq_add_nand(&q,t,t,&r); if (s != HQ_OK) return s;
    *p=q; *out=r; return HQ_OK;
}
HQStatus hq_emit_or(HQProgram *p, HQRef a, HQRef b, HQRef *out) {
    HQProgram q; HQRef na,nb,r; HQStatus s;
    if (!p || !out) return HQ_ERR_NULL;
    q=*p;
    s=hq_add_nand(&q,a,a,&na); if (s != HQ_OK) return s;
    s=hq_add_nand(&q,b,b,&nb); if (s != HQ_OK) return s;
    s=hq_add_nand(&q,na,nb,&r); if (s != HQ_OK) return s;
    *p=q; *out=r; return HQ_OK;
}
HQStatus hq_emit_nor(HQProgram *p, HQRef a, HQRef b, HQRef *out) {
    HQProgram q; HQRef r; HQStatus s;
    if (!p || !out) return HQ_ERR_NULL;
    q=*p;
    s=hq_emit_or(&q,a,b,&r); if (s != HQ_OK) return s;
    s=hq_emit_not(&q,r,&r); if (s != HQ_OK) return s;
    *p=q; *out=r; return HQ_OK;
}
HQStatus hq_emit_xnor(HQProgram *p, HQRef a, HQRef b, HQRef *out) {
    HQProgram q; HQRef r; HQStatus s;
    if (!p || !out) return HQ_ERR_NULL;
    q=*p;
    s=hq_emit_xor(&q,a,b,&r); if (s != HQ_OK) return s;
    s=hq_emit_not(&q,r,&r); if (s != HQ_OK) return s;
    *p=q; *out=r; return HQ_OK;
}
HQStatus hq_emit_switch(HQProgram *p, HQRef data, HQRef enable, HQRef *out) {
    return hq_emit_and(p,data,enable,out);
}
HQStatus hq_emit_mux(HQProgram *p, HQRef a, HQRef b, HQRef select, HQRef *out) {
    HQProgram q; HQRef ns,x,y,xy,nxy,nab,r; HQStatus s;
    if (!p || !out) return HQ_ERR_NULL;
    q=*p;
    /* (a AND NOT select) OR (b AND select) OR (a AND b).
     * The consensus term (a AND b) preserves a common definite branch
     * when select=UNKNOWN under strong Kleene logic. 7 NANDs total. */
    s=hq_add_nand(&q,select,select,&ns); if (s != HQ_OK) return s;
    s=hq_add_nand(&q,a,ns,&x); if (s != HQ_OK) return s;
    s=hq_add_nand(&q,b,select,&y); if (s != HQ_OK) return s;
    s=hq_add_nand(&q,x,y,&xy); if (s != HQ_OK) return s;
    s=hq_add_nand(&q,xy,xy,&nxy); if (s != HQ_OK) return s;
    s=hq_add_nand(&q,a,b,&nab); if (s != HQ_OK) return s;
    s=hq_add_nand(&q,nxy,nab,&r); if (s != HQ_OK) return s;
    *p=q; *out=r; return HQ_OK;
}
HQStatus hq_emit_demux(HQProgram *p, HQRef data, HQRef select, HQRef out_refs[2]) {
    HQProgram q; HQRef ns,left,right; HQStatus s;
    if (!p || !out_refs) return HQ_ERR_NULL;
    q=*p;
    s=hq_emit_not(&q,select,&ns); if (s != HQ_OK) return s;
    s=hq_emit_and(&q,data,ns,&left); if (s != HQ_OK) return s;
    s=hq_emit_and(&q,data,select,&right); if (s != HQ_OK) return s;
    *p=q; out_refs[0]=left; out_refs[1]=right; return HQ_OK;
}
HQStatus hq_emit_guarded_lock(HQProgram *p, HQRef data, HQRef key,
                              HQRef permission, HQRef *out) {
    HQProgram q; HQRef allow,r; HQStatus s;
    if (!p || !out) return HQ_ERR_NULL;
    q=*p;
    s=hq_emit_and(&q,key,permission,&allow); if (s != HQ_OK) return s;
    s=hq_emit_and(&q,data,allow,&r); if (s != HQ_OK) return s;
    *p=q; *out=r; return HQ_OK;
}
int hq_guard_allows(HQTruth evaluated) { return evaluated == HQ_TRUE; }
