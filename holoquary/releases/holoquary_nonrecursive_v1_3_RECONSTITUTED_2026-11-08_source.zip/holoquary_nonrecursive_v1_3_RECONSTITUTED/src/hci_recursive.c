#include "hci_recursive.h"

typedef struct {
    const HCIRecNode *nodes[HCI_RECURSIVE_MAX_NODES];
    unsigned char state[HCI_RECURSIVE_MAX_NODES]; /* 1 running; 2 evaluated */
    HQTruth value[HCI_RECURSIVE_MAX_NODES];
    HCIRecTrace trace;
    const HQTruth *inputs;
    unsigned int input_count;
    unsigned int graph_generation;
    unsigned int snapshot_id;
    unsigned int max_nand_calls;
} Walk;
static int valid_truth(HQTruth t) {
    return t==HQ_FALSE || t==HQ_TRUE || t==HQ_UNKNOWN;
}
static HCIStatus evaluate_node(const HCIRecNode *node,Walk *w,
                               unsigned int depth,HQTruth *result) {
    unsigned int i,slot;
    HQTruth left,right,outputs[1];
    HQProgram program;
    HQRef gate;
    if(!node) return HCI_ERR_NULL;
    if(depth>HCI_RECURSIVE_MAX_DEPTH) return HCI_ERR_CAPACITY;
    if(hci_validate_identity(&node->identity)!=HCI_OK ||
       node->identity.graph_gen!=w->graph_generation ||
       node->identity.snapshot_id!=w->snapshot_id ||
       node->identity.param_gen!=0u) return HCI_ERR_STALE;
    for(i=0u;i<w->trace.visited;++i) {
        if(w->nodes[i]==node) {
            if(w->state[i]==1u) return HCI_ERR_INVALID; /* cycle */
            if(w->state[i]!=2u) return HCI_ERR_INVALID;
            ++w->trace.cache_hits;
            *result=w->value[i];
            return HCI_OK;
        }
        /* Distinct node pointers cannot impersonate an existing instance. */
        if(w->nodes[i]->identity.instance_id==node->identity.instance_id)
            return HCI_ERR_INVALID;
    }
    if(w->trace.visited>=HCI_RECURSIVE_MAX_NODES) return HCI_ERR_CAPACITY;
    slot=w->trace.visited++;
    w->nodes[slot]=node;
    w->state[slot]=1u;
    w->trace.source_instance_ids[slot]=node->identity.instance_id;
    w->trace.source_holon_ids[slot]=node->identity.holon_id;
    if(node->kind==HCI_RECUR_INPUT) {
        if(node->left || node->right || node->input_port>=w->input_count)
            return HCI_ERR_INVALID;
        outputs[0]=w->inputs[node->input_port];
    } else if(node->kind==HCI_RECUR_NAND) {
        HCIStatus s;
        if(!node->left || !node->right || node->input_port!=0u)
            return HCI_ERR_INVALID;
        s=evaluate_node(node->left,w,depth+1u,&left);
        if(s!=HCI_OK) return s;
        s=evaluate_node(node->right,w,depth+1u,&right);
        if(s!=HCI_OK) return s;
        if(w->trace.nand_evaluated>=w->max_nand_calls) return HCI_ERR_BUDGET;
        /* Run the unchanged standalone NAND implementation. */
        if(hq_init(&program,2u)!=HQ_OK ||
           hq_add_nand(&program,hq_input(0u),hq_input(1u),&gate)!=HQ_OK ||
           hq_export(&program,gate)!=HQ_OK) return HCI_ERR_SOURCE;
        {
            HQTruth pair[2]={left,right};
            if(hq_eval(&program,pair,2u,outputs,1u)!=HQ_OK)
                return HCI_ERR_SOURCE;
        }
        ++w->trace.nand_evaluated;
        ++w->trace.budget_used;
    } else return HCI_ERR_INVALID;
    w->state[slot]=2u;
    w->value[slot]=outputs[0];
    w->trace.observed_values[slot]=outputs[0];
    *result=outputs[0];
    return HCI_OK;
}
HCIStatus hci_recursive_evaluate(const HCIRecNode *root,
                                 const HQTruth *inputs,unsigned int count,
                                 unsigned int max_nand_calls,
                                 HQTruth *out,HCIRecTrace *trace) {
    Walk w={0};
    HCIStatus s;
    HQTruth value;
    unsigned int i;
    if(!root || !inputs || !out || !trace) return HCI_ERR_NULL;
    if(!count || count>HQ_MAX_INPUTS || !max_nand_calls ||
       max_nand_calls>HCI_RECURSIVE_MAX_NODES ||
       hci_validate_identity(&root->identity)!=HCI_OK)
        return HCI_ERR_INVALID;
    for(i=0u;i<count;++i) if(!valid_truth(inputs[i])) return HCI_ERR_INVALID;
    w.inputs=inputs;
    w.input_count=count;
    w.max_nand_calls=max_nand_calls;
    w.graph_generation=root->identity.graph_gen;
    w.snapshot_id=root->identity.snapshot_id;
    s=evaluate_node(root,&w,1u,&value);
    if(s!=HCI_OK) return s; /* no caller state modified */
    *out=value;
    *trace=w.trace;
    return HCI_OK;
}
