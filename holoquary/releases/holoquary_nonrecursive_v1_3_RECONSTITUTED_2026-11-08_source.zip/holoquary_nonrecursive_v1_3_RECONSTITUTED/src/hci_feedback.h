#ifndef HCI_FEEDBACK_H
#define HCI_FEEDBACK_H
/* Holoquary I-05: fixed-capacity, externally verified lesson proposals.
 * These interfaces do not authenticate callers, verifiers, or source handles. */
#include "holon_types.h"
#define HCI_MAX_FEEDBACK_EVENTS 32u

typedef enum { HCI_CAND_FACT=1, HCI_CAND_RULE=2, HCI_CAND_ANTI=3 } HCICandidateKind;
typedef enum { HCI_VERDICT_ACCEPT=1, HCI_VERDICT_REJECT=2,
               HCI_VERDICT_DEFER=3 } HCIVerdict;
typedef enum { HCI_EVENT_ADMITTED=1, HCI_EVENT_REJECTED=2,
               HCI_EVENT_DEFERRED=3, HCI_EVENT_CONFLICT=4,
               HCI_EVENT_ANTI_ADMITTED=5 } HCIEventOutcome;

typedef struct {
    unsigned int candidate_id;   /* replay identifier scoped to one store */
    unsigned int proposer_id;    /* opaque handle, NOT authentication */
    unsigned int source_id;      /* provenance handle, NOT source validation */
    unsigned int evidence_id;    /* opaque evidence handle */
    unsigned int scope_id;
    HCIIdentity observed;       /* the original state-frame identity */
    HCICandidateKind kind;
    unsigned int premise_port;  /* rule only */
    HQTruth premise_value;      /* rule only */
    unsigned int result_port;   /* fact port or rule consequent port */
    HQTruth result_value;       /* fact/rule only: TRUE or FALSE */
    unsigned int action_code;   /* anti-lesson only, observational */
    unsigned int failure_code;  /* anti-lesson only, observational */
} HCICandidate;

typedef struct {
    HCIVerdict verdict;
    unsigned int verifier_id;   /* caller-assigned, NOT proof of independence */
    unsigned int checked_candidate_id;
    unsigned int checked_evidence_id;
    unsigned int proof_ref;     /* opaque external verifier receipt reference */
} HCIVerification;

/* Contract: caller supplies pure verifier against independently held evidence.
 * Callback must not mutate the store, source bank, candidate or external effects. */
typedef HCIStatus (*HCIVerifier)(const HCICandidate *candidate,
                                  const void *oracle_ctx, HCIVerification *out);

typedef struct {
    HCICandidate candidate;
    HCIVerification verification;
    HCIEventOutcome outcome;
    unsigned int generation_after;
} HCIEvent;

typedef struct {
    HQLessonBank bank;          /* accepted facts/rules for existing EXTENDED */
    unsigned int scope_id;
    unsigned int generation;   /* store-local commit generation */
    unsigned int count;
    HCIEvent events[HCI_MAX_FEEDBACK_EVENTS]; /* append-only while live */
} HCIFeedbackStore;

HCIStatus hci_feedback_init(HCIFeedbackStore *store, unsigned int scope_id);
HCIStatus hci_feedback_submit(HCIFeedbackStore *store,
                              const HCIFrame *observation,
                              unsigned int input_count,
                              const HCICandidate *candidate,
                              HCIVerifier verifier, const void *oracle_ctx,
                              HCIEvent *receipt);
/* Read-only bank access for existing hci_observe_extended(). */
const HQLessonBank *hci_feedback_bank(const HCIFeedbackStore *store);
#endif
