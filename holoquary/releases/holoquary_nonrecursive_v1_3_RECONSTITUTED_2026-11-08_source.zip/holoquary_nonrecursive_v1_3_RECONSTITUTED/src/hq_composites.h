#ifndef HQ_COMPOSITES_H
#define HQ_COMPOSITES_H
/* Holoquary v0.8: pure, transactionally appended NAND-derived templates.
 * No embedded source authorization; guard is logical, not security access control.
 * All output references are assigned only on success. */
#include "holoquary.h"

HQStatus hq_emit_not(HQProgram *p, HQRef a, HQRef *out);
HQStatus hq_emit_and(HQProgram *p, HQRef a, HQRef b, HQRef *out);
HQStatus hq_emit_or(HQProgram *p, HQRef a, HQRef b, HQRef *out);
HQStatus hq_emit_nor(HQProgram *p, HQRef a, HQRef b, HQRef *out);
HQStatus hq_emit_xnor(HQProgram *p, HQRef a, HQRef b, HQRef *out);
HQStatus hq_emit_switch(HQProgram *p, HQRef data, HQRef enable, HQRef *out);
/* Select a if select=FALSE, b if select=TRUE. For select=UNKNOWN:
 * return common definite branch if a==b, otherwise UNKNOWN. */
HQStatus hq_emit_mux(HQProgram *p, HQRef a, HQRef b, HQRef select, HQRef *out);
/* Routes a single data value to two outputs: select=FALSE -> left;
 * select=TRUE -> right. Inactive output is FALSE; ambiguous selection
 * can yield UNKNOWN. out_refs[0]=left, out_refs[1]=right. */
HQStatus hq_emit_demux(HQProgram *p, HQRef data, HQRef select, HQRef out_refs[2]);
/* Logical condition: data AND key AND permission. No authentication or
 * authority is established merely because input called 'permission' is TRUE. */
HQStatus hq_emit_guarded_lock(HQProgram *p, HQRef data, HQRef key,
                              HQRef permission, HQRef *out);
/* Only definite TRUE may produce an actuator-like approval. UNKNOWN and
 * FALSE both produce 0, but remain distinguishable in the truth output. */
int hq_guard_allows(HQTruth evaluated);
#endif
