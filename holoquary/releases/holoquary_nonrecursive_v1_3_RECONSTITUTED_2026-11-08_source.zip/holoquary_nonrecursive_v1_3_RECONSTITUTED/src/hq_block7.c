#include "hq_block7.h"
#include <limits.h>

static int valid_digit(int v) { return v >= -3 && v <= 3; }
static int valid_carry(int v) { return v >= -1 && v <= 1; }
static uint8_t bit_for(int v) { return (uint8_t)(1u << (unsigned)(v+3)); }
static void balanced_reduce(int n, int8_t *d, int8_t *c)
{
    int carry=0;
    while (n>3) { n-=7; ++carry; }
    while (n< -3) { n+=7; --carry; }
    *d=(int8_t)n; *c=(int8_t)carry;
}
HQ7Status hq7_validate(HQ7Set value)
{ return (value.mask & (uint8_t)~HQ7_ALL) ? HQ7_INVALID : HQ7_OK; }
HQ7Status hq7_pair_to_digit(int block,int inner,int8_t *out_digit)
{
    if (!out_digit) return HQ7_NULL;
    if (!valid_carry(block) || !valid_carry(inner) || (block==0 && inner!=0)) return HQ7_INVALID;
    *out_digit=(int8_t)(2*block+inner); return HQ7_OK;
}
HQ7Status hq7_digit_to_pair(int digit,int8_t *out_block,int8_t *out_inner)
{
    if (!out_block || !out_inner) return HQ7_NULL;
    if (!valid_digit(digit)) return HQ7_INVALID;
    int block = digit<0 ? -1 : digit>0 ? 1 : 0;
    /* Negative block: -3,-2,-1; positive block: +1,+2,+3. */
    *out_block=(int8_t)block;
    *out_inner=(int8_t)(digit-2*block);
    return HQ7_OK;
}
HQ7Status hq7_exact(int digit,HQ7Set *out)
{
    if (!out) return HQ7_NULL;
    if (!valid_digit(digit)) return HQ7_INVALID;
    out->mask=bit_for(digit); return HQ7_OK;
}
HQ7Status hq7_block(int block,HQ7Set *out)
{
    if (!out) return HQ7_NULL;
    if (!valid_carry(block)) return HQ7_INVALID;
    out->mask=block<0 ? HQ7_NEGATIVE_BLOCK : block>0 ? HQ7_POSITIVE_BLOCK : HQ7_CENTRAL_BLOCK;
    return HQ7_OK;
}
HQ7Status hq7_inner(int inner,HQ7Set *out)
{
    if(!out) return HQ7_NULL;
    if(!valid_carry(inner)) return HQ7_INVALID;
    /* block -1: -2 + inner; block 0 only inner 0; block +1: 2 + inner */
    out->mask=(uint8_t)(bit_for(-2+inner)|bit_for(2+inner)|
              (inner==0 ? bit_for(0) : 0u));
    return HQ7_OK;
}
HQ7Status hq7_possible_blocks(HQ7Set value,uint8_t *out_blocks)
{
    if(!out_blocks) return HQ7_NULL;
    if(hq7_validate(value)!=HQ7_OK) return HQ7_INVALID;
    *out_blocks=(uint8_t)(((value.mask & HQ7_NEGATIVE_BLOCK)?1u:0u)|
              ((value.mask & HQ7_CENTRAL_BLOCK)?2u:0u)|
              ((value.mask & HQ7_POSITIVE_BLOCK)?4u:0u));
    return HQ7_OK;
}
HQ7Status hq7_knowledge(HQ7Set value,HQ7Knowledge *out)
{
    if (!out) return HQ7_NULL;
    if (hq7_validate(value)!=HQ7_OK) return HQ7_INVALID;
    if (!value.mask) *out=HQ7_CONTRADICTORY;
    else if (value.mask==HQ7_ALL) *out=HQ7_UNKNOWN;
    else if (!(value.mask & (uint8_t)(value.mask-1u))) *out=HQ7_EXACT;
    else *out=HQ7_PARTIAL;
    return HQ7_OK;
}
HQ7Status hq7_refine(HQ7Set prev,HQ7Set constraint,HQ7Set *out)
{
    if (!out) return HQ7_NULL;
    if (hq7_validate(prev)!=HQ7_OK || hq7_validate(constraint)!=HQ7_OK) return HQ7_INVALID;
    out->mask=(uint8_t)(prev.mask & constraint.mask); return HQ7_OK;
}
HQ7Status hq7_union(HQ7Set a,HQ7Set b,HQ7Set *out)
{
    if (!out) return HQ7_NULL;
    if (hq7_validate(a)!=HQ7_OK || hq7_validate(b)!=HQ7_OK) return HQ7_INVALID;
    out->mask=(uint8_t)(a.mask|b.mask); return HQ7_OK;
}
HQ7Status hq7_negate(HQ7Set value,HQ7Set *out)
{
    if (!out) return HQ7_NULL;
    if (hq7_validate(value)!=HQ7_OK) return HQ7_INVALID;
    uint8_t mask=0;
    for(int v=-3;v<=3;++v) if(value.mask&bit_for(v)) mask=(uint8_t)(mask|bit_for(-v));
    out->mask=mask; return HQ7_OK;
}
HQ7Status hq7_add_exact(int a,int b,int carry_in,int8_t *out_digit,int8_t *out_carry)
{
    if (!out_digit || !out_carry) return HQ7_NULL;
    if (out_digit==out_carry || !valid_digit(a) || !valid_digit(b) || !valid_carry(carry_in)) return HQ7_INVALID;
    int8_t d,c; balanced_reduce(a+b+carry_in,&d,&c);
    *out_digit=d; *out_carry=c; return HQ7_OK;
}
HQ7Status hq7_mul_exact(int a,int b,int8_t *out_digit,int8_t *out_carry)
{
    if (!out_digit || !out_carry) return HQ7_NULL;
    if (out_digit==out_carry || !valid_digit(a) || !valid_digit(b)) return HQ7_INVALID;
    int8_t d,c; balanced_reduce(a*b,&d,&c);
    *out_digit=d; *out_carry=c; return HQ7_OK;
}
static HQ7Status binary_set_op(HQ7Set a,HQ7Set b,int carry_in,int multiply,HQ7Outcome *out)
{
    if (!out) return HQ7_NULL;
    if (hq7_validate(a)!=HQ7_OK || hq7_validate(b)!=HQ7_OK ||
        (!multiply && !valid_carry(carry_in))) return HQ7_INVALID;
    uint32_t bits=0;
    for(int i=-3;i<=3;++i) if (a.mask&bit_for(i))
      for(int j=-3;j<=3;++j) if(b.mask&bit_for(j)) {
        int8_t d,c;
        balanced_reduce(multiply ? i*j : i+j+carry_in,&d,&c);
        bits |= (uint32_t)1u << ((unsigned)(c+1)*7u+(unsigned)(d+3));
      }
    out->joint=bits; return HQ7_OK;
}
HQ7Status hq7_add_sets(HQ7Set a,HQ7Set b,int cin,HQ7Outcome *out)
{ return binary_set_op(a,b,cin,0,out); }
HQ7Status hq7_mul_sets(HQ7Set a,HQ7Set b,HQ7Outcome *out)
{ return binary_set_op(a,b,0,1,out); }
HQ7Status hq7_outcome_project(HQ7Outcome value,HQ7Set *out_digit,uint8_t *out_carries)
{
    if (!out_digit || !out_carries) return HQ7_NULL;
    if (value.joint & ~((uint32_t)((1u<<21)-1u))) return HQ7_INVALID;
    uint8_t digits=0, carries=0;
    for (unsigned c=0;c<3;++c) for (unsigned d=0;d<7;++d)
      if(value.joint & ((uint32_t)1u << (c*7u+d))) {
        digits=(uint8_t)(digits | (uint8_t)(1u<<d));
        carries=(uint8_t)(carries | (uint8_t)(1u<<c));
      }
    out_digit->mask=digits; *out_carries=carries; return HQ7_OK;
}
HQ7Status hq7_compare_sets(HQ7Set a,HQ7Set b,uint8_t *out_relations)
{
    if (!out_relations) return HQ7_NULL;
    if (hq7_validate(a)!=HQ7_OK || hq7_validate(b)!=HQ7_OK) return HQ7_INVALID;
    uint8_t relations=0;
    for(int i=-3;i<=3;++i) if(a.mask&bit_for(i))
      for(int j=-3;j<=3;++j) if(b.mask&bit_for(j))
        relations=(uint8_t)(relations | (i<j ? 1u : i>j ? 4u : 2u));
    *out_relations=relations; return HQ7_OK;
}
HQ7Status hq7_select_block(HQ7Set selector,const HQ7Set branches[3],HQ7Set *out)
{
    if (!branches || !out) return HQ7_NULL;
    if (hq7_validate(selector)!=HQ7_OK) return HQ7_INVALID;
    for(unsigned j=0;j<3;++j) if(hq7_validate(branches[j])!=HQ7_OK) return HQ7_INVALID;
    uint8_t mask=0;
    if (selector.mask & HQ7_NEGATIVE_BLOCK) mask=(uint8_t)(mask|branches[0].mask);
    if (selector.mask & HQ7_CENTRAL_BLOCK) mask=(uint8_t)(mask|branches[1].mask);
    if (selector.mask & HQ7_POSITIVE_BLOCK) mask=(uint8_t)(mask|branches[2].mask);
    out->mask=mask; return HQ7_OK;
}
HQ7Status hq7_cell_init(HQ7Cell *cell,HQ7Set initial)
{
    if (!cell) return HQ7_NULL;
    if (hq7_validate(initial)!=HQ7_OK) return HQ7_INVALID;
    cell->value=initial; cell->generation=0u; return HQ7_OK;
}
HQ7Status hq7_cell_read(const HQ7Cell *cell,HQ7Set *out,uint32_t *generation)
{
    if (!cell || !out || !generation) return HQ7_NULL;
    if (hq7_validate(cell->value)!=HQ7_OK) return HQ7_INVALID;
    *out=cell->value; *generation=cell->generation; return HQ7_OK;
}
HQ7Status hq7_cell_tick(HQ7Cell *cell,uint32_t expected,HQ7Tick tick,HQ7Set write_value,HQ7Set *out_value)
{
    if (!cell || !out_value) return HQ7_NULL;
    if (hq7_validate(cell->value)!=HQ7_OK || hq7_validate(write_value)!=HQ7_OK ||
        (tick!=HQ7_HOLD && tick!=HQ7_WRITE && tick!=HQ7_RESET)) return HQ7_INVALID;
    if (expected!=cell->generation) return HQ7_STALE;
    if (cell->generation==UINT32_MAX) return HQ7_OVERFLOW;
    HQ7Set next=cell->value;
    if (tick==HQ7_WRITE) next=write_value;
    if (tick==HQ7_RESET) next.mask=HQ7_CENTRAL_BLOCK;
    cell->value=next;
    ++cell->generation;
    *out_value=next;
    return HQ7_OK;
}
HQ7Status hq7_add_word(const int8_t *a,const int8_t *b,unsigned n,int cin,int8_t *out,int8_t *out_carry)
{
    if (!a || !b || !out || !out_carry) return HQ7_NULL;
    if (n==0 || n>HQ7_MAX_WORD || !valid_carry(cin)) return HQ7_INVALID;
    /* All validations and calculations precede output mutation. */
    int8_t tmp[HQ7_MAX_WORD],carry=(int8_t)cin;
    for(unsigned j=0;j<n;++j) {
        if (!valid_digit(a[j]) || !valid_digit(b[j])) return HQ7_INVALID;
        balanced_reduce(a[j]+b[j]+carry,&tmp[j],&carry);
    }
    for(unsigned j=0;j<n;++j) out[j]=tmp[j];
    *out_carry=carry; return HQ7_OK;
}
