#include "hq_cells.h"
#include <limits.h>
static int good(HQTruth v) { return v==HQ_FALSE || v==HQ_TRUE || v==HQ_UNKNOWN; }
HQCellStatus hq_bit_init(HQBitCell *cell, HQTruth initial) {
    if (!cell) return HQ_CELL_NULL;
    if (!good(initial)) return HQ_CELL_VALUE;
    cell->value=initial; cell->generation=0u;
    return HQ_CELL_OK;
}
HQCellStatus hq_bit_read(const HQBitCell *cell, HQTruth *out,
                         unsigned int *generation) {
    if (!cell || !out || !generation) return HQ_CELL_NULL;
    if (!good(cell->value)) return HQ_CELL_VALUE;
    *out=cell->value; *generation=cell->generation; return HQ_CELL_OK;
}
HQCellStatus hq_bit_tick(HQBitCell *cell, unsigned int expected_generation,
                         HQTruth write_enable, HQTruth write_data, HQTruth *out) {
    HQTruth next;
    if (!cell || !out) return HQ_CELL_NULL;
    if (!good(cell->value) || !good(write_enable) || !good(write_data)) return HQ_CELL_VALUE;
    if (cell->generation != expected_generation) return HQ_CELL_STALE;
    if (cell->generation == UINT_MAX) return HQ_CELL_EXHAUSTED;
    if (write_enable == HQ_FALSE) next=cell->value;
    else if (write_enable == HQ_TRUE) next=write_data;
    else next=cell->value == write_data ? cell->value : HQ_UNKNOWN;
    cell->value=next;
    ++cell->generation;
    *out=next;
    return HQ_CELL_OK;
}
