#include "hci_recovery.h"
#include <float.h>

static int same_id(const HCIIdentity *a,const HCIIdentity *b) {
    return a->holon_id==b->holon_id && a->instance_id==b->instance_id &&
        a->graph_gen==b->graph_gen && a->param_gen==b->param_gen &&
        a->snapshot_id==b->snapshot_id;
}
static int same_generations(const HCIIdentity *a,const HCIIdentity *b) {
    return a->holon_id==b->holon_id && a->instance_id==b->instance_id &&
        a->graph_gen==b->graph_gen && a->param_gen==b->param_gen;
}
static int valid_effect(HCIEffect e) {
    return e==HCI_EFFECT_PURE || e==HCI_EFFECT_EXTERNAL || e==HCI_EFFECT_UNKNOWN;
}
static int valid_frame_type(const HCIFrame *f) {
    return hci_validate_identity(&f->identity)==HCI_OK &&
        (f->kind==HCI_NEURAL || f->kind==HCI_LOGIC) &&
        f->input_count>0u && f->input_count<=HQ_MAX_INPUTS;
}
static int id_used(const HCIRecoveryStore *s,unsigned int id) {
    unsigned int k;
    for(k=0u;k<s->count;++k) if(s->events[k].event_id==id) return 1;
    return 0;
}
static const HCIRecoveryEvent *find_failure(const HCIRecoveryStore *s,
                                             unsigned int id) {
    unsigned int k;
    for(k=0u;k<s->count;++k) if(s->events[k].event_id==id &&
                                s->events[k].outcome==HCI_REC_FAILURE)
        return &s->events[k];
    return (const HCIRecoveryEvent*)0;
}
static unsigned int attempt_count(const HCIRecoveryStore *s,unsigned int id,
                                  int *completed) {
    unsigned int k,n=0u;
    *completed=0;
    for(k=0u;k<s->count;++k) if(s->events[k].parent_failure_id==id) {
        if(s->events[k].outcome==HCI_REC_REEVAL_COMPLETED) *completed=1;
        if(s->events[k].outcome==HCI_REC_REEVAL_COMPLETED ||
           s->events[k].outcome==HCI_REC_REEVAL_FAILED) ++n;
    }
    return n;
}
static int valid_completed(const HCIFrame *f) {
    if(!valid_frame_type(f) || f->execution!=HCI_COMPLETED) return 0;
    if(f->kind==HCI_LOGIC)
        return f->result_kind==HCI_RESULT_LOGIC && f->source_status==HQ_OK &&
            (f->truth==HQ_TRUE || f->truth==HQ_FALSE || f->truth==HQ_UNKNOWN) &&
            (f->disposition==HCI_STABLE || f->disposition==HCI_CONFLICT ||
             f->disposition==HCI_EXHAUSTED || f->disposition==HCI_UNCHECKED);
    return f->kind==HCI_NEURAL && f->result_kind==HCI_RESULT_NUMERIC &&
        f->number==f->number && f->number<=FLT_MAX && f->number>=-FLT_MAX;
}
static HCIStatus commit(HCIRecoveryStore *s,HCIRecoveryEvent *e,
                        HCIRecoveryEvent *receipt) {
    if(s->generation==(unsigned int)-1 || s->count>=HCI_REC_MAX_EVENTS)
        return HCI_ERR_CAPACITY;
    e->generation_after=s->generation+1u;
    s->events[s->count]=*e;
    ++s->count;
    ++s->generation;
    *receipt=*e;
    return HCI_OK;
}
HCIStatus hci_recovery_init(HCIRecoveryStore *s,unsigned int scope,
                            unsigned int limit) {
    if(!s) return HCI_ERR_NULL;
    if(!scope || !limit || limit>HCI_REC_MAX_ATTEMPTS) return HCI_ERR_INVALID;
    s->scope_id=scope;
    s->generation=1u;
    s->count=0u;
    s->per_failure_limit=limit;
    return HCI_OK;
}
HCIStatus hci_recovery_record(HCIRecoveryStore *s,unsigned int id,
                              const HCIFrame *f,HCIStatus source_error,
                              HCIEffect effect,HCIRecoveryEvent *receipt) {
    HCIRecoveryEvent e={0};
    if(!s || !f || !receipt) return HCI_ERR_NULL;
    if(!s->scope_id || !s->generation || !s->per_failure_limit ||
       s->per_failure_limit>HCI_REC_MAX_ATTEMPTS ||
       s->count>HCI_REC_MAX_EVENTS || !id || id_used(s,id) ||
       !valid_frame_type(f) || !valid_effect(effect) ||
       (f->execution!=HCI_FAILED && f->execution!=HCI_COMPLETION_UNKNOWN) ||
       (f->execution==HCI_FAILED && source_error==HCI_OK))
        return HCI_ERR_INVALID;
    e.event_id=id;
    e.scope_id=s->scope_id;
    e.observed=*f;
    e.native_error=source_error;
    e.effect=effect;
    e.outcome=HCI_REC_FAILURE;
    return commit(s,&e,receipt);
}
HCIStatus hci_recovery_attempt(HCIRecoveryStore *s,unsigned int id,
                               unsigned int attempt_snapshot,
                               const HCIRecoveryGrant *g,HCIReeval evaluate,
                               const void *context,HCIRecoveryEvent *receipt) {
    HCIRecoveryEvent next={0};
    HCIFrame observed={0};
    HCIFrame original;
    const HCIRecoveryEvent *parent;
    HCIStatus status;
    unsigned int attempts;
    int completed;
    if(!s || !g || !receipt) return HCI_ERR_NULL;
    if(!s->scope_id || !s->generation || !s->per_failure_limit ||
       s->per_failure_limit>HCI_REC_MAX_ATTEMPTS || s->count>HCI_REC_MAX_EVENTS ||
       !id || !attempt_snapshot || id_used(s,id) ||
       !g->scope_id || g->scope_id!=s->scope_id ||
       !g->parent_failure_id || !g->policy_id ||
       !g->max_attempts || g->max_attempts>s->per_failure_limit ||
       hci_validate_identity(&g->exact_origin)!=HCI_OK)
        return HCI_ERR_INVALID;
    if(s->count>=HCI_REC_MAX_EVENTS || s->generation==(unsigned int)-1)
        return HCI_ERR_CAPACITY;
    parent=find_failure(s,g->parent_failure_id);
    if(!parent || !same_id(&parent->observed.identity,&g->exact_origin) ||
       attempt_snapshot==parent->observed.identity.snapshot_id)
        return HCI_ERR_STALE;
    attempts=attempt_count(s,g->parent_failure_id,&completed);
    next.event_id=id;
    next.parent_failure_id=g->parent_failure_id;
    next.scope_id=s->scope_id;
    next.effect=parent->effect;
    next.policy_id=g->policy_id;
    next.observed=parent->observed;
    next.native_error=parent->native_error;
    if(parent->effect!=HCI_EFFECT_PURE ||
       parent->observed.execution==HCI_COMPLETION_UNKNOWN ||
       !g->permit_pure_reeval || !evaluate ||
       completed || attempts>=g->max_attempts) {
        next.outcome=HCI_REC_BLOCKED;
        status=commit(s,&next,receipt);
        return status==HCI_OK?HCI_ERR_DENIED:status;
    }
    original=parent->observed;
    status=evaluate(&original,attempt_snapshot,context,&observed);
    if(status==HCI_OK && valid_completed(&observed) &&
       same_generations(&observed.identity,&original.identity) &&
       observed.identity.snapshot_id==attempt_snapshot &&
       observed.kind==original.kind && observed.input_count==original.input_count) {
        next.observed=observed;
        next.native_error=HCI_OK;
        next.outcome=HCI_REC_REEVAL_COMPLETED;
    } else {
        next.outcome=HCI_REC_REEVAL_FAILED;
        next.native_error=status==HCI_OK?HCI_ERR_INVALID:status;
        /* Failed callback's returned buffer is untrusted; preserve original. */
    }
    status=commit(s,&next,receipt);
    return status;
}
