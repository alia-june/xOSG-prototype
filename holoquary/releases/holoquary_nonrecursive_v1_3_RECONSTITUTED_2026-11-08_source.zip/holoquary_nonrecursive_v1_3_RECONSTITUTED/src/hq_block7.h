#ifndef HQ_BLOCK7_H
#define HQ_BLOCK7_H
/* Holoquary v1.1: independent 3-1-3 structure / optional balanced-seven profile.
 * No heap, I/O, time, or runtime recursion. Caller owns all storage.
 * Structural states are exact pairs: (-1,-1/0/+1), (0,0), (+1,-1/0/+1).
 * Numeric mapping V=2*block+inner is a selectable *proposal*, not an
 * assertion that structural block labels necessarily denote base-seven.
 * UNKNOWN and ERROR are NOT numerical digits.
 */
#include <stdint.h>
#define HQ7_MAX_WORD 32u
#define HQ7_ALL 0x7fu
#define HQ7_NEGATIVE_BLOCK 0x07u
#define HQ7_CENTRAL_BLOCK 0x08u
#define HQ7_POSITIVE_BLOCK 0x70u
/* Each bit i denotes possible exact numeric value (i-3).
 * mask 0 is CONTRADICTION; mask 0x7F is wholly UNKNOWN.
 */
typedef struct { uint8_t mask; } HQ7Set;
typedef enum { HQ7_OK=0, HQ7_NULL, HQ7_INVALID, HQ7_STALE, HQ7_OVERFLOW, HQ7_RANGE } HQ7Status;
typedef enum { HQ7_CONTRADICTORY=0, HQ7_EXACT, HQ7_PARTIAL, HQ7_UNKNOWN } HQ7Knowledge;
/* A joint result: bit ((carry+1)*7 + (digit+3)), valid carries -1,0,+1.
 * Correlation between carry and digit is retained; it is NOT two unrelated
 * sets of marginal values. 0 represents no permitted (digit,carry) pair.
 */
typedef struct { uint32_t joint; } HQ7Outcome;
typedef struct { HQ7Set value; uint32_t generation; } HQ7Cell;
typedef enum { HQ7_HOLD=0, HQ7_WRITE=1, HQ7_RESET=2 } HQ7Tick;

HQ7Status hq7_pair_to_digit(int block, int inner, int8_t *out_digit);
HQ7Status hq7_digit_to_pair(int digit, int8_t *out_block, int8_t *out_inner);
HQ7Status hq7_exact(int digit, HQ7Set *out);
HQ7Status hq7_block(int block, HQ7Set *out);
/* Structural inner position across every valid block; note (0,+/-1) are
 * invalid, so each inner constraint covers only existing pairs. */
HQ7Status hq7_inner(int inner, HQ7Set *out);
/* Bit 0: block -1, bit 1: block 0, bit 2: block +1. */
HQ7Status hq7_possible_blocks(HQ7Set value, uint8_t *out_blocks);
HQ7Status hq7_validate(HQ7Set value);
HQ7Status hq7_knowledge(HQ7Set value, HQ7Knowledge *out);
HQ7Status hq7_refine(HQ7Set previous, HQ7Set new_constraint, HQ7Set *out);
HQ7Status hq7_union(HQ7Set a, HQ7Set b, HQ7Set *out);
HQ7Status hq7_negate(HQ7Set value, HQ7Set *out);
/* Exact balanced-seven arithmetic. carry-in for addition -1/0/+1.
 * Result = digit + 7 * carry, digit in [-3,+3]. Outputs atomic on error.
 * Output pointers must not alias one another; the caller owns valid storage.
 */
HQ7Status hq7_add_exact(int a, int b, int carry_in, int8_t *out_digit, int8_t *out_carry);
HQ7Status hq7_mul_exact(int a, int b, int8_t *out_digit, int8_t *out_carry);
/* Input values in a set are independent possibilities (no symbolic identity
 * binding). Empty-set inputs return a valid empty joint possibility set.
 */
HQ7Status hq7_add_sets(HQ7Set a, HQ7Set b, int carry_in, HQ7Outcome *out);
HQ7Status hq7_mul_sets(HQ7Set a, HQ7Set b, HQ7Outcome *out);
HQ7Status hq7_outcome_project(HQ7Outcome result, HQ7Set *out_digit_set,
                               uint8_t *out_carry_mask);
/* Set of possible comparison relations: LT=bit0 EQ=bit1 GT=bit2.
 * Unknown operands have independent possible completions; empty set => 0.
 */
HQ7Status hq7_compare_sets(HQ7Set a, HQ7Set b, uint8_t *out_relations);
/* Structural 3-way switch by the selector's outer block. Union of all
 * possible selected branch values; no implicit shortcut to U or E.
 */
HQ7Status hq7_select_block(HQ7Set selector, const HQ7Set branches[3], HQ7Set *out);
HQ7Status hq7_cell_init(HQ7Cell *cell, HQ7Set initial);
HQ7Status hq7_cell_read(const HQ7Cell *cell, HQ7Set *out, uint32_t *generation);
HQ7Status hq7_cell_tick(HQ7Cell *cell, uint32_t expected_generation,
                         HQ7Tick tick, HQ7Set write_value, HQ7Set *out_value);
/* Exact balanced-seven word addition, little-endian signed digits, length
 * 1..32. Reads all input digits before writing anything. Supports exact
 * input/output alias, but not partial array overlap. Caller must supply
 * nonoverlapping output-carry storage. No external numeric overflow.
 */
HQ7Status hq7_add_word(const int8_t *a, const int8_t *b, unsigned length,
                        int carry_in, int8_t *out, int8_t *out_carry);
#endif
