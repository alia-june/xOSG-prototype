#ifndef HCI_FLEX_H
#define HCI_FLEX_H
/* Holoquary v0.7 candidate: typed, fixed-capacity input snapshots and
 * checked read-only evaluation. FNV integrity is accidental-corruption
 * detection, not authentication or adversarial tamper resistance. */
#include "holon_types.h"

/* A port has exactly one active payload type. No implicit numeric -> truth. */
typedef enum { HCI_FLEX_LOGIC=1, HCI_FLEX_NUMERIC=2 } HCIFlexType;
typedef struct {
    HCIFlexType type;
    HCIIdentity source;       /* caller-maintained identity; not attestation */
    HQTruth logic;            /* meaningful for HCI_FLEX_LOGIC only */
    float numeric;            /* meaningful for HCI_FLEX_NUMERIC only */
    HCIInputOrigin origin;    /* unverified data versus classified signal */
    unsigned int conversion_id; /* zero unless known classified origin */
} HCIFlexPort;

typedef struct {
    HCIIdentity target;       /* binds graph, model generation and invocation */
    unsigned int port_count;
    HCIFlexPort port[HQ_MAX_INPUTS];
    unsigned int checksum;   /* local host representation, unkeyed FNV-1a */
} HCIFlexSnapshot;

HCIStatus hci_flex_port_from_frame(const HCIFrame *source, HCIFlexPort *out);
HCIStatus hci_flex_capture(HCIFlexSnapshot *out,
                            const HCIIdentity *target,
                            const HCIFlexPort *port, unsigned int count);
HCIStatus hci_flex_validate(const HCIFlexSnapshot *snapshot,
                             const HCIIdentity *expected_target);
/* `policies[i]` required for each numeric port, ignored for logic ports.
 * A mixed input uses input_conversion_id=0 on resulting HCIFrame and its
 * per-port policy/source mapping remains in the snapshot. */
HCIStatus hci_flex_eval_logic(const HCIFlexSnapshot *snapshot,
                               const HCILogicAdapter *logic,
                               const HCIThreshold *policies,
                               unsigned int policy_count,
                               unsigned int budget_left, HCIFrame *out);
HCIStatus hci_flex_eval_neural(const HCIFlexSnapshot *snapshot,
                                HCINeuralAdapter *neural,
                                unsigned int budget_left, HCIFrame *out);

typedef struct {
    const HCIFlexSnapshot *snapshot;
    const HQProgram *program;
    const HCIThreshold *policies;
    unsigned int policy_count;
    unsigned int budget_left;
} HCIFlexLogicReplay;
/* Compatible with HCIReeval callback; validates captured input binding and
 * reevaluates the captured values. Does not prove historical input authenticity,
 * observer honesty, authority, or successful repair of a prior fault. */
HCIStatus hci_flex_replay_logic(const HCIFrame *original,
                                 unsigned int new_snapshot_id,
                                 const void *context, HCIFrame *out);
#endif
