#ifndef HQ_CELLS_H
#define HQ_CELLS_H
/* Explicit single-bit state owner; no cycles injected into HQProgram.
 * A tick computes MUX(old_value, write_data, write_enable) in a 3-valued
 * consensus semantics, then commits atomically if all checks pass. */
#include "holoquary.h"

typedef enum {
    HQ_CELL_OK=0,
    HQ_CELL_NULL,
    HQ_CELL_VALUE,
    HQ_CELL_STALE,
    HQ_CELL_EXHAUSTED
} HQCellStatus;

typedef struct {
    HQTruth value;
    unsigned int generation;   /* successful tick count, including HOLD */
} HQBitCell;

HQCellStatus hq_bit_init(HQBitCell *cell, HQTruth initial);
HQCellStatus hq_bit_read(const HQBitCell *cell, HQTruth *out,
                         unsigned int *generation);
/* Requires exact expected generation. Failed calls leave cell/out unchanged.
 * reset is `hq_bit_tick(cell, gen, HQ_TRUE, HQ_FALSE, &out)`.
 * enable UNKNOWN: if old and new are the same definite value, keep it;
 * otherwise result UNKNOWN (representing both possible switch positions).
 * This is a single-threaded API; caller must synchronize concurrent access. */
HQCellStatus hq_bit_tick(HQBitCell *cell, unsigned int expected_generation,
                         HQTruth write_enable, HQTruth write_data, HQTruth *out);
#endif
