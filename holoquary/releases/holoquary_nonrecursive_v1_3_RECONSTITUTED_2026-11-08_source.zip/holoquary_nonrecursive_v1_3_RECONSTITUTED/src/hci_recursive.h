#ifndef HCI_RECURSIVE_H
#define HCI_RECURSIVE_H
/* I-08 bounded runtime composition of pure three-valued NAND nodes.
 * The source Holoquary implementation remains authoritative for NAND.
 * Supports DAG fan-out via pointer identity and per-call memoization.
 * NOT a general recursive neural/logic runtime, thread-safe isolation,
 * authenticated source map, or external system recovery. */
#include "holon_types.h"
#define HCI_RECURSIVE_MAX_NODES 16u
#define HCI_RECURSIVE_MAX_DEPTH 8u

typedef enum { HCI_RECUR_INPUT=1, HCI_RECUR_NAND=2 } HCIRecKind;
typedef struct HCIRecNode {
    HCIIdentity identity;
    HCIRecKind kind;
    unsigned int input_port; /* meaningful for INPUT only; NAND requires zero */
    const struct HCIRecNode *left;
    const struct HCIRecNode *right;
} HCIRecNode;

typedef struct {
    unsigned int visited;
    unsigned int nand_evaluated;
    unsigned int cache_hits;
    unsigned int budget_used;
    unsigned int source_instance_ids[HCI_RECURSIVE_MAX_NODES];
    unsigned int source_holon_ids[HCI_RECURSIVE_MAX_NODES];
    HQTruth observed_values[HCI_RECURSIVE_MAX_NODES];
} HCIRecTrace;

HCIStatus hci_recursive_evaluate(const HCIRecNode *root,
                                 const HQTruth *inputs,unsigned int input_count,
                                 unsigned int max_nand_calls,
                                 HQTruth *out,HCIRecTrace *trace);
#endif
