#include "holon_types.h"

HCIStatus hci_validate_identity(const HCIIdentity *id) {
    if (!id) return HCI_ERR_NULL;
    if (!id->holon_id || !id->instance_id || !id->graph_gen || !id->snapshot_id)
        return HCI_ERR_INVALID;
    return HCI_OK;
}

static HCIFrame setup(const HCILogicAdapter *a, unsigned int left) {
    HCIFrame f={0};
    f.identity=a->identity;
    f.kind=HCI_LOGIC;
    f.execution=HCI_FAILED;
    f.result_kind=HCI_RESULT_NONE;
    f.disposition=HCI_UNCHECKED;
    f.truth=HQ_UNKNOWN;
    f.source_status=HQ_OK;
    f.input_count=a->program ? a->program->input_count : 0u;
    f.input_origin=HCI_INPUT_UNATTESTED;
    f.compute_remaining=left;
    return f;
}

HCIStatus hci_observe_logic(const HCILogicAdapter *a, const HQTruth *inputs,
                            unsigned int count, unsigned int left,
                            HCIFrame *frame) {
    HQTruth out[HQ_MAX_OUTPUTS];
    HCIFrame f;
    HQStatus s;
    if (!a || !frame) return HCI_ERR_NULL;
    if (hci_validate_identity(&a->identity)!=HCI_OK || a->identity.param_gen!=0u)
        return HCI_ERR_INVALID;
    f=setup(a,left);
    if (!a->program || !inputs) { f.source_status=HQ_ERR_NULL; *frame=f; return HCI_ERR_NULL; }
    s=hq_eval(a->program,inputs,count,out,HQ_MAX_OUTPUTS);
    f.source_status=s;
    if (s!=HQ_OK) { *frame=f; return HCI_ERR_SOURCE; }
    /* First exported port is the summary. Full outputs remain available through HQ API. */
    f.execution=HCI_COMPLETED;
    f.result_kind=HCI_RESULT_LOGIC;
    f.truth=out[0];
    f.disposition=HCI_UNCHECKED;
    *frame=f;
    return HCI_OK;
}

HCIStatus hci_observe_extended(const HCILogicAdapter *a, const HQTruth *inputs,
                               unsigned int count, const HQLessonBank *bank,
                               unsigned int scope, unsigned int rounds,
                               unsigned int left, HCIFrame *frame) {
    HQTruth out[HQ_MAX_OUTPUTS];
    HQLessonTrace trace;
    HQStatus s;
    HCIFrame f;
    if (!a || !frame) return HCI_ERR_NULL;
    if (hci_validate_identity(&a->identity)!=HCI_OK || a->identity.param_gen!=0u)
        return HCI_ERR_INVALID;
    f=setup(a,left);
    if (!a->program || !inputs || !bank) { f.source_status=HQ_ERR_NULL; *frame=f; return HCI_ERR_NULL; }
    s=hq_eval_extended(a->program,inputs,count,bank,scope,rounds,
                       out,HQ_MAX_OUTPUTS,&trace);
    f.source_status=s;
    if (s!=HQ_OK) { *frame=f; return HCI_ERR_SOURCE; }
    f.execution=HCI_COMPLETED;
    f.result_kind=HCI_RESULT_LOGIC;
    f.truth=out[0];
    f.lesson_rounds=trace.rounds;
    f.new_facts=trace.new_facts;
    f.conflict_count=trace.conflicts;
    f.disposition= trace.disposition==HQ_LESSON_STABLE ? HCI_STABLE :
                  trace.disposition==HQ_LESSON_CONFLICT ? HCI_CONFLICT : HCI_EXHAUSTED;
    *frame=f;
    return HCI_OK;
}

/* Typed numerical-classification bridge. It validates lineage handles and
   conversion IDs, not the empirical correctness of neural predictions. */
HCIStatus hci_observe_classified_logic(const HCILogicAdapter *a,
                                       const HCIClassifiedSignal *signals,
                                       unsigned int count,
                                       unsigned int conversion_id,
                                       unsigned int left,HCIFrame *frame) {
    HQTruth inputs[HQ_MAX_INPUTS];
    HCIFrame f;
    unsigned int i;
    HCIStatus status;
    if (!a || !frame) return HCI_ERR_NULL;
    if (hci_validate_identity(&a->identity)!=HCI_OK || a->identity.param_gen!=0u)
        return HCI_ERR_INVALID;
    f=setup(a,left);
    if (!signals) { f.source_status=HQ_ERR_NULL; *frame=f; return HCI_ERR_NULL; }
    if (!conversion_id || count>HQ_MAX_INPUTS || !count) {
        f.source_status=HQ_ERR_INPUT_COUNT; *frame=f; return HCI_ERR_INVALID;
    }
    for(i=0;i<count;++i) {
        if (signals[i].domain!=HCI_CLASSIFICATION ||
            signals[i].conversion_id!=conversion_id ||
            signals[i].source_holon_id==0u ||
            signals[i].source_snapshot_id!=a->identity.snapshot_id ||
            (signals[i].value!=HQ_TRUE && signals[i].value!=HQ_FALSE &&
             signals[i].value!=HQ_UNKNOWN)) {
            f.source_status=HQ_ERR_VALUE;
            *frame=f;
            return HCI_ERR_INVALID;
        }
        inputs[i]=signals[i].value;
    }
    status=hci_observe_logic(a,inputs,count,left,&f);
    f.input_origin=HCI_INPUT_CLASSIFIED;
    f.input_conversion_id=conversion_id;
    *frame=f;
    return status;
}
