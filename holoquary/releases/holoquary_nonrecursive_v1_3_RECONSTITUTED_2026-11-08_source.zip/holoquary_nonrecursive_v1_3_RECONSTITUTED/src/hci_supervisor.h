#ifndef HCI_SUPERVISOR_H
#define HCI_SUPERVISOR_H
/* I-07 isolated toy: 2-feature policy trained to imitate a deterministic
 * rule. Does NOT establish a better controller, source authority or truth. */
#include "holon_types.h"

typedef struct {
    DNNModel model; /* separate from all subordinate neural parameter banks */
    unsigned int generation;
    unsigned int trained_steps;
} HCINeuralSupervisor;
HCIStatus hci_supervisor_init(HCINeuralSupervisor *s,unsigned int seed);
HCIStatus hci_supervisor_train_imitation(HCINeuralSupervisor *s,
                                         unsigned int steps,float lr);
HCIStatus hci_supervisor_propose(const HCINeuralSupervisor *s,
                                 const HCIFrame *frame,unsigned int lessons,
                                 HCIProposal *out,float *raw_score);
/* Specialized action-specific gate. Existing hci_gate_proposal unchanged. */
HCIStatus hci_supervisor_gate(const HCIProposal *p,const HCIFrame *frame,
                              const HCIGrant *grant,unsigned int lessons);
#endif
