#ifndef HQ_RADIX5_H
#define HQ_RADIX5_H
/* v0.9: Two DISJOINT mathematical domains sharing five storage symbols.
 * PURE5: base-5 digits 0,1,2,3,4.  TERNARY_UE: -1,0,+1,U,E.
 * U and E are not numbers. E is an in-band marker, distinct from HQ5Status.
 * Caller owns all storage. No heap, I/O, or standard-library dependency.
 */
#include <stdint.h>

typedef enum {
    HQ5_DOMAIN_PURE5=1,
    HQ5_DOMAIN_TERNARY_UE=2
} HQ5Domain;

typedef enum {
    HQ5_N=0, HQ5_Z=1, HQ5_P=2,
    HQ5_U=3, HQ5_E=4
} HQ3UESymbol;

typedef enum {
    HQ5_OK=0,
    HQ5_NULL,
    HQ5_BAD_DOMAIN,
    HQ5_BAD_VALUE,
    HQ5_BAD_CARRY,
    HQ5_BAD_OPERATION,
    HQ5_STALE,
    HQ5_EXHAUSTED
} HQ5Status;

typedef struct {
    HQ5Domain domain;
    uint8_t symbol; /* ordinal 0..4; interpretation requires domain */
} HQ5Value;

typedef struct {
    HQ5Domain domain;
    uint8_t symbols[25]; /* indexed a*5+b; PURE5 only */
} HQ5PureTable2;

typedef enum { HQ5_HOLD=0, HQ5_WRITE=1, HQ5_RESET=2 } HQ5Tick;
typedef struct {
    HQ5Value value;
    uint32_t generation;
} HQ5Cell;

HQ5Status hq5_make(HQ5Domain domain, unsigned symbol, HQ5Value *out);
HQ5Status hq5_validate(HQ5Value value);
/* PURE5.  Add carry-in 0/1, multiply carry-in 0..4.
 * Outputs are modified together, only on success; no alias between outputs. */
HQ5Status hq5_add_pure(HQ5Value a, HQ5Value b, unsigned carry_in,
                       HQ5Value *out_digit, unsigned *out_carry);
HQ5Status hq5_mul_pure(HQ5Value a, HQ5Value b, unsigned carry_in,
                       HQ5Value *out_digit, unsigned *out_carry);
HQ5Status hq5_cmp_pure(HQ5Value a, HQ5Value b, int *out_sign);
HQ5Status hq5_select_pure(HQ5Value selector, const HQ5Value branches[5],
                          HQ5Value *out);
HQ5Status hq5_table2_pure(const HQ5PureTable2 *table, HQ5Value a,
                          HQ5Value b, HQ5Value *out);
/* TERNARY_UE. Ordinals 0,1,2 mean numeric -1,0,+1; 3 U; 4 E.
 * Existing E dominates even if the numeric other operand is zero.
 * UNKNOWN is NOT an ordinary numeric zero.
 * Conservative digit addition: if any operand U, both outputs U.
 * Zero multiplication is known even with U, unless an E is present. */
HQ5Status hq5_add_balanced(HQ5Value a, HQ5Value b, HQ5Value carry_in,
                           HQ5Value *out_digit, HQ5Value *out_carry);
HQ5Status hq5_mul_balanced(HQ5Value a, HQ5Value b, HQ5Value *out);
HQ5Status hq5_neg_balanced(HQ5Value a, HQ5Value *out);
HQ5Status hq5_cmp_balanced(HQ5Value a, HQ5Value b, HQ5Value *out_sign);
/* Select branch N/Z/P. Selector U: if all three equal return that
 * symbol; otherwise E if any branch E, else U. Selector E -> E.
 * That error-preserving rule is a deliberate conservative policy. */
HQ5Status hq5_select_balanced(HQ5Value selector, const HQ5Value branches[3],
                              HQ5Value *out);
/* Independent volatile state, outside legacy combinational HQProgram.
 * Explicit HOLD, WRITE or RESET; RESET to radix-5 zero or balanced zero.
 * Every successful tick increments generation. No concurrency guarantees. */
HQ5Status hq5_cell_init(HQ5Cell *cell, HQ5Value value);
HQ5Status hq5_cell_read(const HQ5Cell *cell, HQ5Value *out_value,
                        uint32_t *out_generation);
HQ5Status hq5_cell_tick(HQ5Cell *cell, uint32_t expected_generation,
                        HQ5Tick command, HQ5Value write_value,
                        HQ5Value *out_value);
/* Words are little-endian arrays of 1..32 typed symbols.
 * No heap; exact length required. All inputs validated before any output
 * change. Result may alias either input exactly; partial overlap is not
 * supported and must be excluded by caller. */
#define HQ5_MAX_WORD 32u
HQ5Status hq5_add_word_pure(const HQ5Value *a, const HQ5Value *b,
                            unsigned length, unsigned carry_in,
                            HQ5Value *out, unsigned *out_carry);
HQ5Status hq5_add_word_balanced(const HQ5Value *a, const HQ5Value *b,
                                unsigned length, HQ5Value carry_in,
                                HQ5Value *out, HQ5Value *out_carry);
#endif
