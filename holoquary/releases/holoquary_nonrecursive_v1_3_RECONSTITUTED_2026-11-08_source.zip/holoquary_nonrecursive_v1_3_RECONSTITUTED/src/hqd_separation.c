#include "hqd_separation.h"

static int domain_range(HQDDomain d,int *lo,int *hi)
{
    switch(d) {
    case HQD_BALANCED3: *lo=-1; *hi=1; return 1;
    case HQD_PURE5: *lo=0; *hi=4; return 1;
    case HQD_BALANCED7: *lo=-3; *hi=3; return 1;
    case HQD_KLEENE3: *lo=0; *hi=2; return 1;
    default: return 0;
    }
}
static uint16_t all_mask(HQDDomain d)
{
    int lo,hi;
    if(!domain_range(d,&lo,&hi)) return 0;
    return (uint16_t)((1u << (unsigned)(hi-lo+1))-1u);
}
static unsigned bit_for(HQDDomain d,int v)
{
    int lo,hi;
    if(!domain_range(d,&lo,&hi) || v<lo || v>hi) return 0u;
    return 1u << (unsigned)(v-lo);
}
static int singleton(unsigned mask)
{ return mask != 0u && !(mask & (mask-1u)); }
static int valid_logic(HQTruth v)
{ return v==HQ_FALSE || v==HQ_TRUE || v==HQ_UNKNOWN; }
static HQDProvenance untrusted_origin(HQDOrigin origin)
{
    HQDProvenance p={0u,0u,0u,origin}; return p;
}
static HQDExecution completed(void)
{
    HQDExecution e={HQD_EXEC_COMPLETE,0u,HQD_NO_MARKER}; return e;
}
static HQDRecord from_mask(HQDDomain d,unsigned mask,unsigned grade,
                            HQDOrigin origin)
{
    HQDRecord r;
    int lo=0,hi=0;
    r.domain=d;
    r.data.kind=HQD_ABSENT;
    r.data.number=0;
    r.data.logic=HQ_FALSE;
    r.knowledge.possibilities=(uint16_t)mask;
    r.knowledge.unknown_grade=(uint8_t)grade;
    r.execution=completed();
    r.provenance=untrusted_origin(origin);
    if(singleton(mask)) {
        domain_range(d,&lo,&hi);
        for(int v=lo;v<=hi;++v) if(mask & bit_for(d,v)) {
            if(d==HQD_KLEENE3) {
                r.data.kind=HQD_LOGIC;
                r.data.logic=(HQTruth)v;
            } else {
                r.data.kind=HQD_NUMBER;
                r.data.number=(int8_t)v;
            }
            break;
        }
        r.knowledge.unknown_grade=0u;
    }
    return r;
}
HQDStatus hqd_validate(const HQDRecord *r)
{
    int lo,hi;
    unsigned m;
    if(!r) return HQD_NULL;
    if(!domain_range(r->domain,&lo,&hi)) return HQD_BAD_DOMAIN;
    m=r->knowledge.possibilities;
    if((m & ~all_mask(r->domain)) || r->knowledge.unknown_grade>3u)
        return HQD_BAD_METADATA;
    if(r->provenance.origin!=HQD_ORIGIN_UNATTESTED &&
       r->provenance.origin!=HQD_ORIGIN_CALLER &&
       r->provenance.origin!=HQD_ORIGIN_DERIVED) return HQD_BAD_METADATA;
    if(r->execution.state!=HQD_EXEC_COMPLETE &&
       r->execution.state!=HQD_EXEC_FAILED &&
       r->execution.state!=HQD_EXEC_COMPLETION_UNKNOWN) return HQD_BAD_METADATA;
    if((r->execution.state==HQD_EXEC_FAILED && r->execution.error_code==0u) ||
       (r->execution.state!=HQD_EXEC_FAILED && r->execution.error_code!=0u))
        return HQD_BAD_METADATA;
    if(r->execution.marker!=HQD_NO_MARKER &&
       r->execution.marker!=HQD_LEGACY_E_MARKER) return HQD_BAD_METADATA;
    if(r->execution.state!=HQD_EXEC_COMPLETE &&
       r->execution.marker!=HQD_NO_MARKER) return HQD_BAD_METADATA;
    if(r->execution.marker==HQD_LEGACY_E_MARKER &&
       (r->data.kind!=HQD_ABSENT || m!=all_mask(r->domain) ||
        r->knowledge.unknown_grade!=0u)) return HQD_BAD_METADATA;
    if(r->data.kind!=HQD_ABSENT && r->data.kind!=HQD_NUMBER &&
       r->data.kind!=HQD_LOGIC) return HQD_BAD_VALUE;
    if(r->data.kind==HQD_ABSENT) {
        if(r->data.number!=0 || r->data.logic!=HQ_FALSE) return HQD_BAD_VALUE;
        if(singleton(m)) return HQD_BAD_METADATA;
    } else if(r->data.kind==HQD_NUMBER) {
        if(r->domain==HQD_KLEENE3 || r->data.number<lo ||
           r->data.number>hi || r->data.logic!=HQ_FALSE) return HQD_BAD_VALUE;
        if(r->execution.state!=HQD_EXEC_COMPLETE ||
           r->execution.marker!=HQD_NO_MARKER ||
           m!=bit_for(r->domain,r->data.number) ||
           r->knowledge.unknown_grade!=0u) return HQD_BAD_METADATA;
    } else {
        if(r->domain!=HQD_KLEENE3 || !valid_logic(r->data.logic) ||
           r->data.number!=0) return HQD_BAD_VALUE;
        if(r->execution.state!=HQD_EXEC_COMPLETE ||
           r->execution.marker!=HQD_NO_MARKER ||
           m!=bit_for(r->domain,(int)r->data.logic) ||
           r->knowledge.unknown_grade!=0u) return HQD_BAD_METADATA;
    }
    if(r->data.kind==HQD_ABSENT &&
       r->execution.state==HQD_EXEC_COMPLETE &&
       r->execution.marker==HQD_NO_MARKER &&
       !singleton(m) && r->knowledge.unknown_grade>3u) return HQD_BAD_METADATA;
    return HQD_OK;
}
HQDStatus hqd_exact_number(HQDDomain d,int value,HQDRecord *out)
{
    int lo,hi;
    if(!out) return HQD_NULL;
    if(!domain_range(d,&lo,&hi)) return HQD_BAD_DOMAIN;
    if(d==HQD_KLEENE3 || value<lo || value>hi) return HQD_BAD_VALUE;
    *out=from_mask(d,bit_for(d,value),0u,HQD_ORIGIN_UNATTESTED);
    return HQD_OK;
}
HQDStatus hqd_exact_logic(HQTruth v,HQDRecord *out)
{
    if(!out) return HQD_NULL;
    if(!valid_logic(v)) return HQD_BAD_VALUE;
    *out=from_mask(HQD_KLEENE3,bit_for(HQD_KLEENE3,(int)v),0u,
                   HQD_ORIGIN_UNATTESTED);
    return HQD_OK;
}
HQDStatus hqd_possibilities(HQDDomain d,unsigned mask,unsigned grade,HQDRecord *out)
{
    if(!out) return HQD_NULL;
    if(!all_mask(d)) return HQD_BAD_DOMAIN;
    if((mask & ~all_mask(d)) || grade>3u ||
       ((mask==0u || singleton(mask)) && grade!=0u)) return HQD_BAD_METADATA;
    /* A singleton is a definite mathematical value, never an 'unknown trit'. */
    *out=from_mask(d,mask,grade,HQD_ORIGIN_UNATTESTED);
    return HQD_OK;
}
static HQDStatus operand_check(const HQDRecord *r)
{
    HQDStatus s=hqd_validate(r);
    if(s!=HQD_OK) return s;
    if(r->execution.state!=HQD_EXEC_COMPLETE ||
       r->execution.marker!=HQD_NO_MARKER) return HQD_DENIED;
    return HQD_OK;
}
HQDStatus hqd_refine(const HQDRecord *a,const HQDRecord *b,HQDRecord *out)
{
    HQDStatus s;
    HQDRecord next;
    if(!a || !b || !out) return HQD_NULL;
    if((s=operand_check(a))!=HQD_OK || (s=operand_check(b))!=HQD_OK) return s;
    if(a->domain!=b->domain) return HQD_BAD_DOMAIN;
    next=from_mask(a->domain,a->knowledge.possibilities &
                   b->knowledge.possibilities,0u,HQD_ORIGIN_DERIVED);
    *out=next; return HQD_OK;
}
HQDStatus hqd_get_number(const HQDRecord *r,int *out)
{
    HQDStatus s;
    if(!r || !out) return HQD_NULL;
    if((s=operand_check(r))!=HQD_OK) return s;
    if(r->data.kind!=HQD_NUMBER) return HQD_DENIED;
    *out=r->data.number; return HQD_OK;
}
HQDStatus hqd_add_digits(const HQDRecord *a,const HQDRecord *b,HQDAddResult *out)
{
    HQDStatus s;
    HQDAddResult next;
    int lo=0,hi=0,radix;
    if(!a || !b || !out) return HQD_NULL;
    if((s=operand_check(a))!=HQD_OK || (s=operand_check(b))!=HQD_OK) return s;
    if(a->domain!=b->domain) return HQD_BAD_DOMAIN;
    if(a->domain==HQD_KLEENE3) return HQD_BAD_OPERATION;
    domain_range(a->domain,&lo,&hi);
    radix=hi-lo+1;
    next.domain=a->domain;
    next.joint=0u;
    next.execution=completed();
    next.provenance=untrusted_origin(HQD_ORIGIN_DERIVED);
    for(int av=lo;av<=hi;++av) if(a->knowledge.possibilities & bit_for(a->domain,av)) {
        for(int bv=lo;bv<=hi;++bv) if(b->knowledge.possibilities & bit_for(b->domain,bv)) {
            int sum=av+bv,carry=0,digit;
            if(a->domain==HQD_PURE5) {
                carry=sum/5;
                digit=sum%5;
            } else {
                while(sum>hi) {sum-=radix; ++carry;}
                while(sum<lo) {sum+=radix; --carry;}
                digit=sum;
            }
            next.joint |= (uint32_t)1u <<
                 ((unsigned)(carry+(a->domain==HQD_PURE5?0:1))*
                  (unsigned)radix+(unsigned)(digit-lo));
        }
    }
    *out=next; return HQD_OK;
}
HQDStatus hqd_add_project(const HQDAddResult *pairs,HQDRecord *digit,HQDRecord *carry)
{
    unsigned dm=0u,cm=0u;
    int lo,hi,radix,carry_values;
    HQDRecord d,c;
    if(!pairs || !digit || !carry) return HQD_NULL;
    if(digit==carry) return HQD_BAD_OPERATION;
    if(!domain_range(pairs->domain,&lo,&hi) || pairs->domain==HQD_KLEENE3)
        return HQD_BAD_DOMAIN;
    if(pairs->execution.state!=HQD_EXEC_COMPLETE ||
       pairs->execution.error_code || pairs->execution.marker!=HQD_NO_MARKER)
        return HQD_DENIED;
    if(pairs->provenance.origin!=HQD_ORIGIN_DERIVED) return HQD_BAD_METADATA;
    radix=hi-lo+1;
    carry_values=pairs->domain==HQD_PURE5?2:3;
    if(pairs->joint & ~((1u<<((unsigned)radix*(unsigned)carry_values))-1u))
        return HQD_BAD_VALUE;
    for(int ci=0;ci<carry_values;++ci) for(int di=0;di<radix;++di) {
        if(pairs->joint & (1u<<((unsigned)ci*(unsigned)radix+(unsigned)di))) {
            dm |= 1u << (unsigned)di;
            cm |= 1u << (unsigned)ci;
        }
    }
    d=from_mask(pairs->domain,dm,0u,HQD_ORIGIN_DERIVED);
    c=from_mask(pairs->domain==HQD_PURE5?HQD_PURE5:HQD_BALANCED3,
                cm,0u,HQD_ORIGIN_DERIVED);
    *digit=d; *carry=c; return HQD_OK;
}
HQDStatus hqd_compare(const HQDRecord *a,const HQDRecord *b,uint8_t *out_relations)
{
    HQDStatus s;
    unsigned rel=0u;
    int lo=0,hi=0;
    if(!a || !b || !out_relations) return HQD_NULL;
    if((s=operand_check(a))!=HQD_OK || (s=operand_check(b))!=HQD_OK) return s;
    if(a->domain!=b->domain) return HQD_BAD_DOMAIN;
    if(a->domain==HQD_KLEENE3) return HQD_BAD_OPERATION;
    domain_range(a->domain,&lo,&hi);
    for(int av=lo;av<=hi;++av) if(a->knowledge.possibilities & bit_for(a->domain,av))
      for(int bv=lo;bv<=hi;++bv) if(b->knowledge.possibilities & bit_for(b->domain,bv))
        rel |= av<bv?HQD_LT:av>bv?HQD_GT:HQD_EQ;
    *out_relations=(uint8_t)rel; return HQD_OK;
}
HQDStatus hqd_relation_truth(uint8_t relations,HQDRelation requested,HQDRecord *out)
{
    HQTruth t;
    if(!out) return HQD_NULL;
    if(relations==0u || (relations&~7u) ||
       (requested!=HQD_LT && requested!=HQD_EQ && requested!=HQD_GT))
        return HQD_BAD_VALUE;
    if(relations==requested) t=HQ_TRUE;
    else if(!(relations & (unsigned)requested)) t=HQ_FALSE;
    else t=HQ_UNKNOWN;
    *out=from_mask(HQD_KLEENE3,bit_for(HQD_KLEENE3,(int)t),0u,HQD_ORIGIN_DERIVED);
    return HQD_OK;
}
HQDStatus hqd_guard_proposal(const HQDRecord *r,int *out_allow)
{
    HQDStatus s;
    if(!r || !out_allow) return HQD_NULL;
    if((s=hqd_validate(r))!=HQD_OK) return s;
    if(r->domain!=HQD_KLEENE3) return HQD_BAD_DOMAIN;
    *out_allow=(r->execution.state==HQD_EXEC_COMPLETE &&
                r->execution.marker==HQD_NO_MARKER &&
                r->data.kind==HQD_LOGIC && r->data.logic==HQ_TRUE);
    return HQD_OK;
}
HQDStatus hqd_from_hq5(HQ5Value v,HQDRecord *out)
{
    HQDRecord next;
    if(!out) return HQD_NULL;
    if(hq5_validate(v)==HQ5_BAD_DOMAIN) return HQD_BAD_DOMAIN;
    if(hq5_validate(v)!=HQ5_OK) return HQD_BAD_VALUE;
    if(v.domain==HQ5_DOMAIN_PURE5) return hqd_exact_number(HQD_PURE5,(int)v.symbol,out);
    if(v.domain!=HQ5_DOMAIN_TERNARY_UE) return HQD_BAD_DOMAIN;
    if(v.symbol<=HQ5_P) return hqd_exact_number(HQD_BALANCED3,(int)v.symbol-1,out);
    next=from_mask(HQD_BALANCED3,all_mask(HQD_BALANCED3),0u,HQD_ORIGIN_UNATTESTED);
    if(v.symbol==HQ5_E) next.execution.marker=HQD_LEGACY_E_MARKER;
    *out=next; return HQD_OK;
}
HQDStatus hqd_to_hq5(const HQDRecord *r,unsigned policy,HQ5Value *out)
{
    HQDStatus s;
    HQ5Value next;
    if(!r || !out) return HQD_NULL;
    if(policy & ~(HQD_BRIDGE_ALLOW_U|HQD_BRIDGE_ALLOW_E)) return HQD_BAD_OPERATION;
    if((s=hqd_validate(r))!=HQD_OK) return s;
    if(r->domain!=HQD_BALANCED3 && r->domain!=HQD_PURE5) return HQD_BAD_DOMAIN;
    if(r->execution.state!=HQD_EXEC_COMPLETE) return HQD_DENIED;
    if(r->execution.marker==HQD_LEGACY_E_MARKER) {
        if(!(policy & HQD_BRIDGE_ALLOW_E) || r->domain!=HQD_BALANCED3) return HQD_DENIED;
        next.domain=HQ5_DOMAIN_TERNARY_UE; next.symbol=HQ5_E;
    } else if(r->data.kind==HQD_NUMBER) {
        next.domain=r->domain==HQD_PURE5?HQ5_DOMAIN_PURE5:HQ5_DOMAIN_TERNARY_UE;
        next.symbol=(uint8_t)(r->data.number+(r->domain==HQD_BALANCED3?1:0));
    } else {
        if(r->domain!=HQD_BALANCED3 || !(policy & HQD_BRIDGE_ALLOW_U) ||
           r->knowledge.possibilities==0u) return HQD_DENIED;
        next.domain=HQ5_DOMAIN_TERNARY_UE;next.symbol=HQ5_U;
    }
    *out=next; return HQD_OK;
}
HQDStatus hqd_from_hq7(HQ7Set v,HQDRecord *out)
{
    if(!out) return HQD_NULL;
    if(hq7_validate(v)!=HQ7_OK) return HQD_BAD_VALUE;
    *out=from_mask(HQD_BALANCED7,v.mask,0u,HQD_ORIGIN_UNATTESTED);
    return HQD_OK;
}
HQDStatus hqd_to_hq7(const HQDRecord *r,HQ7Set *out)
{
    HQDStatus s;
    if(!r || !out) return HQD_NULL;
    if((s=operand_check(r))!=HQD_OK) return s;
    if(r->domain!=HQD_BALANCED7) return HQD_BAD_DOMAIN;
    out->mask=(uint8_t)r->knowledge.possibilities; return HQD_OK;
}
HQDStatus hqd_from_hqx(HQXCondition v,HQDRecord *out)
{
    HQDRecord next;
    if(!out) return HQD_NULL;
    if(v==HQX_FALSE) return hqd_exact_logic(HQ_FALSE,out);
    if(v==HQX_TRUE) return hqd_exact_logic(HQ_TRUE,out);
    if(v==HQX_UNKNOWN) return hqd_exact_logic(HQ_UNKNOWN,out);
    if(v!=HQX_ERROR) return HQD_BAD_VALUE;
    next=from_mask(HQD_KLEENE3,all_mask(HQD_KLEENE3),0u,HQD_ORIGIN_UNATTESTED);
    next.execution.marker=HQD_LEGACY_E_MARKER;
    *out=next; return HQD_OK;
}
HQDStatus hqd_to_hqx(const HQDRecord *r,unsigned policy,HQXCondition *out)
{
    HQDStatus s;
    HQXCondition v;
    if(!r || !out) return HQD_NULL;
    if(policy & ~(HQD_BRIDGE_ALLOW_U|HQD_BRIDGE_ALLOW_E)) return HQD_BAD_OPERATION;
    if((s=hqd_validate(r))!=HQD_OK) return s;
    if(r->domain!=HQD_KLEENE3) return HQD_BAD_DOMAIN;
    if(r->execution.state!=HQD_EXEC_COMPLETE) return HQD_DENIED;
    if(r->execution.marker==HQD_LEGACY_E_MARKER) {
        if(!(policy & HQD_BRIDGE_ALLOW_E)) return HQD_DENIED;
        v=HQX_ERROR;
    } else if(r->data.kind==HQD_LOGIC) {
        v=r->data.logic==HQ_TRUE?HQX_TRUE:r->data.logic==HQ_FALSE?HQX_FALSE:HQX_UNKNOWN;
    } else {
        if(!(policy & HQD_BRIDGE_ALLOW_U) ||
           r->knowledge.possibilities==0u) return HQD_DENIED;
        v=HQX_UNKNOWN;
    }
    *out=v; return HQD_OK;
}
