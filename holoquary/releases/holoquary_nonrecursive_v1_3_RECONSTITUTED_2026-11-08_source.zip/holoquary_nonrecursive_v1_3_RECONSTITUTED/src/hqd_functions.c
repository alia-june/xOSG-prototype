#include "hqd_functions.h"
#include <limits.h>

static int domain_bounds(HQDDomain d,int *lo,int *hi)
{
    switch(d) {
    case HQD_BALANCED3: *lo=-1; *hi=1; return 1;
    case HQD_PURE5: *lo=0; *hi=4; return 1;
    case HQD_BALANCED7: *lo=-3; *hi=3; return 1;
    case HQD_KLEENE3: *lo=0; *hi=2; return 1;
    default: return 0;
    }
}
static unsigned value_bit(HQDDomain d,int v)
{
    int lo,hi;
    if(!domain_bounds(d,&lo,&hi) || v<lo || v>hi) return 0u;
    return 1u << (unsigned)(v-lo);
}
static int operand_ok(const HQDRecord *r)
{
    return r && hqd_validate(r)==HQD_OK &&
           r->execution.state==HQD_EXEC_COMPLETE &&
           r->execution.marker==HQD_NO_MARKER;
}
static void mark_derived(HQDRecord *r)
{
    r->provenance.source_id=0u;
    r->provenance.scope_id=0u;
    r->provenance.generation=0u;
    r->provenance.origin=HQD_ORIGIN_DERIVED;
    r->knowledge.unknown_grade=0u;
}
static HQDStatus record_from_mask(HQDDomain d,unsigned mask,HQDRecord *out)
{
    HQDStatus s;
    if(!out) return HQD_NULL;
    s=hqd_possibilities(d,mask,0u,out);
    if(s!=HQD_OK) return s;
    mark_derived(out);
    return HQD_OK;
}
static HQTruth k_not(HQTruth a)
{
    HQTruth r=HQ_UNKNOWN;
    (void)hq_nand(a,a,&r);
    return r;
}
static HQTruth k_and(HQTruth a,HQTruth b)
{
    HQTruth t=HQ_UNKNOWN,r=HQ_UNKNOWN;
    (void)hq_nand(a,b,&t);
    (void)hq_nand(t,t,&r);
    return r;
}
static HQTruth k_or(HQTruth a,HQTruth b)
{
    HQTruth na=HQ_UNKNOWN,nb=HQ_UNKNOWN,r=HQ_UNKNOWN;
    (void)hq_nand(a,a,&na);
    (void)hq_nand(b,b,&nb);
    (void)hq_nand(na,nb,&r);
    return r;
}
static HQTruth k_xor(HQTruth a,HQTruth b)
{
    HQTruth t=HQ_UNKNOWN,x=HQ_UNKNOWN,y=HQ_UNKNOWN,r=HQ_UNKNOWN;
    (void)hq_nand(a,b,&t);
    (void)hq_nand(a,t,&x);
    (void)hq_nand(b,t,&y);
    (void)hq_nand(x,y,&r);
    return r;
}
static HQTruth logic_eval(HQDNLogicOp op,HQTruth a,HQTruth b,HQTruth c)
{
    HQTruth x,y;
    switch(op) {
    case HQDN_NOT: return k_not(a);
    case HQDN_AND: return k_and(a,b);
    case HQDN_OR: return k_or(a,b);
    case HQDN_XOR: return k_xor(a,b);
    case HQDN_IMPLIES: return k_or(k_not(a),b);
    case HQDN_EQUIV: return k_not(k_xor(a,b));
    case HQDN_MAJORITY:
        x=k_or(k_and(a,b),k_and(a,c));
        y=k_and(b,c);
        return k_or(x,y);
    default: return HQ_UNKNOWN;
    }
}
static int mask_has(const HQDRecord *r,int v)
{
    return (r->knowledge.possibilities & value_bit(r->domain,v)) != 0u;
}
static HQDStatus require_logic(const HQDRecord *r)
{
    if(!operand_ok(r)) return r ? (hqd_validate(r)==HQD_OK ? HQD_DENIED : hqd_validate(r)) : HQD_NULL;
    return r->domain==HQD_KLEENE3 ? HQD_OK : HQD_BAD_DOMAIN;
}
static HQDStatus require_numeric(const HQDRecord *r)
{
    HQDStatus s;
    if(!r) return HQD_NULL;
    s=hqd_validate(r); if(s!=HQD_OK) return s;
    if(r->execution.state!=HQD_EXEC_COMPLETE || r->execution.marker!=HQD_NO_MARKER) return HQD_DENIED;
    return r->domain==HQD_KLEENE3 ? HQD_BAD_DOMAIN : HQD_OK;
}
HQDStatus hqdn_logic(HQDNLogicOp op,const HQDRecord *a,const HQDRecord *b,
                     const HQDRecord *c,HQDRecord *out)
{
    HQDStatus s;
    unsigned mask=0u;
    int av,bv,cv;
    if(!out) return HQD_NULL;
    if(op<HQDN_NOT || op>HQDN_MAJORITY) return HQD_BAD_OPERATION;
    s=require_logic(a); if(s!=HQD_OK) return s;
    if(op!=HQDN_NOT) { s=require_logic(b); if(s!=HQD_OK) return s; }
    if(op==HQDN_MAJORITY) { s=require_logic(c); if(s!=HQD_OK) return s; }
    for(av=HQ_FALSE;av<=HQ_UNKNOWN;av++) if(mask_has(a,av)) {
        if(op==HQDN_NOT) {
            mask |= value_bit(HQD_KLEENE3,(int)logic_eval(op,(HQTruth)av,HQ_FALSE,HQ_FALSE));
            continue;
        }
        for(bv=HQ_FALSE;bv<=HQ_UNKNOWN;bv++) if(mask_has(b,bv)) {
            if(op!=HQDN_MAJORITY) {
                mask |= value_bit(HQD_KLEENE3,(int)logic_eval(op,(HQTruth)av,(HQTruth)bv,HQ_FALSE));
                continue;
            }
            for(cv=HQ_FALSE;cv<=HQ_UNKNOWN;cv++) if(mask_has(c,cv))
                mask |= value_bit(HQD_KLEENE3,(int)logic_eval(op,(HQTruth)av,(HQTruth)bv,(HQTruth)cv));
        }
    }
    return record_from_mask(HQD_KLEENE3,mask,out);
}
HQDStatus hqdn_guard(const HQDRecord *a,const HQDRecord *b,const HQDRecord *c,
                     HQDRecord *out)
{
    HQDRecord ab;
    HQDStatus s=hqdn_logic(HQDN_AND,a,b,0,&ab);
    if(s!=HQD_OK) return s;
    return hqdn_logic(HQDN_AND,&ab,c,0,out);
}
HQDStatus hqdn_compare_set(HQDRelation relation,const HQDRecord *a,
                           const HQDRecord *b,HQDRecord *out)
{
    HQDStatus s;
    int lo,hi,av,bv;
    unsigned mask=0u;
    if(!out) return HQD_NULL;
    if(relation!=HQD_LT && relation!=HQD_EQ && relation!=HQD_GT) return HQD_BAD_OPERATION;
    s=require_numeric(a); if(s!=HQD_OK) return s;
    s=require_numeric(b); if(s!=HQD_OK) return s;
    if(a->domain!=b->domain) return HQD_BAD_DOMAIN;
    if(!domain_bounds(a->domain,&lo,&hi)) return HQD_BAD_DOMAIN;
    for(av=lo;av<=hi;av++) if(mask_has(a,av))
        for(bv=lo;bv<=hi;bv++) if(mask_has(b,bv)) {
            int yes = relation==HQD_LT ? av<bv : relation==HQD_EQ ? av==bv : av>bv;
            mask |= value_bit(HQD_KLEENE3, yes ? HQ_TRUE : HQ_FALSE);
        }
    return record_from_mask(HQD_KLEENE3,mask,out);
}
HQDStatus hqdn_between(const HQDRecord *value,const HQDRecord *lower,
                       const HQDRecord *upper,HQDRecord *out)
{
    HQDStatus s;
    int lo,hi,v,l,u;
    unsigned mask=0u;
    if(!out) return HQD_NULL;
    s=require_numeric(value); if(s!=HQD_OK) return s;
    s=require_numeric(lower); if(s!=HQD_OK) return s;
    s=require_numeric(upper); if(s!=HQD_OK) return s;
    if(value->domain!=lower->domain || value->domain!=upper->domain) return HQD_BAD_DOMAIN;
    if(!domain_bounds(value->domain,&lo,&hi)) return HQD_BAD_DOMAIN;
    for(v=lo;v<=hi;v++) if(mask_has(value,v))
        for(l=lo;l<=hi;l++) if(mask_has(lower,l))
            for(u=lo;u<=hi;u++) if(mask_has(upper,u)) {
                int yes=(l<=v && v<=u);
                mask |= value_bit(HQD_KLEENE3,yes?HQ_TRUE:HQ_FALSE);
            }
    return record_from_mask(HQD_KLEENE3,mask,out);
}
static HQTruth mux_u(HQTruth a,HQTruth b)
{
    return a==b ? a : HQ_UNKNOWN;
}
HQDStatus hqdn_select(const HQDRecord *selector,const HQDRecord *when_false,
                      const HQDRecord *when_true,HQDRecord *out)
{
    HQDStatus s;
    int lo,hi,sv,fv,tv;
    unsigned mask=0u;
    if(!out) return HQD_NULL;
    s=require_logic(selector); if(s!=HQD_OK) return s;
    if(!operand_ok(when_false) || !operand_ok(when_true)) {
        if(!when_false || !when_true) return HQD_NULL;
        s=hqd_validate(when_false); if(s!=HQD_OK) return s;
        s=hqd_validate(when_true); if(s!=HQD_OK) return s;
        return HQD_DENIED;
    }
    if(when_false->domain!=when_true->domain) return HQD_BAD_DOMAIN;
    if(!domain_bounds(when_false->domain,&lo,&hi)) return HQD_BAD_DOMAIN;
    for(sv=HQ_FALSE;sv<=HQ_UNKNOWN;sv++) if(mask_has(selector,sv)) {
        if(sv==HQ_FALSE) mask |= when_false->knowledge.possibilities;
        else if(sv==HQ_TRUE) mask |= when_true->knowledge.possibilities;
        else if(when_false->domain!=HQD_KLEENE3)
            mask |= when_false->knowledge.possibilities | when_true->knowledge.possibilities;
        else {
            for(fv=lo;fv<=hi;fv++) if(mask_has(when_false,fv))
                for(tv=lo;tv<=hi;tv++) if(mask_has(when_true,tv))
                    mask |= value_bit(HQD_KLEENE3,(int)mux_u((HQTruth)fv,(HQTruth)tv));
        }
    }
    return record_from_mask(when_false->domain,mask,out);
}
HQDStatus hqdn_cell_init(HQDNCell *cell,uint32_t instance_id,const HQDRecord *initial)
{
    HQDStatus s;
    HQDNCell next;
    if(!cell || !initial) return HQD_NULL;
    if(instance_id==0u) return HQD_BAD_METADATA;
    s=hqd_validate(initial); if(s!=HQD_OK) return s;
    if(initial->execution.state!=HQD_EXEC_COMPLETE || initial->execution.marker!=HQD_NO_MARKER) return HQD_DENIED;
    next.instance_id=instance_id;
    next.generation=1u;
    next.state=*initial;
    *cell=next;
    return HQD_OK;
}
HQDStatus hqdn_cell_read(const HQDNCell *cell,HQDRecord *out_state,uint32_t *out_generation)
{
    HQDStatus s;
    if(!cell || !out_state || !out_generation) return HQD_NULL;
    if(cell->instance_id==0u || cell->generation==0u) return HQD_BAD_METADATA;
    s=hqd_validate(&cell->state); if(s!=HQD_OK) return s;
    *out_state=cell->state;
    *out_generation=cell->generation;
    return HQD_OK;
}
HQDStatus hqdn_tick_transaction(const HQDNTick *ticks,unsigned count,
                                HQDNTickReceipt *receipts)
{
    HQDNCell staged[HQDN_MAX_TICKS];
    HQDNTickReceipt local[HQDN_MAX_TICKS];
    unsigned i,j;
    HQDStatus s;
    if(!ticks || !receipts) return HQD_NULL;
    if(count==0u || count>HQDN_MAX_TICKS) return HQD_BAD_OPERATION;
    for(i=0u;i<count;i++) {
        if(!ticks[i].cell) return HQD_NULL;
        for(j=0u;j<i;j++)
            if(ticks[i].cell==ticks[j].cell ||
               ticks[i].cell->instance_id==ticks[j].cell->instance_id)
                return HQD_BAD_METADATA;
        if(ticks[i].cell->instance_id==0u || ticks[i].cell->generation==0u)
            return HQD_BAD_METADATA;
        if(ticks[i].cell->generation!=ticks[i].expected_generation)
            return HQD_DENIED;
        if(ticks[i].cell->generation==UINT32_MAX) return HQD_BAD_METADATA;
        s=hqd_validate(&ticks[i].cell->state); if(s!=HQD_OK) return s;
        s=require_logic(&ticks[i].selector); if(s!=HQD_OK) return s;
        if(!operand_ok(&ticks[i].write)) {
            s=hqd_validate(&ticks[i].write); if(s!=HQD_OK) return s;
            return HQD_DENIED;
        }
        if(ticks[i].write.domain!=ticks[i].cell->state.domain) return HQD_BAD_DOMAIN;
        staged[i]=*ticks[i].cell;
        s=hqdn_select(&ticks[i].selector,&ticks[i].cell->state,&ticks[i].write,&staged[i].state);
        if(s!=HQD_OK) return s;
        /* Preserve exact HOLD/WRITE metadata; ambiguous selection is derived. */
        if(ticks[i].selector.data.kind==HQD_LOGIC &&
           ticks[i].selector.data.logic==HQ_FALSE)
            staged[i].state=ticks[i].cell->state;
        else if(ticks[i].selector.data.kind==HQD_LOGIC &&
                ticks[i].selector.data.logic==HQ_TRUE)
            staged[i].state=ticks[i].write;
        staged[i].generation=ticks[i].cell->generation+1u;
        local[i].instance_id=ticks[i].cell->instance_id;
        local[i].before_generation=ticks[i].cell->generation;
        local[i].after_generation=staged[i].generation;
        local[i].before_mask=ticks[i].cell->state.knowledge.possibilities;
        local[i].after_mask=staged[i].state.knowledge.possibilities;
    }
    for(i=0u;i<count;i++) *ticks[i].cell=staged[i];
    for(i=0u;i<count;i++) receipts[i]=local[i];
    return HQD_OK;
}
