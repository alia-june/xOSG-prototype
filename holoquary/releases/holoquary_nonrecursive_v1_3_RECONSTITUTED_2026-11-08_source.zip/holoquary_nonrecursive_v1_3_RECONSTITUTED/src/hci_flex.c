#include "hci_flex.h"
#include <float.h>

static int finite_f32(float x) { return x==x && x<=FLT_MAX && x>=-FLT_MAX; }
static int valid_truth(HQTruth t) {
    return t==HQ_FALSE || t==HQ_TRUE || t==HQ_UNKNOWN;
}
static int id_equal(const HCIIdentity *a,const HCIIdentity *b) {
    return a->holon_id==b->holon_id && a->instance_id==b->instance_id &&
        a->graph_gen==b->graph_gen && a->param_gen==b->param_gen &&
        a->snapshot_id==b->snapshot_id;
}
static int valid_port(const HCIFlexPort *p,unsigned int snap) {
    if(hci_validate_identity(&p->source)!=HCI_OK ||
       p->source.snapshot_id!=snap) return 0;
    if(p->origin!=HCI_INPUT_UNATTESTED &&
       p->origin!=HCI_INPUT_CLASSIFIED) return 0;
    if(p->origin==HCI_INPUT_CLASSIFIED && !p->conversion_id) return 0;
    if(p->origin==HCI_INPUT_UNATTESTED && p->conversion_id) return 0;
    if(p->type==HCI_FLEX_LOGIC) return valid_truth(p->logic);
    if(p->type==HCI_FLEX_NUMERIC) return finite_f32(p->numeric);
    return 0;
}
/* Explicit scalar-by-scalar checksum deliberately excludes C struct padding.
 * Numeric payload is checked using object-representation bytes, with byte order
 * bound to the local ABI; there is no portable serialized wire format here. */
static unsigned int mix_byte(unsigned int h,unsigned int b) {
    return (h^(b&255u))*16777619u;
}
static unsigned int mix_u32(unsigned int h,unsigned int v) {
    unsigned int k;
    for(k=0u;k<4u;++k) {
        h=mix_byte(h,v&255u);
        v>>=8u;
    }
    return h;
}
static unsigned int mix_id(unsigned int h,const HCIIdentity *id) {
    h=mix_u32(h,id->holon_id);h=mix_u32(h,id->instance_id);
    h=mix_u32(h,id->graph_gen);h=mix_u32(h,id->param_gen);
    return mix_u32(h,id->snapshot_id);
}
static unsigned int checksum(const HCIFlexSnapshot *s) {
    unsigned int i,k,h=2166136261u;
    h=mix_id(h,&s->target);
    h=mix_u32(h,s->port_count);
    for(i=0u;i<s->port_count;++i) {
        const HCIFlexPort *p=&s->port[i];
        h=mix_u32(h,(unsigned int)p->type);
        h=mix_id(h,&p->source);
        h=mix_u32(h,(unsigned int)p->origin);
        h=mix_u32(h,p->conversion_id);
        if(p->type==HCI_FLEX_LOGIC) {
            h=mix_u32(h,(unsigned int)p->logic);
        } else {
            const unsigned char *bytes=(const unsigned char *)&p->numeric;
            for(k=0u;k<(unsigned int)sizeof(float);++k)
                h=mix_byte(h,bytes[k]);
        }
    }
    return h;
}
HCIStatus hci_flex_port_from_frame(const HCIFrame *f,HCIFlexPort *out) {
    HCIFlexPort p={0};
    if(!f || !out) return HCI_ERR_NULL;
    if(hci_validate_identity(&f->identity)!=HCI_OK ||
       f->execution!=HCI_COMPLETED) return HCI_ERR_INVALID;
    p.source=f->identity;
    if(f->kind==HCI_LOGIC && f->result_kind==HCI_RESULT_LOGIC &&
       f->source_status==HQ_OK && valid_truth(f->truth) &&
       f->disposition!=HCI_CONFLICT && f->disposition!=HCI_EXHAUSTED) {
        p.type=HCI_FLEX_LOGIC;
        p.logic=f->truth;
        p.origin=f->input_origin;
        p.conversion_id=f->input_conversion_id;
        if(p.origin==HCI_INPUT_CLASSIFIED && !p.conversion_id)
            return HCI_ERR_INVALID;
    } else if(f->kind==HCI_NEURAL && f->result_kind==HCI_RESULT_NUMERIC &&
              finite_f32(f->number)) {
        p.type=HCI_FLEX_NUMERIC;
        p.numeric=f->number;
        p.origin=HCI_INPUT_UNATTESTED;
    } else return HCI_ERR_INVALID;
    *out=p;
    return HCI_OK;
}
HCIStatus hci_flex_capture(HCIFlexSnapshot *out,
                            const HCIIdentity *target,
                            const HCIFlexPort *port,unsigned int count) {
    HCIFlexSnapshot tmp={0};
    unsigned int i;
    if(!out || !target || !port) return HCI_ERR_NULL;
    if(hci_validate_identity(target)!=HCI_OK || !count ||
       count>HQ_MAX_INPUTS) return HCI_ERR_INVALID;
    tmp.target=*target;
    tmp.port_count=count;
    for(i=0u;i<count;++i) {
        if(!valid_port(&port[i],target->snapshot_id)) return HCI_ERR_INVALID;
        tmp.port[i]=port[i];
    }
    tmp.checksum=checksum(&tmp);
    *out=tmp; /* single commit after all validation */
    return HCI_OK;
}
HCIStatus hci_flex_validate(const HCIFlexSnapshot *s,
                             const HCIIdentity *expected) {
    unsigned int i;
    if(!s || !expected) return HCI_ERR_NULL;
    if(hci_validate_identity(expected)!=HCI_OK ||
       hci_validate_identity(&s->target)!=HCI_OK ||
       !id_equal(&s->target,expected)) return HCI_ERR_STALE;
    if(!s->port_count || s->port_count>HQ_MAX_INPUTS) return HCI_ERR_INVALID;
    for(i=0u;i<s->port_count;++i)
        if(!valid_port(&s->port[i],expected->snapshot_id)) return HCI_ERR_INVALID;
    if(s->checksum!=checksum(s)) return HCI_ERR_STALE;
    return HCI_OK;
}
HCIStatus hci_flex_eval_logic(const HCIFlexSnapshot *s,
                               const HCILogicAdapter *a,
                               const HCIThreshold *policies,
                               unsigned int policy_count,
                               unsigned int budget_left,HCIFrame *out) {
    HQTruth inputs[HQ_MAX_INPUTS];
    HCIFrame frame;
    unsigned int i,has_classified=0u,all_classified=1u,common_id=0u;
    HCIStatus status;
    if(!s || !a || !out) return HCI_ERR_NULL;
    status=hci_flex_validate(s,&a->identity);
    if(status!=HCI_OK) return status;
    if(!a->program || s->port_count!=a->program->input_count ||
       a->identity.param_gen!=0u) return HCI_ERR_INVALID;
    for(i=0u;i<s->port_count;++i) {
        const HCIFlexPort *p=&s->port[i];
        unsigned int policy_id=0u;
        if(p->type==HCI_FLEX_LOGIC) {
            inputs[i]=p->logic;
            if(p->origin==HCI_INPUT_CLASSIFIED) policy_id=p->conversion_id;
        } else {
            const HCIThreshold *t;
            if(!policies || policy_count!=s->port_count) return HCI_ERR_INVALID;
            t=&policies[i];
            if(!finite_f32(t->false_max) || !finite_f32(t->true_min) ||
               t->false_max>=t->true_min || !t->conversion_id)
                return HCI_ERR_INVALID;
            inputs[i]=p->numeric<=t->false_max?HQ_FALSE:
                      p->numeric>=t->true_min?HQ_TRUE:HQ_UNKNOWN;
            policy_id=t->conversion_id;
        }
        if(policy_id) {
            if(!has_classified) common_id=policy_id;
            else if(common_id!=policy_id) common_id=0u;
            has_classified=1u;
        } else all_classified=0u;
    }
    status=hci_observe_logic(a,inputs,s->port_count,budget_left,&frame);
    if(status!=HCI_OK) return status; /* don't overwrite caller output */
    if(has_classified) {
        frame.input_origin=HCI_INPUT_CLASSIFIED;
        /* 0 means mixed policy IDs OR mixed classified/unclassified ports. */
        frame.input_conversion_id=all_classified?common_id:0u;
    }
    *out=frame;
    return HCI_OK;
}
HCIStatus hci_flex_eval_neural(const HCIFlexSnapshot *s,
                                HCINeuralAdapter *a,
                                unsigned int budget_left,HCIFrame *out) {
    float x[DNN_INPUTS];
    HCIFrame frame;
    HCIStatus status;
    unsigned int i;
    if(!s || !a || !out) return HCI_ERR_NULL;
    status=hci_flex_validate(s,&a->identity);
    if(status!=HCI_OK) return status;
    if(s->port_count!=DNN_INPUTS || !a->identity.param_gen) return HCI_ERR_INVALID;
    for(i=0u;i<DNN_INPUTS;++i) {
        if(s->port[i].type!=HCI_FLEX_NUMERIC) return HCI_ERR_INVALID;
        x[i]=s->port[i].numeric;
    }
    status=hci_observe_neural(a,x,budget_left,&frame);
    if(status!=HCI_OK) return status;
    *out=frame;
    return HCI_OK;
}
HCIStatus hci_flex_replay_logic(const HCIFrame *original,
                                 unsigned int new_snapshot_id,
                                 const void *context,HCIFrame *out) {
    const HCIFlexLogicReplay *ctx=(const HCIFlexLogicReplay *)context;
    HCILogicAdapter adapter;
    HCIFrame reevaluated;
    HCIStatus status;
    if(!original || !ctx || !out) return HCI_ERR_NULL;
    if(!ctx->snapshot || !ctx->program || !new_snapshot_id ||
       new_snapshot_id==original->identity.snapshot_id ||
       original->kind!=HCI_LOGIC ||
       original->input_count!=ctx->snapshot->port_count)
        return HCI_ERR_INVALID;
    status=hci_flex_validate(ctx->snapshot,&original->identity);
    if(status!=HCI_OK) return status;
    adapter.program=ctx->program;
    adapter.identity=original->identity;
    status=hci_flex_eval_logic(ctx->snapshot,&adapter,ctx->policies,
                               ctx->policy_count,ctx->budget_left,&reevaluated);
    if(status!=HCI_OK) return status;
    reevaluated.identity.snapshot_id=new_snapshot_id;
    *out=reevaluated;
    return HCI_OK;
}
