# BLOCK7 v1.1 — Executed test receipt

**Date:** 2026-10-02. **Environment:** hosted Linux x86-64; GCC and Clang C99 (`-O2 -Wall -Wextra -Wpedantic -Werror`). **Scope:** additive BLOCK7 C99 implementation, unchanged legacy kernels, and bounded reference tests. Not firmware or independent attestation.

## New module — observed

- `BLOCK7_TESTS=PASS assertions=415972` under GCC and Clang.
- `BLOCK7_TESTS=PASS assertions=415972` with GCC executed UBSan/array-bounds instrumentation.
- Valid and invalid `(block,inner)` mappings tested, including rejection without output mutation of invalid `(0,-1)` and `(0,+1)`.
- All 128 seven-bit knowledge masks tested for classification, negation, block projection, pairwise union/intersection and pairwise comparison (16,384 mask pairs).
- All 49 known digit pairs and their 147 single-digit additions with carry-in verified against independently written signed integer reference arithmetic; multiplication verified against integer identity.
- All 128×128 set pairs verified against independent joint digit/carry oracle for addition at three carry-in values and multiplication; marginal digit and carry sets independently checked.
- Block selection exhaustively tested for all 128 selector masks, including empty, partial and fully unknown cases.
- Generation-stale, overflow, invalid input, HOLD/WRITE/RESET and output-immutability memory cases tested.
- Exact word addition across lengths 1..32 and 130 deterministic random trials per length, with independent signed-digit reference and exact output/input alias check; invalid input does not partially commit results.
- Demo checks: block+1 set `0x70`, refinement to +2 set `0x20`, +3 plus +1 yields digit -3 carry +1, contradictory positive/negative intersection set `0x00`, zero times unknown digit set `0x08` and carry set `0x02`.

## Inherited suite — observed

`make CC=gcc test` and `make CC=clang test` pass all inherited integration targets. The recorded per-suite results are:

| Suite | Result |
|---|---:|
| Integration | 72,091 |
| Feedback | 16,127 |
| Recovery | 6,070 |
| Toy neural supervisor | 467 |
| Pure logic recursion | 4,143 |
| Typed base flexibility | 84,048 |
| Small composites | 7,394 |
| Radix-5/ternary-UE | 220,147 |
| Higher logic v1.0 | 139,724 |
| Freestanding memory shim | 33,282 |
| BLOCK7 v1.1 | 415,972 |

Original logic and LESSONS suites reproduce 20,191 and 31,175 checks respectively in `make baseline`. Baseline neural gradient/representation checks also pass. `make CC=gcc sanitized` passes the executed integration cases and BLOCK7 test suite. Both GCC and Clang `make freestanding` build a combined relocatable host object with **zero unresolved symbols** under `nm -u`; this is not firmware execution.

## Validation boundary

The tests are finite assertions plus exhaustive small bounded mathematical cases. They do not establish correctness for adversarial memory pointers, unspecified source authenticity, correlated symbolic unknowns, all mathematical interpretations of the user's 3–1–3 shape, persistent data, runtime recursion, concurrent updates, board execution, or external attestation.

The record includes source archive manifest and compiler logs in `logs/`. Source comparisons in the packaging receipt identify unchanged files and intentional documentation/build additions.
