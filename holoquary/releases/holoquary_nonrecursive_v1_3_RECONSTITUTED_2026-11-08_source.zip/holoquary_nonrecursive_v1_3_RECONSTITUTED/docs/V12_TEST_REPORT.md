# Holoquary v1.2 — Executed separation test report

**Date:** 2026-10-02. **Environment:** hosted Linux x86-64, GCC/Clang C99 builds with strict `-Wall -Wextra -Wpedantic -Werror`, and GCC `-fsanitize=undefined,bounds`. **Status:** assistant-executed local tests, not independent attestation, formal verification, proof of hardware safety, source authenticity, or race freedom.

## New stage: executed

- `make CC=gcc separation_test`: **SEPARATION_TESTS=PASS ASSERTIONS=279320**.
- `make CC=clang separation_test`: **SEPARATION_TESTS=PASS ASSERTIONS=279320**.
- Targeted GCC sanitized compilation of `hq_radix5.c`, `hq_block7.c`, `hq_higher.c`, `hqd_separation.c`, and `test_separation.c`: **SEPARATION_TESTS=PASS ASSERTIONS=279320**.
- `make CC=gcc separation_demo`: verified before final test-only additions; demonstrates exact numerical zero versus ABSENT numerical data, lifted addition and separate E marker.

New test families:

- Every possible numeric possibility mask for BALANCED3 (8), PURE5 (32), BALANCED7 (128), crossed with every second operand mask within the same domain. Results checked against independently written digit/carry and comparison enumerators.
- `hqd_add_project`: compare projected digit/carry masks to observed joint pairs; joint pairs remain authoritative for correlated outputs.
- Exact numeric getters for every supported value; uncertainty grades cannot change arithmetic joint result at constant possibilities; source IDs likewise cannot influence the joint result.
- Logical Kleene UNKNOWN as an **exact logical** symbol, separate from absent numerical operand.
- Constraint intersection, derived provenance, empty-set contradiction, failed/uncertain execution denial, strict advisory-guard behavior.
- Legacy conversion across all five TERNARY_UE symbols, all five PURE5 symbols, all four HQX predicate symbols, all 128 BLOCK7 sets, plus invalid conversion and stale/error fixtures.
- Failure atomicity for invalid source records and rejected lossy conversion; invalid grade/value combinations rejected.

## Inherited v1.1 regressions reproduced

Complete `make CC=gcc test` and `make CC=clang test` **both passed after all final test-fixture additions**. Original source kernels and existing test files were not modified.

| Suite | Result |
|---|---:|
| Integration | 72,091 PASS |
| Feedback | 16,127 PASS |
| Recovery | 6,070 PASS |
| Neural supervisor toy imitation | 467 PASS |
| Pure logic recursion | 4,143 PASS |
| Flexibility | 84,048 PASS |
| Composites | 7,394 PASS |
| Radix5 | 220,147 PASS |
| Higher logic | 139,724 PASS |
| BLOCK7 | 415,972 PASS |
| Freestanding memory shim | 33,282 PASS |

- Both `make CC=gcc freestanding` and `make CC=clang freestanding` ended in `COMBINED_FREESTANDING_OBJECT_NO_EXTERNAL_SYMBOLS`. These are *host* objects, not firmware or physical hardware execution.
- `make CC=gcc baseline` ran the original Holoquary tests: `OVERALL=PASS checks=20191`; LESSONS `assertions=31175`; neural gradient checks `ALL_GRAD_CHECKS_PASS max_abs_difference=2.0056963e-05`; original NN freestanding host-object test also passed.
- A full `make sanitized` invocation was attempted but **interrupted by an external command timeout** after integration, feedback and recovery suites had passed. **Do not describe the full sanitized target as passed.** The new separation module's targeted sanitizer suite passed independently. Other existing modules had previous versioned sanitizer evidence, not a completed v1.2 full sanitizer report.
- A pre-package comparison found 138 inherited files byte-for-byte unchanged and only Makefile, README and TODO amended; source kernels remained unchanged. The source-only archive excludes build outputs and regenerates the package manifest.

## Source-only archive validation

Final ZIP integrity check passed. The archive contains **150 entries**: 149 manifest-listed source/documentation files plus `MANIFEST_SHA256.txt`. SHA-256 for every listed file matched on clean extraction; from that extraction `make CC=gcc separation_test separation_demo` reproduced **279320 assertions PASS**, and `make CC=clang freestanding` produced the combined host object with no unresolved external symbols. No compiler output binaries are intentionally included in the source archive.

## Limits and next checks

Current scope is single-writer trusted-address-space software, simple mathematical domains, no authenticated source IDs, no correlated hidden variables or independent evidence verification. New v1.2 code tests do not establish correctness of arbitrary updates to historical APIs, complete caller migration, external I/O authorization, process isolation, durable journaling, mixed recursion or physical deployment.

**See also:** `docs/V12_PLAN.md`, `docs/V12_SEPARATION_CONTRACT.md`, `docs/V12_MIGRATION.md`, `docs/V12_AI_ERROR_LOG.md`.
