# Observed assistant implementation/test issues — v0.7

Only actual assistant-generated code/test/packaging issues are recorded. No hypothetical unimplemented feature is classified as an observed error.

1. **F07-E01: provenance loss (caught before release).** The initial mixed-port implementation marked outputs CLASSIFIED only when a *numeric* port was converted. This silently lost the classification origin when an already-classified logical port fed another logical composite. Correction: propagate classified lineage from both numeric and already-classified logical ports, use aggregate conversion_id=0 on mixed ancestry and reject implicit port promotion without a full provenance map. Added tests.
2. **F07-E02: incorrect negative test fixture.** The first adjusted regression attempted to reject an invalid numerical threshold after changing the snapshot to contain only logical ports. This should not fail: no numeric conversion was required. Correction: restore the numeric snapshot before the negative threshold test. Recompiled and reran.
3. **F07-E03: stale expected provenance marker.** The original test expected one conversion ID when one input was direct logic. The corrected mixed-lineage contract intentionally marks the aggregate ID zero. Updated the test to match explicit lineage semantics, without treating a mixed-origin summary as fully sourced.

These corrections do not establish that no further errors exist. Historical baseline error logs are retained separately in the source archive.
