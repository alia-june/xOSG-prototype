# I-06 — ERROR/RECOVERY contract (v0.6 candidate)

**Implemented:** fixed-capacity in-memory accounting and bounded side-effect-free reevaluation. **Not implemented:** trusted original-input replay, actual hardware remediation, cross-process capability controls, durable recovery journal, independent attestation.

## Separation of domains

`HQ_UNKNOWN` with `HQ_OK`: completed logical evaluation; never automatically enters error recovery.

`HCI_FAILED` with non-OK `HCIStatus`: known execution failure, eligible for an error record. Source `HQStatus` is retained in the observed frame.

`HCI_COMPLETION_UNKNOWN`: completion cannot be established by the outer controller. It may be recorded with `native_error=HCI_OK`, but not automatically retried.

`HCI_CONFLICT`, `HCI_EXHAUSTED`: source v0.2 logical dispositions; not native execution failures.

`HCI_EFFECT_PURE`, `HCI_EFFECT_EXTERNAL`, `HCI_EFFECT_UNKNOWN`: caller-declared effect classes, NOT authenticated by the current C code.

## Record and controlled attempt

1. A single-writer caller creates a store with exact nonzero scope and 1–3 attempts per failure.
2. `hci_recovery_record` takes a failed/unknown-completion frame, original typed return status, effect class, and unique event ID. It commits an original `HCI_REC_FAILURE` event.
3. A separate request supplies matching scope, exact five-field origin identity, policy ID, unique attempt-event ID, new snapshot ID, max attempt budget and explicit `permit_pure_reeval`.
4. The library checks one failure record, disallows completed/over-budget attempts, rejects stale lineage and refuses reevaluation when effect is external/unknown or completion is unknown.
5. For a permitted pure attempt, a **caller-implemented** callback evaluates a new snapshot. Successful completion must preserve holon/instance/graph/parameter generation, type and input count. A completed NAND result requires the source `HQ_OK` truth contract; neural result must be finite.
6. A failed, invalid or completed attempt appends a separate outcome event. Original error remains in its original ledger slot. The caller sees both the status and the returned receipt.

Denials due to blocked effects, missing callback, exhausted attempts or prior completion append `HCI_REC_BLOCKED` and return `HCI_ERR_DENIED`. Invalid/replayed/stale requests do not append a new event. Capacity exhaustion fails before a callback is invoked.

## Critical unsatisfied conditions

- The code **cannot prove** that the callback replayed the same input bytes. The `HCIFrame` holds identity and counts, not a verifiable input snapshot. Even graph/parameter generation matches are caller-managed numerical values, not content verification.
- A callback can have arbitrary side effects in a trusted process. The library cannot enforce purity, independent authority, or nonmutation of source buffers without a stronger isolation/snapshot contract.
- A completed rerun establishes only that **that rerun completed according to its reported result**. It does not establish the original error cause was removed, earlier external effects were reversed, or the original result was truth.
- Attempts may return a second failure, remain bounded, and never suppress the original event. A full in-memory ledger requires a new storage/disposition policy; resetting it is not a durable recovery transaction.

## Next hardening prerequisites

Immutable input snapshots with externally verifiable digests; trusted callback/evaluator isolation; attested effect classification and policy authority; persistent transaction/evidence journal; precise recovery taxonomy; independent cross-generation validation; target-specific resource limits; and fault-injection tests. No automatic retry of effectful/unknown operations until these policies are established.
