# Holoquary v0.9 — Executed tests and proof ceiling

**Date:** 2026-10-02. **Environment:** hosted Linux x86-64, C99 GCC and Clang; GCC UBSan/array-bounds instrumentation. Not independent attestation, fuzzing proof, hardware execution, or malicious-pointer-safety verification.

## New dual-domain module

**`RADIX5_TESTS=PASS ASSERTIONS=220147`** reported with GCC and Clang `-std=c99 -O2 -Wall -Wextra -Wpedantic -Werror` and with executed GCC `-fsanitize=undefined,bounds -fno-sanitize-recover=all`.

Coverage includes:

- All 25 ordered pairs of PURE5 digit addition at both allowed input carry values, plus all 25 pairs of multiplication at all five allowed input carries; independently compared against ordinary integer division/remainder by 5.
- Exhaustive 5^5 branch configurations × 5 selectors for PURE5 five-way selection; every LUT entry checked before lookup.
- All 5^3 ordered TERNARY_UE addition triples (including U/E) against an independent reference function, and all 27 fully known balanced additions checked using `sum = digit + 3*carry`.
- All 25 U/E multiplication and comparison pairs, five negation cases, and 5^3 × 5 TERNARY_UE selector cases; explicit `Z * U = Z`, `Z * E = E` checks.
- 5,000 deterministic random 1..32-digit PURE5 additions, plus exact input/output-array in-place aliasing; 125 eight-digit mixed known/U/E balanced addition cases.
- Independent two-digit integer reconstruction for all 625 ordered PURE5 pairs and both possible initial carries; and all 81 ordered known two-trit balanced pairs with all three possible incoming carries.
- Typed domain mismatch, bad carry, invalid symbol, malformed LUT, null buffers, empty/oversize words, invalid tick, stale cell generation, generation exhaustion, failed-call output preservation, and explicit HOLD/WRITE/RESET for both domains.
- A demo illustrating PURE5 4+3 and balanced +1+1, U/E propagation and an explicit memory tick.

## Source preservation and regression

- Direct SHA-256 byte-comparison of the v0.8 source tree and v0.9 source tree, excluding only `Makefile`, `README.md`, generated build artifacts and the old checksum manifest, found **108 unchanged existing files and 0 unexpected modifications**.
- `make test CC=gcc` and `make test CC=clang`: all original v0.8 component suites passed, plus the new radix suite. Representative logged totals: original integrated 72,091; feedback 16,127; recovery 6,070; supervisor imitation 467; recursive 4,143; flexibility 84,048; composites 7,394; freestanding memory shim 33,282.
- `make baseline CC=gcc`: legacy NAND 20,191, legacy LESSONS 31,175, and neural representation/gradient suite all passed.
- `make sanitized CC=gcc`: all executed instrumented suites passed.
- `make freestanding CC=gcc` and `CC=clang`: combined relocatable host object had zero unresolved symbols with the existing explicit memory shim. This is **not** compiled, booted, or benchmarked firmware for any physical target.

## Limits and open issues

- No claim that the in-band E marker is a fourth/fifth *numeric* digit. Numeric TERNARY_UE operations have radix three on known operands; PURE5 has radix five.
- Conservative U propagation and E precedence are declared policies, not unique or universally accepted semantics.
- For U-driven three-way selection, the candidate chooses a common exact branch if all three agree, else E if *any* branch is E, else U. This may report a potential but unrealized error as E; richer branch-provenance analysis is not implemented.
- Word addition supports exact in-place input/output alias, but caller must not supply partially overlapping unrelated arrays or invalid memory pointers; no general C memory isolation is established.
- `HQ5Cell` is a single volatile state cell with no memory synchronization or durable storage.
- Existing Holoquary and neural kernels are not automatically converted to this new representation; all cross-domain conversions remain explicitly open.
- No general multi-digit multiplication, division, general mixed runtime integration, physical ternary/quinary circuitry, formal proof, signed release, or external attestation is claimed.

## Reproduction commands

```sh
make radix5_test CC=gcc
make radix5_test CC=clang
make radix5_demo CC=gcc
make test CC=gcc
make test CC=clang
make sanitized CC=gcc
make freestanding CC=gcc
make freestanding CC=clang
make baseline CC=gcc
```
