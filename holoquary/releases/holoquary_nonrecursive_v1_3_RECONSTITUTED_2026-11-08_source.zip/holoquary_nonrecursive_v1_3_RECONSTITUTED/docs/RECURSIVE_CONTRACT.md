# I-08 — Bounded pure NAND DAG recursion (candidate)

**Status:** Hosted/tested **logic-only** recursion subset. Not general mixed neural/logic execution.

## Graph contract

`HCIRecNode` has instance identity, `INPUT` or `NAND` kind, input-port index or left/right pointers. Nodes are caller-owned and immutable during evaluation. Root graph generation and snapshot IDs constrain all nodes. Duplicate instance IDs across distinct pointers, stale graph/snapshot generations, invalid ports/kinds, null edges on gates and cycles fail without publishing an output/trace.

The evaluator uses caller-provided strong-Kleene values, at most eight inputs, 16 distinct reachable nodes and maximum depth eight. A single call's local memo table caches each unique node by pointer and rejects a node reached again before completion. This preserves a shared fan-out with **one** evaluation per primitive per invocation. NAND operations are evaluated through the source Holoquary `hq_eval` with a one-gate `HQProgram`, retaining source truth semantics. The explicit NAND budget is enforced at execution, and neither caller-visible result nor trace is committed after a failed traversal.

`HCIRecTrace` records visited source instance IDs/holon IDs, derived results, actual NAND evaluations, budget used, and cache hits. These IDs/versions remain caller-managed references, not authenticated provenance. Shared pointers represent DAG reuse; the subset does not implement named runtime instances with mutable parameter banks or identity-preserving flattened arbitrary mixed graph plans.

## Tested properties

- All nine strong-Kleene XOR cases compare equal to the original four-NAND `hq_emit_xor` graph.
- All 27 nested XOR/parity cases compare equal to the original flattened eight-NAND program.
- 2,000 deterministic additional three-input patterns agree with the source evaluator.
- Cycle, identical instance IDs on distinct pointers, stale generation/snapshot, malformed input, excessive depth, exceeded NAND budget and null output/trace reject with unchanged caller buffers.

## Exclusions

- Arbitrary mixed neural/logic execution; explicit general-purpose typed port routing; backpropagation through composite instances; recurrent/stateful cycles; concurrent node mutation; hardware/stack sizing; malicious or invalid pointer memory safety; independent source-map attestation; optional lesson/weight sharing across recursive levels.

Freestanding compilation is an **object-level** result only. Each nested NAND evaluation constructs a small temporary source `HQProgram`, so actual stack footprint and latency require target-specific measurement.
