# Observed assistant integration-development error log

These were **actual issues during creation of this v0.4 candidate**, not independent user-authored code defects or hypothetical risks.

- `HCI-AI-001` — When adding typed signal lineage to the test and demo, the earlier direct input arrays became unused and compilation failed under `-Werror=unused-but-set-variable`. Corrected by removing the unused arrays; strict compiler rerun passed.
- `HCI-AI-002` — One negative assertion expected denial on forged source status while an unrelated prior budget of 3 exceeded its grant of 2. The guard correctly returned the budget error first; the test assumption masked the intended condition. Corrected the test fixture to reset `requested_budget=0` before the forged-status case. The revised test passed.

These are resolved within the generated candidate; they do not establish the absence of further defects.

## New v0.5 development correction

- `HCI-AI-003` — The first version of a rollback assertion compared an entire C store struct bytewise using `memcmp`, even though structure padding and unused event-array slots can contain indeterminate bytes. Replaced with explicit comparison of defined bank/event fields; GCC/Clang suites were rerun successfully. This was an assistant-authored test design issue, not an observed defect in the source Holoquary kernel.
- `HCI-AI-004` — The first v0.5 source-archive checksum manifest accidentally enumerated two generated binaries in nested baseline `build/` directories while the ZIP correctly omitted compiled build output. Clean-extraction manifest verification failed with missing-file errors. Corrected the manifest generation filter to exclude all nested build paths; followed by clean-extraction verification and rebuild. This was an assistant packaging mistake, not a logic-engine failure.

## v0.6 — Observed assistant-originated corrections

- `HCI-AI-005`: A first recovery example assumed the Holoquary wrapper returned `HCI_ERR_INVALID` for an invalid native logic value. The wrapper correctly returns `HCI_ERR_SOURCE` while setting its native `HQStatus`. The example's expected return code was corrected and rerun.
- `HCI-AI-006`: The first recovery demo represented a successful rerun on **changed inputs** as though it could establish a same-input recovery. Corrected its documentation/claim boundary: this only proves a new evaluation completed, and illustrates the missing immutable-input snapshot check; it does not prove the original invalid input was repaired.
- `HCI-AI-007`: An initial automated Makefile substitution put two `-c` source files into a single `-o` compilation command for freestanding build, which GCC rejected. Split it into one object per source and reran.
- `HCI-AI-008`: After that fix, Clang-generated aggregate copies still referenced `memcpy`/`memset` in the freestanding object. Added an explicit freestanding-only byte-copy/byte-set shim and verified zero unresolved symbols with both GCC and Clang. This remains an object-level test, not a physical target deployment.
- `HCI-AI-009`: The first neural trainer updated its model in place before detecting a possible nonfinite intermediate. Reworked it to train a local copy, validate each step and commit at the end; the original kernel remains unchanged. The existing test only establishes executed paths, not exhaustive numerical safety.
