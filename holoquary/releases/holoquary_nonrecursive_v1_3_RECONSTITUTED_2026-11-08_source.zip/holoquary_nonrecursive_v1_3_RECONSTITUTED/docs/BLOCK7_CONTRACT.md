# BLOCK7 v1.1 — 3–1–3 structured states and optional balanced-seven arithmetic

**Status:** IMPLEMENTED BOUNDED PROTOTYPE / generated design; not accepted canon; not independently attested or physically deployed.
**Attribution:** m.A.R.S. specified the 3–1–3 structure; assistant proposed and implemented the numeric profile, set-of-possibilities representation, and APIs.
**Source:** v1.0 higher-logic package, preserved without changing its computational kernels. See `RADIX5_TODO.md`.

## 1. Structural source (USER)

```
block −1 : inner −1, 0, +1
block  0 : inner 0 only
block +1 : inner −1, 0, +1
```

There are exactly seven valid `(block,inner)` pairs. `(0,−1)` and `(0,+1)` are INVALID, not alternative encodings of zero. The object is first a structure, not inherently an arithmetic radix.

## 2. Numerical profile (GENERATED PROPOSAL)

For the bounded numeric implementation select `digit = 2*block + inner`:

| block | inner | exact balanced-seven digit | mask bit |
|---:|---:|---:|---:|
| −1 | −1 | −3 | 0 |
| −1 | 0 | −2 | 1 |
| −1 | +1 | −1 | 2 |
| 0 | 0 | 0 | 3 |
| +1 | −1 | +1 | 4 |
| +1 | 0 | +2 | 5 |
| +1 | +1 | +3 | 6 |

The pair/digit conversion is reversible for these seven pairs. Negation maps `(b,i)` to `(-b,-i)`. This numeric profile is explicitly separate from existing PURE5, TERNARY_UE and NAND-K3 domains. No implicit conversion is introduced.

## 3. Knowledge domain is NOT the arithmetic domain

`HQ7Set.mask` uses bits 0..6, one for each exact digit. Valid masks range `0..127`.

| mask | meaning | knowledge label |
|---:|---|---|
| `0x00` | no possible states remain | `CONTRADICTORY` (empty set) |
| power of two | exactly one state | `EXACT` |
| other nonempty proper subset | two to six possibilities | `PARTIAL` |
| `0x7F` | any of the seven states | `UNKNOWN` |

`hq7_block(-1)` returns mask `0x07`, `hq7_block(0)` returns `0x08`, and `hq7_block(+1)` returns `0x70`. `hq7_inner(inner)` returns only existing pairs whose inner coordinate matches. `hq7_possible_blocks` returns a 3-bit mask of outer blocks represented by any possible value.

`hq7_refine(old,constraint) = old ∩ constraint`. It may give the empty set; this is an evidence conflict *under the assumed conjunction of constraints*, not proof that the underlying phenomenon is impossible or that execution failed. Revision/removal of evidence and its provenance are separate future operations. `hq7_union` joins alternative possibility sets and may broaden knowledge.

A separate `HQ7Status` reports invalid arguments, stale cell generations and exhaustion/overflow; no `ERROR` marker is inserted into the seven numerical digits. All defined outputs remain unchanged on API failures. No provenance/attestation is provided by a bitmask alone.

## 4. Exact arithmetic (GENERATED PROPOSAL)

The balanced-seven profile uses `digit ∈ [-3,+3]` and `carry ∈ [-1,+1]`. Exact addition with carry-in follows `a + b + cin = digit + 7*carry` and exact multiplication follows `a*b = digit + 7*carry`, choosing the **unique digit** in the signed range. Arithmetic is not defined over in-band UNKNOWN or ERROR symbols; partial knowledge is lifted over finite sets of exact digits.

`hq7_add_word` adds 1..32 little-endian exact digits with signed carry-in and signed final carry-out, staging all output digits until input validation and computation succeed. It supports exact output alias with an input, but not partial array overlaps; callers must supply valid nonoverlapping carry storage. Nothing is persisted automatically.

## 5. Lifted arithmetic and correlated output

For every possible pair of input digits, compute the exact result and union the **pairs of (digit,carry)** into one 21-bit `HQ7Outcome.joint`. Position `(carry+1)*7 + (digit+3)` represents one permitted exact pair. The high eleven bits are invalid. A joint set is required because independently recombining marginal digit and carry sets can manufacture arithmetically impossible output pairs. `hq7_outcome_project` returns marginals only when the caller explicitly requests them; it does not license a Cartesian product interpretation.

Inputs `a` and `b` are treated as independently selectable among their possible values. If both represent the **same unresolved variable**, special identity/correlation handling must be defined in a later implementation. Two masks with equal content do not imply equal underlying values.

An empty input set yields an empty joint result with `HQ7_OK`; no valid arithmetic possibility exists. Multiplying exact zero by `UNKNOWN` yields exact zero and exact zero carry under this mathematical **possibility set** semantics, not by suppressing an execution error. If the evaluation process fails, `HQ7Status` remains authoritative.

## 6. Higher functions and state

- `hq7_compare_sets` returns a mask of possible `{LT, EQ, GT}` relations: bits 0,1,2 respectively. It does not silently select a single relation when multiple are possible.
- `hq7_select_block` chooses among three separately typed branch sets according to the selector's possible outer blocks; alternative selected branch sets are unioned.
- `hq7_negate` mirrors every exact possibility around zero.
- `HQ7Cell` stores one (possibly partial or contradictory) knowledge set in a caller-owned C struct, with `WRITE`, `HOLD`, `RESET (zero)` and explicit expected-generation checking. Successful ticks increment generation; invalid or stale ticks preserve storage and outputs. It is volatile, non-concurrent, and not a durable multi-trit register.

## 7. Non-collapse rules and proof ceiling

- A seven-state encoding is not itself proof that the user accepted balanced base-seven arithmetic.
- `UNKNOWN` is a full possibility set, not numerical zero. `CONTRADICTORY` is an empty possibility set, not an execution error.
- `HQ7Status != HQ7_OK` never means a legitimate numeric result.
- More computation alone does not narrow a set; an explicit new constraint is required.
- Identical partial masks do not encode shared-variable identity. A future correlated-value system must preserve dependencies and source identities.
- Input/output masks contain **no authenticated provenance**. Caller authority, memory safety against adversarial pointers, atomic multi-cell transactions, durable state, neural training, physical trinary/seven-level circuits, and runtime recursive composition remain open.
- Tests prove only behavior for the executed host builds and bounded fixtures. Freestanding host-object compilation is not physical hardware boot or an external attestation.
