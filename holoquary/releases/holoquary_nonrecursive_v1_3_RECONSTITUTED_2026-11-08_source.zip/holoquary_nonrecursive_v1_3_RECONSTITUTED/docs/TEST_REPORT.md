# Holoquary-006 — Executed host test report

**Scope:** Current-turn local hosted x86-64 C99 tests, 2026-10-02. No physical board, independent security attestation, cryptographic verifier authority, or general trained-controller benefit evaluation.

| Suite | GCC -O2 | Clang -O2 | GCC UBSan+bounds |
|---|---:|---:|---:|
| Existing v0.4 integration | PASS, 72,091 assertions | PASS, 72,091 | PASS, 72,091 |
| Existing I-05 feedback | PASS, 16,127 assertions | PASS, 16,127 | PASS, 16,127 |
| I-06 recovery | PASS, 6,070 assertions | PASS, 6,070 | PASS, 6,070 |
| I-07 neural toy controller | PASS, 467 assertions | PASS, 467 | PASS, 467 |
| I-08 recursive NAND DAG | PASS, 4,143 assertions | PASS, 4,143 | PASS, 4,143 |

The original Holoquary baseline was independently rerun (`OVERALL=PASS checks=20191`, `LESSONS_TESTS=PASS assertions=31175`), as was the HNN v0.4 topology/gradient suite (`ALL_GRAD_CHECKS_PASS`, report maximum absolute difference `2.0056963e-05`). Original baseline manifest checks and byte comparisons of the v0.5 controller/adapters/feedback code passed.


- Freestanding memory shim: `memcpy` and `memset` return pointers and byte behavior exercised over every length 0–128 (`SHIM_PASS assertions=33282` in the GCC host fixture). This is not a proof of memory isolation or all C-library semantics.

## New-test coverage

- Recovery: retained original failure and new attempt records, finite retry budget, blocked external-effect and unknown-completion cases, stale generation, replayed event ID, malformed policy/scope, invalid callback output, denial receipts, exhausted event ledger, repeated fixture initialization.
- Neural imitation: all four synthetic action labels with 32 deterministic initialization seeds; 128/128 *training-label* matches. Learned proposals never bypass the separate control gate, including stale/denied/no-lesson situations. No real-world/hard held-out task, controller improvement or dynamic neural orchestration proven.
- Recursion: exhaustive 9 strong-Kleene XOR inputs and 27 nested parity inputs, 2,000 deterministic parity patterns against the unchanged flattened source, explicit duplicate/cycle/stale/depth/budget guards, unchanged output/trace on rejected evaluation.

## Build profile and size ceilings

- Hosted strict C99 (`-std=c99 -O2 -Wall -Wextra -Wpedantic -Werror`): GCC and Clang tests PASS.
- GCC `-fsanitize=undefined,bounds -fno-sanitize-recover=all`: all executed test suites PASS.
- GCC and Clang freestanding-object compile + relocatable combination + `nm -u`: PASS **only after** linking the explicitly provided `hci_freestanding_memory.c` shim for compiler-generated `memcpy/memset`. This does not prove a complete firmware image links or boots.
- Clang host combined relocatable object: `.text=21,173`, `.data=0`, `.bss=0` bytes on the observed host toolchain. This is neither linked firmware size nor total RAM/stack requirement.
- Observed x86-64 ABI `sizeof`: recovery store=3,600; recovery event=112; recovery grant=40; neural supervisor=256; recursive node=48; recursion trace=208; state frame=80 bytes. Not portable sizes and exclude stack/external evidence.

## Known limitations and wall

Successful pure rerun does not prove input identity or that the original failure was repaired. Callback, verifier, source and policy identity are not authenticated; event ledgers are in RAM only. Learned controller copied 4 labels on 4 training inputs and has no measured advantage. Recursive DAG runtime supports logic-only NAND, not mixed trainable holons. No physical ISA/board supplied for I-09. Pointer integrity/physical hardware/multi-threaded adversarial execution not proven.

These are executable test results with limited proof ceilings, not independent attestation or canonical acceptance.
