# Holoquary v0.7 — Flexibility/resilience test receipt

**Source state:** v0.6 archived source extracted as source baseline; new files added, existing C logic and neural kernel source unchanged. **Execution:** x86-64 hosted GCC and Clang, plus freestanding host-object compilation. This is *not* physical embedded execution or independent attestation.

## Regression and new coverage

- Baseline original Holoquary v0.1: reported `OVERALL=PASS checks=20191`, reproduced from archived source.
- Baseline Holoquary v0.2 LESSONS: reported `LESSONS_TESTS=PASS assertions=31175`, reproduced.
- Baseline NN v0.4: gradient suite reports `ALL_GRAD_CHECKS_PASS` with max absolute difference about `2.0056963e-05`, reproduced.
- Existing integration: `INTEGRATION_PASS assertions=72091` reproduced.
- Feedback: `FEEDBACK_PASS assertions=16127` reproduced.
- Recovery: `RECOVERY_PASS assertions=6070` reproduced.
- Experimental neural supervisor: `SUPERVISOR_PASS assertions=467` reproduced; no generalization/superiority claim.
- Pure logic recursive: `RECURSIVE_PASS assertions=4143` reproduced; no mixed recursive graph claim.
- Freestanding memory shim: `SHIM_PASS assertions=33282` reproduced.
- New fixed-capacity typed port / snapshot / replay suite: `FLEX_RESILIENCE_PASS assertions=84048` under GCC and Clang.
- GCC UBSan + bounds instrumentation: existing and new integration suites passed their exercised paths.
- GCC/Clang freestanding combined host-object builds: no unresolved symbols reported by `nm -u`.
- Baseline source SHA-256 checks: Holoquary v0.2 and NN v0.4 archives verified against their included manifests.

## Key test families

- 6,000 mixed numeric/logical input variations checked against the unchanged direct XOR evaluator.
- 3,000 neural numeric-input snapshot evaluations compared with unmodified NN observation output.
- Per-port threshold validity, distinct and matching conversion policies, direct versus classified provenance, mixed ancestry, refusal to promote aggregate mixed lineage without its port map.
- Snapshot capture rejects invalid type/value and stale source, leaving the previous snapshot intact; evaluation rejects changed numeric bytes and stale generation, leaving the output frame intact.
- Pure callback verifies snapshot binding, rejects modified payload and mismatched graph generation, and retains the original recovery event after a subsequent successful reevaluation.
- ERROR, UNKNOWN and completion status remain separate as represented by the baseline source types.

## Explicit limitations

This test does not establish authenticated input capture, malicious-tamper resistance, concurrent snapshot correctness, exact historical same-input replay, source/verifier independence, durable crash recovery, physical firmware execution, model quality, or general mixed runtime recursion. The original v0.6 test assertion figures remain artifact-reported and reproduced in this local run only. No test count proves correctness for untested graph or pointer configurations.
