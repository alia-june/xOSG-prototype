# Baseline and research provenance

Original artifacts used as immutable references. The baseline trees are extracted from their archived source ZIPs, and were checksum-verified before adding integration files. Their original C source/header files remain unchanged.

| Reference | ZIP SHA-256 | Role |
|---|---|---|
| `hnn_topology_comparison_v0_4_source.zip` | `9b818c459dfc5a8000b31103011309aff142f5e5a53e4749e59df34f1f436122` | Trainable neural computation (numerical kernel); previous experiments |
| `holoquary_lessons_v0_2_source.zip` | `2a433fc5121d6b471cf8a96e9d82597d6cd5bc2bfaa291e3d13c8f0da7d34d64` | NAND/XOR logic and caller-admitted LESSONS |
| `holoquary_controller_docs_v0_3.zip` | `29f7698b73a8895fae5796bef10d653d7e890c034e73a1fe21de346889633f38` | Pre-integration research and test planning |

`baseline/holoquary_lessons_v0_2/SHA256SUMS` and `baseline/hnn_topology_comparison_v0_4/SHA256SUMS.txt` are the original archive-side manifests. Run `sha256sum -c ...` from each respective base directory. `reference/holoquary_controller_docs_v0_3/` is a copied complete prior documentation directory.

The new files under `src/`, `tests/test_integration.c`, `examples/demo_integration.c` and `docs/` are assistant-generated v0.4 prototype additions, not user-accepted canon or externally attested implementation.

## Added in v0.5

`src/hci_feedback.h`, `src/hci_feedback.c`, `tests/test_feedback.c` and `examples/demo_feedback.c` are generated I-05 integration code, not recovered source. The original `baseline/` neural and logic kernels and previous v0.4 `src/holon_types.h`, `src/controller_deterministic.c`, `src/holon_adapter_logic.c`, `src/holon_adapter_neural.c` remain unchanged. The new source is governed by `docs/FEEDBACK_CONTRACT.md` and is *not* an independent attester or authenticator.

## Added in v0.6

Generated additional source files: `src/hci_recovery.{h,c}`, `src/hci_supervisor.{h,c}`, `src/hci_recursive.{h,c}`, and `src/hci_freestanding_memory.c` (the latter is linked only under the freestanding-object build profile). Added three tests and three examples, plus separate new design/test documents. These are new assistant-originated candidates; they do not rewrite the original `baseline/` files or old v0.5 adapter/feedback sources. Only the integration Makefile, top-level README and additive docs were modified.
