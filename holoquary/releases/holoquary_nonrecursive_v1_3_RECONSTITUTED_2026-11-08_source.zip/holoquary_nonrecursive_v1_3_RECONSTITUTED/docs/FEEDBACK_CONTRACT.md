# Holoquary-005 I-05 — Candidate LESSONS feedback contract

**Maturity:** generated/implemented candidate. This file does not grant operational or canonical authority.

## 1. Boundary

- **Kernel**: unchanged NAND/XOR and fixed point evaluator.
- **Candidate**: proposal only; may be wrong, poisoned or stale.
- **Verifier**: `HCIVerifier(candidate, oracle_ctx, verification)` is caller-selected. Its independence and evidence quality are *external obligations*.
- **Admission store**: owns original-compatible `HQLessonBank`, an ephemeral append-only list of recorded *validly submitted* decisions, and a monotonically increasing local generation.
- **Consumer**: `hci_observe_extended` reads the bank under matching scope, without changing its native code.

## 2. Preconditions

`hci_feedback_submit` preflights nonnull pointers, event capacity, store consistency, candidate uniqueness, nonzero scope/source/proposer/evidence IDs, matching observed identity (holon, instance, graph, parameters, snapshot), valid observed execution disposition and result kind, typed candidate content and bounds. Admissible fact/rule candidates require completed logic evaluations, valid 3-valued logic output, and native source status `HQ_OK`. Anti-lessons require a nonzero action and failure code. A caller must not use fabricated/forged frames or mutation across source snapshot generation boundaries.

## 3. Verifier binding

The caller-provided callback returns ACCEPT, REJECT or DEFER and records `verifier_id`, exact `checked_candidate_id`, `checked_evidence_id`, and nonzero proof reference. The module rejects malformed callback responses and same-numeric-ID proposer/verifier. This does **not** authenticate identity, verify the proof reference, prevent malicious callback writes or guarantee that the checker is independent. The caller must ensure these properties separately.

## 4. Disposition

| Verifier | Candidate | Admission store result | Original HQLessonBank |
|---|---|---|---|
| ACCEPT | new valid fact/rule | `ADMITTED` event | Append fact/rule |
| ACCEPT | exact duplicate fact/rule | `REJECTED` event | Unchanged |
| ACCEPT | directly opposite same-target fact/rule | `CONFLICT` event | Unchanged |
| ACCEPT | anti-lesson | `ANTI_ADMITTED` event | Unchanged |
| REJECT | any valid candidate | `REJECTED` event | Unchanged |
| DEFER | any valid candidate | `DEFERRED` event | Unchanged |
| invalid request/callback, full capacity | any | error return, no event and no bank/receipt commit | Unchanged |

A syntactically conflicting proposed rule is **not** silently erased: it generates a decision event if otherwise valid and independently accepted. The direct conflict check covers same target facts and same-premise/same-result-port opposite rules; it is NOT a theorem prover or completeness guarantee. A separately admitted rule can still produce conflict during `hq_eval_extended`, which continues to fail closed to UNKNOWN.

## 5. Atomicity and replay

The module preflights event and bank capacity, invokes a conforming *pure* verifier, checks its receipt, then appends at most one fact/rule and one event. It writes the provided receipt only on success. An invalid attempt leaves the store unchanged under the documented pure-callback and no-concurrent-writer assumptions. On a checked ACCEPT, a new event identity is retained. Repeated candidate IDs return `HCI_ERR_INVALID` without mutation. Different candidate IDs can describe the same fact; exact bank content checks reject duplicate facts/rules with a recorded rejection event. `generation` increments once per recorded decision, whether admitted, rejected, deferred or conflicting.

A callback that maliciously edits memory or performs external effects is outside this contract; the library does not provide a process boundary, transaction log, or rollback for arbitrary side effects. ID checks are not an authentication primitive.

## 6. Truth and negative evidence

A rejected, deferred, exhausted or contradicted candidate is **not** a logical FALSE by default. An anti-lesson documents a scoped negative observation about an action; it does **not** invert a proposition and cannot enter the NAND bank. An admitted fact/rule is valid only relative to the authority of the caller-provided verifier and evidence oracle. More rounds never establish truth without admitted applicable evidence.

## 7. Outstanding hardening

External proof/authority verification; immutable source snapshot hashes or generation service; event persistence and tamper evidence; dynamic source expiry/revocation; complete dependency-aware consistency; independent audit/attestation; concurrent or malicious caller memory isolation; recovery semantics and side-effect accounting; explicit source ID binding to external evidence. Until then, only a single-writer, trusted-process hosted C programming boundary has been tested.
