# Staged v0.7 integration log

1. **Baseline:** Extract unmodified v0.6 archive into a new v0.7 branch; run original Holoquary logic/LESSONS, NN gradient and five v0.6 integration suites; preserve underlying kernel source checksums.
2. **TODO intake:** Register all six paths A–F from the user request, with explicit open dependencies and evidence ceilings; mark base-level tasks as candidate work only.
3. **New base module:** Add typed two-kind port protocol, scoped immutable-by-convention snapshots, per-port numeric classification, separate numeric versus logical evaluation, pure-logic recovery replay callback.
4. **Correction pass:** Identify and repair classified-provenance propagation and test-fixture false negatives; record actual errors in `BASE_ERROR_LOG.md`.
5. **Validation:** Run GCC/Clang warnings-as-errors tests, GCC UBSan/bounds, freestanding combined object and original source manifest checks. See `FLEX_TEST_REPORT.md`.
6. **Stop boundary:** Do not claim physical hardware deployment, trusted same-input recovery, authenticated source binding, general mixed recursive graph, or neural policy advantage. Those remain TODO.
