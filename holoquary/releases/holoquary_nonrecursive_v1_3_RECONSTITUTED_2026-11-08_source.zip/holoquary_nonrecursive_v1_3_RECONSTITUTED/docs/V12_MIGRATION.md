# Holoquary v1.2 — Explicit migration map

## Why this is a wrapper-first correction

Current source packages have deployed/tested historical contracts. Rewriting a low-level `U/E` variant into new fields in place would invalidate earlier test evidence and caller assumptions. v1.2 adds a strict wrapper and new operations while leaving those historical kernels untouched. It does not falsely claim an architecture-wide migration.

| Prior interface | Existing representation | Normalized interpretation | Remaining work |
|---|---|---|---|
| HQ5 PURE5 | Five numerical ordinals | EXACT PURE5 number | Replace caller handling with explicit record, then test with historical reference |
| HQ5 TERNARY_UE N/Z/P | Five-symbol union, known ordinals | EXACT BALANCED3 number | Convert call sites after confirming scope and error semantics |
| HQ5 TERNARY_UE U | In-band U marker | ABSENT numerical payload + full possible-trit mask | Preserve original unknown origin and correlation after a source-binding scheme exists |
| HQ5 TERNARY_UE E | In-band E marker | ABSENT payload + marker, not a verified runtime failure | Bind actual error ledger and effect-state identity before trustworthy recovery |
| HQX four-way F/T/U/E | Predicate outcomes with E marker | Exact KLEENE3 F/T/U or absent with propagated E | Audit per-operator strict-E behavior and explicit losing conversions |
| HQ7Set | Seven-bit set; contradiction=0 | BALANCED7 possibility mask plus derived exact payload for singleton | Preserve scope, shared variables, optional structural profile identity |
| HQTruth | F/T/U logical symbols | EXACT KLEENE3 symbols | Keep this original strong Kleene interpretation |
| HCIFrame | Result + execution + disposition + source IDs | Distinct lanes, source-identity attachment *only* with explicit provenance contract | Not migrated in v1.2; separate adapter TODO |
| HCI_FLEX typed ports | Numeric float or HQTruth plus local origin | Separate value/domain and knowledge/execution authority | Not migrated in v1.2; retain earlier runtime unchanged |
| Neural outputs | Floating numerical outputs | Numeric domain requires explicitly selected precision/conversion | Not migrated in v1.2 |
| Proposed NINE / FIFTEEN | Earlier design discussion | NINE numerical profile optional; FIFTEEN block-local U/E presentation only | TODO, no numeric promotion of metadata |

**Example:** `hqd_to_hq5(partial, EXACT)` refuses instead of choosing 0. Explicit `ALLOW_U` discards a partial mask to the legacy U marker and therefore must not be used for evidence-sensitive replay. `hqd_to_hq5(failed_execution, ALLOW_E)` refuses: the operation failure must remain a typed failure, not be disguised as an in-band error digit.

## Sequenced future migration

1. Review this model and clarify U1/U2/U3 semantics with the operator: they remain opaque until specified.
2. Implement explicit HCIFrame and HCI_FLEX adapters; avoid silent promotion or dropping provenance lineage across ports.
3. Introduce source-bound knowledge constraints and exact unknown-variable identity; distinguish two references to the same X from independent unknowns.
4. Add tests for multi-stage metadata transformation with scope/generation/effect guards, including negative evidence and replay.
5. Make independent validation/attestation a separate authority from same-process metadata validation.
6. Only then connect the corrected operation-neutral interfaces to a general mixed recursive runtime.

This roadmap is subordinate to operator approval; code in v1.2 implements only the bounded adapter and nonrecursive algorithms listed in `V12_SEPARATION_CONTRACT.md`.
