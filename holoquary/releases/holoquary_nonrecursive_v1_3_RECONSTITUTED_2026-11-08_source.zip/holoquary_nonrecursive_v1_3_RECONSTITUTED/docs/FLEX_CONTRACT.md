# Holoquary v0.7 — Typed base ports and bounded snapshot resilience

**Status:** IMPLEMENTED PROTOTYPE / NONCANONICAL. **Authority:** operator-proposed continuation; assistant-authored code and contract. **Source:** additive to Holoquary v0.6, without modifying the original Holoquary/NN source kernels.

## 1. Intent

Add a minimal, optional interface that allows a neural or logical leaf result to be captured, routed, interpreted and reevaluated without forcing all children to have the same internal data type. Preserve fallible operations as fallible, and keep the existing deterministic logic API authoritative.

## 2. New modules

- `src/hci_flex.h`, `src/hci_flex.c`: tagged logical/numeric ports, bounded input snapshots, local checksum, read-only evaluation adapters, pure-logic recovery callback.
- `tests/test_flex.c`: valid and negative cases; includes tamper/identity, per-port threshold, and replay cases.
- `examples/demo_flex.c`: mixed numeric/logical XOR and mutation rejection.

No change to the existing v0.6 controller, neural optimizer, NAND evaluator, lesson bank, recovery event store or recursion evaluator is necessary. Build may omit `hci_flex.c` when the new interface is not required.

## 3. Exact typed-port contract

`HCIFlexPort` carries a single active type: `HCI_FLEX_LOGIC` with `HQTruth` in {FALSE, TRUE, UNKNOWN}, or `HCI_FLEX_NUMERIC` with finite `float`. It carries caller-supplied source identity and a classification-origin marker. A source identity is a *declared handle*, not evidence of external authenticity. Ports in one captured invocation must match the target snapshot ID, but their graph/parameter generations remain local to the source holon; one child may be trainable and another not.

`hci_flex_port_from_frame` accepts only completed, well-typed state frames. Logic frames with CONFLICT/EXHAUSTED traces are intentionally rejected as ordinary data; they must be handled through explicit policy, not silently flattened to UNKNOWN. Failed/unknown-completion frame outputs are never accepted as ordinary logical/numeric inputs.

`HCIInputOrigin=CLASSIFIED` denotes a classification lineage, **not independent truth**. An output with mixed classified/unclassified ancestry or mixed conversion policy IDs remains marked CLASSIFIED but carries aggregate `input_conversion_id=0`. Its per-port mapping is available only from the captured snapshot. Such an aggregated frame cannot be used as a new single-source `HCIFlexPort` without an additional explicit lineage-preserving adapter. No provenance is silently fabricated.

## 4. Snapshot and evaluation boundaries

`hci_flex_capture` validates all fields into a temporary local copy and commits only on success. It binds the destination identity, port count, typed source identities, payloads and conversion lineage to a local, unkeyed FNV-style checksum. `hci_flex_validate` checks target identity, bounds, port representations and checksum before use. A checksum mismatch => `HCI_ERR_STALE`. Identity/generation mismatch => `HCI_ERR_STALE`; malformed values => `HCI_ERR_INVALID`.

This checksum detects ordinary accidental modification. It is **not a cryptographic MAC, collision-resistant digest, trusted snapshot provenance, immutable storage, authentication, security boundary or persistent wire format**. Numeric bytes are included using `float`'s local C object representation. Cross-ABI serialization requires a separately specified format. Concurrent mutation of snapshots or their external source objects is not handled; callers must provide isolation.

`hci_flex_eval_logic` evaluates logical ports directly and converts numeric ports only under finite explicit per-port `false_max < true_min` with nonzero conversion IDs. It calls the original `hci_observe_logic`, whose underlying NAND truth tables remain unchanged. A mixed-input result must not be presented as independently attested truth. The result is published only on successful completion; invalid snapshot/policy/source failure leaves the caller's prior result unchanged.

`hci_flex_eval_neural` accepts exactly `DNN_INPUTS` finite numeric ports and preserves the original NN model generation and original numerical kernel. It does not train or mutate weights. Its successful observation may update the existing adapter's **observation cache**, not the parameter bank. On validation failure no evaluation is invoked and the caller's output frame remains intact.

## 5. Recovery adapter boundary

`hci_flex_replay_logic` is an `HCIReeval`-compatible callback, used by the unchanged v0.6 recovery ledger. It revalidates the caller-captured snapshot against the original observation's complete target identity, reruns the exact saved typed inputs using the named Holoquary program, then publishes the new attempt snapshot ID. The underlying recovery ledger still rejects effectful, completion-unknown, unauthorized and over-budget retries.

**Critical limit:** The callback cannot prove what byte sequence was actually present in the *historical* failing evaluation. Both snapshot identity and policy handles are supplied by the caller. The snapshot can be forged by a caller with write access, and the callback does not certify side-effect classification or authorize external effects. A successful subsequent evaluation is *not* proof of repairing the original error, nor does it rewrite the earlier failure event. For trusted replay, bind input snapshots to the original operation at an independently controlled capture boundary and retain authenticated journals/receipts before permitting effectful recovery.

## 6. Failure and resource posture

- No heap allocation, standard I/O, or general runtime dependency in the new C core.
- At most `HQ_MAX_INPUTS` typed input ports and original HNN two-input constraint.
- Invalid or stale snapshots do not partially publish a result or change the source kernels.
- COMPLETE/FAILED/COMPLETION_UNKNOWN remain distinct; execution failure is not a fourth Kleene truth value.
- Explicit conversion with possible UNKNOWN (gap between thresholds); no implicit score -> truth cast.
- No extra recursive runtime nodes, parameter-bank ownership, secure source verification, auto learning, evidence durability, independent attestation or physical hardware test is claimed.

## 7. Known open changes

Future bounded work: explicit type-checked mixed recursive DAG nodes; durable authenticated input acquisition and revisioned snapshots; dependency-aware multi-output failure isolation; source ownership and lifetime; concurrently consistent parameter/snapshot reads; cryptographic source binding; valid cross-ABI serialization; separately attested replay; hardware-target-specific stack/timing constraints.
