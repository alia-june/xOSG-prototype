# Holoquary v0.8 — Incremental change log

| Stage | Change | Recorded outcome |
|---|---|---|
| C00 | Copy v0.7 baseline into separately named v0.8 candidate | Existing Holoquary and neural core source retained unchanged |
| C01 | Add transactionally composed NOT/AND/OR/NOR/XNOR/enable/MUX/DEMUX/guarded lock | Compile and exhaustive ternary comparisons PASS |
| C02 | Add explicit one-bit T/F/U memory cell with versioned ticks | All ternary state/enable/data comparisons match the NAND MUX graph |
| C03 | Add composite + memory negative/rollback tests | 7,371 initial, then 7,394 assertions after partial-capacity tests; PASS |
| C04 | Integrate into existing Makefile and append TODOs | Original baseline, integrations and six extension branches preserved |
| C05 | Run GCC/Clang strict builds, sanitizer, freestanding host-object tests | PASS in development environment |
| C06 | Package source and documentation; verify clean extraction | Evidence recorded in final archive verification, not assumed by this log |

Open: actual authentication, independent controller privilege, persistence, concurrent state mutation, general neural/logic recursive instances, physical electronics and hardware boots.
