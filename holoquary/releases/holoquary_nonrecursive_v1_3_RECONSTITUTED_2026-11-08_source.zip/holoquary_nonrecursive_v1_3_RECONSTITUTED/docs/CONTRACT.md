# Holoquary-004 integration contract

**State:** GENERATION/IMPLEMENTATION CANDIDATE; tested behavior listed below is limited to the submitted source and listed environments, not adoption as universal canon.

## Preserved kernel behavior

- The source Holoquary logic remains strong-Kleene `HQ_FALSE`, `HQ_TRUE`, `HQ_UNKNOWN`. A failed `HQStatus` is not a fourth truth-table value. The controller's public ERROR/UNKNOWN accounting does not redefine logic.
- Source `hq_eval()` remains QUICK; `hq_eval_extended()` remains fixed-capacity, externally supplied, scope-keyed LESSONS. No raw NAND gate changes weights or learns.
- Source HNN v0.4 retains its 2-input / 1-output dense network constraints, context-dependent gradient routines, and caller-managed parameters.
- The two source baselines are compiled into the mixed test **without editing source files**.

## Published state and epochs

`HCIFrame` contains a kind, caller-assigned identity/instance/graph/parameter/snapshot IDs, typed output, exec status, logic disposition and minimal lesson/error/budget metadata. On a host x86-64 ABI tested here, `sizeof(HCIFrame)=80` bytes; target-specific measurements are necessary elsewhere. This is one published result, **not a complete snapshot of all descendants**. The logic adapter summarizes the first exported output of the v0.2 program; callers needing all outputs must use the original Holoquary API directly pending a multiport frame extension.

All generation and snapshot IDs are supplied/maintained by the calling orchestrator. If the orchestrator mutates a model or program without incrementing the relevant generation, this implementation CANNOT independently detect the resulting stale observation. No concurrency protection, authority authentication, lifetime management for pointer aliases, or tamper-proof hash is implemented.

## Visibility tiers actually supported

- L0 frame: supported for logic and neural leaves.
- L1: the neural adapter can copy its last successfully observed two input scalars to a caller-owned array if the explicit view bit and snapshot generation match.
- L2: gradient/optimizer inspection is **not implemented**. The upstream neural kernel still exposes gradients through its separate API.
- L3: read-only copy of neural model parameters, bounded by buffer capacity and explicit view bit; stale version and bad model rejected. The interface returns copies rather than exposing a writable pointer, but access grants are not independently authenticated.

One model version shared across multiple holon instances is not covered by a shared-bank ownership model yet.

## Numeric-to-logical conversion

`hci_classify_signal` accepts a **completed numeric** frame and an explicit finite `false_max < true_min` policy. It reports `FALSE` for `x <= false_max`, `TRUE` for `x >= true_min`, and `UNKNOWN` between thresholds. It emits source holon, source snapshot, conversion ID and domain=CLASSIFICATION. The bridge `hci_observe_classified_logic` rejects wrong domains/values, mismatched conversion IDs and signal snapshot IDs that differ from the logic adapter's current invocation. It never treats a numerical score as independent evidence of external truth. `input_origin=HCI_INPUT_CLASSIFIED` and conversion ID are retained in the outgoing summary; full per-port provenance remains in the external caller/trace, not the frame.

A reported `TRUE` after conversion means **the signal met its threshold**, not that the underlying proposition has been attested TRUE. Admission and factual verification are future separate stages.

## Deterministic action-selection and validation-only gate

The candidate controller proposes actions according to the published frame and count of applicable lessons. A valid definite logic result leads to `ANSWER`, an unresolved QUICK result with applicable lessons leads to `APPLY_LESSON` (one requested round), exhaustion with budget leads to `CONTINUE`, conflict/stable unresolved leads to `REQUEST_EVIDENCE`, a neural numeric result leads to `ROUTE`, and execution failure leads to `REPORT_ERROR`.

The gate rejects unknown action enum values, incorrect target IDs, stale graph/parameter/snapshot versions, missing action-mask grants and excess requested budget. It additionally rejects `ANSWER` on a failed/unknown/unsupported logic state and `ROUTE` on a non-neural or failed result. The gate does not call a holon, mutate weights, apply lessons, perform recovery, authorize external effects, or attest a fact. More complete action-specific and scope-specific policies are pending.

## Failure and conflict

- Source Holoquary evaluation failure -> failed frame with native HQStatus and no valid truth value.
- Extended conflict/exhaustion -> successful execution but logical UNKNOWN with CONFLICT/EXHAUSTED disposition.
- Model validation or nonfinite arithmetic -> non-OK adapter return and FAILED frame; no false/true is published.
- On invalid typed conversion signal -> failed frame and typed HCI return. Previous source output buffers are not modified.
- Unauthorized/old input or parameter view -> rejection without changing the caller-provided output buffer.
- The formal semantics of a `HCI_COMPLETION_UNKNOWN` condition are reserved for a future orchestrator monitoring an outstanding external operation; the current synchronous adapter does not emit this state itself.

## Not proven

No general-purpose neural supervisor, private/confidential information boundary, durable audit ledger, semantic source verification, real authorization, secure execution environment, out-of-process crash recovery, side-effect replay, physical firmware, or independent attestation is implemented or tested. Compiler memory sanitizers are bounded test evidence, not a security guarantee.
