# Holoquary v0.9 — Dual five-symbol arithmetic substrate

**Status:** GENERATED IMPLEMENTATION CANDIDATE, not canonical; source executed on hosted x86-64 and freestanding-object checked separately. **Attribution:** m.A.R.S. (design direction), ChatGPT (implementation). **Date:** 2026-10-02.

## 1. The essential non-collapse rule

The same *storage cardinality* is not the same *arithmetic radix*.

| Profile | Five symbols | Numeric base | Meaning of fourth/fifth symbol |
|---|---|---|---|
| `HQ5_DOMAIN_PURE5` | 0,1,2,3,4 | Five | Both 3 and 4 are numbers. No embedded UNKNOWN/ERROR. |
| `HQ5_DOMAIN_TERNARY_UE` | N,Z,P,U,E (ordinals 0..4) | Three, when numeric | Ordinal 3 = UNKNOWN; ordinal 4 = propagated ERROR marker. Neither is a number. |

`HQ5Value` contains a domain tag and symbol ordinal. A value of ordinal zero means **numeric zero** in PURE5 but **numeric −1** in TERNARY_UE. No conversion is implicit. Explicit conversions between logical `HQTruth`, ternary numeric, and pure base-five are intentionally unimplemented until the semantics and provenance contract are defined.

`HQ5Status` remains separate from the fifth in-band symbol E. `HQ5_OK` and an E-valued result mean *the routine validly propagated the E marker*. `HQ5_BAD_VALUE` means the implementation rejected malformed input without publishing a result. The caller's ERROR event must retain its original source/identity; a bare E symbol does not reconstruct that provenance.

## 2. PURE5 arithmetic

- A digit encodes exactly 0..4.
- Addition: `sum = a + b + carry_in`, with carry_in ∈ {0,1}, output `sum % 5`, carry `sum / 5`.
- Multiplication: `product = a*b + carry_in`, with carry_in ∈ {0,1,2,3,4}, output `product % 5`, carry `product / 5`. The carry range is sufficient for a single base-five multiplication column; multi-column multiplication and long division remain TODO.
- Comparison yields −1/0/+1 as an ordinary **separate integer output** (not a PURE5 digit).
- Five-way selector chooses one of five provided PURE5 values by the numeric selector digit.
- Two-input LUT stores 25 PURE5 outputs. Every entry is checked for 0..4 before evaluation, not just the selected entry.
- Word addition supports 1..32 digits in least-significant-digit-first order and an explicit initial/final carry.

For example 4+3 => output digit 2, carry 1; the two-digit representation is `12_5`.

## 3. TERNARY_UE arithmetic

Known digits are N=−1, Z=0, P=+1. U=UNKNOWN and E=ERROR MARKER are not integer operands. Internal encoded symbol ordinals are N=0, Z=1, P=2, U=3, E=4; this *does not mean* arithmetic on ordinals is valid.

### Known arithmetic

Balanced carry addition for digit operands and incoming carry:
`sum = a + b + carry`, with all known terms in [−1,+1]. Choose result digit in [−1,+1] and carry in [−1,+1] so `sum = result + 3*carry`. One-digit multiplication produces a known digit without carry. Negation swaps N/P and preserves Z. Comparison returns a ternary sign (N/Z/P).

### UNKNOWN and ERROR rules (explicit proposal)

- **Existing E dominates arithmetic evaluation** (including `Z * E = E`) so an observed propagated error marker is not silently erased by arithmetic identities.
- Addition with any U and no E conservatively outputs `(U,U)` for (digit,carry), even if a more refined set-valued analysis could determine one component. This policy prioritizes simple, auditable semantics over precision.
- Multiplication with U and no E yields Z if the other operand is definitely zero; otherwise U.
- Negation preserves U and E.
- Comparison with E => E; otherwise U with U; otherwise definite N/Z/P.
- Balanced three-way selection on definite N/Z/P selects that branch; E selector => E. U selector returns a common branch value if all three are identical; otherwise returns E if any candidate branch is E, else U. This is a **conservative possible-error policy** and is not interchangeable with standard Kleene MUX semantics.
- Word addition conservatively propagates U or E into later carries, while retaining correctly computed less significant digits. It does not purport to derive all possible values of uncertain sums.

These rules are **domain choices**, not mathematical claims that every five-valued logical algebra must use them. They require separate acceptance before becoming canonical.

## 4. State, type, authority, and failure boundaries

`HQ5Cell` is a caller-owned in-process one-symbol cell; it stores a PURE5 or TERNARY_UE symbol with exact 32-bit generation checking. HOLD retains the symbol; WRITE can store any **valid symbol from the same domain**; RESET explicitly sets PURE5 to numeric 0 or TERNARY_UE to numeric Z. Each successful tick increments generation. Stale, invalid, exhausted, or malformed ticks preserve both cell state and caller result. A reset can clear an E marker only through an explicit accepted command; that is not recovery evidence.

No dynamic allocation in the new module. No direct memory-mapped I/O, external side effects, true electrical five-level signaling, physical Setun-style hardware, cryptographic input provenance, thread safety, durable memory, or independently attested recovered history. Client pointers/buffers must be valid and non-overlapping except for exact input/output word aliasing. The C compiler/ABI may pad structures; do not assume compact binary serialization from `sizeof`.

The v0.8 Holoquary `HQProgram` remains a three-valued strong-Kleene logical DAG and does **not** silently inherit either arithmetic profile. Composition uses an explicit typed adapter as a future step, not a reinterpretation of existing NAND semantics.

## 5. Composition direction

```
HOLOQUARY
 +-- PURE5 arithmetic/memory domain (all five numerical)
 +-- TERNARY_UE arithmetic/memory domain (three numeric + U/E)
 +-- KLEENE logical domain (F/U/T)
 +-- NEURAL domain (floats/weights)
 +-- explicit, versioned domain conversion policies (future)
```

The project TODO records true multi-digit multiply, carry diagnostics, selector alternatives, explicit typed bridges, atomic multi-cell registers and physical validation as open work.
