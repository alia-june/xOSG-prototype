# Holoquary v1.3 — executed test report

**Date:** 2026-10-02. **Maturity:** locally hosted C99 prototype, not independently attested. Compiler and tests executed in Linux x86-64 development container. All assertions below are test-harness checks, not independent formal proofs.

## New module

- `make CC=gcc functions_test functions_demo`: `NONRECURSIVE_FUNCTIONS_PASS assertions=857664`, success after latest new-code changes.
- `make CC=clang test`: complete inherited functional target plus new suite passed, including `NONRECURSIVE_FUNCTIONS_PASS assertions=857664` after latest code changes.
- `make CC=gcc test`: complete inherited functional target plus new suite passed, including `NONRECURSIVE_FUNCTIONS_PASS assertions=857664` after latest code changes.
- Targeted new-module sanitizer: GCC `-fsanitize=undefined,bounds -fno-sanitize-recover=all` passed `857664` assertions.
- GCC and Clang `make freestanding`: combined **host** relocatable objects produced and linked; `nm -u` reports no unresolved symbols. No real processor/board boot or measurements.

### New coverage

- Exhaustive Kleene operator possible-value sets across 8 logical set masks and selected arities; reference truth tables independent of the new source composition.
- Exhaustive conditional selection masks for Kleene3, balanced3, PURE5, and BLOCK7; exact logical U distinguished from partial `{FALSE,TRUE}`.
- Exhaustive numerical comparison-set logic (up to all 128 × 128 balanced7 masks) and independent LT/EQ/GT oracle.
- Exhaustive bounded ternary and PURE5 inclusive BETWEEN set combinations; 12,000 deterministic BLOCK7 mask samples; local reused-variable consistency fixture which rejects a spurious TRUE in `X>=1 AND X<=0` when X∈{0,1}.
- Strict denial of execution failure and propagated legacy E markers, even on unselected branch or FALSE guard; invalid op/domain; failed output remains unchanged.
- Multi-cell tick success across three distinct state domains, double stale, late invalid write, duplicated pointer, duplicated instance, overflow, HOLD and uncertain-write; all-or-nothing under single-threaded, disjoint-pointer preconditions; read and generation checks, grades cannot alter mathematical possibility masks.

## Inherited functional suites reproduced under both compilers

- Integration `72091`; Feedback `16127`; Recovery `6070`; Neural supervisor `467`; previous pure-logic recursion `4143` (no new recursion); Flex `84048`; Composite `7394`; Radix5 `220147`; Higher `139724`; BLOCK7 `415972`; Separation `279320`; shim `33282`; all report PASS.
- Standalone original logic suite (GCC): `OVERALL=PASS checks=20191`.
- Standalone LESSONS suite (GCC): `LESSONS_TESTS=PASS assertions=31175`.
- Standalone original neural gradient suite: `ALL_GRAD_CHECKS_PASS max_abs_difference=2.0056963e-05` after a separate GCC compile/run.

**Timeout caveat:** A combined command running GCC/Clang full targets followed by the standalone `make baseline` hit its total command timeout *during the standalone neural test compilation*. The two functional suites were already completed and their logs show success. The original logic, LESSONS, and neural gradient suites were subsequently verified separately as described above. The combined baseline invocation is NOT cited as a fully passed command. Full inherited sanitizer target was not run in this pass; only targeted new-module sanitizer execution is claimed.

## Source preservation / security scope

A source-by-source comparison with the v1.2 release archive found 144 inherited non-manifest files unchanged; only the Makefile, README and two TODO files were amended. All original computational kernels and existing test sources retain their bytes. No secure identity, cryptographic validation, external side-effect authority, authenticated history, general symbolic correlation, durable storage, concurrent atomicity, board-specific deployment or SSMI/UPTI/Sisterhood integration is demonstrated.

## Packaging checks

The source-only archive uses a generated SHA-256 manifest. See terminal archive verification receipts for actual entry count, integrity status, clean-extraction test and reproducibility. The manifest is an accidental/tamper *detection aid to someone independently checking the bytes*, not a signed authenticity claim.
