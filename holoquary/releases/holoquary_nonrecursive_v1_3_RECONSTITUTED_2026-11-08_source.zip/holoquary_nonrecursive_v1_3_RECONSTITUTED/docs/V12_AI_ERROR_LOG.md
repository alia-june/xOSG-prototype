# Holoquary v1.2 — AI-originated error register

**Scope:** assistant interpretation, contract design, implementation, and testing errors only. Do not conflate independent user code defects with AI errors.

- **AE-12-01 — Architectural conflation, acknowledged in current conversation.** Earlier assistant-proposed architectures counted uncertainty markers and error indicators together with arithmetic digits and treated the resulting 5/13/15 symbol counts as computational architectures. The user identified metadata/data conflation. **Correction:** distinct computational data, knowledge, execution, provenance types; legacy compatibility remains explicitly bounded. **Status:** interface correction implemented, project-wide replacement OPEN.
- **AE-12-02 — Compiler warning during implementation.** Initial additive `hqd_separation.c` compiled with GCC `-Werror` failed because two local bounds were not visibly initialized to the optimizer before the validated domain dispatch. **Correction:** initialize locals and rerun. **Status:** corrected; test evidence documented in report.
- **AE-12-03 — Implicit grade normalization at first draft.** A singleton possibility mask supplied with an unknown grade would silently discard the grade during exact-value normalization. **Correction:** reject nonzero grades for singleton and contradictory masks. **Status:** corrected, tested.

**No claim:** A passing test demonstrates neither independent validation of a declared source ID nor absence of unknown implementation errors.
