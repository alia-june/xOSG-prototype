# I-07 — Neural action-controller feasibility experiment

**Status:** Implemented in a strictly bounded synthetic **imitation** test. I-07 general-benefit admission gate NOT PASSED (no evidence of advantage or out-of-distribution generalization).

## Code and training

`src/hci_supervisor.{h,c}` holds a *separate* HNN 2–8–1 parameter bank of 33 learned values, with generation and step counters. No subordinate weight is read or modified. The model has two Boolean features:

- `x0`: current logical result is UNKNOWN.
- `x1`: one or more lessons are declared available **and** at least one compute unit remains.

The externally chosen supervised targets are a small, deterministic policy's actions encoded numerically: ANSWER=0, RETURN_UNKNOWN=0.5, APPLY_LESSON=1. It is trained on **all four possible feature combinations**; model scores below 0.25, below 0.75, and otherwise select the three action codes. Training uses the source `dnn_forward`, `dnn_backward_add`, and `dnn_step` and a candidate model copy with commit after numeric checks.

`hci_supervisor_propose()` accepts only source-completed, unconflicted, unchecked logic state frames with typed strong-Kleene values. It outputs a proposal and raw numeric score. `hci_supervisor_gate()` combines the earlier deterministic action gate with extra action-specific checks: correct truth context, available lessons, and nonzero budget. Neither a neural score nor a successful training loss grants execution authority or attests truth.

## Executed comparison

On the training-domain four-state policy, 32 seeds trained for 3000 batch-gradient steps each with learning rate 0.15. **128 of 128 in-sample decisions match the deterministic label**; all 32 seeds matched all four states. This is *not* a held-out validation set. The deterministic oracle itself also has 128/128 on its own four-case rule by definition. Therefore the model has **no demonstrated improvement** over that baseline, and adds inference/training cost not yet justified by independent measurement.

## Unresolved training gate

A useful controller requires an external dataset of realistic problem families, verified correct actions/results, a version- and lineage-safe feedback loop, admissible action labels, a fixed train/validation/test split and predeclared quantitative benefit criteria (verified answer rate, false answer count, compute cost and inspection bytes). The model may be disabled/replaced without affecting underlying QUICK/EXTENDED execution.

## Non-effects

No autonomous lesson mining, controller-generated truth labels, reward-based optimization, calibrated truth probabilities, raw subordinate-weight ingestion, or evidence of recursive general intelligence was created.
