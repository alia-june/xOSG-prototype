# v0.6 — Bounded next steps and hard wall

## Current stage disposition

- I-00 through I-05: reused and regression-tested. Existing sources/semantics not modified.
- I-06: bounded in-memory ERROR events and pure-reevaluation attempts *prototype*, not trusted recovery.
- I-07: 2–8–1 toy controller imitation executable, **benefit gate not established**.
- I-08: pure logic DAG recursive evaluation executable, **mixed neural/logic graph not implemented**.
- I-09: **blocked on processor/board, memory map, ABI, firmware/runtime and physical measurements**.

## Binding blockers — do not infer completion

1. **I06-W01 INPUT REPLAY:** capture immutable original input bytes in a scope/parameter/graph-bound snapshot; check digest and exact generations at a trust boundary; distinguish a changed-input operation from retrying original work.
2. **I06-W02 EFFECT AUTHORITY:** obtain trustworthy effect classification and actual completion/effect records; prevent a C callback from laundering arbitrary side effects or forged policy IDs into authorized recovery.
3. **I06-W03 DURABILITY:** introduce append-only replay-safe external journal/recovery ledger with crash-safe atomic receipts, audit continuity and independent validation.
4. **I07-W01 TRAINING ORACLE:** construct a separately checked multi-task controller dataset and predeclare holdout/metric/compute budgets; mere 4-case imitation does not pass the neural-controller benefit gate.
5. **I08-W01 COMPOSITION:** define explicit mixed-type input/output port binding, instance/definition maps, parameter bank sharing, invocation states, scheduling and effect boundaries before general mixed recursion.
6. **I09-W01 HARDWARE:** specify target processor ISA, board, RAM/flash limits, compiler, linker script and a measurable I/O/timing/energy harness. Freestanding host builds do not select hardware.
7. **SOURCE AUTHENTICATION:** build external independent validation for lesson/verifier provenance (v0.5) before using feedback for consequential training or recovery.
8. **EXTERNAL ATTESTATION:** produce externally inspectable source maps, schematics, trace contracts and a separate universal attester toolset; internal tests do not confer external attestation.

## Useful bounded follow-on experiments

- Compare verified answer/abstention/error/compute on real held-out logical problem families using the deterministic and learned policies with equal action/observation budgets.
- Add snapshot hashes to observed input records and reject mismatched input/parameter generation before calling a recovery function.
- Extend recursive evaluation with typed read-only neural leaves (not trainable) while retaining runtime source mapping and independent grant checks.
- Measure actual stack, graph traversal cost and memory consumption on a selected bare-metal target; determine whether 3.6-KB host `HCIRecoveryStore` is affordable.
- Add fuzzing, ASan/UBSan where supported, compiler matrix and hostile pointer/threat-model tests without treating them as proof of memory security.

**Do not promote I-07, I-08 general composition, trusted recovery or I-09 to DONE without new test artifacts and explicit acceptance.**

---

## User-directed expansion — all six next paths (2026-10-02)

The six branches below are registered as TODOs, **not** promoted to implemented or accepted universal design. Work from immutable v0.6 source; choose small, independently testable deltas. Preserve source, proposals, execution and external attestation as separate evidence classes.

### PATH A — Trusted recovery hardening [OPEN; PARTIAL v0.7]
- A01: Capture exact, immutable input representation; bind target holon, graph, parameter generation and source lineage to the evaluation. v0.7 adds fixed-capacity caller-owned typed snapshots and an **unkeyed corruption-detection checksum only**, not authenticated historical identity.
- A02: Refuse stale generations, changed payloads, mismatched scope and incorrect recovery targets before reevaluation.
- A03: Authenticate/independently attest original input capture, effect classification and recovery authority. **Not implemented.**
- A04: Append-only crash-safe journal, atomic receipts, durable preservation and independent validation. **Not implemented.**
- Acceptance: show *same-input* replay with evidence independent of mutable caller claims; prohibit unproved external-effect replay; preserve original failure and both outcomes.

### PATH B — Mixed recursive holons [OPEN; PARTIAL v0.7]
- B01: Typed base port contract for logical and numeric values, with explicit per-port numeric classification policy, source identity, invocation generation and count bounds. **Initial base-level v0.7 implementation.**
- B02: Read-only neural leaves inside recursively composed logic, with explicit binding, source mapping, fan-out, cycle/depth/budget checks and failure isolation. **Not implemented in recursive graph.**
- B03: Mixed composite nodes and parameter-bank ownership, instance vs definition semantics and invocation state; preserve v0.6 logic-only recursion as a baseline.
- B04: Trainable recursive composition, explicit parameter sharing, gradient fan-out, snapshot consistency and atomic update transactions.
- Acceptance: compare mixed recursive outputs with an independently checked flat reference over all selected truth/numeric boundary cases.

### PATH C — Neural controller benchmark [OPEN]
- C01: Independent multi-task fixtures, labeled permitted actions, holdout by *problem family*, oracle separation and predeclared acceptance criteria.
- C02: Equal-action/equal-state/equal-budget deterministic versus trained controller comparisons, with variance, latency, unresolved and verified-false rates.
- C03: Test L0 versus L1/L2/L3 inspection only where permissions and actual use case warrant it; account for permutation symmetries if raw weight arrays enter a learned model.
- C04: Ensure model proposals cannot alter gate policy, verifier, errors, evidence ledger, or training labels.
- Acceptance: independently demonstrated incremental value without increasing invalid action or incorrect definite result rates.

### PATH D — LESSONS lifecycle and resilience [OPEN]
- D01: Scope-bound observation -> candidate -> independent check -> admit/reject/retain pending. Preserve v0.5 source-provenance and event log contracts.
- D02: Lesson/anti-lesson source revisions, invalidation/revocation, retention, replay, expiry, dependency tracking and durable storage.
- D03: Negative cases and contradicted evidence must survive later successful runs; prevent feedback self-training and confidence-by-repetition.
- D04: Compare QUICK, extended deterministic inference and lessons-informed control on held-out fixtures.
- Acceptance: no unverified evidence promoted, no silent scope crossing, no erased negative record.

### PATH E — External independent attestation [OPEN]
- E01: Export definition/instance source maps, typed-port schemas, exact versions, input/parameter snapshot references, operation/event traces and reproducible checks.
- E02: Specify a separate universal attester / integrity reconstruction toolset; require independent verification of artifacts and proofs, not self-certification.
- E03: Include source digests, build metadata, observed tests, omission maps and recovery-of-recovery procedures.
- Acceptance: independently reconstruct selected execution outcomes from immutable external schematics with explicit proof ceilings.

### PATH F — Physical bare-metal target [BLOCKED: TARGET UNKNOWN]
- F01: Select specific ISA/board/ABI, memory regions, RAM/flash/stack limits, compiler/linker/startup and observable I/O.
- F02: Rebuild complete firmware; measure runtime, memory, stack depth, failures and resource use on physical hardware.
- F03: Compare minimal deterministic build against optional lessons, feedback, recovery and neural controller profiles.
- Acceptance: observed target behavior, not a host freestanding object report.

### Immediate base-level work [v0.7 candidate]
- BASE01: Add type-checked, fixed-capacity input snapshots; make numeric-to-logic conversion explicit *per port*; allow mixed logical/numeric inputs; preserve source kernels.
- BASE02: Validate complete invocation/generation bindings, bounds, finite numeric values and local payload checksum before an evaluation; all new public output commits are all-or-nothing on validation/runtime failure.
- BASE03: Implement a constrained pure-logic replay callback compatible with existing recovery ledger; refuse stale/modified snapshots and disallow implicit external-effect retry.
- BASE04: Compare new typed evaluation with unmodified NAND/XOR and neural reference; run compiler/sanitizer/freestanding/clean-archive regression. **Executed only when actual test receipt is produced.**
- BASE05: Follow up with authenticated input acquisition, dependency-aware multi-output resilience, mixed recursive graph nodes and fault-injection/snapshot lifetime tests; do not claim those from BASE01–04.

---

## v0.8 small composite family — user-directed extension

**Implemented candidate:** NAND-built NOT/AND/OR/NOR/XNOR, enabled switch, two-way MUX, DEMUX and logical guarded lock; separate one-bit, explicit-tick memory cell with generation checking. Consult `COMPOSITES_CONTRACT.md`. No change to the old three-valued NAND semantics or neural kernels.

**Next / open:**
- COMP-01: Compose switch, guarded lock and memory as named **instance-level** holons with source maps and typed control ports; retain exact instance versus definition identity and eliminate implicit authority from structural parenthood.
- COMP-02: Define an external ownership and synchronization contract for stateful cells, especially concurrent access and mutation between snapshots.
- COMP-03: Add multi-bit registers, addressable banks and state-transition transactions with atomic commit; distinguish software cell from physical electronics and hardware devices.
- COMP-04: Research domain-specific lock semantics (logic guard, stateful lock, capability gate, cryptographic lock, physical interlock) without conflating them.
- COMP-05: Support composite runtime types with named logic operators instead of flatten-only templates, while preserving a mapped executable DAG.
- COMP-06: Add per-output dependency-aware fault isolation for compound systems rather than globally failing all outputs on any unrelated conflict.
- COMP-07: Add typed memory events to LESSONS and ERROR; memory writes must not become automatically admitted knowledge.
- COMP-08: Extend the suite to compiler, sanitizer, snapshot, cycle, fault-injection, multi-cell transaction and eventual physical target tests; none should be claimed until executed.
- COMP-09: Reuse existing v0.7 typed-port classification when connecting a neural output to switch/lock/memory; classify explicitly and preserve provenance.


## BLOCK7 v1.1
The full user 3–1–3 seven-state task register is in `RADIX5_TODO.md` section B7. Preserve its distinction between structural source, optional numeric mapping, partial knowledge, and proof ceilings. Do not promote general recursion or external attestation on account of this additive base-level implementation.
