# Holoquary v1.0 — Higher logic executed-test report

**Date:** 2026-10-02. **Environment:** hosted x86-64/Linux container. **Status:** tests executed locally, not externally attested. Compilers: GCC and Clang, C99 warnings-as-errors. A freestanding host object is not a bootable firmware image.

## Actual v1.0 higher-logic suite

| Test | Observation |
|---|---|
| `make CC=gcc higher_test` | HIGHER_LOGIC_PASS assertions=139724 failures=0 |
| `make CC=clang higher_test` | HIGHER_LOGIC_PASS assertions=139724 failures=0 |
| `make CC=gcc higher_demo` | Prints six deterministic scenarios, including `(+1 >= U): TRUE`, `(U == U): UNKNOWN`, `min(U,-1): -1`, `max(U,+1): +1`, `case(U,+1,+1): +1`, `FALSE AND ERROR: ERROR`. |
| `make CC=gcc sanitized` | HIGHER_LOGIC_PASS assertions=139724 failures=0 under UBSan + bounds sanitizer in executed paths. |
| `make CC=gcc freestanding` | Combined freestanding host object has no unresolved external symbols. |
| `make CC=clang freestanding` | Combined freestanding host object has no unresolved external symbols. |

## Higher-logic coverage

- All 16 pairs of condition inputs across five binary connectives plus NOT, including strict E masking checks.
- All 25 pairs of TERNARY_UE symbols across six comparison predicates, checked against an independent per-value completion enumerator.
- All 25 pairs of PURE5 digits across six numeric comparisons.
- All five symbol-state cases for IS_ERROR, IS_UNKNOWN, IS_KNOWN, IS_ZERO and corresponding PURE5 tests.
- MIN/MAX for all 25 balanced TERNARY_UE pairs, independent completion oracle; conditional selection across all four conditions and 25 pairs of balanced branches.
- 625 two-trit balanced-word combinations and six comparison types, checked against separately enumerated possible whole-number values; sampled three-trit words and random PURE5 word comparisons up to length 32.
- 64 ternary-condition majority cases, BETWEEN tests for all 125 balanced-trit triples and 125 pure-digit triples.
- Programmable 25-entry PURE5 predicate table, including whole-table rejection when an unused entry contains E.
- Invalid domain, value, enum, pointer, length and bad-output mutation checks; a `HQ5_OK` with `HQX_ERROR` is not a non-OK C execution status.
- Test-discovered counterexample for unsound range-only equality, corrected and rerun.

**Important scope:** Exact completions are exhaustively enumerated for two-trit comparisons and sample subsets, not for every possible 32-trit word. The tests are not a formal proof of all future caller-supplied functions.

## Preserved v0.9 suites

`make CC=gcc test`, `make CC=clang test`: both pass for existing integration, feedback, recovery, toy supervisor, recursion, flexibility, gates/cells, radix and freestanding-memory-shim suites. Recorded counts from the executed development build:

| Suite | Result |
|---|---:|
| Neural/logic integration | 72,091 assertions |
| LESSONS feedback | 16,127 assertions |
| Recovery | 6,070 assertions |
| Experimental neural action imitation | 467 assertions |
| Logic-only recursion | 4,143 assertions |
| Base flexibility/resilience | 84,048 assertions |
| NAND-derived gates/switches and memory | 7,394 assertions |
| Pure radix5 and balanced-UE arithmetic | 220,147 assertions |
| Freestanding memory shim | 33,282 assertions |
| New higher-logic suite | **139,724 assertions** |

`make CC=gcc baseline` reproduced LESSONS 31,175 assertions and HNN gradient checks with max absolute difference 2.0056963e-05; the original Holoquary logic sub-suite was also run as part of that Makefile target. As with previous phases, test assertion counts are counts of test expressions rather than formal independent proofs.

## Provenance and source changes

A byte comparison against v0.9 found 115 previously existing non-build files unchanged. Three existing entrypoint/plan files intentionally differ: `Makefile`, `README.md`, `docs/RADIX5_TODO.md`. One pre-existing `baseline/.../topology_nn.o` object file was not carried into the source copy; it is a generated build output, and running the baseline rebuilds it. The new module and its tests are additive.

## Non-claims

- No physical bare-metal board execution; no measured hardware power/timing.
- No authorization/cryptographic locks, independent evidence verification, autonomous lessons or trained controller improvement.
- No changes to mixed recursion, stateful concurrency, durable memory, source authentication, or error recovery authority.
- No guarantee against hostile pointers or arbitrary memory corruption; sanitizers only cover executed test paths.
- `STRICT_E_OVER_K3` is a documented profile, not a universal theorem about how failures must propagate in every language/logic.
