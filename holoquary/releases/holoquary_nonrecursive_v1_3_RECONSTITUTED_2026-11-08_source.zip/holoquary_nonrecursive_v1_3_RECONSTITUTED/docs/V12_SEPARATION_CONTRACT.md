# Holoquary v1.2 — Value and metadata separation contract

**Status:** generated / host-tested candidate, not independently attested or accepted canon. **Provenance:** m.A.R.S. required computational-data/metadata separation; details of additive C interface generated for review. The operator's three UNKNOWN types are *not yet given formal semantics*; `unknown_grade` is a caller-provided label 0..3, not a confidence measurement.

## The boundary

| Lane | v1.2 representation | Cannot do |
|---|---|---|
| Computational payload | `HQDData {kind, number, logic}`; kind EXACT NUMBER / EXACT LOGIC / ABSENT | Invent numeric 0 from ABSENT or treat E as arithmetic operand |
| Numerical domain | BALANCED3 `[-1,+1]`, PURE5 `[0,4]`, BALANCED7 `[-3,+3]` | Reuse ordinals across domains as if numerically equivalent |
| Logical domain | KLEENE3: exact `HQ_FALSE`, `HQ_TRUE`, `HQ_UNKNOWN` | Convert logical UNKNOWN to numeric zero or missing number |
| Knowledge | Domain-bound possibility mask and opaque `unknown_grade` 0..3 | Assert truth or authenticity from a grade or source label |
| Execution | `COMPLETE`, `FAILED(error_code)`, `COMPLETION_UNKNOWN`; independent propagated legacy-E marker | Change in-band legacy E into proven execution failure |
| Provenance | Caller-declared source/scope/generation and UNATTESTED/CALLER/DERIVED_LOCAL tag | Authenticate a source or grant an action based on an identifier |

An **exact logical UNKNOWN** is a valid, completed computation in KLEENE3. An **absent numerical result** in BALANCED3 has data.kind=ABSENT and a set of possible trits. These are different data objects. A completed value with legacy E retains the E marker as metadata, with no numeric payload; any attempted arithmetic involving that marker is denied.

## Mathematical value and epistemic set

For a domain with ordered exact values `lo..hi`, bit `(v-lo)` represents possible numeric value `v`. Valid range masks are BALANCED3=3 bits, PURE5=5 bits, BALANCED7=7 bits, KLEENE3=3 bits. A singleton becomes an exact payload with grade 0. Multiple bits mean ABSENT exact payload, and a zero mask is a **contradiction** in available possibilities; zero numeric value is a distinct singleton bit. Unknown grade is 0 (unspecified) or 1..3 (explicit caller classification only); a nonzero grade on exact or contradictory values is rejected rather than silently normalized. A fully unknown mask may have a grade without implying any numerical conclusion. A mask is mathematical *possibility*, not epistemically authenticated evidence.

**No verified grade semantics.** The earlier illustrative U3 -> U2 -> U1 -> EXACT ordering is **not implemented** as a valid reasoning rule. Transitions require an explicit new constraint in `hqd_refine`. Intersection derives a result *relative to the supplied assumptions*, without making those assumptions independently authentic. The output provenance is DERIVED with zero source identifiers; this is not proof or audit lineage.

## Arithmetic and higher functions

`hqd_add_digits(a,b,out)` supports nonrecursive one-digit addition over NUMERICAL domains. For exact inputs it computes radix-correct digit and carry; for partial inputs it enumerates all independent completions and records a **joint** `uint32_t` digit/carry bitmap. A projection into separate digit/carry records is optional and **loses pairing**; consumers must not cross-multiply the marginals as if every pair occurred. PURE5 carry ∈{0,1}, BALANCED3 and BALANCED7 carry ∈{-1,0,+1}. There is no implicit carry-in at this new adapter, no multi-digit atomic register, and no recursion.

`hqd_compare` records a set of possible relations LT/EQ/GT for the two independently chosen operands. `hqd_relation_truth` explicitly abstracts that relation set to an exact Kleene predicate symbol F/T/U. Empty relation sets are refused rather than fabricating a truth value. `hqd_refine` intersects *knowledge constraints* for one domain; it is not numerical addition or a provenance verification. `hqd_get_number` allows only a completed, exact, non-E-marker numeric input. `hqd_guard_proposal` is **advisory**, not a security or physical authorization grant, and always returns 0 unless the exact computational domain is KLEENE3 with a completed definite TRUE and no error marker; caller provenance cannot make an unresolved result TRUE.

All new entry points validate type and condition invariants before committing output. Known caller buffers are assumed accessible and unmodified concurrently; there is no hostile-pointer, race or process isolation guarantee. In-place refinement is supported; results preserve output on failure under the declared accessible-buffer contract.

## Legacy bridge / non-collapse policy

- `hqd_from_hq5(PURE5 symbol 0..4)` maps to an exact PURE5 numerical value.
- `hqd_from_hq5(TERNARY_UE numeric ordinal 0..2)` maps to an exact BALANCED3 value -1/0/+1.
- `hqd_from_hq5(TERNARY_UE U)` yields ABSENT numeric data with full 3-bit possibilities.
- `hqd_from_hq5(TERNARY_UE E)` yields ABSENT numeric data with full possibilities and a **propagated legacy marker**. Execution remains COMPLETE because the marker alone does not attest runtime failure.
- Reverse `hqd_to_hq5` is exact-only by default; explicitly requesting ALLOW_U permits lossy conversion of any nonempty partial BALANCED3 mask to legacy U; ALLOW_E permits return of its legacy propagated E marker. Failed or uncertain execution, contradiction and nonmatching domains cannot silently be flattened into a legacy symbol.
- `hqd_from_hqx` maps legacy F/T/U to **exact logical** KLEENE3 symbols; legacy ERROR to ABSENT plus E marker. The opposite bridge likewise requires explicit lossy flags when information would be discarded.
- `hqd_from_hq7` / `hqd_to_hq7` transfer the v1.1 seven-bit knowledge set without rewriting the original BLOCK7 numerical structure. The proposed `2B+I` numeric map remains a candidate.

No implicit conversion from BALANCED3 to PURE5, to BALANCED7, or to numerical/float neural values. A future conversion holon must carry an explicit mathematical mapping, source relationship, and declared precision/overflow effects.

## Limits

Original `hq_radix5` and `hq_higher` source APIs still contain U/E markers. v1.2 wraps them; **whole-system replacement is not claimed**. Neither NINE nor FIFTEEN numerical logic has been implemented. An exact common possibility mask does not prove two operands denote the same hidden variable. Store state is volatile, provenance fields are not authenticated, and no firmware/physical hardware implementation is claimed.
