# v0.9 follow-up register — OPEN

- RAD-01: Define and externally validate explicit conversions PURE5 ↔ TERNARY_UE ↔ legacy HQTruth ↔ numerical neural outputs. No implicit meaning transfer between U and numeric zero or between E and runtime failures.
- RAD-02: Introduce independently specified **multi-digit multiplication**, subtraction, long division and signed/unsigned number serialization for PURE5; calculate actual resource budget and overflow policy.
- RAD-03: Add complete balanced ternary multi-digit multiplication, arithmetic shifts, normalization, comparison with U/E, and exact reference-oracle tests.
- RAD-04: Evaluate **set-valued unknown** instead of conservative U propagation where possible, with formal evidence for each refinement; preserve E marker lineage.
- RAD-05: Research and test alternative five-state truth/conditional policies; do not silently reinterpret ternary U/E as a five-digit quinary algebra.
- RAD-06: Add typed five-way and three-way switches as addressable composite instances in the mixed recursive Holoquary runtime; retain child source maps.
- RAD-07: Implement *atomic multi-symbol registers*, caller transaction receipts and durable journaling; existing `HQ5Cell` is only one in-process cell.
- RAD-08: Check state corruption, invalid pointer/alias policies, independent memory snapshot capture, replay authority, provenance, and recovery-of-recovery in external attestation scope.
- RAD-09: Benchmark byte-packing (5 levels need 3 binary bits in simple per-value coding), array encoding and physical ternary/quinary representation without assuming literal hardware wires have three or five levels.
- RAD-10: Select hardware if physical verification is desired; previous freestanding host object is not a booted embedded system.
- RAD-11: Extend LESSONS and ERROR feedback to retain typed U/E event provenance (a marker alone does not identify the failing invocation); no auto-admission.
- RAD-12: Compare pure five-digit logic LUTs with operation-specific TERNARY_UE tables and test each independently against complete specifications.

The v0.8 `docs/TODO.md` continues to apply; no earlier open work is removed.

## v1.0 higher-logic follow-up (2026-10-02)

- HL-01: Add optional explicit unknown-variable identity/binding, so correlated unknowns can be distinguished from independent U symbols. Current `U == U` is UNKNOWN by design.
- HL-02: Introduce typed output reports for U/E provenance and source witnesses; diagnostics must not be silently rewritten into authority.
- HL-03: Implement named immutable higher-function instance definitions and a nonrecursive composition catalog before reopening general recursion.
- HL-04: Provide pure5 condition-controlled selection with an explicit condition-outcome wrapper; do not coerce UNKNOWN/ERROR to an arbitrary 0..4 digit.
- HL-05: Explore alternate explicitly named semantics (K3, Ł3, error-dominant, weak/strict evaluation), with complete truth-table oracle and clearly documented conversion boundaries.
- HL-06: Extend higher comparisons to signed, externally versioned multi-register state, retaining whole-operation atomic publication.
- HL-07: Add tracked witness/lineage for mathematically definite conclusions derived from unresolved digits; a correct closed-world result is not proof of source authenticity.
- HL-08: Validate against additional compilers, physical targets, fuzzing and independent source oracle; no physical hardware measured yet.
- HL-09: Postpone generalized recursion until higher-function semantics and source maps are stabilized and explicitly accepted.

## B7 — User-proposed 3–1–3 seven-state substrate (2026-10-02)

**SOURCE / USER STRUCTURE:** block -1 contains inner -1/0/+1; block 0 contains only inner 0; block +1 contains inner -1/0/+1. This is seven **valid structured states**, not a statement that seven states are already numerical digits. Preserve invalid middle-block pairs as invalid rather than silently normalizing them.

**PROPOSAL / OPTIONAL NUMERIC PROFILE:** map `(block,inner)` to `digit = 2*block + inner` giving balanced digits -3..+3. This mapping and base-seven arithmetic are generated design proposals; arithmetic must have an explicitly selected profile.

- B7-01: Typed exact seven-state values, reversible (block,inner) mapping, and rejection of invalid middle-block pairs.
- B7-02: Separate set-valued partial knowledge: exact / proper partial / wholly UNKNOWN / CONTRADICTION. Retain all seven possibilities rather than confuse inner UNKNOWN with a fourth numerical digit.
- B7-03: Monotone evidence refinement by intersection; explicit inconsistent/empty-set disposition; retain prior input on invalid operations.
- B7-04: Exhaustive balanced-seven one-digit addition/multiplication, valid digit/carry decomposition and checked two-operand carry behavior.
- B7-05: Lift operations across independent possibilities; retain **joint digit/carry relationship**, not only separate marginal sets; test every singleton and all nonempty masks.
- B7-06: Ordered comparisons, blockwise selection, negation, typed memory with exact generation checks and transactionally committed word arithmetic.
- B7-07: Integrate as independent nonrecursive C99 module with source-provenance maps, named profiles and baseline invariance; compile/test GCC, Clang, sanitizer, freestanding host object, clean-package hashes.
- B7-08: Research/validate sharing identities for correlated unknowns, arbitrary set union/intersection policies, subset lineage witnesses, multi-cell atomic transactions, and external attestation before inference admission.
- B7-09: Later optionally add a `BLOCK7` type to the mixed holon port vocabulary, with explicit typed conversions to PURE5/TERNARY_UE and no rewriting of legacy NAND semantics.
- B7-10: Preserve generalized recursion as deferred until explicit higher-function contracts/source mapping and acceptance gates are satisfied.

**Scope boundary:** No automatic source authentication, trusted history, newly trained neural supervisor, physical seven-state circuits, physical bare-metal boot, or formal semantics outside the selected numeric profile are claimed by B7-01 through B7-07.

### B7 implementation disposition — v1.1 candidate

- **B7-01 / 02 / 03 / 04 / 05 / 06:** Implemented and exercised as defined in `BLOCK7_CONTRACT.md` and `BLOCK7_TEST_REPORT.md`; no source authentication, exact unknown correlation, or atomic multi-register storage asserted.
- **B7-07:** Additive, nonrecursive host C99 module passes executed compiler/sanitizer/freestanding-object checks; clean archive receipt follows package verification. General mixed-port runtime source mapping is still open.
- **B7-08 / 09 / 10:** OPEN. Deferred unknown correlation, evidence provenance and identity, typed conversion into general runtime, and recursion. Original seven-state structure preserved; selected arithmetic profile is generated design, not declared canonical by packaging.

---

## v1.2 — Corrective separation of computational data and metadata (operator-directed)

**User correction:** computational arithmetic symbols are not containers for epistemic or execution metadata. `U1/U2/U3` are not automatically values of radix 13/15, and `E` is not an arithmetic digit. Keep existing historical code intact while migrating through explicitly validated interfaces. See `V12_PLAN.md`, `V12_SEPARATION_CONTRACT.md`, and `V12_MIGRATION.md`.

- SEP-01 [CANDIDATE IMPLEMENTED]: Add `HQDRecord` split: data and domain / knowledge mask and opaque grade / execution and propagated marker / provenance.
- SEP-02 [CANDIDATE IMPLEMENTED]: Strict validation, explicit ABSENT vs zero, singleton masks, contradiction masks, Kleene logical UNKNOWN distinct from numerical missingness.
- SEP-03 [CANDIDATE IMPLEMENTED]: Explicit adapters from legacy `HQ5`, `HQX` and `HQ7`; require named lossy U/E bridge policies.
- SEP-04 [CANDIDATE IMPLEMENTED]: Nonrecursive lifted add and relation-set comparison, retaining paired digit/carry outcomes; prevent stale/error/invalid records from silently serving as arithmetic operands.
- SEP-05 [PARTIALLY VERIFIED]: Final GCC/Clang functional regressions, baseline tests, targeted new-module sanitizer, host freestanding objects and source comparison passed. Full inherited sanitizer target was interrupted by command timeout; clean-archive receipt documented in `V12_TEST_REPORT.md`. Do not claim full sanitizer coverage.
- SEP-06 [OPEN]: Migrate `HCIFrame`, HCI_FLEX ports, LESSONS and existing controller call sites to normalized types; no same-process source IDs may attest themselves.
- SEP-07 [OPEN]: Define operator-approved U1/U2/U3 meaning and gradient transition rules; preserve numerical possibilities separately from evidence quality.
- SEP-08 [OPEN]: General source correlations and evidence-based refinements, owner/generation binding, provenance DAG, immutable replay and external attester authority.
- SEP-09 [OPEN]: Decide whether NINE/FIFTEEN are numerical computation or block-local presentation; never treat UNKNOWN/ERROR as arithmetic digits by default.
- SEP-10 [DEFERRED]: General mixed recursion until SEP-06 through SEP-09 contracts and nonrecursive tests are adequately resolved.

**No accidental promotion:** Nonrecursive v1.2 interface tests do not establish autonomous learning, true authenticated locks, physical hardware, or trusted recovery.

---

## v1.3 — Operator-directed continuation: nonrecursive logic, state, resilience

- NR-01 **CANDIDATE IMPLEMENTED:** Strict typed higher functions NOT, AND, OR, XOR, implication, equivalence, majority, guarded conjunction. Keep strict failure/legacy-E denial and explicit Kleene-U versus epistemic logical set.
- NR-02 **CANDIDATE IMPLEMENTED:** Nonrecursive comparison-set and inclusive BETWEEN preserving correlation for a reused value inside one check; no general unknown identity resolution.
- NR-03 **CANDIDATE IMPLEMENTED:** Typed numeric/Kleene selectors, conservative selection on logical U, conditional memory tick.
- NR-04 **CANDIDATE IMPLEMENTED:** Up to four caller-owned memory cells in one all-preflighted, in-process failure-atomic tick, with generation and duplicate-ID rejection; no crash/concurrent durability claim.
- NR-05 **VERIFICATION:** GCC/Clang functional and original baseline suites, targeted sanitizers and host freestanding symbol checks, preserved source hashes, fresh archive; report exactly executed results in `V13_TEST_REPORT.md`.
- NR-06 **OPEN:** Multi-output source dependency maps, cross-expression correlation/unknown-variable identity, aliasing tests, stronger fault injection, synchronization, secure owner/source binding, durable/replay-safe transaction journal and external attestation.
- NR-07 **OPEN:** Named immutable reusable function instances with explicit source maps, capability-dependent action checks and typed LESSONS/ERROR event linkage; no implicit authority from a guard or local receipt.
- NR-08 **DEFERRED:** Recursion, SSMI/UPTI/Sisterhood integration, NINE/FIFTEEN semantics, U1/U2/U3 meanings, and physical hardware deployment. Preserve earlier TODOs unchanged.
