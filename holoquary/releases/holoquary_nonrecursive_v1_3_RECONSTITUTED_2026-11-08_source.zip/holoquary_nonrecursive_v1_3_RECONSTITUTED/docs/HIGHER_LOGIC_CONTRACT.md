# Holoquary v1.0 — Higher logic and predicate substrate

**Status:** Proposed interface; hosted test suite executed. **Attribution:** m.A.R.S. requested development direction; implementation synthesized by assistant. Not canonically adopted, not physically deployed, not independently attested.

## Scope and unchanged baselines

- Preserve PURE-5 arithmetic `0..4` and TERNARY-UE arithmetic `-1,0,+1,U,E` in `hq_radix5.{h,c}` unchanged.
- Preserve existing three-valued NAND/XOR logic, neural kernels, lesson bank, controllers, and recovery modules unchanged.
- Add `hq_higher.{h,c}`: typed predicates, strict-error condition operators, numeric-domain comparisons, range/majority and conditional data selection. This module has no heap, OS, I/O, memory state, recursion, learned parameters or hidden retry.
- No implicit conversion from a radix-5 digit or balanced ternary *zero* into `HQXCondition`.

## Distinct domains

| Domain | Values | Meaning |
| --- | --- | --- |
| `HQ5_DOMAIN_PURE5` | 0,1,2,3,4 | Ordinary nonnegative base-five digit values. |
| `HQ5_DOMAIN_TERNARY_UE` | -1,0,+1,U,E | Balanced numerical trits with in-band knowledge/failure markers. |
| `HQXCondition` | FALSE,TRUE,UNKNOWN,ERROR | Predicate *result* over a declared domain. Not another arithmetic radix. |
| `HQ5Status` | HQ5_OK / typed failures | C API validity and execution status, independent of predicate ERROR. |

`HQX_ERROR` is an in-band predicate outcome that may be returned with `HQ5_OK` (for example, comparing a value that carries an `E` marker); malformed pointers, mismatched domains, invalid enum values and bad lengths return a non-OK `HQ5Status` and preserve the caller output.

## Predicates

`hqx_test`: `EQ NE LT LE GT GE IS_ZERO IS_KNOWN IS_UNKNOWN IS_ERROR`.

- For PURE5, all valid comparisons produce definite TRUE/FALSE. `IS_UNKNOWN` and `IS_ERROR` are false; `IS_KNOWN` true. There is no numerical UNKNOWN digit.
- For balanced UE, `E` dominates all numerical predicates. `IS_ERROR` is an **explicit diagnostic** exception that detects the E marker and returns TRUE. `IS_UNKNOWN(E)` and `IS_KNOWN(E)` propagate ERROR; `IS_ZERO(U)=UNKNOWN`; `IS_UNKNOWN(U)=TRUE`; `IS_KNOWN(U)=FALSE`.
- `hqx_test` consumes operand B only for binary comparisons (`EQ...GE`). Unary predicates intentionally do not inspect B; callers must not treat an unused B as inspected or validated.
- Each U operand represents an independent unobserved trit in `{-1,0,+1}`. `U == U` is UNKNOWN unless an identity relation is separately established by a future subsystem. Shared-reference correlations are **not** represented by this API.

## Four-result connective profile: `STRICT_E_OVER_K3`

`hqx_not`, `hqx_connect`: NOT, AND, OR, XOR, material IMPLIES (`NOT a OR b`), EQUIV (`NOT XOR`). The T/F/U fragment uses strong-Kleene truth tables. E propagates strictly through every connective, including `FALSE AND ERROR = ERROR` and `TRUE OR ERROR = ERROR`.

This is **not** classical four-valued truth logic, a Belnap bilattice, or a claim that ERROR is truth-theoretically equivalent to a value. It is a named *failure-preserving predicate profile* that prevents calculation errors from being masked by absorbing logical terms. Operators are pure, and the caller may explicitly inspect an error marker via `IS_ERROR`; this does not confer recovery or authorization permission.

## Exact computations with UNKNOWN

- `hqx_balanced_order(MIN/MAX,a,b)`: evaluate the selected integer order function over all consistent completions of U; if every completion agrees, return the common numeric trit; otherwise return U. E dominates. Examples: `MIN(U,-1)=-1`; `MAX(U,+1)=+1`; `MIN(U,+1)=U`.
- `hqx_test` comparisons: enumerate/characterize the possible values. E dominates. Examples: `(+1 >= U)=TRUE`; `U == U=UNKNOWN`; `(U < -1)=FALSE`.
- `hqx_between(x,lo,hi)`: `(x >= lo) AND (x <= hi)` under the named strict-E condition profile; even invalid or reversed bounds retain their ordinary mathematical meaning (no silent bound sorting).
- `hqx_majority3`: FALSE if >=2 known FALSE, TRUE if >=2 known TRUE, UNKNOWN otherwise; ERROR if *any* input ERROR, even when two known votes agree. Majority here is a computational aggregation, not evidence validation or human vote adjudication.
- `hqx_select_condition(c,false_branch,true_branch)` accepts balanced UE branches only. A known TRUE/FALSE chooses one branch; UNKNOWN chooses an identical branch value if both agree, else E if either branch E, otherwise U; ERROR returns E. Known selection does not inspect an unselected branch's in-band E for propagation, but the API validates both branch representations and domains.

### Word comparisons

`hqx_test_word(op,domain,a,b,length,out)` accepts 1..32 little-endian digit arrays.

- PURE5: examine most-significant differing digit to compare complete numbers without integer overflow.
- TERNARY-UE: E in **any** operand digit dominates. For `< <= > >=`, compute exact attainable numerical lower/upper bounds of each word; these bounds suffice to establish universal truth/falsity for an ordering predicate.
- `==` and `!=` are **NOT computed by overlapping intervals**: possible balanced-ternary word values can be noncontiguous. Because balanced ternary has unique canonical digit representations, any position with two unequal *known* digits proves whole-word inequality, otherwise both words must be wholly known and identical to establish equality; if neither, the comparison is unresolved.
- The 32-trit interval calculation is bounded: 3^32 < 2^63. All digits are checked before publishing any result. Array pointers must reference valid accessible buffers; no memory-safety guarantee is made against hostile pointers or concurrent writers.

### Programmable PURE5 condition tables

`HQXPurePredicateTable` contains 25 checked outcomes. Its entries may be FALSE, TRUE, or UNKNOWN; `ERROR` is rejected at table validation because a caller-defined numeric lookup is not permitted to fabricate diagnostic failures. All 25 entries are validated even when only one entry is selected. Use source-governed named tables for specific applications. A table's UNKNOWN is an explicit unresolved *predicate output*, never a PURE5 digit.

## Resilience and authority boundaries

- All API functions validate relevant argument types and bounds before changing output on non-OK status.
- A legitimate `HQX_ERROR` condition or `HQ5_E` value is different from `HQ5_BAD_OPERATION` and from an unverified external side effect.
- A comparison or majority result is not external attestation, an authorization decision, or proof that the premise values came from real-world facts.
- This module makes no changes to recursive evaluator, source mapping, neural-controller policy, lesson admission, recovery or target-specific firmware.
