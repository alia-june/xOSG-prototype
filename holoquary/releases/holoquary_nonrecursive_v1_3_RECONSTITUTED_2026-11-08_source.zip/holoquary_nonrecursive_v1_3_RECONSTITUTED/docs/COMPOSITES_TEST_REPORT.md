# Holoquary v0.8 — Small composites executed test report

**Date:** 2026-10-02. **Environment:** hosted Linux x86-64 toolchain. **Status:** tests executed; no physical hardware execution, persistent storage attestation or independent security audit.

## New module tests

`tests/test_composites.c` reports **COMPOSITES_TESTS=PASS ASSERTIONS=7394** with GCC and Clang C99 strict warning/error builds, including the executed GCC undefined-behavior/bounds sanitizer build. Coverage:

- NAND-composed NOT, AND, OR, NOR, XNOR, and enabled switch against independent strong-Kleene reference equations: all nine two-input combinations per binary operation and all three NOT inputs.
- Consensus MUX behavior exhaustively across 27 three-valued combinations; `MUX(T,T,U)=T` and `MUX(F,F,U)=F` established. Each MUX result independently compared with an explicit one-bit memory tick over the same states.
- DEMUX both outputs across nine ternary combinations; guarded lock across 27 combinations including unknown; `hq_guard_allows` returns true only for a definite TRUE condition.
- Compounded XOR+MUX+guarded lock with two exported outputs for all 243 combinations of five ternary inputs in a 15-NAND graph; compare each result against an independently written reference expression.
- All new constructors tested for invalid references and null pointers; partial-capacity failures preserve source program gate counts and output reference values, including failures after intermediate candidate nodes were added.
- Memory cell: read, write, hold, uncertain write, explicit generation mismatch, invalid values, null output, generation overflow, invalid stored state, read-only snapshot, and 2,048 deterministic repetitions; on failed tick, cell and output remain unchanged.

## Existing tests reproduced

- Original Holoquary v0.1 truth tests: `OVERALL=PASS checks=20191`.
- Existing Holoquary v0.2 LESSONS suite: `LESSONS_TESTS=PASS assertions=31175`.
- Existing neural topology suite: all supported topology representational cases and gradient checks, observed maximum absolute difference `2.0056963e-05`.
- Integration suite: `INTEGRATION_PASS assertions=72091`.
- Feedback suite: `FEEDBACK_PASS assertions=16127`.
- Recovery suite: `RECOVERY_PASS assertions=6070`.
- Neural supervisor imitation suite: `SUPERVISOR_PASS assertions=467` (not a learned-benefit validation).
- Logic-only recursive suite: `RECURSIVE_PASS assertions=4143`.
- Base flexibility suite: `FLEX_RESILIENCE_PASS assertions=84048`.
- Freestanding memory shim: `SHIM_PASS assertions=33282`.
- GCC and Clang combined freestanding host-object build: `COMBINED_FREESTANDING_OBJECT_NO_EXTERNAL_SYMBOLS`.

`make test CC=gcc`, `make test CC=clang`, `make sanitized CC=gcc`, `make baseline CC=gcc`, `make freestanding CC=gcc` and `make freestanding CC=clang` executed successfully in the development directory. `make composites_demo` shows a non-authorizing UNKNOWN guarded lock and an explicitly ticked memory cell.

## Evidence boundaries

The tests do not prove absence of untested defects, mathematical universality of three-valued NAND, persistence beyond the owning process, crash-safe storage, thread safety, real-time behavior, cryptographic key authority, physical lock safety, independent attestation, memory fault resistance, or actual bare-metal processor execution. The code uses no dynamic allocation in the new modules, but stack and program footprint are compiler/target dependent. All cited assertion counts are test-harness assertion totals, not independent formal proofs.
