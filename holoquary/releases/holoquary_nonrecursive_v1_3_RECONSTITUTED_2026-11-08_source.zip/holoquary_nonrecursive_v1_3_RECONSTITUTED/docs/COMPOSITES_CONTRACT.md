# Holoquary v0.8 — Small gates, locks, switches and memory

**Maturity:** generated, hosted-tested prototype; not a canonical architectural lock. Existing Holoquary v0.2 and integrated v0.7 kernels are preserved. Current standalone logic is strong-Kleene TRUE/FALSE/UNKNOWN; evaluator failure is a separately typed status.

## Scope

Add a **pure combinational library** assembled entirely from existing NAND nodes and a **small stateful cell** with explicit, caller-owned sequential state. Composite templates are expanded into the original static `HQProgram` DAG. No changes to its evaluator, strong-Kleene truth tables, maximum capacities or cycle rejection.

## Gate and combinational families

| Template | Mathematical behavior | NAND count | Inputs |
|---|---|---:|---:|
| `hq_emit_not` | NOT A | 1 | 1 |
| `hq_emit_and` | A AND B | 2 | 2 |
| `hq_emit_or` | A OR B | 3 | 2 |
| `hq_emit_nor` | NOT (A OR B) | 4 | 2 |
| `hq_emit_xnor` | NOT XOR(A,B) | 5 | 2 |
| `hq_emit_switch` | DATA AND ENABLE | 2 | 2 |
| `hq_emit_mux` | select FALSE→A; TRUE→B; UNKNOWN→common definite branch or UNKNOWN | 7 | 3 |
| `hq_emit_demux` | DATA to one of two outputs via SELECT | 5 | 2 |
| `hq_emit_guarded_lock` | DATA AND KEY AND PERMISSION | 4 | 3 |

`hq_emit_xor` and `hq_add_nand` remain existing original primitives/templates. These functions return **unexported** internal `HQRef` outputs; callers explicitly `hq_export` the desired results. All multi-gate additions are transactional: on failure the caller's program and output references are unchanged. They do not allocate a runtime instance for each template. The static program still has at most 16 NAND nodes, eight inputs and four exported outputs.

## Three-valued switch semantics

`MUX(A,B,S)` implements a *consensus-extended* three-valued selector:

- S=FALSE: A;
- S=TRUE: B;
- S=UNKNOWN: if A and B are the same definite truth value, return that value; otherwise UNKNOWN.

The NAND implementation is `(A AND NOT S) OR (B AND S) OR (A AND B)`. The consensus term is essential under strong-Kleene semantics: naïve `(A AND NOT S) OR (B AND S)` returns UNKNOWN even when both branches are TRUE and the selector is UNKNOWN. This semantics is specific to this selected composite and should not be silently substituted for a different conditional operator in another logic profile.

`hq_emit_demux` is ordinary Kleene `DATA AND NOT SELECT` and `DATA AND SELECT`. It does **not** guarantee exclusivity of both outputs when SELECT is UNKNOWN. For DATA TRUE/SELECT UNKNOWN both outputs are UNKNOWN; no physical switching action is authorized from those values.

## Logical guard / lock

`hq_emit_guarded_lock(DATA,KEY,PERMISSION)` is a **logical conjunction of caller-supplied signals only**; `KEY` is not an authenticated key, `PERMISSION` is not an independent authorization grant, and this gate is neither a safe actuator driver nor access-control enforcement. Logical output can be UNKNOWN; `hq_guard_allows` returns 1 only for definite TRUE and 0 for FALSE/UNKNOWN/invalid. Preserve original three-valued output for diagnostics; collapsing it to `int` for a final action must never erase the source condition or replace a real authorization check.

## State and memory

`HQBitCell {value,generation}` holds one T/F/U value. `hq_bit_init` sets the value and generation=0, `hq_bit_read` observes it and returns its generation, and `hq_bit_tick` atomically evaluates `next=MUX(old,write_data,write_enable)` while requiring an exact expected generation. HOLD (`enable=FALSE`) increments the generation but preserves the value. WRITE (`enable=TRUE`) sets the value, including to UNKNOWN. Indeterminate enable preserves a common definite state/value, otherwise yields UNKNOWN; this conservatively represents both possible branches. A definite RESET is an ordinary WRITE(FALSE). A tick with bad data, stale generation or generation overflow must not modify the cell or output parameter. The cell uses caller-owned memory and has no hidden timing source.

A stateful memory cell is **not** represented by a feedback cycle in `HQProgram`. The current Holoquary evaluator is an acyclic combinational DAG. Memory state is applied on an explicit caller-controlled tick outside the graph. The cell is single-threaded; higher-level synchronization, owner identity, durable persistence, crash recovery, clock/tick authorization and authenticated snapshots remain open. A call to `hq_bit_init` resets generation, so reinitialization needs a new external instance generation to prevent old references being confused with new ones.

## Invariants and limitations

1. Existing Holoquary v0.2 logic kernel, lesson bank, neural kernel and v0.7 typed-port layer remain unchanged.
2. Pure templates use only `hq_add_nand` and the existing `hq_emit_xor`; `hq_eval` is the authority for combinational results.
3. No template introduces hidden global state, heap allocation, system time or operating-system dependencies.
4. No failed template may partially alter a program; no failed cell tick may alter cell state or output.
5. TRUE/FALSE/UNKNOWN remain logical values; ERROR is a distinct execution condition, not a fourth NAND truth state.
6. No fact can be inferred from an unverified external key, permission signal or learning outcome merely because it has the value TRUE.
7. Explicit resource boundaries continue to apply; `HQBitCell` persistence is in-memory only.
8. Hardware power/reset behavior, metastability, electrical tri-state switching, actual security enforcement, adversarial memory corruption, concurrent access, durable journaling, multi-bit atomic transactions and mixed neural/logic recursion are **not** established.
