# Holoquary v1.0 — Online research, source boundaries, pattern mine

**Date:** 2026-10-02. **Source status:** online primary/reference sources consulted during this pass; their findings are background evidence, not project-specific acceptance or imported code. Code in this archive is independently assistant-authored, not copied from linked repositories.

## Research progression

1. **Probe:** separate true radix-five arithmetic from balanced ternary and its U/E markers. The Moscow State University Setun historical account supports balanced `-1/0/+1` numerics and branch/word-level architectural patterns, not Holoquary's added U/E semantics.
2. **Theory test:** Stanford Encyclopedia of Philosophy's *Many-Valued Logic* confirms many distinct three-valued calculi. K3's conjunction, disjunction and negation do not uniquely determine other logical systems. Treat logic profiles as typed contracts.
3. **Refinement:** Cousot & Cousot's abstract-interpretation framework motivates reasoning about collections of possible concrete values. Here U maps to {-1,0,+1}; only return a definite answer if every supported completion agrees. This is our specifically defined policy, not a claim that the paper prescribed these exact Holoquary operations.
4. **Independent tests:** enumerated all 25 one-symbol input pairs for arithmetic-predicate families and the 5-state condition tables, all 625 two-trit pair combinations (including U/E) for six comparisons, selected three-trit cases, and large randomized PURE5 words.
5. **Test-driven correction:** original word-equality implementation used interval overlap to infer possible equality. Exhaustive completion enumeration found 226 assertion failures. Intervals can overlap without the sparse balanced-ternary completion sets sharing a representable number. Changed equality/inequality to test digit-level constraints. Subsequent test suites pass. This observed implementation failure is retained in `HIGHER_LOGIC_ERROR_LOG.md`.

## Web-grounded reference sources

- Russian Virtual Computer Museum / Moscow State University historians, *Development of ternary computers at Moscow State University*: https://www.computer-museum.ru/english/setun.htm
- Stanford Encyclopedia of Philosophy, *Many-Valued Logic*: https://plato.stanford.edu/entries/logic-manyvalued/
- Stanford Encyclopedia of Philosophy, *Truth Values*, K3 truth functions: https://plato.sydney.edu.au/entries/truth-values/
- Patrick & Radhia Cousot, *Abstract interpretation: a unified lattice model for static analysis of programs*, POPL 1977: https://www.di.ens.fr/~cousot/COUSOTpapers/POPL77.shtml
- H2 Labs, *zvm3: a balanced-ternary VM* (secondary modern engineering illustration of ternary sign-directed branching; no project code imported): https://labs.h2.io/zvm3/

## Mined patterns

- **P01 Domain-tag everything:** same 0..4 storage symbols have different mathematical meanings in PURE5 and TERNARY-UE.
- **P02 Separate truth from execution:** an E value, an ERROR predicate and a failed function call each need a separately typed location.
- **P03 Completion-preserving inference:** evaluate U by possible concrete values; retain a definite conclusion only if all completions support it.
- **P04 Strict error accountability:** error inputs do not disappear merely because a Boolean absorbing value appears in the same computation.
- **P05 Numeric bounds for order:** comparing minimum/maximum attainable whole-number values is sufficient for a universally quantified ordering test.
- **P06 Representation-aware equality:** exact digit constraints, not bounding-box overlap, are required for equality.
- **P07 Full specification validation:** validate every LUT cell before accepting any result.
- **P08 Pure higher functions:** make boolean connective, comparison, range, majority and conditional selection small, testable operations that do not require recursive runtime.

## Anti-patterns and anti-lessons

- **A01 Interval overlap proves possible equality:** FALSE in sparse digit-completion sets. Specific observed counterexample class discovered in tests.
- **A02 Assume two UNKNOWNs share one identity:** an unresolved marker alone contains no binding/reference information. `U==U` cannot be assumed TRUE.
- **A03 Treat balanced zero as UNKNOWN:** zero is a concrete numeric value in balanced ternary.
- **A04 Treat numeric PURE5 as a five-valued logic:** five arithmetic digits do not imply five truth statuses.
- **A05 Mask errors using Boolean short-circuit identities:** under selected STRICT_E policy, `FALSE AND ERROR` remains ERROR, while pure mathematical K3 still preserves ordinary `FALSE AND UNKNOWN = FALSE`.
- **A06 Let diagnostics authorize actions:** detection of `IS_ERROR(E)=TRUE` does not resolve the error or authorize recovery.
- **A07 Compare alternative three-valued implication operators without naming their logical profile:** K3 material implication is not the same truth table as Łukasiewicz L3 implication.
- **A08 Claim exhaustive validation for every word length or all possible arbitrary functions:** only the enumerated fixtures and randomized samples are executed.
- **A09 Promote local source IDs, outcomes or controller confidence to independent evidence:** a successful computation proves the result relative to its inputs and declared semantics, not the authenticity of those inputs.

## Atomics and pre-recursion molecules

| Atomic | Molecule / use |
|---|---|
| Domain tag | Numeric input and output contract |
| Four-outcome `HQXCondition` | T/F/U/E predicate representation |
| `hqx_test` | Compare, detect U/E or test zero |
| `hqx_connect` | Logical composition without general graph recursion |
| `hqx_balanced_order` | Uncertainty-preserving numeric min/max |
| `hqx_select_condition` | Decision switch over typed balanced data |
| `hqx_between` | Range guard |
| `hqx_majority3` | Three-condition vote/consensus (not independent verification) |
| `hqx_test_word` | Word-level conditional branch predicate |
| `hqx_table_pure` | User-declared 25-entry condition function |

**Suggested next gate:** build a small read-only *higher-function catalog* and verify its explicitly composed behavior, then design a separate instance/state runtime if needed. General recursion, durable state, authenticated locks and automatic lessons are not asserted by this pass.
