# Holoquary v1.3 reconstitution report

**Reconstitution date:** 2026-11-08  
**Status:** RECONSTITUTED SOURCE CANDIDATE — not claimed byte-identical to the lost 2026-10-02 v1.3 source archive.

## Evidence used

1. Complete preserved Holoquary v1.2 source archive: `holoquary_separated_v1_2_source.zip`.
2. Preserved v1.3 `V13_FUNCTION_CONTRACT.md`.
3. Preserved historical v1.3 `V13_TEST_REPORT.md`, retained here as `V13_HISTORICAL_TEST_REPORT.md`.
4. Preserved v1.3 `V13_AI_ERROR_LOG.md` and TODO material.

The original v1.3 source ZIP was not available in the active runtime when reconstitution began. The C source for `hqd_functions.*` and its tests were therefore reconstructed from the preserved contract on top of the byte-preserved v1.2 predecessor.

## Reconstructed module

Added:

- `src/hqd_functions.h`
- `src/hqd_functions.c`
- `tests/test_functions_reconstituted.c`
- `examples/demo_functions_reconstituted.c`

The reconstructed module implements the preserved v1.3 contract families:

- nonrecursive strong-Kleene NOT/AND/OR/XOR/IMPLIES/EQUIV/MAJORITY;
- diagnostic three-input guard;
- uncertainty-aware numeric relation sets;
- locally correlated inclusive BETWEEN;
- KLEENE3-controlled selection;
- caller-owned volatile cells;
- staged 1–4 cell transactions with stale-generation and duplicate-cell rejection.

## Current verification

Observed in the reconstitution environment:

- GCC strict C99 reconstructed suite: `V13_RECONSTITUTED_PASS assertions=187861`.
- Clang strict C99 reconstructed suite: `V13_RECONSTITUTED_PASS assertions=187861`.
- GCC targeted `undefined,bounds` sanitizer reconstructed suite: PASS, 187861 assertions.
- Complete inherited functional target: PASS under GCC.
- Complete inherited functional target: PASS under Clang.
- GCC freestanding combined host object: no unresolved symbols.
- Clang freestanding combined host object: no unresolved symbols.

The historical report records 857,664 v1.3 assertions on 2026-10-02. That historical count is preserved as evidence of the lost implementation and is **not** claimed for the reconstituted module. The current 187,861 count is the test evidence for this reconstruction.

## Preservation

Before updating this reconstitution README and manifest, 149 inherited v1.2 files compared byte-for-byte identical; only `Makefile` had been amended to include the reconstructed module. The computational kernels inherited from v1.2 were not rewritten.

## Boundaries

This reconstitution does not prove equivalence to every implementation detail of the lost v1.3 archive. It reconstructs the documented contract and reproduces the documented architectural boundaries. Historical and current test evidence are kept separate. No UPTI, SSMI, Sisterhood, expert-system mining, or post-v1.3 integration has been imported into this baseline.
