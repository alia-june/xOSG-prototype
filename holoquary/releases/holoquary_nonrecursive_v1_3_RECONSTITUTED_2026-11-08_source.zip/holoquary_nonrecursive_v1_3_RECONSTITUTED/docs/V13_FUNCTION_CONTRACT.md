# v1.3 contract — normalized higher functions and small state transactions

**Status:** additive C99 hosted-tested candidate. Not independently attested, accepted canon, physical firmware or a secure memory subsystem. v1.2 source code is unchanged.

## Interface and semantics

`src/hqd_functions.{h,c}` consumes and emits the historical v1.2 `HQDRecord` type. Computational domains are `BALANCED3`, `PURE5`, `BALANCED7`, and `KLEENE3`. A numerical payload is either exact or absent with a domain-bound possible-value mask. A logical payload may itself be exactly the Kleene symbol `UNKNOWN`; this is **not** the same as `ABSENT` with a mask of `{FALSE,TRUE}`.

| Function | Defined behavior | Restriction |
|---|---|---|
| `hqdn_logic` | NOT/AND/OR/XOR/IMPLIES/EQUIV/MAJORITY over strong-Kleene exact completions; enumerate epistemic alternatives | KLEENE3 only; no elevation of grade to truth |
| `hqdn_guard` | Strict three-input Kleene conjunction, retaining possible logical outcomes | Diagnostic, not authorization |
| `hqdn_compare_set` | For numerical input masks, enumerate `<`, `=`, `>` outcomes as possible FALSE and/or TRUE logical symbols | Returns `{F,T}`, **not** exact Kleene U, for unresolved predicate; contradictions propagate empty set |
| `hqdn_between` | Inclusive `lower <= value <= upper`; reuse each single completion of the value across both clauses | Supports three implemented numerical domains; does not infer external source correlations |
| `hqdn_select` | Definite Kleene F selects left; T selects right; logical U selects via v0.8 consensus ternary MUX for logical branches or unions numerical possibilities; selector uncertainty enumerated | Left/right same domain, selector KLEENE3; invalid/failed/unverified-E input rejected before selection |
| `hqdn_cell_init` | Sets positive cell instance ID, starting generation 1 and a validated, completed value | Caller-owned volatile cell; reinitialization needs a separate external epoch |
| `hqdn_cell_read` | Read state and generation together under single-threaded caller assumption | Cannot verify concurrent mutation |
| `hqdn_tick_transaction` | Preflight and stage 1–4 cell ticks; reject stale generation, duplicate pointer/instance, invalid domain/metadata, marker, overflow; commit all on success | Not crash-atomic, not thread-safe, not an authenticated receipt |

Strong Kleene logical primitives are composed using the unchanged `hq_nand`; the majority operation is `(A∧B)∨(A∧C)∨(B∧C)`. Each epistemic completion is tested independently. The independent truth-table tests do **not** establish arbitrary symbolic correlation, e.g. identity X−X=0 when X is used as two unrelated input records.

## Local correlation example

For a single `value ∈ {0,+1}`, `lower=+1`, `upper=0`, `hqdn_between` returns exact FALSE: no **single** completion can satisfy both comparisons. Separate computation of `(value≥+1)` and `(value≤0)` gives each a possible TRUE, and naive independent conjunction would spuriously include TRUE. `hqdn_between` preserves this correlation *inside one operation*. Across distinct input records/graph nodes, unknown-variable identity remains unresolved.

## Metadata and error boundary

All operators require structurally valid v1.2 records with `HQD_EXEC_COMPLETE` and no legacy E marker. Thus input errors cannot be hidden by a logically annihilating FALSE or zero, or by an unselected switch branch. A contradictory empty numeric possibility set returns an empty result set, **not** numerical zero or logical U. A logical exact U can yield a definite result under a sufficiently constraining gate, but that says nothing about external permission or data authenticity.

Outputs from computed functions carry `HQD_ORIGIN_DERIVED` with zero source identifiers, which does **not** constitute a complete lineage trace. Exact HOLD preserves cell metadata; definite WRITE preserves caller-supplied record metadata **without upgrading its authenticity**. Ambiguous WRITE produces a derived record with an empty source map. `U1/U2/U3` are opaque labels not copied into newly derived results; they have no ranking or transition semantics here.

## Transaction guarantees and limits

The `HQDNCell` contains `{instance_id, generation, HQDRecord state}`. `HQDNTick` contains a pointer, expected generation, selector and candidate write record. A definitely FALSE selector holds the old record, TRUE copies the write record, and logical U selects a conservative joined result. Successful ticks—including HOLD—advance generation by exactly one. Every preflight and computation completes before any cell or receipt is committed. Rejected calls do not modify caller-visible cells or receipts when all pointers are valid, mutually non-aliasing except repeated `cell` pointers which are explicitly rejected, and no concurrent writer mutates inputs. The implementation does not protect against hardware faults or process crash during the commit loop, malformed/hostile pointers, shared-memory races, stale identity from cell reinitialization, or unexpected aliasing with the receipt buffer. There is no durable transaction log or independent attestation.

Receipts contain IDs and before/after generation and mask summaries only. They are caller-controlled/local observations; they are not signed, remotely acknowledged, replay-safe, or authorized action grants. A full immutable source/capability binding remains future work.

## Capacity and deployment ceiling

Maximum four cell operations per local transaction. No heap use inside the new module. Build target `freestanding` generates and symbol-checks a **host** relocatable object, not board-specific executable firmware. Target ISA, stack measurements, crash fault injection, concurrent safety and authenticated transport remain unverified.
