# Holoquary v1.2 — Boundary correction plan

**Operator request:** separate computational data from epistemic, execution and structural metadata. No accepted definition of U1/U2/U3 was supplied; retain these as opaque metadata labels without automatic authority or grade ordering. **Scope:** additive pre-recursion stage, no change to legacy source semantics. Proposed implementation, not canon.

## Step register

| Step | Objective | Evidence / status |
|---|---|---|
| S-00 | Inventory conflated interfaces and immutable numerical/logical baselines | COMPLETE: `hq_radix5` contains in-band U/E, `hq_higher` in-band condition E, `hq_block7` set-mask separation already present. |
| S-01 | Define a typed envelope around computational data, knowledge, execution, provenance | IMPLEMENTED candidate: `src/hqd_separation.h`; source and type declarations are not authentication. |
| S-02 | Add numeric and logical invariants, exact/missing distinction, validation | IMPLEMENTED candidate: canonical singleton mask and exact value consistency; contradiction is mask 0. |
| S-03 | Build explicit adapters, prohibit silent U/E arithmetic promotion | IMPLEMENTED candidate: explicit `hq5`, `hqx`, `hq7` bridges; U/E export requires named lossy policy, runtime failure cannot be encoded as legacy E. |
| S-04 | Lift finite arithmetic through knowledge without treating metadata as numeric | IMPLEMENTED candidate: nonrecursive add/compare/refine; joint carry/digit outcome preserved before optional projection. |
| S-05 | Exhaustive test and integrated regression | Report results *only after actual execution* in `V12_TEST_REPORT.md`. |
| S-06 | Migration: replace legacy module call sites by validated wrapper one family at a time | OPEN: existing kernels preserved; architecture-wide migration is not complete. |
| S-07 | Source-map authority, correlation of shared unknown variables, independent attestation | OPEN / requires explicit trust and effect contracts. |
| S-08 | Revisit NINE/FIFTEEN presentation, gradations, higher functions | OPEN: do not count U/E as radix digits or infer grade semantics. |
| S-09 | General mixed recursion | DEFERRED until explicit acceptance and validated nonrecursive bindings. |

## Acceptance invariants

1. Mathematical domain and computational payload determine valid arithmetic; source IDs, grades, error markers and execution fields never act as digits.
2. Missing numerical data is represented by an explicit ABSENT field plus set of possible values, never by numeric zero or a sentinel number.
3. A completed operation that encountered a legacy `E` marker is not labeled as a verified runtime failure; the marker remains separate.
4. Failed/completion-unknown operations do not supply numerical inputs to lifted arithmetic or refinement.
5. A caller-supplied uncertainty grade may annotate an unresolved value but cannot change the result of a fixed possibility mask.
6. Strong-Kleene UNKNOWN remains a *real symbol* of its explicitly named logical calculus, not the same as an absent numerical input.
7. Conversion policies are named and lossy conversions are explicitly requested. No silent crossing of PURE5, BALANCED3, BALANCED7 or KLEENE3.
8. Metadata and local-derived provenance are not attestation, independent verification, grants, or side-effect authorization.
