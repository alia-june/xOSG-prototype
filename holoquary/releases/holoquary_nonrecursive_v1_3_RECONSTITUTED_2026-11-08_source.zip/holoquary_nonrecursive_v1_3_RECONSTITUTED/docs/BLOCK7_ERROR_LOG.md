# BLOCK7 observed implementation/error log

No new runtime defect is claimed absent a failing executed fixture.

## Risk register (not observed defects)

- A raw `HQ7Set` bitmask cannot authenticate evidence or retain why a possibility was removed.
- Flattening unknown results to a single U symbol discards block-level information.
- Treating projected digit and carry masks as an independent pair would create spurious numerical outcomes. The current module retains a joint 21-bit relation.
- A selector bitmask does not imply the unknown branches share one underlying variable.
- Multiple independent one-cell ticks are not a multi-cell atomic transaction.
- Caller-controlled snapshots and callbacks do not establish external trust or safe replay.

These are current design constraints, not fabricated bug reports.
