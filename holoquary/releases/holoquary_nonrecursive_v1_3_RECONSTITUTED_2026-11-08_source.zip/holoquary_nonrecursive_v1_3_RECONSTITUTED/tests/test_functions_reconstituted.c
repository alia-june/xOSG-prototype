#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "hqd_functions.h"

static unsigned long long checks=0;
#define CHECK(x) do { ++checks; if(!(x)) { printf("FAIL line=%d expr=%s\n",__LINE__,#x); return 1; } } while(0)

static unsigned bit(HQDDomain d,int v) {
    int lo=0;
    switch(d){case HQD_BALANCED3:lo=-1;break;case HQD_PURE5:lo=0;break;case HQD_BALANCED7:lo=-3;break;case HQD_KLEENE3:lo=0;break;default:return 0;}
    return 1u << (unsigned)(v-lo);
}
static HQDRecord rec(HQDDomain d,unsigned mask) {
    HQDRecord r;
    if(hqd_possibilities(d,mask,0u,&r)!=HQD_OK) { memset(&r,0,sizeof(r)); }
    return r;
}
static HQTruth k_not_ref(HQTruth a){return a==HQ_FALSE?HQ_TRUE:a==HQ_TRUE?HQ_FALSE:HQ_UNKNOWN;}
static HQTruth k_and_ref(HQTruth a,HQTruth b){if(a==HQ_FALSE||b==HQ_FALSE)return HQ_FALSE;if(a==HQ_UNKNOWN||b==HQ_UNKNOWN)return HQ_UNKNOWN;return HQ_TRUE;}
static HQTruth k_or_ref(HQTruth a,HQTruth b){if(a==HQ_TRUE||b==HQ_TRUE)return HQ_TRUE;if(a==HQ_UNKNOWN||b==HQ_UNKNOWN)return HQ_UNKNOWN;return HQ_FALSE;}
static HQTruth k_xor_ref(HQTruth a,HQTruth b){if(a==HQ_UNKNOWN||b==HQ_UNKNOWN)return HQ_UNKNOWN;return a==b?HQ_FALSE:HQ_TRUE;}
static HQTruth eval_ref(HQDNLogicOp op,HQTruth a,HQTruth b,HQTruth c){
    switch(op){
    case HQDN_NOT:return k_not_ref(a);
    case HQDN_AND:return k_and_ref(a,b);
    case HQDN_OR:return k_or_ref(a,b);
    case HQDN_XOR:return k_xor_ref(a,b);
    case HQDN_IMPLIES:return k_or_ref(k_not_ref(a),b);
    case HQDN_EQUIV:return k_not_ref(k_xor_ref(a,b));
    case HQDN_MAJORITY:return k_or_ref(k_or_ref(k_and_ref(a,b),k_and_ref(a,c)),k_and_ref(b,c));
    default:return HQ_UNKNOWN;
    }
}
static unsigned logic_ref_mask(HQDNLogicOp op,unsigned am,unsigned bm,unsigned cm){
    unsigned m=0; int a,b,c;
    for(a=0;a<3;a++) if(am&(1u<<a)) {
        if(op==HQDN_NOT){m|=1u<<(unsigned)eval_ref(op,(HQTruth)a,HQ_FALSE,HQ_FALSE);continue;}
        for(b=0;b<3;b++) if(bm&(1u<<b)) {
            if(op!=HQDN_MAJORITY){m|=1u<<(unsigned)eval_ref(op,(HQTruth)a,(HQTruth)b,HQ_FALSE);continue;}
            for(c=0;c<3;c++) if(cm&(1u<<c))m|=1u<<(unsigned)eval_ref(op,(HQTruth)a,(HQTruth)b,(HQTruth)c);
        }
    }
    return m;
}
static int test_logic(void){
    unsigned am,bm,cm; int op; HQDRecord a,b,c,o;
    for(op=HQDN_NOT;op<=HQDN_MAJORITY;op++)
      for(am=0;am<8;am++) for(bm=0;bm<8;bm++) for(cm=0;cm<8;cm++) {
        a=rec(HQD_KLEENE3,am); b=rec(HQD_KLEENE3,bm); c=rec(HQD_KLEENE3,cm);
        CHECK(hqdn_logic((HQDNLogicOp)op,&a,&b,&c,&o)==HQD_OK);
        CHECK(o.knowledge.possibilities==logic_ref_mask((HQDNLogicOp)op,am,bm,cm));
        CHECK(o.domain==HQD_KLEENE3);
        CHECK(o.provenance.origin==HQD_ORIGIN_DERIVED);
      }
    return 0;
}
static int bounds(HQDDomain d,int *lo,int *hi){switch(d){case HQD_BALANCED3:*lo=-1;*hi=1;return 1;case HQD_PURE5:*lo=0;*hi=4;return 1;case HQD_BALANCED7:*lo=-3;*hi=3;return 1;default:return 0;}}
static unsigned cmp_ref(HQDDomain d,unsigned am,unsigned bm,HQDRelation rel){
    int lo=0,hi=0,a,b;unsigned m=0;if(!bounds(d,&lo,&hi))return 0;
    for(a=lo;a<=hi;a++) {
        if(!(am&bit(d,a))) continue;
        for(b=lo;b<=hi;b++) {
            int y;
            if(!(bm&bit(d,b))) continue;
            y=rel==HQD_LT ? a<b : rel==HQD_EQ ? a==b : a>b;
            m|=1u<<(unsigned)(y?HQ_TRUE:HQ_FALSE);
        }
    }
    return m;
}
static int test_compare(void){
    HQDDomain ds[3]={HQD_BALANCED3,HQD_PURE5,HQD_BALANCED7};unsigned lim[3]={8,32,128};int di;unsigned a,b;int r;HQDRecord ar,br,o;
    for(di=0;di<3;di++) {
        for(a=0;a<lim[di];a++) {
            for(b=0;b<lim[di];b++) {
                for(r=HQD_LT;r<=HQD_GT;r<<=1) {
                    ar=rec(ds[di],a);
                    br=rec(ds[di],b);
                    CHECK(hqdn_compare_set((HQDRelation)r,&ar,&br,&o)==HQD_OK);
                    CHECK(o.knowledge.possibilities==cmp_ref(ds[di],a,b,(HQDRelation)r));
                }
            }
        }
    }
    return 0;
}
static unsigned between_ref(HQDDomain d,unsigned vm,unsigned lm,unsigned um){int lo=0,hi=0,v,l,u;unsigned m=0;if(!bounds(d,&lo,&hi))return 0;for(v=lo;v<=hi;v++)if(vm&bit(d,v))for(l=lo;l<=hi;l++)if(lm&bit(d,l))for(u=lo;u<=hi;u++)if(um&bit(d,u))m|=1u<<(unsigned)((l<=v&&v<=u)?HQ_TRUE:HQ_FALSE);return m;}
static int test_between(void){
    HQDDomain ds[2]={HQD_BALANCED3,HQD_PURE5}; unsigned lim[2]={8,32};int di;unsigned v,l,u;HQDRecord vr,lr,ur,o;
    for(di=0;di<2;di++)for(v=0;v<lim[di];v++)for(l=0;l<lim[di];l++)for(u=0;u<lim[di];u++){
        vr=rec(ds[di],v);lr=rec(ds[di],l);ur=rec(ds[di],u);CHECK(hqdn_between(&vr,&lr,&ur,&o)==HQD_OK);CHECK(o.knowledge.possibilities==between_ref(ds[di],v,l,u));
    }
    /* local-correlation counterexample from preserved v1.3 contract */
    vr=rec(HQD_BALANCED3,bit(HQD_BALANCED3,0)|bit(HQD_BALANCED3,1));
    lr=rec(HQD_BALANCED3,bit(HQD_BALANCED3,1)); ur=rec(HQD_BALANCED3,bit(HQD_BALANCED3,0));
    CHECK(hqdn_between(&vr,&lr,&ur,&o)==HQD_OK); CHECK(o.knowledge.possibilities==bit(HQD_KLEENE3,HQ_FALSE));
    return 0;
}
static unsigned mux_ref_logic(unsigned sm,unsigned fm,unsigned tm){
    int f,t; unsigned m=0;
    if(sm & (1u<<HQ_FALSE)) m |= fm;
    if(sm & (1u<<HQ_TRUE)) m |= tm;
    if(sm & (1u<<HQ_UNKNOWN))
        for(f=0;f<3;f++) if(fm&(1u<<f))
            for(t=0;t<3;t++) if(tm&(1u<<t))
                m |= 1u << (unsigned)(f==t ? f : HQ_UNKNOWN);
    return m;
}
static int test_select(void){
    unsigned s,a,b;HQDRecord sr,ar,br,o;
    for(s=0;s<8;s++)for(a=0;a<8;a++)for(b=0;b<8;b++){sr=rec(HQD_KLEENE3,s);ar=rec(HQD_KLEENE3,a);br=rec(HQD_KLEENE3,b);CHECK(hqdn_select(&sr,&ar,&br,&o)==HQD_OK);CHECK(o.knowledge.possibilities==mux_ref_logic(s,a,b));}
    for(s=0;s<8;s++)for(a=0;a<8;a++)for(b=0;b<8;b++){sr=rec(HQD_KLEENE3,s);ar=rec(HQD_BALANCED3,a);br=rec(HQD_BALANCED3,b);CHECK(hqdn_select(&sr,&ar,&br,&o)==HQD_OK);unsigned exp=0;if(s&1u)exp|=a;if(s&2u)exp|=b;if(s&4u)exp|=a|b;CHECK(o.knowledge.possibilities==exp);}
    return 0;
}
static int test_errors(void){
    HQDRecord f,t,o,bad;int allow=123;HQDNCell c;HQDNTick tk;HQDNTickReceipt rr={99,99,99,99,99};
    CHECK(hqd_exact_logic(HQ_FALSE,&f)==HQD_OK); CHECK(hqd_exact_logic(HQ_TRUE,&t)==HQD_OK);
    bad=t; bad.data.kind=HQD_ABSENT; bad.data.logic=HQ_FALSE; bad.knowledge.possibilities=7u; bad.execution.state=HQD_EXEC_FAILED; bad.execution.error_code=7;
    CHECK(hqd_validate(&bad)==HQD_OK);
    CHECK(hqdn_logic(HQDN_AND,&f,&bad,0,&o)==HQD_DENIED);
    CHECK(hqd_guard_proposal(&f,&allow)==HQD_OK); CHECK(allow==0);
    CHECK(hqdn_cell_init(&c,11,&t)==HQD_OK);
    tk.cell=&c;tk.expected_generation=99;tk.selector=f;tk.write=t;
    CHECK(hqdn_tick_transaction(&tk,1,&rr)==HQD_DENIED);CHECK(c.generation==1);CHECK(rr.instance_id==99);
    return 0;
}
static int test_cells(void){
    HQDNCell c[3],before[3];HQDRecord f,t,u,n0,n1;HQDNTick ticks[3];HQDNTickReceipt recs[3];unsigned i;
    CHECK(hqd_exact_logic(HQ_FALSE,&f)==HQD_OK);CHECK(hqd_exact_logic(HQ_TRUE,&t)==HQD_OK);CHECK(hqd_exact_logic(HQ_UNKNOWN,&u)==HQD_OK);
    CHECK(hqd_exact_number(HQD_BALANCED3,0,&n0)==HQD_OK);CHECK(hqd_exact_number(HQD_BALANCED3,1,&n1)==HQD_OK);
    CHECK(hqdn_cell_init(&c[0],1,&n0)==HQD_OK);CHECK(hqdn_cell_init(&c[1],2,&n0)==HQD_OK);CHECK(hqdn_cell_init(&c[2],3,&n0)==HQD_OK);
    ticks[0]=(HQDNTick){&c[0],1,t,n1}; ticks[1]=(HQDNTick){&c[1],1,f,n1}; ticks[2]=(HQDNTick){&c[2],1,u,n1};
    CHECK(hqdn_tick_transaction(ticks,3,recs)==HQD_OK);
    CHECK(c[0].state.knowledge.possibilities==bit(HQD_BALANCED3,1));CHECK(c[1].state.knowledge.possibilities==bit(HQD_BALANCED3,0));CHECK(c[2].state.knowledge.possibilities==(bit(HQD_BALANCED3,0)|bit(HQD_BALANCED3,1)));
    for(i=0;i<3;i++){CHECK(c[i].generation==2);CHECK(recs[i].before_generation==1);CHECK(recs[i].after_generation==2);}
    memcpy(before,c,sizeof(c));
    ticks[0].expected_generation=2;ticks[1].expected_generation=999;ticks[2].expected_generation=2;
    memset(recs,0xA5,sizeof(recs));
    CHECK(hqdn_tick_transaction(ticks,3,recs)==HQD_DENIED);CHECK(memcmp(c,before,sizeof(c))==0);for(i=0;i<sizeof(recs);i++)CHECK(((unsigned char*)recs)[i]==0xA5);
    ticks[0]=(HQDNTick){&c[0],2,t,n1};ticks[1]=(HQDNTick){&c[0],2,t,n1};memset(recs,0x5A,sizeof(recs));
    CHECK(hqdn_tick_transaction(ticks,2,recs)==HQD_BAD_METADATA);CHECK(memcmp(c,before,sizeof(c))==0);
    return 0;
}
int main(void){
    if(test_logic()) return 1;
    if(test_compare()) return 1;
    if(test_between()) return 1;
    if(test_select()) return 1;
    if(test_errors()) return 1;
    if(test_cells()) return 1;
    printf("V13_RECONSTITUTED_PASS assertions=%llu\n",checks);return 0;
}
