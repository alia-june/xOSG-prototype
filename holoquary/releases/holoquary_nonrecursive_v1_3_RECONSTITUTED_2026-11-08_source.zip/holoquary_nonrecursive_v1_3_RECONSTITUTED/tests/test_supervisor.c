#include "hci_supervisor.h"
#include <stdio.h>

static unsigned int checks=0u;
#define CHECK(x) do {++checks;if(!(x)){fprintf(stderr,"SUP_FAIL line=%u: %s\n",(unsigned)__LINE__,#x);return 1;}}while(0)
static HCIFrame frame(unsigned int unknown,unsigned int budget,unsigned int snap) {
    HCIFrame f={0};
    f.identity=(HCIIdentity){2u,6u,3u,0u,snap};
    f.kind=HCI_LOGIC;
    f.execution=HCI_COMPLETED;
    f.result_kind=HCI_RESULT_LOGIC;
    f.source_status=HQ_OK;
    f.disposition=HCI_UNCHECKED;
    f.truth=unknown?HQ_UNKNOWN:HQ_TRUE;
    f.input_count=2u;
    f.compute_remaining=budget;
    return f;
}
static HCIAction label(unsigned int unknown,unsigned int lessons) {
    return !unknown?HCI_ACT_ANSWER:lessons?HCI_ACT_APPLY_LESSON:HCI_ACT_RETURN_UNKNOWN;
}
static int verify_four(const HCINeuralSupervisor *s,unsigned int *valid,unsigned int *matches) {
    unsigned int i;
    *matches=0u;*valid=0u;
    for(i=0u;i<4u;++i) {
        unsigned int unknown=i>>1u, lessons=i&1u;
        HCIFrame f=frame(unknown,1u,100u+i);
        HCIGrant grant={0};
        HCIProposal p;
        float y=999.0f;
        grant.target_holon_id=f.identity.holon_id;
        grant.action_mask=HCI_ACTION_BIT(HCI_ACT_ANSWER)|HCI_ACTION_BIT(HCI_ACT_APPLY_LESSON)|
                          HCI_ACTION_BIT(HCI_ACT_RETURN_UNKNOWN);
        grant.max_budget=1u;
        CHECK(hci_supervisor_propose(s,&f,lessons,&p,&y)==HCI_OK);
        CHECK(y==y && y<3.0f && y>-3.0f);
        *matches+=(unsigned int)(p.action==label(unknown,lessons));
        if(hci_supervisor_gate(&p,&f,&grant,lessons)==HCI_OK) ++*valid;
        else CHECK(p.action!=label(unknown,lessons));
    }
    return 0;
}
static int test_training(void) {
    unsigned int seed, total_matches=0,all_four=0,matched,allowed;
    HCINeuralSupervisor s;
    HCIFrame f;
    HCIProposal p, prior={0};
    float score;
    HCIGrant grant={0};
    for(seed=1u;seed<=32u;++seed) {
        CHECK(hci_supervisor_init(&s,seed)==HCI_OK);
        CHECK(s.generation==1u && s.trained_steps==0u);
        CHECK(hci_supervisor_train_imitation(&s,3000u,0.15f)==HCI_OK);
        CHECK(s.generation==2u && s.trained_steps==3000u);
        CHECK(verify_four(&s,&allowed,&matched)==0);
        total_matches+=matched;
        all_four+=(unsigned int)(matched==4u);
        CHECK(allowed<=matched);
    }
    printf("SUPERVISOR_IMITATION samples=4 seeds=32 matches=%u/128 complete_seeds=%u/32\n",total_matches,all_four);
    CHECK(hci_supervisor_init(&s,1u)==HCI_OK);
    f=frame(1u,1u,600u);
    CHECK(hci_supervisor_propose(&s,&f,1u,&p,&score)==HCI_ERR_INVALID);
    CHECK(hci_supervisor_train_imitation(&s,3000u,0.15f)==HCI_OK);
    CHECK(hci_supervisor_propose(&s,&f,1u,&p,&score)==HCI_OK);
    grant.target_holon_id=2u;grant.action_mask=HCI_ACTION_BIT(HCI_ACT_APPLY_LESSON);
    grant.max_budget=1u;
    /* A learned score cannot bypass the independent control gate. */
    prior=p;f.identity.graph_gen++;
    CHECK(hci_supervisor_gate(&p,&f,&grant,1u)==HCI_ERR_STALE);
    f.identity.graph_gen--;
    CHECK(hci_supervisor_gate(&p,&f,&grant,1u)==HCI_OK);
    grant.action_mask=0u;
    CHECK(hci_supervisor_gate(&p,&f,&grant,1u)==HCI_ERR_DENIED);
    grant.action_mask=HCI_ACTION_BIT(HCI_ACT_APPLY_LESSON);
    CHECK(hci_supervisor_gate(&p,&f,&grant,0u)==HCI_ERR_DENIED);
    CHECK(p.action==prior.action);
    f.execution=HCI_FAILED;
    CHECK(hci_supervisor_propose(&s,&f,1u,&p,&score)==HCI_ERR_INVALID);
    f.execution=HCI_COMPLETED;f.disposition=HCI_CONFLICT;
    CHECK(hci_supervisor_propose(&s,&f,1u,&p,&score)==HCI_ERR_INVALID);
    f.disposition=HCI_UNCHECKED;f.source_status=HQ_ERR_VALUE;
    CHECK(hci_supervisor_propose(&s,&f,1u,&p,&score)==HCI_ERR_INVALID);
    f.source_status=HQ_OK;f.kind=HCI_NEURAL;
    CHECK(hci_supervisor_propose(&s,&f,1u,&p,&score)==HCI_ERR_INVALID);
    f.kind=HCI_LOGIC;f.compute_remaining=0u;
    CHECK(hci_supervisor_propose(&s,&f,1u,&p,&score)==HCI_OK);
    CHECK(hci_supervisor_gate(&p,&f,&grant,1u)==HCI_ERR_DENIED ||
          hci_supervisor_gate(&p,&f,&grant,1u)==HCI_ERR_BUDGET);
    CHECK(hci_supervisor_train_imitation(&s,0u,0.15f)==HCI_ERR_INVALID);
    CHECK(hci_supervisor_train_imitation(&s,1u,0.0f)==HCI_ERR_INVALID);
    CHECK(hci_supervisor_train_imitation(&s,1u,0.6f)==HCI_ERR_INVALID);
    return 0;
}
int main(void) {
    CHECK(test_training()==0);
    printf("SUPERVISOR_PASS assertions=%u\n",checks);
    return 0;
}
