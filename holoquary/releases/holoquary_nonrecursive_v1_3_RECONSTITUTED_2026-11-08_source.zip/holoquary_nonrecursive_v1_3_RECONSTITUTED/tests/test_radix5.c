#include "hq_radix5.h"
#include <stdio.h>
#include <stdint.h>
#include <limits.h>

static unsigned long long checks=0;
static int failures=0;
#define CHECK(x) do { ++checks; if (!(x)) { \
  ++failures; if (failures < 12) fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x); \
} } while (0)
static HQ5Value pure(unsigned v) { HQ5Value x; x.domain=HQ5_DOMAIN_PURE5; x.symbol=(uint8_t)v; return x; }
static HQ5Value bal(unsigned v) { HQ5Value x; x.domain=HQ5_DOMAIN_TERNARY_UE; x.symbol=(uint8_t)v; return x; }
static int ieq(HQ5Value a,HQ5Value b) { return a.domain==b.domain && a.symbol==b.symbol; }
static unsigned ref_add_bal(unsigned a,unsigned b,unsigned c,unsigned *result_carry) {
    int sum, carry=0, digit;
    if (a==HQ5_E || b==HQ5_E || c==HQ5_E) { *result_carry=HQ5_E; return HQ5_E; }
    if (a==HQ5_U || b==HQ5_U || c==HQ5_U) { *result_carry=HQ5_U; return HQ5_U; }
    sum=(int)a+(int)b+(int)c-3;
    if (sum >= 2) carry=1;
    if (sum <= -2) carry=-1;
    digit=sum-3*carry;
    *result_carry=(unsigned)(carry+1);
    return (unsigned)(digit+1);
}
static unsigned ref_mul_bal(unsigned a,unsigned b) {
    if (a==HQ5_E || b==HQ5_E) return HQ5_E;
    if (a==HQ5_Z || b==HQ5_Z) return HQ5_Z;
    if (a==HQ5_U || b==HQ5_U) return HQ5_U;
    return (unsigned)(((int)a-1)*((int)b-1)+1);
}
static uint32_t rnd=0x542916f3u;
static uint32_t next_random(void) {
    rnd^=rnd<<13; rnd^=rnd>>17; rnd^=rnd<<5; return rnd;
}
static void test_representation(void) {
    unsigned v,d;
    HQ5Value out=pure(4);
    for(d=1;d<=2;d++) for(v=0;v<5;v++) {
        CHECK(hq5_make((HQ5Domain)d,v,&out)==HQ5_OK);
        CHECK(out.domain == (HQ5Domain)d);
        CHECK(out.symbol==v);
        CHECK(hq5_validate(out)==HQ5_OK);
    }
    out=pure(3);
    CHECK(hq5_make((HQ5Domain)99,3,&out)==HQ5_BAD_DOMAIN);
    CHECK(ieq(out,pure(3)));
    CHECK(hq5_make(HQ5_DOMAIN_PURE5,5,&out)==HQ5_BAD_VALUE);
    CHECK(ieq(out,pure(3)));
    CHECK(hq5_make(HQ5_DOMAIN_PURE5,3,0)==HQ5_NULL);
    CHECK(hq5_validate(pure(6))==HQ5_BAD_VALUE);
    CHECK(hq5_validate((HQ5Value){(HQ5Domain)8,0})==HQ5_BAD_DOMAIN);
    CHECK(sizeof(HQ5Value) >= 2u);
}
static void test_pure(void) {
    unsigned a,b,c,co,s;
    int cmp;
    HQ5Value dig=pure(0);
    HQ5PureTable2 table;
    table.domain=HQ5_DOMAIN_PURE5;
    for(a=0;a<25;a++) table.symbols[a]=(uint8_t)((a/5u+a%5u)%5u);
    for(a=0;a<5;a++) for(b=0;b<5;b++) {
        CHECK(hq5_cmp_pure(pure(a),pure(b),&cmp)==HQ5_OK);
        CHECK(cmp==(int)((a>b)-(a<b)));
        CHECK(hq5_table2_pure(&table,pure(a),pure(b),&dig)==HQ5_OK);
        CHECK(ieq(dig,pure((a+b)%5u)));
        for(c=0;c<2;c++) {
            co=999;
            CHECK(hq5_add_pure(pure(a),pure(b),c,&dig,&co)==HQ5_OK);
            s=a+b+c;
            CHECK(ieq(dig,pure(s%5u)));
            CHECK(co==s/5u);
        }
        for(c=0;c<5;c++) {
            co=999;
            CHECK(hq5_mul_pure(pure(a),pure(b),c,&dig,&co)==HQ5_OK);
            s=a*b+c;
            CHECK(ieq(dig,pure(s%5u)));
            CHECK(co==s/5u);
        }
    }
    dig=pure(3); co=177; cmp=177;
    CHECK(hq5_add_pure(pure(0),bal(0),0,&dig,&co)==HQ5_BAD_DOMAIN);
    CHECK(ieq(dig,pure(3)) && co==177);
    CHECK(hq5_add_pure(pure(2),pure(3),2,&dig,&co)==HQ5_BAD_CARRY);
    CHECK(ieq(dig,pure(3)) && co==177);
    CHECK(hq5_mul_pure(pure(2),pure(3),5,&dig,&co)==HQ5_BAD_CARRY);
    CHECK(ieq(dig,pure(3)) && co==177);
    CHECK(hq5_cmp_pure(pure(1),bal(2),&cmp)==HQ5_BAD_DOMAIN);
    CHECK(cmp==177);
    CHECK(hq5_cmp_pure(pure(1),pure(2),0)==HQ5_NULL);
    table.symbols[24]=7;
    CHECK(hq5_table2_pure(&table,pure(0),pure(0),&dig)==HQ5_BAD_VALUE);
    CHECK(ieq(dig,pure(3)));
    CHECK(hq5_table2_pure(0,pure(0),pure(0),&dig)==HQ5_NULL);
    table.symbols[24]=3;
    table.domain=HQ5_DOMAIN_TERNARY_UE;
    CHECK(hq5_table2_pure(&table,pure(0),pure(0),&dig)==HQ5_BAD_DOMAIN);
    CHECK(ieq(dig,pure(3)));
    {
        HQ5Value bs[5];
        unsigned x,y,z,w,t;
        /* Exhaust all 5^5 branch combinations for all five selectors. */
        for(x=0;x<5;x++) for(y=0;y<5;y++) for(z=0;z<5;z++)
        for(w=0;w<5;w++) for(t=0;t<5;t++) {
            bs[0]=pure(x); bs[1]=pure(y); bs[2]=pure(z);
            bs[3]=pure(w); bs[4]=pure(t);
            for(a=0;a<5;a++) {
                CHECK(hq5_select_pure(pure(a),bs,&dig)==HQ5_OK);
                CHECK(ieq(dig,bs[a]));
            }
        }
        bs[4]=bal(2); dig=pure(4);
        CHECK(hq5_select_pure(pure(0),bs,&dig)==HQ5_BAD_DOMAIN);
        CHECK(ieq(dig,pure(4)));
        CHECK(hq5_select_pure(bal(0),bs,&dig)==HQ5_BAD_DOMAIN);
        CHECK(ieq(dig,pure(4)));
    }
}
static void test_balanced(void) {
    unsigned a,b,c,correct_c,correct,d;
    HQ5Value dig=bal(HQ5_Z),carry=bal(HQ5_Z),out=bal(HQ5_Z),bs[3];
    for(a=0;a<5;a++) {
        CHECK(hq5_neg_balanced(bal(a),&out)==HQ5_OK);
        CHECK(out.symbol==(a <= 2u ? 2u-a : a));
        for(b=0;b<5;b++) {
            CHECK(hq5_mul_balanced(bal(a),bal(b),&out)==HQ5_OK);
            CHECK(ieq(out,bal(ref_mul_bal(a,b))));
            CHECK(hq5_cmp_balanced(bal(a),bal(b),&out)==HQ5_OK);
            correct=(a==HQ5_E||b==HQ5_E) ? HQ5_E :
                    (a==HQ5_U||b==HQ5_U) ? HQ5_U :
                    (unsigned)(((int)a>(int)b)-((int)a<(int)b)+1);
            CHECK(ieq(out,bal(correct)));
            for(c=0;c<5;c++) {
                correct=ref_add_bal(a,b,c,&correct_c);
                CHECK(hq5_add_balanced(bal(a),bal(b),bal(c),&dig,&carry)==HQ5_OK);
                CHECK(ieq(dig,bal(correct)));
                CHECK(ieq(carry,bal(correct_c)));
                if (a<3 && b<3 && c<3) {
                    /* Invariant: a+b+carryin = low_trit+3*out_carry. */
                    CHECK((int)a+(int)b+(int)c-3 ==
                         (int)dig.symbol-1+3*((int)carry.symbol-1));
                }
            }
        }
    }
    for(a=0;a<5;a++) for(b=0;b<5;b++) for(c=0;c<5;c++) {
        bs[0]=bal(a);bs[1]=bal(b);bs[2]=bal(c);
        for(d=0;d<5;d++) {
            unsigned r;
            if(d<3) r=bs[d].symbol;
            else if(d==HQ5_E) r=HQ5_E;
            else if(a==b && b==c) r=a;
            else if(a==HQ5_E||b==HQ5_E||c==HQ5_E) r=HQ5_E;
            else r=HQ5_U;
            CHECK(hq5_select_balanced(bal(d),bs,&out)==HQ5_OK);
            CHECK(ieq(out,bal(r)));
        }
    }
    CHECK(hq5_mul_balanced(bal(HQ5_Z),bal(HQ5_U),&out)==HQ5_OK);
    CHECK(ieq(out,bal(HQ5_Z)));
    CHECK(hq5_mul_balanced(bal(HQ5_Z),bal(HQ5_E),&out)==HQ5_OK);
    CHECK(ieq(out,bal(HQ5_E)));
    out=bal(HQ5_P);
    CHECK(hq5_neg_balanced(pure(2),&out)==HQ5_BAD_DOMAIN);
    CHECK(ieq(out,bal(HQ5_P)));
    CHECK(hq5_cmp_balanced(bal(3),pure(3),&out)==HQ5_BAD_DOMAIN);
    CHECK(ieq(out,bal(HQ5_P)));
    CHECK(hq5_add_balanced(bal(0),bal(0),pure(1),&dig,&carry)==HQ5_BAD_DOMAIN);
    CHECK(hq5_add_balanced(bal(0),bal(0),bal(1),&dig,&dig)==HQ5_BAD_OPERATION);
    CHECK(hq5_add_balanced(bal(6),bal(0),bal(1),&dig,&carry)==HQ5_BAD_VALUE);
    CHECK(hq5_select_balanced(bal(0),0,&out)==HQ5_NULL);
    CHECK(ieq(out,bal(HQ5_P)));
}
static void test_words(void) {
    HQ5Value a[HQ5_MAX_WORD],b[HQ5_MAX_WORD],out[HQ5_MAX_WORD];
    unsigned length,i,round,carry,expected,ci,expected_c;
    HQ5Value bcarry=bal(HQ5_Z);
    for(round=0;round<5000;round++) {
        length=1u+next_random()%HQ5_MAX_WORD;
        ci=next_random()%2u;
        for(i=0;i<length;i++) {
            a[i]=pure(next_random()%5u);
            b[i]=pure(next_random()%5u);
            out[i]=pure(4);
        }
        carry=ci;
        CHECK(hq5_add_word_pure(a,b,length,ci,out,&expected_c)==HQ5_OK);
        for(i=0;i<length;i++) {
            unsigned s=(unsigned)a[i].symbol+(unsigned)b[i].symbol+carry;
            expected=s%5u;carry=s/5u;
            CHECK(ieq(out[i],pure(expected)));
        }
        CHECK(carry==expected_c);
        /* Exact in-place aliasing is supported; arbitrary overlap is not. */
        for(i=0;i<length;i++) a[i]=out[i];
        carry=0;
        CHECK(hq5_add_word_pure(a,b,length,0,a,&expected_c)==HQ5_OK);
        for(i=0;i<length;i++) {
            unsigned s=(unsigned)out[i].symbol+(unsigned)b[i].symbol+carry;
            CHECK(ieq(a[i],pure(s%5u))); carry=s/5u;
        }
        CHECK(carry==expected_c);
    }
    {
        unsigned a0,b0,c0,k;
        for(a0=0;a0<5;a0++) for(b0=0;b0<5;b0++) for(c0=0;c0<5;c0++) {
            for(k=0;k<8;k++) {
                a[k]=bal((a0+k)%5u);
                b[k]=bal((b0+k)%5u);
                out[k]=bal(HQ5_Z);
            }
            CHECK(hq5_add_word_balanced(a,b,8,bal(c0),out,&bcarry)==HQ5_OK);
            ci=c0;
            for(k=0;k<8;k++) {
                expected=ref_add_bal((a0+k)%5u,(b0+k)%5u,ci,&expected_c);
                CHECK(ieq(out[k],bal(expected)));
                ci=expected_c;
            }
            CHECK(ieq(bcarry,bal(ci)));
        }
    }
    /* Reject the whole candidate word rather than publishing a prefix. */
    for(i=0;i<4;i++) { a[i]=pure(1);b[i]=pure(2);out[i]=pure(4); }
    b[3]=bal(2);carry=98;
    CHECK(hq5_add_word_pure(a,b,4,0,out,&carry)==HQ5_BAD_DOMAIN);
    for(i=0;i<4;i++) CHECK(ieq(out[i],pure(4)));
    CHECK(carry==98);
    CHECK(hq5_add_word_pure(a,b,0,0,out,&carry)==HQ5_BAD_OPERATION);
    CHECK(hq5_add_word_pure(a,b,HQ5_MAX_WORD+1u,0,out,&carry)==HQ5_BAD_OPERATION);
    CHECK(hq5_add_word_pure(0,b,4,0,out,&carry)==HQ5_NULL);
    for(i=0;i<4;i++) { a[i]=bal(HQ5_Z);b[i]=bal(HQ5_Z);out[i]=bal(HQ5_E); }
    b[3]=pure(0);bcarry=bal(HQ5_E);
    CHECK(hq5_add_word_balanced(a,b,4,bal(HQ5_Z),out,&bcarry)==HQ5_BAD_DOMAIN);
    for(i=0;i<4;i++) CHECK(ieq(out[i],bal(HQ5_E)));
    CHECK(ieq(bcarry,bal(HQ5_E)));
}
static void test_number_level(void) {
    unsigned a0,a1,b0,b1,ci,c;
    HQ5Value a[2],b[2],out[2];
    HQ5Value bc;
    /* Independent whole-number check of all 625 two-digit base-5 pairs. */
    for(a0=0;a0<5;a0++) for(a1=0;a1<5;a1++)
    for(b0=0;b0<5;b0++) for(b1=0;b1<5;b1++)
    for(ci=0;ci<2;ci++) {
        unsigned actual,expected;
        a[0]=pure(a0);a[1]=pure(a1);
        b[0]=pure(b0);b[1]=pure(b1);
        CHECK(hq5_add_word_pure(a,b,2,ci,out,&c)==HQ5_OK);
        actual=(unsigned)out[0].symbol+5u*(unsigned)out[1].symbol+25u*c;
        expected=a0+5u*a1+b0+5u*b1+ci;
        CHECK(actual==expected);
    }
    /* Independent integer check of known balanced-ternary words. */
    for(a0=0;a0<3;a0++) for(a1=0;a1<3;a1++)
    for(b0=0;b0<3;b0++) for(b1=0;b1<3;b1++)
    for(ci=0;ci<3;ci++) {
        int actual,expected;
        a[0]=bal(a0);a[1]=bal(a1);
        b[0]=bal(b0);b[1]=bal(b1);
        CHECK(hq5_add_word_balanced(a,b,2,bal(ci),out,&bc)==HQ5_OK);
        actual=((int)out[0].symbol-1)+3*((int)out[1].symbol-1)+9*((int)bc.symbol-1);
        expected=((int)a0-1)+3*((int)a1-1)+((int)b0-1)+3*((int)b1-1)+((int)ci-1);
        CHECK(actual==expected);
    }
}
static void test_cells(void) {
    unsigned domain,sym,gen;
    HQ5Cell cell;
    HQ5Value val,old;
    for(domain=1;domain<=2;domain++) for(sym=0;sym<5;sym++) {
        HQ5Value starting = domain==1?pure(sym):bal(sym);
        CHECK(hq5_cell_init(&cell,starting)==HQ5_OK);
        CHECK(hq5_cell_read(&cell,&val,&gen)==HQ5_OK);
        CHECK(ieq(val,starting) && gen==0u);
        old=starting;val=pure(4);
        CHECK(hq5_cell_tick(&cell,0,HQ5_HOLD,bal(HQ5_E),&val)==HQ5_OK);
        CHECK(ieq(val,starting) && cell.generation==1u);
        CHECK(hq5_cell_tick(&cell,0,HQ5_WRITE,old,&val)==HQ5_STALE);
        CHECK(ieq(val,starting) && cell.generation==1u);
        CHECK(hq5_cell_tick(&cell,1,HQ5_WRITE,domain==1?bal(1):pure(1),&val)==HQ5_BAD_DOMAIN);
        CHECK(ieq(val,starting) && cell.generation==1u);
        CHECK(hq5_cell_tick(&cell,1,HQ5_WRITE,old,&val)==HQ5_OK);
        CHECK(ieq(val,starting) && cell.generation==2u);
        CHECK(hq5_cell_tick(&cell,2,HQ5_RESET,bal(HQ5_E),&val)==HQ5_OK);
        CHECK(ieq(val,domain==1?pure(0):bal(HQ5_Z)) && cell.generation==3u);
        old=val;
        CHECK(hq5_cell_tick(&cell,3,(HQ5Tick)77,starting,&val)==HQ5_BAD_OPERATION);
        CHECK(ieq(cell.value,old) && cell.generation==3u);
        cell.generation=UINT32_MAX;
        CHECK(hq5_cell_tick(&cell,UINT32_MAX,HQ5_HOLD,old,&val)==HQ5_EXHAUSTED);
        CHECK(cell.generation==UINT32_MAX);
    }
    CHECK(hq5_cell_init(&cell,pure(2))==HQ5_OK);
    val=pure(4);
    CHECK(hq5_cell_tick(&cell,0,HQ5_WRITE,pure(7),&val)==HQ5_BAD_VALUE);
    CHECK(ieq(val,pure(4)) && ieq(cell.value,pure(2)) && cell.generation==0u);
    CHECK(hq5_cell_tick(&cell,0,HQ5_HOLD,pure(0),0)==HQ5_NULL);
    CHECK(hq5_cell_read(&cell,0,&gen)==HQ5_NULL);
    CHECK(hq5_cell_read(&cell,&val,0)==HQ5_NULL);
    CHECK(hq5_cell_init(0,pure(0))==HQ5_NULL);
    CHECK(hq5_cell_init(&cell,pure(8))==HQ5_BAD_VALUE);
}
int main(void) {
    test_representation();test_pure();test_balanced();test_words();test_number_level();test_cells();
    printf("RADIX5_TESTS=%s ASSERTIONS=%llu\n",failures?"FAIL":"PASS",checks);
    return failures?1:0;
}
