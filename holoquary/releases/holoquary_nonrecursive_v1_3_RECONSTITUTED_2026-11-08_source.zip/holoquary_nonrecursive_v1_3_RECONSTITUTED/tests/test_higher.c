#include "hq_higher.h"
#include <stdio.h>
#include <stdint.h>
#include <limits.h>

static unsigned long long assertions;
static int failures;
#define C(q) do {++assertions;if(!(q)){++failures;if(failures<20)fprintf(stderr,"FAIL:%d %s\n",__LINE__,#q);}}while(0)
static HQ5Value P(unsigned n){HQ5Value v={HQ5_DOMAIN_PURE5,(uint8_t)n};return v;}
static HQ5Value B(unsigned n){HQ5Value v={HQ5_DOMAIN_TERNARY_UE,(uint8_t)n};return v;}
static int V(HQ5Value a,HQ5Value b){return a.domain==b.domain && a.symbol==b.symbol;}
static uint32_t seed=0xa8339117u;
static uint32_t rand32(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static int raw_pred(HQXPredicate p,int64_t a,int64_t b){
    switch(p){case HQX_EQ:return a==b;case HQX_NE:return a!=b;
        case HQX_LT:return a<b;case HQX_LE:return a<=b;
        case HQX_GT:return a>b;case HQX_GE:return a>=b;
        default:return -1;}
}
static int known_sym(unsigned s){return s<=2u;}
/* Independent possible-world reference: for each unresolved operand,
 * enumerate all three values independently; answer definite only if every
 * possible assignment agrees. These functions do not call production code. */
static HQXCondition oracle_one(HQXPredicate p,unsigned a,unsigned b){
    int first=-1,i,j,found=0;
    if(a==HQ5_E || b==HQ5_E)return HQX_ERROR;
    for(i=-1;i<=1;i++){
        if(known_sym(a) && i!=(int)a-1)continue;
        for(j=-1;j<=1;j++){
            int v;
            if(known_sym(b) && j!=(int)b-1)continue;
            v=raw_pred(p,i,j);
            if(found && first!=v)return HQX_UNKNOWN;
            first=v;found=1;
        }
    }
    return first?HQX_TRUE:HQX_FALSE;
}
static int complete_word(const HQ5Value *word,unsigned len,unsigned idx,
                         int64_t accum,int64_t *values,unsigned *count){
    unsigned i;
    if(idx==len){values[(*count)++]=accum;return 1;}
    for(i=0;i<3u;i++){
        if(word[idx].symbol<=2u && i!=word[idx].symbol)continue;
        complete_word(word,len,idx+1,accum+(int64_t)((int)i-1)*
                      (idx==0 ? 1 : idx==1 ? 3 : 9),values,count);
    }
    return 1;
}
static HQXCondition oracle_word(HQXPredicate p,const HQ5Value *a,
                                const HQ5Value *b,unsigned len){
    int first=-1,seen=0;
    unsigned i,j,na=0,nb=0;
    int64_t av[27],bv[27];
    for(i=0;i<len;i++)if(a[i].symbol==HQ5_E || b[i].symbol==HQ5_E)return HQX_ERROR;
    complete_word(a,len,0,0,av,&na);
    complete_word(b,len,0,0,bv,&nb);
    for(i=0;i<na;i++)for(j=0;j<nb;j++){
        int v=raw_pred(p,av[i],bv[j]);
        if(seen && first!=v)return HQX_UNKNOWN;
        seen=1;first=v;
    }
    return first ? HQX_TRUE : HQX_FALSE;
}
static void test_conditions(void){
    unsigned a,b,p,op;
    HQXCondition c=HQX_ERROR,n=HQX_FALSE;
    for(a=0;a<4;a++){
        C(hqx_not((HQXCondition)a,&c)==HQ5_OK);
        C(c==(a==HQX_FALSE?HQX_TRUE:a==HQX_TRUE?HQX_FALSE:(HQXCondition)a));
        for(b=0;b<4;b++)for(op=0;op<=HQX_EQUIV;op++){
            HQXCondition expect;
            C(hqx_connect((HQXConnective)op,(HQXCondition)a,(HQXCondition)b,&c)==HQ5_OK);
            if(a==HQX_ERROR||b==HQX_ERROR)expect=HQX_ERROR;
            else if(op==HQX_AND)expect=(a==HQX_FALSE||b==HQX_FALSE)?HQX_FALSE:
                    (a==HQX_UNKNOWN||b==HQX_UNKNOWN)?HQX_UNKNOWN:HQX_TRUE;
            else if(op==HQX_OR)expect=(a==HQX_TRUE||b==HQX_TRUE)?HQX_TRUE:
                    (a==HQX_UNKNOWN||b==HQX_UNKNOWN)?HQX_UNKNOWN:HQX_FALSE;
            else if(op==HQX_IMPLIES)expect=(a==HQX_FALSE||b==HQX_TRUE)?HQX_TRUE:
                    (a==HQX_UNKNOWN||b==HQX_UNKNOWN)?HQX_UNKNOWN:HQX_FALSE;
            else expect=(a==HQX_UNKNOWN||b==HQX_UNKNOWN)?HQX_UNKNOWN:
                    ((a!=b)==(op==HQX_XOR)?HQX_TRUE:HQX_FALSE);
            C(c==expect);
        }
    }
    for(a=0;a<5;a++)for(b=0;b<5;b++)for(p=HQX_EQ;p<=HQX_GE;p++){
        C(hqx_test((HQXPredicate)p,B(a),B(b),&c)==HQ5_OK);
        C(c==oracle_one((HQXPredicate)p,a,b));
        C(hqx_test((HQXPredicate)p,P(a),P(b),&c)==HQ5_OK);
        C(c==(raw_pred((HQXPredicate)p,a,b)?HQX_TRUE:HQX_FALSE));
    }
    for(a=0;a<5;a++){
        C(hqx_test(HQX_IS_ERROR,B(a),P(9),&c)==HQ5_OK);
        C(c==(a==HQ5_E?HQX_TRUE:HQX_FALSE));
        C(hqx_test(HQX_IS_UNKNOWN,B(a),P(9),&c)==HQ5_OK);
        C(c==(a==HQ5_E?HQX_ERROR:a==HQ5_U?HQX_TRUE:HQX_FALSE));
        C(hqx_test(HQX_IS_KNOWN,B(a),P(9),&c)==HQ5_OK);
        C(c==(a==HQ5_E?HQX_ERROR:a==HQ5_U?HQX_FALSE:HQX_TRUE));
        C(hqx_test(HQX_IS_ZERO,B(a),P(9),&c)==HQ5_OK);
        C(c==(a==HQ5_E?HQX_ERROR:a==HQ5_U?HQX_UNKNOWN:a==HQ5_Z?HQX_TRUE:HQX_FALSE));
        C(hqx_test(HQX_IS_ZERO,P(a),B(9),&c)==HQ5_OK);
        C(c==(a==0?HQX_TRUE:HQX_FALSE));
    }
    c=HQX_TRUE;
    C(hqx_test((HQXPredicate)100,P(1),P(1),&c)==HQ5_BAD_OPERATION);
    C(c==HQX_TRUE);
    C(hqx_test(HQX_EQ,P(1),B(1),&c)==HQ5_BAD_DOMAIN);
    C(c==HQX_TRUE);
    C(hqx_test(HQX_EQ,P(1),P(6),&c)==HQ5_BAD_VALUE);
    C(c==HQX_TRUE);
    C(hqx_connect(HQX_OR,(HQXCondition)77,HQX_TRUE,&c)==HQ5_BAD_VALUE);
    C(c==HQX_TRUE);
    C(hqx_connect((HQXConnective)77,HQX_TRUE,HQX_TRUE,&c)==HQ5_BAD_OPERATION);
    C(c==HQX_TRUE);
    C(hqx_not((HQXCondition)77,&c)==HQ5_BAD_VALUE);
    C(c==HQX_TRUE);
    C(hqx_not(HQX_TRUE,0)==HQ5_NULL);
    C(hqx_test(HQX_EQ,P(1),P(1),0)==HQ5_NULL);
    C(hqx_connect(HQX_AND,HQX_TRUE,HQX_TRUE,0)==HQ5_NULL);
    /* E is diagnosed, but an error marker cannot silently be made a TRUE premise. */
    C(hqx_test(HQX_IS_ERROR,B(HQ5_E),B(HQ5_N),&n)==HQ5_OK && n==HQX_TRUE);
    C(hqx_connect(HQX_AND,HQX_FALSE,HQX_ERROR,&n)==HQ5_OK && n==HQX_ERROR);
}
static void test_molecules(void){
    unsigned a,b,c;
    HQXCondition out=HQX_FALSE;
    for(a=0;a<4u;a++)for(b=0;b<4u;b++)for(c=0;c<4u;c++) {
        HQXCondition expected;
        unsigned t=(a==HQX_TRUE)+(b==HQX_TRUE)+(c==HQX_TRUE);
        unsigned f=(a==HQX_FALSE)+(b==HQX_FALSE)+(c==HQX_FALSE);
        if(a==HQX_ERROR || b==HQX_ERROR || c==HQX_ERROR) expected=HQX_ERROR;
        else expected=t>=2u?HQX_TRUE:f>=2u?HQX_FALSE:HQX_UNKNOWN;
        C(hqx_majority3((HQXCondition)a,(HQXCondition)b,(HQXCondition)c,&out)==HQ5_OK);
        C(out==expected);
    }
    for(a=0;a<5;a++)for(b=0;b<5;b++)for(c=0;c<5;c++){
        HQXCondition lhs,rhs,expected;
        C(hqx_test(HQX_GE,B(a),B(b),&lhs)==HQ5_OK);
        C(hqx_test(HQX_LE,B(a),B(c),&rhs)==HQ5_OK);
        C(hqx_connect(HQX_AND,lhs,rhs,&expected)==HQ5_OK);
        C(hqx_between(B(a),B(b),B(c),&out)==HQ5_OK);
        C(out==expected);
        C(hqx_test(HQX_GE,P(a),P(b),&lhs)==HQ5_OK);
        C(hqx_test(HQX_LE,P(a),P(c),&rhs)==HQ5_OK);
        C(hqx_connect(HQX_AND,lhs,rhs,&expected)==HQ5_OK);
        C(hqx_between(P(a),P(b),P(c),&out)==HQ5_OK);
        C(out==expected);
    }
    C(hqx_between(B(HQ5_U),B(HQ5_N),B(HQ5_P),&out)==HQ5_OK && out==HQX_TRUE);
    C(hqx_between(B(HQ5_U),B(HQ5_Z),B(HQ5_P),&out)==HQ5_OK && out==HQX_UNKNOWN);
    C(hqx_between(B(HQ5_E),B(HQ5_N),B(HQ5_P),&out)==HQ5_OK && out==HQX_ERROR);
    out=HQX_FALSE;
    C(hqx_between(P(0),B(HQ5_N),P(4),&out)==HQ5_BAD_DOMAIN);
    C(out==HQX_FALSE);
    C(hqx_majority3(HQX_TRUE,(HQXCondition)29,HQX_TRUE,&out)==HQ5_BAD_VALUE);
    C(out==HQX_FALSE);
    C(hqx_majority3(HQX_TRUE,HQX_FALSE,HQX_UNKNOWN,0)==HQ5_NULL);
    C(hqx_between(P(1),P(0),P(4),0)==HQ5_NULL);
}
static void test_order_select(void){
    unsigned a,b,op,k;
    HQ5Value out=B(HQ5_N);
    for(a=0;a<5;a++)for(b=0;b<5;b++)for(op=0;op<=1;op++){
        int found=0,first=-1,consistent=1,i,j;
        unsigned expected;
        if(a==HQ5_E||b==HQ5_E)expected=HQ5_E;
        else {
            for(i=-1;i<=1;i++)for(j=-1;j<=1;j++){
                int v;
                if(a<=2 && i!=(int)a-1)continue;
                if(b<=2 && j!=(int)b-1)continue;
                v=op==HQX_MIN?(i<j?i:j):(i>j?i:j);
                if(found && v!=first)consistent=0;
                first=v;found=1;
            }
            expected=consistent?(unsigned)(first+1):HQ5_U;
        }
        C(hqx_balanced_order((HQXOrder)op,B(a),B(b),&out)==HQ5_OK);
        C(V(out,B(expected)));
    }
    for(k=0;k<4;k++)for(a=0;a<5;a++)for(b=0;b<5;b++){
        unsigned expect;
        if(k==HQX_TRUE)expect=b;
        else if(k==HQX_FALSE)expect=a;
        else if(k==HQX_ERROR)expect=HQ5_E;
        else if(a==b)expect=a;
        else if(a==HQ5_E||b==HQ5_E)expect=HQ5_E;
        else expect=HQ5_U;
        C(hqx_select_condition((HQXCondition)k,B(a),B(b),&out)==HQ5_OK);
        C(V(out,B(expect)));
    }
    C(hqx_balanced_order(HQX_MIN,B(HQ5_U),B(HQ5_N),&out)==HQ5_OK && V(out,B(HQ5_N)));
    C(hqx_balanced_order(HQX_MAX,B(HQ5_U),B(HQ5_P),&out)==HQ5_OK && V(out,B(HQ5_P)));
    out=B(HQ5_P);
    C(hqx_balanced_order(HQX_MAX,P(0),B(2),&out)==HQ5_BAD_DOMAIN);
    C(V(out,B(HQ5_P)));
    C(hqx_balanced_order((HQXOrder)88,B(1),B(2),&out)==HQ5_BAD_OPERATION);
    C(V(out,B(HQ5_P)));
    C(hqx_select_condition(HQX_UNKNOWN,P(0),P(0),&out)==HQ5_BAD_DOMAIN);
    C(V(out,B(HQ5_P)));
    C(hqx_select_condition((HQXCondition)66,B(0),B(1),&out)==HQ5_BAD_VALUE);
    C(V(out,B(HQ5_P)));
    C(hqx_balanced_order(HQX_MIN,B(1),B(2),0)==HQ5_NULL);
    C(hqx_select_condition(HQX_TRUE,B(1),B(2),0)==HQ5_NULL);
}
static void test_words(void){
    HQ5Value a[HQ5_MAX_WORD],b[HQ5_MAX_WORD];
    HQXCondition c=HQX_TRUE;
    unsigned x,y,z,w,p,i,len,round;
    for(x=0;x<5;x++)for(y=0;y<5;y++)for(z=0;z<5;z++)for(w=0;w<5;w++){
        a[0]=B(x);a[1]=B(y);b[0]=B(z);b[1]=B(w);
        for(p=HQX_EQ;p<=HQX_GE;p++){
            C(hqx_test_word((HQXPredicate)p,HQ5_DOMAIN_TERNARY_UE,a,b,2,&c)==HQ5_OK);
            C(c==oracle_word((HQXPredicate)p,a,b,2));
        }
    }
    /* Length 3, where high digits make some comparisons definite despite U. */
    for(round=0;round<1800;round++){
        for(i=0;i<3;i++){a[i]=B(rand32()%5u);b[i]=B(rand32()%5u);}
        for(p=HQX_EQ;p<=HQX_GE;p++){
            C(hqx_test_word((HQXPredicate)p,HQ5_DOMAIN_TERNARY_UE,a,b,3,&c)==HQ5_OK);
            C(c==oracle_word((HQXPredicate)p,a,b,3));
        }
    }
    for(round=0;round<9000;round++){
        len=1u+rand32()%HQ5_MAX_WORD;
        for(i=0;i<len;i++){a[i]=P(rand32()%5u);b[i]=P(rand32()%5u);}
        for(p=HQX_EQ;p<=HQX_GE;p++){
            int sign=0;
            for(i=len;i>0;i--)if(a[i-1].symbol!=b[i-1].symbol){
                sign=a[i-1].symbol>b[i-1].symbol?1:-1;break;
            }
            C(hqx_test_word((HQXPredicate)p,HQ5_DOMAIN_PURE5,a,b,len,&c)==HQ5_OK);
            C(c==(raw_pred((HQXPredicate)p,sign,0)?HQX_TRUE:HQX_FALSE));
        }
    }
    for(i=0;i<HQ5_MAX_WORD;i++){a[i]=B(HQ5_U);b[i]=B(HQ5_Z);}
    for(p=HQX_EQ;p<=HQX_GE;p++){
        C(hqx_test_word((HQXPredicate)p,HQ5_DOMAIN_TERNARY_UE,a,b,HQ5_MAX_WORD,&c)==HQ5_OK);
        C(c==HQX_UNKNOWN);
    }
    a[31]=B(HQ5_P);b[31]=B(HQ5_N);
    C(hqx_test_word(HQX_GT,HQ5_DOMAIN_TERNARY_UE,a,b,32,&c)==HQ5_OK && c==HQX_TRUE);
    C(hqx_test_word(HQX_LT,HQ5_DOMAIN_TERNARY_UE,a,b,32,&c)==HQ5_OK && c==HQX_FALSE);
    a[0]=B(HQ5_E);
    C(hqx_test_word(HQX_GT,HQ5_DOMAIN_TERNARY_UE,a,b,32,&c)==HQ5_OK && c==HQX_ERROR);
    c=HQX_TRUE;
    C(hqx_test_word(HQX_GT,HQ5_DOMAIN_TERNARY_UE,a,b,0,&c)==HQ5_BAD_OPERATION);
    C(c==HQX_TRUE);
    C(hqx_test_word(HQX_GT,HQ5_DOMAIN_TERNARY_UE,a,b,33,&c)==HQ5_BAD_OPERATION);
    C(c==HQX_TRUE);
    C(hqx_test_word((HQXPredicate)44,HQ5_DOMAIN_TERNARY_UE,a,b,1,&c)==HQ5_BAD_OPERATION);
    C(c==HQX_TRUE);
    C(hqx_test_word(HQX_EQ,HQ5_DOMAIN_PURE5,a,b,1,&c)==HQ5_BAD_DOMAIN);
    C(c==HQX_TRUE);
    C(hqx_test_word(HQX_EQ,HQ5_DOMAIN_TERNARY_UE,a,0,1,&c)==HQ5_NULL);
    C(c==HQX_TRUE);
}
static void test_table(void){
    HQXPurePredicateTable tab;
    HQXCondition c=HQX_TRUE;
    unsigned i,j;
    tab.domain=HQ5_DOMAIN_PURE5;
    for(i=0;i<25;i++)tab.outcomes[i]=(uint8_t)(i%3u);
    for(i=0;i<5;i++)for(j=0;j<5;j++){
        C(hqx_table_pure(&tab,P(i),P(j),&c)==HQ5_OK);
        C(c==(HQXCondition)((i*5u+j)%3u));
    }
    tab.outcomes[24]=HQX_ERROR;
    c=HQX_TRUE;
    C(hqx_table_pure(&tab,P(0),P(0),&c)==HQ5_BAD_VALUE);
    C(c==HQX_TRUE);
    tab.outcomes[24]=0;
    C(hqx_table_pure(&tab,B(1),P(0),&c)==HQ5_BAD_DOMAIN);
    C(c==HQX_TRUE);
    tab.domain=HQ5_DOMAIN_TERNARY_UE;
    C(hqx_table_pure(&tab,P(0),P(0),&c)==HQ5_BAD_DOMAIN);
    C(c==HQX_TRUE);
    C(hqx_table_pure(0,P(0),P(0),&c)==HQ5_NULL);
    C(c==HQX_TRUE);
}
static void test_composed(void){
    HQXCondition cond,guard;
    HQ5Value selected=B(HQ5_N);
    /* Unknown RHS is still <= +1; selecting +1 is safe. */
    C(hqx_test(HQX_GE,B(HQ5_P),B(HQ5_U),&cond)==HQ5_OK && cond==HQX_TRUE);
    C(hqx_select_condition(cond,B(HQ5_N),B(HQ5_P),&selected)==HQ5_OK && V(selected,B(HQ5_P)));
    C(hqx_test(HQX_GT,selected,B(HQ5_Z),&guard)==HQ5_OK && guard==HQX_TRUE);
    C(hqx_connect(HQX_AND,guard,HQX_FALSE,&guard)==HQ5_OK && guard==HQX_FALSE);
    /* A caught error is a diagnostic condition; not automatic authorization. */
    C(hqx_test(HQX_IS_ERROR,B(HQ5_E),B(HQ5_Z),&cond)==HQ5_OK && cond==HQX_TRUE);
    C(hqx_connect(HQX_AND,cond,guard,&guard)==HQ5_OK && guard==HQX_FALSE);
    C(hqx_test(HQX_EQ,B(HQ5_U),B(HQ5_U),&cond)==HQ5_OK && cond==HQX_UNKNOWN);
}
int main(void){
    test_conditions();test_molecules();test_order_select();test_words();test_table();test_composed();
    printf("HIGHER_LOGIC_%s assertions=%llu failures=%d\n",
           failures?"FAIL":"PASS",assertions,failures);
    return failures?1:0;
}
