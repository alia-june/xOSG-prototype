#include "hq_block7.h"
#include <stdio.h>
#include <stdint.h>
#include <limits.h>
#include <string.h>

static unsigned long checks;
#define CHECK(c) do { ++checks; if (!(c)) { fprintf(stderr,"BLOCK7 FAIL %s:%d: %s\n",__FILE__,__LINE__,#c); return 1; } } while(0)
static uint8_t bit(int n) { return (uint8_t)(1u << (unsigned)(n+3)); }
static void ref_reduce(int n,int *digit,int *carry)
{
    int c = (n+3)/7; /* adjust signed quotient using mathematical floor */
    if(n+3<0 && ((n+3)%7)!=0) --c;
    *carry=c; *digit=n-7*c;
}
static uint32_t ref_joint(HQ7Set a,HQ7Set b,int cin,int mul)
{
    uint32_t bits=0;
    for(int i=-3;i<=3;++i) for(int j=-3;j<=3;++j)
       if((a.mask&bit(i)) && (b.mask&bit(j))) {
          int d,c; ref_reduce(mul ? i*j : i+j+cin,&d,&c);
          bits |= (uint32_t)1u << ((unsigned)(c+1)*7u+(unsigned)(d+3));
       }
    return bits;
}
static uint32_t next_rand(uint32_t *state)
{ *state^=*state<<13; *state^=*state>>17; *state^=*state<<5; return *state; }
static int test_structure(void)
{
    for(int b=-1;b<=1;++b) for(int i=-1;i<=1;++i) {
        int8_t n=99,x=88,y=77;
        HQ7Status status=hq7_pair_to_digit(b,i,&n);
        if(b==0 && i!=0) { CHECK(status==HQ7_INVALID); CHECK(n==99); }
        else {
            CHECK(status==HQ7_OK);
            CHECK(n==2*b+i);
            CHECK(hq7_digit_to_pair(n,&x,&y)==HQ7_OK);
            CHECK(x==b && y==i);
        }
    }
    for(int n=-4;n<=4;++n) {
        int8_t b=99,i=99;
        HQ7Status status=hq7_digit_to_pair(n,&b,&i);
        CHECK(status==(n>=-3 && n<=3 ? HQ7_OK : HQ7_INVALID));
        if(n< -3 || n>3) CHECK(b==99 && i==99);
    }
    for(int b=-2;b<=2;++b) {
        HQ7Set set={0xa5};
        HQ7Status st=hq7_block(b,&set);
        if(b< -1 || b>1) { CHECK(st==HQ7_INVALID); CHECK(set.mask==0xa5); }
        else {
            CHECK(st==HQ7_OK);
            CHECK(set.mask==(uint8_t)(b<0 ? 7u : b>0 ? 112u : 8u));
        }
    }
    for(int inner=-2;inner<=2;++inner) {
        HQ7Set set={0x9a};
        HQ7Status status=hq7_inner(inner,&set);
        if(inner< -1 || inner>1) { CHECK(status==HQ7_INVALID); CHECK(set.mask==0x9a); }
        else {
            uint8_t expected=(uint8_t)(bit(-2+inner)|bit(2+inner)|
                              (inner==0 ? bit(0):0u));
            CHECK(status==HQ7_OK && set.mask==expected);
        }
    }
    CHECK(hq7_pair_to_digit(0,0,0)==HQ7_NULL);
    CHECK(hq7_digit_to_pair(0,0,0)==HQ7_NULL);
    CHECK(hq7_add_exact(1,2,0,0,0)==HQ7_NULL);
    CHECK(hq7_add_exact(1,2,0,(int8_t *)&checks,(int8_t *)&checks)==HQ7_INVALID);
    return 0;
}
static int test_sets(void)
{
    for(unsigned i=0;i<128;++i) {
        HQ7Set a={(uint8_t)i},neg={0xff}; HQ7Knowledge knowledge;
        CHECK(hq7_validate(a)==HQ7_OK);
        uint8_t blocks=0xff;
        CHECK(hq7_possible_blocks(a,&blocks)==HQ7_OK);
        CHECK(blocks==(uint8_t)(((i&7u)?1u:0u)|((i&8u)?2u:0u)|((i&112u)?4u:0u)));
        CHECK(hq7_knowledge(a,&knowledge)==HQ7_OK);
        unsigned cnt=0;
        for(unsigned v=0;v<7;++v) if(i & (1u<<v)) ++cnt;
        CHECK(knowledge==(i==0 ? HQ7_CONTRADICTORY : i==127 ? HQ7_UNKNOWN : cnt==1 ? HQ7_EXACT : HQ7_PARTIAL));
        CHECK(hq7_negate(a,&neg)==HQ7_OK);
        for(int v=-3;v<=3;++v) CHECK(!!(neg.mask&bit(v))==!!(a.mask&bit(-v)));
        HQ7Set negneg={0}; CHECK(hq7_negate(neg,&negneg)==HQ7_OK);
        CHECK(negneg.mask==a.mask);
        for(unsigned j=0;j<128;++j) {
            HQ7Set b={(uint8_t)j},out={0xcc};
            CHECK(hq7_refine(a,b,&out)==HQ7_OK);
            CHECK(out.mask==(i&j));
            CHECK(hq7_union(a,b,&out)==HQ7_OK);
            CHECK(out.mask==(i|j));
            uint8_t rel=0xff,reference=0;
            for(int x=-3;x<=3;++x) for(int y=-3;y<=3;++y)
                if ((i&bit(x))&&(j&bit(y))) reference=(uint8_t)(reference|(x<y?1u:x>y?4u:2u));
            CHECK(hq7_compare_sets(a,b,&rel)==HQ7_OK);
            CHECK(rel==reference);
        }
    }
    HQ7Set bad={0x80},good={0x08},unchanged={0x54};
    CHECK(hq7_validate(bad)==HQ7_INVALID);
    CHECK(hq7_refine(bad,good,&unchanged)==HQ7_INVALID && unchanged.mask==0x54);
    CHECK(hq7_negate(bad,&unchanged)==HQ7_INVALID && unchanged.mask==0x54);
    HQ7Set pos={HQ7_POSITIVE_BLOCK},negative={HQ7_NEGATIVE_BLOCK};
    CHECK(hq7_refine(pos,negative,&unchanged)==HQ7_OK && unchanged.mask==0);
    HQ7Knowledge klass=HQ7_EXACT;
    CHECK(hq7_knowledge(unchanged,&klass)==HQ7_OK && klass==HQ7_CONTRADICTORY);
    return 0;
}
static int test_exact_arithmetic(void)
{
    for(int a=-3;a<=3;++a) for(int b=-3;b<=3;++b) {
        for(int cin=-1;cin<=1;++cin) {
            int8_t d=99,c=99; int rd,rc;
            CHECK(hq7_add_exact(a,b,cin,&d,&c)==HQ7_OK);
            ref_reduce(a+b+cin,&rd,&rc);
            CHECK(d==rd && c==rc);
            CHECK(d>=-3 && d<=3 && c>=-1 && c<=1);
            CHECK(d+7*c==a+b+cin);
        }
        int8_t d=99,c=99; int rd,rc;
        CHECK(hq7_mul_exact(a,b,&d,&c)==HQ7_OK);
        ref_reduce(a*b,&rd,&rc);
        CHECK(d==rd && c==rc);
        CHECK(d+7*c==a*b);
    }
    int8_t d=74,c=67;
    CHECK(hq7_add_exact(4,0,0,&d,&c)==HQ7_INVALID && d==74 && c==67);
    CHECK(hq7_add_exact(0,0,2,&d,&c)==HQ7_INVALID && d==74 && c==67);
    CHECK(hq7_mul_exact(-4,1,&d,&c)==HQ7_INVALID && d==74 && c==67);
    CHECK(hq7_add_exact(1,2,0,&d,&d)==HQ7_INVALID && d==74);
    return 0;
}
static int test_lifted_arithmetic(void)
{
    for(unsigned i=0;i<128;++i) for(unsigned j=0;j<128;++j) {
        HQ7Set a={(uint8_t)i},b={(uint8_t)j};
        for(int cin=-1;cin<=1;++cin) {
            HQ7Outcome actual={0xffffffffu};
            CHECK(hq7_add_sets(a,b,cin,&actual)==HQ7_OK);
            CHECK(actual.joint==ref_joint(a,b,cin,0));
            HQ7Set digits={0x80};uint8_t carries=0x80;
            CHECK(hq7_outcome_project(actual,&digits,&carries)==HQ7_OK);
            uint8_t dm=0,cm=0;
            for(unsigned k=0;k<21;++k) if(actual.joint&((uint32_t)1u<<k)) {
                dm=(uint8_t)(dm|((uint8_t)1u<<(k%7u)));
                cm=(uint8_t)(cm|((uint8_t)1u<<(k/7u)));
            }
            CHECK(digits.mask==dm && carries==cm);
        }
        HQ7Outcome product={0xffffffffu};
        CHECK(hq7_mul_sets(a,b,&product)==HQ7_OK);
        CHECK(product.joint==ref_joint(a,b,0,1));
    }
    HQ7Outcome invalid={7};HQ7Set bad={0x80},good={0x08};
    CHECK(hq7_add_sets(bad,good,0,&invalid)==HQ7_INVALID && invalid.joint==7);
    CHECK(hq7_add_sets(good,good,2,&invalid)==HQ7_INVALID && invalid.joint==7);
    HQ7Set digit={0x55};uint8_t carry=0x55;
    CHECK(hq7_outcome_project((HQ7Outcome){1u<<21},&digit,&carry)==HQ7_INVALID);
    CHECK(digit.mask==0x55 && carry==0x55);
    /* +1+{+1,+2,+3}: (digit -3,carry+1),(-2,+1),(-1,+1). */
    HQ7Set one={bit(1)},plus={HQ7_POSITIVE_BLOCK};
    CHECK(hq7_add_sets(one,plus,0,&invalid)==HQ7_OK);
    CHECK(invalid.joint==ref_joint(one,plus,0,0));
    return 0;
}
static int test_switch_and_memory(void)
{
    HQ7Set branches[3]={{bit(-3)},{bit(0)},{bit(3)}};
    for(unsigned selector=0;selector<128;++selector) {
        HQ7Set out={0x80}, s={(uint8_t)selector};
        CHECK(hq7_select_block(s,branches,&out)==HQ7_OK);
        uint8_t expected=(uint8_t)(((selector&7u)?bit(-3):0u)|
             ((selector&8u)?bit(0):0u)|((selector&112u)?bit(3):0u));
        CHECK(out.mask==expected);
    }
    HQ7Set bad={0x80},out={0x12};
    CHECK(hq7_select_block(bad,branches,&out)==HQ7_INVALID && out.mask==0x12);
    CHECK(hq7_select_block((HQ7Set){127},0,&out)==HQ7_NULL);
    HQ7Cell cell;
    CHECK(hq7_cell_init(&cell,(HQ7Set){HQ7_ALL})==HQ7_OK);
    uint32_t generation=99;
    CHECK(hq7_cell_read(&cell,&out,&generation)==HQ7_OK);
    CHECK(out.mask==HQ7_ALL && generation==0);
    CHECK(hq7_cell_tick(&cell,0,HQ7_WRITE,(HQ7Set){HQ7_POSITIVE_BLOCK},&out)==HQ7_OK);
    CHECK(cell.generation==1 && out.mask==HQ7_POSITIVE_BLOCK);
    CHECK(hq7_cell_tick(&cell,0,HQ7_RESET,(HQ7Set){0},&out)==HQ7_STALE);
    CHECK(cell.generation==1 && cell.value.mask==HQ7_POSITIVE_BLOCK);
    CHECK(hq7_cell_tick(&cell,1,HQ7_HOLD,(HQ7Set){0},&out)==HQ7_OK);
    CHECK(cell.generation==2 && cell.value.mask==HQ7_POSITIVE_BLOCK);
    CHECK(hq7_cell_tick(&cell,2,HQ7_RESET,(HQ7Set){0},&out)==HQ7_OK);
    CHECK(cell.generation==3 && cell.value.mask==bit(0));
    CHECK(hq7_cell_tick(&cell,3,HQ7_WRITE,bad,&out)==HQ7_INVALID);
    CHECK(cell.generation==3 && cell.value.mask==bit(0));
    cell.generation=UINT32_MAX;
    CHECK(hq7_cell_tick(&cell,UINT32_MAX,HQ7_HOLD,(HQ7Set){0},&out)==HQ7_OVERFLOW);
    CHECK(cell.generation==UINT32_MAX && cell.value.mask==bit(0));
    return 0;
}
static int test_word(void)
{
    uint32_t rng=0xf27ca93bu;
    for(unsigned n=1;n<=32;++n) for(unsigned test=0;test<130;++test) {
        int8_t a[32],b[32],out[32],same[32],carry=44,carry2=44;
        for(unsigned i=0;i<n;++i) {
            a[i]=(int8_t)((next_rand(&rng)%7u)-3);
            b[i]=(int8_t)((next_rand(&rng)%7u)-3);
            out[i]=99; same[i]=a[i];
        }
        int cin=(int)(next_rand(&rng)%3u)-1;
        CHECK(hq7_add_word(a,b,n,cin,out,&carry)==HQ7_OK);
        CHECK(hq7_add_word(same,b,n,cin,same,&carry2)==HQ7_OK);
        CHECK(carry==carry2);
        int ref_c=cin;
        for(unsigned i=0;i<n;++i) {
            int d,c; ref_reduce((int)a[i]+(int)b[i]+ref_c,&d,&c);
            CHECK(out[i]==d && same[i]==d);
            ref_c=c;
        }
        CHECK(carry==ref_c);
    }
    int8_t a[3]={1,2,4},b[3]={2,2,2},out[3]={95,95,95},c=95;
    CHECK(hq7_add_word(a,b,3,0,out,&c)==HQ7_INVALID);
    CHECK(out[0]==95 && out[1]==95 && out[2]==95 && c==95);
    CHECK(hq7_add_word(a,b,0,0,out,&c)==HQ7_INVALID);
    CHECK(hq7_add_word(a,b,33,0,out,&c)==HQ7_INVALID);
    CHECK(hq7_add_word(a,b,3,2,out,&c)==HQ7_INVALID);
    return 0;
}
int main(void)
{
    if(test_structure() || test_sets() || test_exact_arithmetic() ||
       test_lifted_arithmetic() || test_switch_and_memory() || test_word()) return 1;
    printf("BLOCK7_TESTS=PASS assertions=%lu\n",checks);
    return 0;
}
