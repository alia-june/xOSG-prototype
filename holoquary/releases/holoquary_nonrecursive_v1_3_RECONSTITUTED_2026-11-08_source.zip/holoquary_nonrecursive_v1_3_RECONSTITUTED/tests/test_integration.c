#include "holon_types.h"
#include <stdio.h>
#include <string.h>
#include <float.h>

static unsigned int checks=0u;
#define CHECK(c) do { ++checks; if(!(c)) { fprintf(stderr,"FAIL line=%d: %s\n",__LINE__,#c); return 1; } } while(0)

static int prepare_logic(HQProgram *p) {
    HQRef x;
    return hq_init(p,2u)==HQ_OK &&
           hq_emit_xor(p,hq_input(0),hq_input(1),&x)==HQ_OK &&
           hq_export(p,x)==HQ_OK;
}
static int prepare_neural(DNNModel *a,DNNModel *b) {
    unsigned int d[2]={2,1};
    if(!dnn_init(a,d,1u,1u,DNN_UNIFORM) || !dnn_init(b,d,1u,2u,DNN_UNIFORM)) return 0;
    a->p[0]=1.0f;a->p[1]=0.0f;a->p[2]=0.0f;
    b->p[0]=0.0f;b->p[1]=1.0f;b->p[2]=0.0f;
    return 1;
}
static HCIIdentity id(unsigned int holon,unsigned int snap,unsigned int param){
    HCIIdentity x={holon,holon+100u,1u,param,snap};return x;
}

static int test_mixed(void) {
    HQProgram p;
    DNNModel m_a,m_b;
    HCINeuralAdapter a,b;
    HCILogicAdapter logic;
    HCIThreshold t={0.25f,0.75f,123u};
    HCIFrame f_a,f_b,f_logic;
    HCIClassifiedSignal q_a,q_b;
    HCIProposal prop;
    HCIGrant grant;
    unsigned int v;
    CHECK(prepare_logic(&p));
    CHECK(prepare_neural(&m_a,&m_b));
    memset(&a,0,sizeof a); memset(&b,0,sizeof b);
    a.model=&m_a;a.identity=id(1,1,1);
    b.model=&m_b;b.identity=id(2,1,1);
    logic.program=&p;logic.identity=id(3,1,0);
    grant.action_mask=HCI_ACTION_BIT(HCI_ACT_ROUTE)|HCI_ACTION_BIT(HCI_ACT_ANSWER)|
        HCI_ACTION_BIT(HCI_ACT_RETURN_UNKNOWN)|HCI_ACTION_BIT(HCI_ACT_APPLY_LESSON)|
        HCI_ACTION_BIT(HCI_ACT_CONTINUE)|HCI_ACTION_BIT(HCI_ACT_REQUEST_EVIDENCE)|
        HCI_ACTION_BIT(HCI_ACT_REPORT_ERROR);
    grant.max_budget=10u;grant.target_holon_id=3u;
    for (v=0u;v<4000u;++v) {
        float x[2]={(float)(v&1u),(float)((v>>1)&1u)};
        unsigned int expected=(v&1u)^((v>>1)&1u);
        a.identity.snapshot_id=v+1u;
        b.identity.snapshot_id=v+1u;
        logic.identity.snapshot_id=v+1u;
        CHECK(hci_observe_neural(&a,x,10u,&f_a)==HCI_OK);
        CHECK(hci_observe_neural(&b,x,10u,&f_b)==HCI_OK);
        CHECK(f_a.execution==HCI_COMPLETED && f_a.result_kind==HCI_RESULT_NUMERIC);
        CHECK(hci_classify_signal(&f_a,&t,&q_a)==HCI_OK);
        CHECK(hci_classify_signal(&f_b,&t,&q_b)==HCI_OK);
        CHECK(q_a.domain==HCI_CLASSIFICATION && q_b.domain==HCI_CLASSIFICATION);
        CHECK(q_a.value== (x[0]>0.5f?HQ_TRUE:HQ_FALSE));
        CHECK(q_b.value== (x[1]>0.5f?HQ_TRUE:HQ_FALSE));
        { HCIClassifiedSignal signals[2]={q_a,q_b};
          CHECK(hci_observe_classified_logic(&logic,signals,2u,t.conversion_id,10u,&f_logic)==HCI_OK);
          CHECK(f_logic.input_origin==HCI_INPUT_CLASSIFIED &&
                f_logic.input_conversion_id==t.conversion_id);
        }
        CHECK(f_logic.execution==HCI_COMPLETED && f_logic.source_status==HQ_OK);
        CHECK(f_logic.result_kind==HCI_RESULT_LOGIC);
        CHECK(f_logic.truth==(expected?HQ_TRUE:HQ_FALSE));
        CHECK(hci_controller_propose(&f_logic,0u,&prop)==HCI_OK);
        CHECK(prop.action==HCI_ACT_ANSWER && prop.target_holon_id==3u);
        CHECK(hci_gate_proposal(&prop,&f_logic,&grant)==HCI_OK);
        grant.target_holon_id=1u;
        CHECK(hci_controller_propose(&f_a,0u,&prop)==HCI_OK && prop.action==HCI_ACT_ROUTE);
        CHECK(hci_gate_proposal(&prop,&f_a,&grant)==HCI_OK);
        grant.target_holon_id=3u;
    }
    {
        float x[2]={0.5f,0.0f};
        HQTruth in[2]={HQ_UNKNOWN,HQ_FALSE};
        CHECK(hci_observe_neural(&a,x,10u,&f_a)==HCI_OK);
        CHECK(hci_classify_signal(&f_a,&t,&q_a)==HCI_OK && q_a.value==HQ_UNKNOWN);
        CHECK(hci_observe_logic(&logic,in,2u,10u,&f_logic)==HCI_OK && f_logic.truth==HQ_UNKNOWN);
        CHECK(hci_controller_propose(&f_logic,0u,&prop)==HCI_OK);
        CHECK(prop.action==HCI_ACT_RETURN_UNKNOWN);
        CHECK(hci_gate_proposal(&prop,&f_logic,&grant)==HCI_OK);
        prop.action=HCI_ACT_ANSWER;
    prop.requested_budget=0u;
        CHECK(hci_gate_proposal(&prop,&f_logic,&grant)==HCI_ERR_DENIED);
    }
    return 0;
}

static int test_extended(void) {
    HQProgram p;
    HQRef x;
    HQTruth in[3]={HQ_TRUE,HQ_UNKNOWN,HQ_UNKNOWN};
    HCILogicAdapter a;
    HQLessonBank bank,conflict;
    HCIFrame f;
    HCIProposal prop;
    HCIGrant grant={0};
    unsigned int round;
    CHECK(hq_init(&p,3u)==HQ_OK);
    CHECK(hq_emit_xor(&p,hq_input(0),hq_input(2),&x)==HQ_OK);
    CHECK(hq_export(&p,x)==HQ_OK);
    a.program=&p;a.identity=id(4,80,0);
    CHECK(hq_lessons_init(&bank,99u)==HQ_OK);
    CHECK(hq_lesson_add_rule(&bank,0u,HQ_TRUE,1u,HQ_FALSE,10u)==HQ_OK);
    CHECK(hq_lesson_add_rule(&bank,1u,HQ_FALSE,2u,HQ_TRUE,11u)==HQ_OK);
    CHECK(hci_observe_logic(&a,in,3u,4u,&f)==HCI_OK && f.truth==HQ_UNKNOWN);
    CHECK(hci_controller_propose(&f,2u,&prop)==HCI_OK && prop.action==HCI_ACT_APPLY_LESSON);
    grant.action_mask=HCI_ACTION_BIT(HCI_ACT_APPLY_LESSON)|HCI_ACTION_BIT(HCI_ACT_CONTINUE)|
        HCI_ACTION_BIT(HCI_ACT_ANSWER)|HCI_ACTION_BIT(HCI_ACT_REQUEST_EVIDENCE);
    grant.max_budget=4u;grant.target_holon_id=4u;
    CHECK(hci_gate_proposal(&prop,&f,&grant)==HCI_OK);
    for(round=1u;round<=3u;++round) {
        CHECK(hci_observe_extended(&a,in,3u,&bank,99u,round,4u,&f)==HCI_OK);
        CHECK(f.execution==HCI_COMPLETED);
        CHECK(f.source_status==HQ_OK);
        if(round<3u) {
            CHECK(f.truth==HQ_UNKNOWN && f.disposition==HCI_EXHAUSTED);
            CHECK(hci_controller_propose(&f,2u,&prop)==HCI_OK && prop.action==HCI_ACT_CONTINUE);
        } else {
            CHECK(f.truth==HQ_FALSE && f.disposition==HCI_STABLE);
            CHECK(hci_controller_propose(&f,2u,&prop)==HCI_OK && prop.action==HCI_ACT_ANSWER);
        }
        CHECK(hci_gate_proposal(&prop,&f,&grant)==HCI_OK);
    }
    CHECK(in[1]==HQ_UNKNOWN && in[2]==HQ_UNKNOWN);
    CHECK(hq_lessons_init(&conflict,99u)==HQ_OK);
    CHECK(hq_lesson_add_fact(&conflict,0u,HQ_FALSE,12u)==HQ_OK);
    CHECK(hci_observe_extended(&a,in,3u,&conflict,99u,3u,4u,&f)==HCI_OK);
    CHECK(f.truth==HQ_UNKNOWN && f.disposition==HCI_CONFLICT && f.conflict_count>0u);
    CHECK(hci_controller_propose(&f,1u,&prop)==HCI_OK && prop.action==HCI_ACT_REQUEST_EVIDENCE);
    CHECK(hci_gate_proposal(&prop,&f,&grant)==HCI_OK);
    CHECK(hci_observe_extended(&a,in,3u,&bank,100u,3u,4u,&f)==HCI_ERR_SOURCE);
    CHECK(f.execution==HCI_FAILED && f.source_status==HQ_ERR_SCOPE && f.result_kind==HCI_RESULT_NONE);
    CHECK(hci_controller_propose(&f,1u,&prop)==HCI_OK && prop.action==HCI_ACT_REPORT_ERROR);
    CHECK(hci_gate_proposal(&prop,&f,&grant)==HCI_ERR_DENIED);
    grant.action_mask|=HCI_ACTION_BIT(HCI_ACT_REPORT_ERROR);
    CHECK(hci_gate_proposal(&prop,&f,&grant)==HCI_OK);
    return 0;
}

static int test_boundaries(void) {
    HQProgram p;
    DNNModel m_a,m_b;
    HCINeuralAdapter n;
    HCILogicAdapter logic;
    HCIFrame f,prior;
    HCIThreshold t={0.25f,0.75f,24u};
    HCIClassifiedSignal sig,old_sig;
    HCIProposal prop;
    HCIGrant grant={0};
    float x[2]={1.0f,0.0f}, copy[2]={42.f,43.f};
    float weights[DNN_MAX_PARAMS];
    unsigned int used=777u,i;
    HQTruth inputs[2]={HQ_TRUE,HQ_FALSE};
    CHECK(prepare_logic(&p) && prepare_neural(&m_a,&m_b));
    memset(&n,0,sizeof n);n.model=&m_a;n.identity=id(55,9,7);
    logic.program=&p;logic.identity=id(44,9,0);
    CHECK(hci_observe_neural(&n,x,5u,&f)==HCI_OK);
    CHECK(hci_inspect_neural_inputs(&n,9u,7u,0u,copy)==HCI_ERR_DENIED);
    CHECK(copy[0]==42.f && copy[1]==43.f);
    CHECK(hci_inspect_neural_inputs(&n,8u,7u,HCI_VIEW_L1,copy)==HCI_ERR_STALE);
    CHECK(hci_inspect_neural_inputs(&n,9u,7u,HCI_VIEW_L1,copy)==HCI_OK);
    CHECK(copy[0]==1.0f && copy[1]==0.0f);
    for(i=0u;i<DNN_MAX_PARAMS;++i) weights[i]=-77.0f;
    CHECK(hci_inspect_neural_weights(&n,1u,7u,0u,weights,DNN_MAX_PARAMS,&used)==HCI_ERR_DENIED);
    CHECK(hci_inspect_neural_weights(&n,1u,8u,HCI_VIEW_L3,weights,DNN_MAX_PARAMS,&used)==HCI_ERR_STALE);
    CHECK(hci_inspect_neural_weights(&n,1u,7u,HCI_VIEW_L3,weights,2u,&used)==HCI_ERR_CAPACITY);
    CHECK(used==777u && weights[0]==-77.0f);
    CHECK(hci_inspect_neural_weights(&n,1u,7u,HCI_VIEW_L3,weights,DNN_MAX_PARAMS,&used)==HCI_OK);
    CHECK(used==3u && weights[0]==1.0f && weights[1]==0.0f && weights[2]==0.0f);
    prior=f;
    old_sig.value=HQ_UNKNOWN;old_sig.conversion_id=888u;sig=old_sig;
    t.true_min=t.false_max;
    CHECK(hci_classify_signal(&f,&t,&sig)==HCI_ERR_INVALID && sig.conversion_id==888u);
    t.true_min=0.75f;
    f.execution=HCI_FAILED;
    CHECK(hci_classify_signal(&f,&t,&sig)==HCI_ERR_INVALID);
    f=prior;
    CHECK(hci_classify_signal(&f,&t,&sig)==HCI_OK && sig.value==HQ_TRUE);
    CHECK(hci_observe_neural(&n,0,5u,&f)==HCI_ERR_NULL && f.execution==HCI_FAILED);
    { float bad[2]={FLT_MAX,FLT_MAX};
      m_a.p[0]=FLT_MAX;m_a.p[1]=FLT_MAX;
      CHECK(hci_observe_neural(&n,bad,5u,&f)==HCI_ERR_NUMERIC && f.execution==HCI_FAILED);
      m_a.p[0]=1.0f;m_a.p[1]=0.0f;
    }
    m_a.used=99u;
    CHECK(hci_observe_neural(&n,x,5u,&f)==HCI_ERR_INVALID && f.execution==HCI_FAILED);
    m_a.used=3u;
    {
        HCIClassifiedSignal wrong[2]={{HQ_TRUE,55u,9u,24u,HCI_CLASSIFICATION},
                                       {HQ_FALSE,56u,8u,24u,HCI_CLASSIFICATION}};
        CHECK(hci_observe_classified_logic(&logic,wrong,2u,24u,5u,&f)==HCI_ERR_INVALID);
        CHECK(f.execution==HCI_FAILED && f.result_kind==HCI_RESULT_NONE);
        wrong[1].source_snapshot_id=9u; wrong[1].conversion_id=25u;
        CHECK(hci_observe_classified_logic(&logic,wrong,2u,24u,5u,&f)==HCI_ERR_INVALID);
        wrong[1].conversion_id=24u; wrong[1].domain=(HCIConversionDomain)222;
        CHECK(hci_observe_classified_logic(&logic,wrong,2u,24u,5u,&f)==HCI_ERR_INVALID);
        wrong[1].domain=HCI_CLASSIFICATION;
        CHECK(hci_observe_classified_logic(&logic,wrong,2u,24u,5u,&f)==HCI_OK);
        CHECK(f.input_origin==HCI_INPUT_CLASSIFIED && f.truth==HQ_TRUE);
    }
    CHECK(hci_observe_logic(&logic,inputs,2u,5u,&f)==HCI_OK);
    grant.action_mask=HCI_ACTION_BIT(HCI_ACT_ANSWER);
    grant.max_budget=2u;grant.target_holon_id=44u;
    CHECK(hci_controller_propose(&f,0u,&prop)==HCI_OK && prop.action==HCI_ACT_ANSWER);
    CHECK(hci_gate_proposal(&prop,&f,&grant)==HCI_OK);
    prop.observed_graph_gen=99u;
    CHECK(hci_gate_proposal(&prop,&f,&grant)==HCI_ERR_STALE);
    prop.observed_graph_gen=1u;
    prop.target_holon_id=55u;
    CHECK(hci_gate_proposal(&prop,&f,&grant)==HCI_ERR_DENIED);
    prop.target_holon_id=44u;
    prop.action=HCI_ACT_CONTINUE;prop.requested_budget=3u;
    CHECK(hci_gate_proposal(&prop,&f,&grant)==HCI_ERR_DENIED);
    grant.action_mask|=HCI_ACTION_BIT(HCI_ACT_CONTINUE);
    CHECK(hci_gate_proposal(&prop,&f,&grant)==HCI_ERR_BUDGET);
    prop.action=HCI_ACT_ANSWER;
    prop.requested_budget=0u;
    f.source_status=HQ_ERR_VALUE;
    CHECK(hci_gate_proposal(&prop,&f,&grant)==HCI_ERR_DENIED);
    f.source_status=HQ_OK;
    f.kind=HCI_NEURAL;
    CHECK(hci_gate_proposal(&prop,&f,&grant)==HCI_ERR_DENIED);
    f.kind=HCI_LOGIC;
    prop.action=(HCIAction)9999;
    CHECK(hci_gate_proposal(&prop,&f,&grant)==HCI_ERR_INVALID);
    inputs[1]=(HQTruth)9999;
    CHECK(hci_observe_logic(&logic,inputs,2u,5u,&f)==HCI_ERR_SOURCE);
    CHECK(f.source_status==HQ_ERR_VALUE && f.execution==HCI_FAILED);
    CHECK(hci_controller_propose(&f,0u,&prop)==HCI_OK && prop.action==HCI_ACT_REPORT_ERROR);
    CHECK(hci_gate_proposal(&prop,&f,&grant)==HCI_ERR_DENIED);
    CHECK(hci_observe_logic(&logic,0,2u,5u,&f)==HCI_ERR_NULL && f.execution==HCI_FAILED);
    return 0;
}
int main(void) {
    CHECK(test_mixed()==0);
    CHECK(test_extended()==0);
    CHECK(test_boundaries()==0);
    printf("INTEGRATION_PASS assertions=%u\n",checks);
    return 0;
}
