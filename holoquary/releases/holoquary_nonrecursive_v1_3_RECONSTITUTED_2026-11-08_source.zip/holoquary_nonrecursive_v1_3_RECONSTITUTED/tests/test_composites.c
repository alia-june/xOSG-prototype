#include "hq_composites.h"
#include "hq_cells.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

static unsigned long checks=0ul;
#define CHECK(c) do { ++checks; if (!(c)) { \
    fprintf(stderr,"FAIL %s:%d: %s\n",__FILE__,__LINE__,#c); exit(1); \
} } while(0)
static const HQTruth v[3]={HQ_FALSE,HQ_TRUE,HQ_UNKNOWN};
static HQTruth nt(HQTruth a) { return a==HQ_UNKNOWN ? HQ_UNKNOWN : (a==HQ_TRUE?HQ_FALSE:HQ_TRUE); }
static HQTruth an(HQTruth a,HQTruth b) { return a==HQ_FALSE||b==HQ_FALSE?HQ_FALSE:(a==HQ_TRUE&&b==HQ_TRUE?HQ_TRUE:HQ_UNKNOWN); }
static HQTruth oor(HQTruth a,HQTruth b) { return a==HQ_TRUE||b==HQ_TRUE?HQ_TRUE:(a==HQ_FALSE&&b==HQ_FALSE?HQ_FALSE:HQ_UNKNOWN); }
static HQTruth xr(HQTruth a,HQTruth b) { return a==HQ_UNKNOWN||b==HQ_UNKNOWN?HQ_UNKNOWN:(a==b?HQ_FALSE:HQ_TRUE); }
static HQTruth mx(HQTruth a,HQTruth b,HQTruth s) { return s==HQ_FALSE?a:(s==HQ_TRUE?b:(a==b?a:HQ_UNKNOWN)); }
static void gates(void) {
    unsigned int i,j,k;
    typedef HQStatus (*BinaryFn)(HQProgram*,HQRef,HQRef,HQRef*);
    BinaryFn funcs[5]={hq_emit_and,hq_emit_or,hq_emit_nor,hq_emit_xnor,hq_emit_switch};
    unsigned int expected_gates[5]={2u,3u,4u,5u,2u};
    for (i=0u;i<5u;i++) {
        HQProgram p; HQRef ref; HQTruth in[2],out[1]={HQ_UNKNOWN};
        CHECK(hq_init(&p,2u)==HQ_OK);
        CHECK(funcs[i](&p,hq_input(0u),hq_input(1u),&ref)==HQ_OK);
        CHECK(p.gate_count==expected_gates[i]);
        CHECK(hq_export(&p,ref)==HQ_OK);
        CHECK(hq_validate(&p)==HQ_OK);
        for(j=0u;j<3u;j++)for(k=0u;k<3u;k++) {
            HQTruth want;
            in[0]=v[j];in[1]=v[k];
            want=i==0u?an(in[0],in[1]):i==1u?oor(in[0],in[1]):
                 i==2u?nt(oor(in[0],in[1])):i==3u?nt(xr(in[0],in[1])):an(in[0],in[1]);
            CHECK(hq_eval(&p,in,2u,out,1u)==HQ_OK);
            CHECK(out[0]==want);
        }
    }
    for(i=0u;i<3u;i++) {
        HQProgram p; HQRef r; HQTruth out[1],input[1]={v[i]};
        CHECK(hq_init(&p,1u)==HQ_OK);
        CHECK(hq_emit_not(&p,hq_input(0u),&r)==HQ_OK);
        CHECK(hq_export(&p,r)==HQ_OK);
        CHECK(hq_eval(&p,input,1u,out,1u)==HQ_OK);
        CHECK(out[0]==nt(v[i]));
    }
}
static void mux_and_memory(void) {
    unsigned int i,j,k;
    HQProgram p; HQRef r;
    CHECK(hq_init(&p,3u)==HQ_OK);
    CHECK(hq_emit_mux(&p,hq_input(0u),hq_input(1u),hq_input(2u),&r)==HQ_OK);
    CHECK(p.gate_count==7u);
    CHECK(hq_export(&p,r)==HQ_OK);
    for(i=0u;i<3u;i++)for(j=0u;j<3u;j++)for(k=0u;k<3u;k++) {
        HQBitCell cell;
        HQTruth in[3]={v[i],v[j],v[k]},out[1]={HQ_UNKNOWN},actual=HQ_UNKNOWN;
        unsigned int gen=999u;
        HQTruth want=mx(in[0],in[1],in[2]);
        CHECK(hq_eval(&p,in,3u,out,1u)==HQ_OK);
        CHECK(out[0]==want);
        CHECK(hq_bit_init(&cell,in[0])==HQ_CELL_OK);
        CHECK(hq_bit_tick(&cell,0u,in[2],in[1],&actual)==HQ_CELL_OK);
        CHECK(actual==want);
        CHECK(hq_bit_read(&cell,&actual,&gen)==HQ_CELL_OK);
        CHECK(actual==want && gen==1u);
    }
    /* TRUE and FALSE must survive an unknown selector when both branches agree. */
    for(i=0u;i<2u;i++) {
        HQTruth in[3]={v[i],v[i],HQ_UNKNOWN},out[1]={HQ_UNKNOWN};
        CHECK(hq_eval(&p,in,3u,out,1u)==HQ_OK);
        CHECK(out[0]==v[i]);
    }
}
static void demux_and_lock(void) {
    unsigned int i,j,k;
    HQProgram dm,lk;
    HQRef refs[2],r;
    CHECK(hq_init(&dm,2u)==HQ_OK);
    CHECK(hq_emit_demux(&dm,hq_input(0u),hq_input(1u),refs)==HQ_OK);
    CHECK(dm.gate_count==5u);
    CHECK(hq_export(&dm,refs[0])==HQ_OK);
    CHECK(hq_export(&dm,refs[1])==HQ_OK);
    for(i=0u;i<3u;i++)for(j=0u;j<3u;j++) {
        HQTruth in[2]={v[i],v[j]},out[2]={HQ_UNKNOWN,HQ_UNKNOWN};
        CHECK(hq_eval(&dm,in,2u,out,2u)==HQ_OK);
        CHECK(out[0]==an(in[0],nt(in[1])));
        CHECK(out[1]==an(in[0],in[1]));
    }
    CHECK(hq_init(&lk,3u)==HQ_OK);
    CHECK(hq_emit_guarded_lock(&lk,hq_input(0u),hq_input(1u),hq_input(2u),&r)==HQ_OK);
    CHECK(lk.gate_count==4u);
    CHECK(hq_export(&lk,r)==HQ_OK);
    for(i=0u;i<3u;i++)for(j=0u;j<3u;j++)for(k=0u;k<3u;k++) {
        HQTruth in[3]={v[i],v[j],v[k]},out[1]={HQ_UNKNOWN};
        HQTruth want=an(in[0],an(in[1],in[2]));
        CHECK(hq_eval(&lk,in,3u,out,1u)==HQ_OK);
        CHECK(out[0]==want);
        CHECK(hq_guard_allows(out[0])==(want==HQ_TRUE));
    }
    CHECK(hq_guard_allows((HQTruth)999)==0);
}
static void composition(void) {
    unsigned int a,b,c,d,e;
    HQProgram p; HQRef x,sw,locked;
    CHECK(hq_init(&p,5u)==HQ_OK);
    CHECK(hq_emit_xor(&p,hq_input(0u),hq_input(1u),&x)==HQ_OK);
    CHECK(hq_emit_mux(&p,hq_input(0u),hq_input(1u),hq_input(2u),&sw)==HQ_OK);
    CHECK(hq_emit_guarded_lock(&p,x,hq_input(3u),hq_input(4u),&locked)==HQ_OK);
    CHECK(p.gate_count==15u);
    CHECK(hq_export(&p,sw)==HQ_OK);
    CHECK(hq_export(&p,locked)==HQ_OK);
    for(a=0u;a<3u;a++)for(b=0u;b<3u;b++)for(c=0u;c<3u;c++)
    for(d=0u;d<3u;d++)for(e=0u;e<3u;e++) {
        HQTruth in[5]={v[a],v[b],v[c],v[d],v[e]}; HQTruth out[2]={HQ_UNKNOWN,HQ_UNKNOWN};
        CHECK(hq_eval(&p,in,5u,out,2u)==HQ_OK);
        CHECK(out[0]==mx(in[0],in[1],in[2]));
        CHECK(out[1]==an(xr(in[0],in[1]),an(in[3],in[4])));
    }
    /* An additional NOR needs 4 NANDs; failure is transactional. */
    {
        HQRef r={HQ_REF_INPUT,7u};
        unsigned int previous=p.gate_count;
        CHECK(hq_emit_nor(&p,hq_input(0u),hq_input(1u),&r)==HQ_ERR_CAPACITY);
        CHECK(p.gate_count==previous && p.output_count==2u);
        CHECK(r.kind==HQ_REF_INPUT && r.index==7u);
    }
    /* One NOT can fill the remaining slot. */
    {
        HQRef r;
        CHECK(hq_emit_not(&p,hq_input(0u),&r)==HQ_OK);
        CHECK(p.gate_count==16u);
        CHECK(hq_emit_not(&p,hq_input(0u),&r)==HQ_ERR_CAPACITY);
        CHECK(p.gate_count==16u);
    }
}
static void partial_capacity(void) {
    HQProgram p; HQRef r,dual[2],prior={HQ_REF_INPUT,2u};
    unsigned int i;
    CHECK(hq_init(&p,3u)==HQ_OK);
    for(i=0u;i<10u;i++) CHECK(hq_add_nand(&p,hq_input(0u),hq_input(1u),&r)==HQ_OK);
    CHECK(p.gate_count==10u);
    r=prior;
    CHECK(hq_emit_mux(&p,hq_input(0u),hq_input(1u),hq_input(2u),&r)==HQ_ERR_CAPACITY);
    CHECK(p.gate_count==10u && r.kind==prior.kind && r.index==prior.index);
    for(i=10u;i<13u;i++) CHECK(hq_add_nand(&p,hq_input(0u),hq_input(1u),&r)==HQ_OK);
    r=prior;
    CHECK(hq_emit_guarded_lock(&p,hq_input(0u),hq_input(1u),hq_input(2u),&r)==HQ_ERR_CAPACITY);
    CHECK(p.gate_count==13u && r.kind==prior.kind && r.index==prior.index);
    dual[0]=prior; dual[1]=prior;
    CHECK(hq_emit_demux(&p,hq_input(0u),hq_input(2u),dual)==HQ_ERR_CAPACITY);
    CHECK(p.gate_count==13u && dual[0].index==2u && dual[1].index==2u);
    CHECK(hq_export(&p,hq_input(0u))==HQ_OK);
    { HQTruth in[3]={HQ_TRUE,HQ_UNKNOWN,HQ_FALSE},out[1]={HQ_UNKNOWN};
      CHECK(hq_eval(&p,in,3u,out,1u)==HQ_OK && out[0]==HQ_TRUE); }
}
static void errors(void) {
    HQProgram p; HQRef r={HQ_REF_INPUT,6u}; HQRef dual[2]={{HQ_REF_INPUT,4u},{HQ_REF_INPUT,5u}};
    HQBitCell cell={HQ_TRUE,7u}; HQTruth out=HQ_FALSE,generation_value=HQ_UNKNOWN;
    unsigned int gen=99u;
    CHECK(hq_init(&p,3u)==HQ_OK);
    CHECK(hq_emit_mux(&p,hq_input(0u),hq_input(99u),hq_input(2u),&r)==HQ_ERR_REF);
    CHECK(p.gate_count==0u && r.kind==HQ_REF_INPUT && r.index==6u);
    CHECK(hq_emit_demux(&p,hq_input(0u),hq_input(99u),dual)==HQ_ERR_REF);
    CHECK(p.gate_count==0u && dual[0].index==4u && dual[1].index==5u);
    CHECK(hq_emit_guarded_lock(&p,hq_input(0u),hq_input(1u),hq_input(99u),&r)==HQ_ERR_REF);
    CHECK(p.gate_count==0u);
    CHECK(hq_emit_and(&p,hq_input(0u),hq_input(99u),&r)==HQ_ERR_REF);
    CHECK(p.gate_count==0u);
    CHECK(hq_emit_mux((HQProgram*)0,hq_input(0u),hq_input(1u),hq_input(2u),&r)==HQ_ERR_NULL);
    CHECK(hq_emit_mux(&p,hq_input(0u),hq_input(1u),hq_input(2u),(HQRef*)0)==HQ_ERR_NULL);
    CHECK(hq_bit_read(&cell,&generation_value,&gen)==HQ_CELL_OK);
    CHECK(generation_value==HQ_TRUE && gen==7u);
    CHECK(hq_bit_tick(&cell,6u,HQ_TRUE,HQ_FALSE,&out)==HQ_CELL_STALE);
    CHECK(cell.value==HQ_TRUE && cell.generation==7u && out==HQ_FALSE);
    CHECK(hq_bit_tick(&cell,7u,(HQTruth)19,HQ_FALSE,&out)==HQ_CELL_VALUE);
    CHECK(cell.value==HQ_TRUE && cell.generation==7u && out==HQ_FALSE);
    CHECK(hq_bit_tick(&cell,7u,HQ_TRUE,(HQTruth)19,&out)==HQ_CELL_VALUE);
    CHECK(cell.value==HQ_TRUE && cell.generation==7u && out==HQ_FALSE);
    CHECK(hq_bit_tick(&cell,7u,HQ_TRUE,HQ_FALSE,(HQTruth*)0)==HQ_CELL_NULL);
    CHECK(cell.value==HQ_TRUE && cell.generation==7u);
    cell.generation=UINT_MAX;
    CHECK(hq_bit_tick(&cell,UINT_MAX,HQ_TRUE,HQ_FALSE,&out)==HQ_CELL_EXHAUSTED);
    CHECK(cell.value==HQ_TRUE && cell.generation==UINT_MAX && out==HQ_FALSE);
    CHECK(hq_bit_init(&cell,(HQTruth)19)==HQ_CELL_VALUE);
    CHECK(cell.value==HQ_TRUE && cell.generation==UINT_MAX);
    cell.value=(HQTruth)50;
    CHECK(hq_bit_read(&cell,&generation_value,&gen)==HQ_CELL_VALUE);
    CHECK(gen==7u && generation_value==HQ_TRUE);
    CHECK(hq_bit_tick(&cell,UINT_MAX,HQ_TRUE,HQ_FALSE,&out)==HQ_CELL_VALUE);
    CHECK(out==HQ_FALSE);
    CHECK(hq_bit_init(&cell,HQ_UNKNOWN)==HQ_CELL_OK);
    CHECK(cell.value==HQ_UNKNOWN && cell.generation==0u);
    CHECK(hq_bit_tick(&cell,0u,HQ_TRUE,HQ_TRUE,&out)==HQ_CELL_OK);
    CHECK(out==HQ_TRUE && cell.generation==1u);
    CHECK(hq_bit_tick(&cell,1u,HQ_FALSE,HQ_FALSE,&out)==HQ_CELL_OK);
    CHECK(out==HQ_TRUE && cell.generation==2u);
    CHECK(hq_bit_tick(&cell,2u,HQ_TRUE,HQ_FALSE,&out)==HQ_CELL_OK);
    CHECK(out==HQ_FALSE && cell.generation==3u);
    CHECK(hq_bit_tick(&cell,3u,HQ_UNKNOWN,HQ_TRUE,&out)==HQ_CELL_OK);
    CHECK(out==HQ_UNKNOWN && cell.generation==4u);
}
int main(void) {
    unsigned int i;
    gates(); mux_and_memory(); demux_and_lock(); composition(); partial_capacity(); errors();
    /* A deterministic repetitive regression over all ternary combinations. */
    for(i=0u;i<2048u;i++) {
        HQBitCell cell; HQTruth out=HQ_UNKNOWN;
        HQTruth old=v[i%3u],data=v[(i/3u)%3u],enable=v[(i/9u)%3u];
        CHECK(hq_bit_init(&cell,old)==HQ_CELL_OK);
        CHECK(hq_bit_tick(&cell,0u,enable,data,&out)==HQ_CELL_OK);
        CHECK(out==mx(old,data,enable));
    }
    printf("COMPOSITES_TESTS=PASS ASSERTIONS=%lu\n",checks);
    return 0;
}
