#include "hqd_separation.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <limits.h>
static unsigned long assertions=0;
#define CK(x) do { ++assertions; if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;} }while(0)
static unsigned pick(int domain,int val) {
    int lo=domain==HQD_BALANCED3?-1:domain==HQD_PURE5?0:-3;
    return 1u << (unsigned)(val-lo);
}
static int ranges(int domain,int *lo,int *hi) {
    if(domain==HQD_BALANCED3){*lo=-1;*hi=1;return 1;}
    if(domain==HQD_PURE5){*lo=0;*hi=4;return 1;}
    if(domain==HQD_BALANCED7){*lo=-3;*hi=3;return 1;}
    return 0;
}
static unsigned ref_joint(int domain,unsigned a,unsigned b) {
    unsigned j=0;
    int lo,hi;
    ranges(domain,&lo,&hi);
    int r=hi-lo+1;
    for(int x=lo;x<=hi;++x) if(a&pick(domain,x))
      for(int y=lo;y<=hi;++y) if(b&pick(domain,y)) {
          int n=x+y,c=0,d;
          if(domain==HQD_PURE5){c=n/5;d=n%5;}
          else {if(n>hi){n-=r;c=1;} if(n<lo){n+=r;c=-1;} d=n;}
          j|=1u << (unsigned)((c+(domain==HQD_PURE5?0:1))*r+(d-lo));
      }
    return j;
}
static int exhaust_domain(HQDDomain domain) {
    int lo,hi;
    ranges(domain,&lo,&hi);
    unsigned limit=1u << (unsigned)(hi-lo+1);
    HQDRecord a,b,d,c;
    HQDAddResult result;
    uint8_t rel;
    for(unsigned am=0;am<limit;++am) {
      CK(hqd_possibilities(domain,am,(am==0u || !(am&(am-1u)))?0u:3u,&a)==HQD_OK);
      CK(hqd_validate(&a)==HQD_OK);
      for(unsigned bm=0;bm<limit;++bm) {
        CK(hqd_possibilities(domain,bm,(bm==0u || !(bm&(bm-1u)))?0u:1u,&b)==HQD_OK);
        CK(hqd_add_digits(&a,&b,&result)==HQD_OK);
        CK(result.domain==domain);
        CK(result.joint==ref_joint(domain,am,bm));
        CK(hqd_add_project(&result,&d,&c)==HQD_OK);
        CK(hqd_validate(&d)==HQD_OK && hqd_validate(&c)==HQD_OK);
        /* The projected pair masks must cover precisely the realizable pairs. */
        unsigned expect_d=0u,expect_c=0u;
        int r=hi-lo+1,cn=domain==HQD_PURE5?2:3;
        for(int k=0;k<cn;++k)for(int n=0;n<r;++n)
          if(result.joint & (1u << (unsigned)(k*r+n))) {
              expect_d|=1u<<(unsigned)n;expect_c|=1u<<(unsigned)k;
          }
        CK(d.knowledge.possibilities==expect_d);
        CK(c.knowledge.possibilities==expect_c);
        CK(hqd_compare(&a,&b,&rel)==HQD_OK);
        unsigned expect_rel=0u;
        for(int x=lo;x<=hi;++x) if(am&pick(domain,x))
          for(int y=lo;y<=hi;++y) if(bm&pick(domain,y))
            expect_rel|=x<y?HQD_LT:x>y?HQD_GT:HQD_EQ;
        CK(rel==expect_rel);
        if(rel) {
            HQDRecord logic;
            CK(hqd_relation_truth(rel,HQD_EQ,&logic)==HQD_OK);
            CK(logic.domain==HQD_KLEENE3 && logic.data.kind==HQD_LOGIC);
            CK(logic.data.logic==(rel==HQD_EQ?HQ_TRUE:
                 !(rel&HQD_EQ)?HQ_FALSE:HQ_UNKNOWN));
            CK(logic.knowledge.possibilities==(1u<<(unsigned)logic.data.logic));
        } else {
            HQDRecord untouched;
            memset(&untouched,0x5a,sizeof untouched);
            HQDRecord saved=untouched;
            CK(hqd_relation_truth(rel,HQD_EQ,&untouched)==HQD_BAD_VALUE);
            CK(memcmp(&saved,&untouched,sizeof saved)==0);
        }
        /* Grades never influence numerical results when possibilities match. */
        if(am>0u) {
            HQDRecord modified=a;
            modified.knowledge.unknown_grade=a.data.kind==HQD_ABSENT?2u:0u;
            HQDAddResult check;
            CK(hqd_add_digits(&modified,&b,&check)==HQD_OK);
            CK(check.joint==result.joint);
        }
      }
    }
    /* Exact arithmetic and lossless numerical projection. */
    for(int v=lo;v<=hi;++v) {
        int got=-99;
        CK(hqd_exact_number(domain,v,&a)==HQD_OK);
        CK(hqd_get_number(&a,&got)==HQD_OK && got==v);
        CK(a.knowledge.possibilities==pick(domain,v));
    }
    return 0;
}
static int fixtures(void) {
    HQDRecord a,b,c,d,old;
    HQDAddResult sum,stored;
    HQ5Value legacy,out5;
    HQ7Set old7,out7;
    HQXCondition outx;
    uint8_t relations=0u;
    int allow=77,value=77;
    /* Explicit numeric zero is not missing data. */
    CK(hqd_exact_number(HQD_BALANCED3,0,&a)==HQD_OK);
    CK(a.data.kind==HQD_NUMBER && a.data.number==0);
    CK(a.knowledge.possibilities==2u);
    CK(hqd_possibilities(HQD_BALANCED3,7u,3u,&b)==HQD_OK);
    CK(b.data.kind==HQD_ABSENT && b.knowledge.possibilities==7u);
    CK(hqd_get_number(&b,&value)==HQD_DENIED && value==77);
    CK(hqd_add_digits(&a,&b,&sum)==HQD_OK);
    CK(hqd_add_project(&sum,&c,&d)==HQD_OK);
    CK(c.data.kind==HQD_ABSENT && c.knowledge.possibilities==7u);
    CK(d.data.kind==HQD_NUMBER && d.data.number==0);
    /* Strong Kleene UNKNOWN is a mathematical logical symbol, not unknown numeric. */
    CK(hqd_exact_logic(HQ_UNKNOWN,&c)==HQD_OK);
    CK(c.data.kind==HQD_LOGIC && c.data.logic==HQ_UNKNOWN);
    CK(c.knowledge.possibilities==(1u<<HQ_UNKNOWN));
    CK(hqd_get_number(&c,&value)==HQD_DENIED && value==77);
    CK(hqd_add_digits(&c,&a,&sum)==HQD_BAD_DOMAIN);
    /* Untrusted 'verified' or grade cannot synthesize an exact value. */
    CK(hqd_possibilities(HQD_BALANCED3,3u,3u,&a)==HQD_OK);
    a.provenance.origin=HQD_ORIGIN_CALLER;
    a.provenance.source_id=777u;
    CK(hqd_get_number(&a,&value)==HQD_DENIED);
    CK(hqd_validate(&a)==HQD_OK);
    /* Contradiction is an empty knowledge set, not failed execution. */
    CK(hqd_exact_number(HQD_BALANCED3,1,&a)==HQD_OK);
    CK(hqd_exact_number(HQD_BALANCED3,-1,&b)==HQD_OK);
    CK(hqd_refine(&a,&b,&c)==HQD_OK);
    CK(c.knowledge.possibilities==0u && c.data.kind==HQD_ABSENT);
    CK(c.execution.state==HQD_EXEC_COMPLETE);
    CK(hqd_add_digits(&c,&a,&sum)==HQD_OK && sum.joint==0u);
    /* Derivation is tagged, and does not become authenticated provenance. */
    CK(c.provenance.origin==HQD_ORIGIN_DERIVED && c.provenance.source_id==0u);
    /* Failed operations must not silently feed numeric computation. */
    b=a;
    b.data.kind=HQD_ABSENT;b.data.number=0;
    b.knowledge.possibilities=7u;
    b.execution.state=HQD_EXEC_FAILED;b.execution.error_code=19u;
    CK(hqd_validate(&b)==HQD_OK);
    stored=sum;
    CK(hqd_add_digits(&a,&b,&sum)==HQD_DENIED);
    CK(memcmp(&sum,&stored,sizeof sum)==0);
    CK(hqd_get_number(&b,&value)==HQD_DENIED && value==77);
    out5.domain=HQ5_DOMAIN_PURE5;out5.symbol=42u;
    CK(hqd_to_hq5(&b,HQD_BRIDGE_ALLOW_U|HQD_BRIDGE_ALLOW_E,&out5)==HQD_DENIED);
    CK(out5.symbol==42u && out5.domain==HQ5_DOMAIN_PURE5);
    b.execution.state=HQD_EXEC_COMPLETION_UNKNOWN;b.execution.error_code=0u;
    CK(hqd_validate(&b)==HQD_OK);
    CK(hqd_refine(&a,&b,&c)==HQD_DENIED);
    /* Logical guards never use unresolved metadata as authority. */
    CK(hqd_possibilities(HQD_KLEENE3,3u,1u,&a)==HQD_OK);
    CK(hqd_guard_proposal(&a,&allow)==HQD_OK && allow==0);
    a.provenance.origin=HQD_ORIGIN_CALLER;a.provenance.source_id=33u;
    CK(hqd_guard_proposal(&a,&allow)==HQD_OK && allow==0);
    CK(hqd_possibilities(HQD_BALANCED3,7u,1u,&b)==HQD_OK);
    CK(hqd_possibilities(HQD_BALANCED3,7u,3u,&c)==HQD_OK);
    b.provenance.origin=HQD_ORIGIN_CALLER;b.provenance.source_id=999u;
    CK(hqd_add_digits(&b,&c,&sum)==HQD_OK);
    stored=sum;
    c.provenance.origin=HQD_ORIGIN_CALLER;c.provenance.source_id=0xffffffffu;
    CK(hqd_add_digits(&b,&c,&sum)==HQD_OK && sum.joint==stored.joint);
    CK(hqd_exact_logic(HQ_TRUE,&a)==HQD_OK);
    CK(hqd_guard_proposal(&a,&allow)==HQD_OK && allow==1);
    a.execution.state=HQD_EXEC_FAILED;a.execution.error_code=1u;
    a.data.kind=HQD_ABSENT;a.data.logic=HQ_FALSE;
    a.knowledge.possibilities=7u;
    CK(hqd_guard_proposal(&a,&allow)==HQD_OK && allow==0);
    /* Legacy U/E moved into metadata, not into a numeric value. */
    legacy.domain=HQ5_DOMAIN_TERNARY_UE;
    for(unsigned sym=0;sym<5u;++sym) {
        legacy.symbol=(uint8_t)sym;
        CK(hqd_from_hq5(legacy,&a)==HQD_OK);
        CK(hqd_validate(&a)==HQD_OK);
        if(sym<3u) CK(a.data.kind==HQD_NUMBER && a.data.number==(int)sym-1);
        else CK(a.data.kind==HQD_ABSENT && a.knowledge.possibilities==7u);
        if(sym==HQ5_E) {
            CK(a.execution.state==HQD_EXEC_COMPLETE);
            CK(a.execution.marker==HQD_LEGACY_E_MARKER);
        }
        old=a;
        CK(hqd_to_hq5(&a,HQD_BRIDGE_EXACT,&out5)==
           (sym<3u?HQD_OK:HQD_DENIED));
        CK(memcmp(&a,&old,sizeof a)==0);
        CK(hqd_to_hq5(&a,HQD_BRIDGE_ALLOW_U|HQD_BRIDGE_ALLOW_E,&out5)==HQD_OK);
        CK(out5.symbol==sym && out5.domain==legacy.domain);
        if(sym>=3u) {
            CK(hqd_add_digits(&a,&a,&sum)==(sym==HQ5_U?HQD_OK:HQD_DENIED));
        }
    }
    legacy.domain=HQ5_DOMAIN_PURE5;
    for(unsigned sym=0;sym<5u;++sym) {
        legacy.symbol=(uint8_t)sym;
        CK(hqd_from_hq5(legacy,&a)==HQD_OK);
        CK(hqd_to_hq5(&a,HQD_BRIDGE_EXACT,&out5)==HQD_OK);
        CK(out5.symbol==sym && out5.domain==legacy.domain);
    }
    CK(hqd_from_hqx(HQX_UNKNOWN,&a)==HQD_OK);
    CK(a.data.kind==HQD_LOGIC && a.data.logic==HQ_UNKNOWN);
    CK(hqd_to_hqx(&a,HQD_BRIDGE_EXACT,&outx)==HQD_OK && outx==HQX_UNKNOWN);
    CK(hqd_from_hqx(HQX_ERROR,&a)==HQD_OK);
    CK(a.data.kind==HQD_ABSENT && a.execution.marker==HQD_LEGACY_E_MARKER);
    CK(hqd_to_hqx(&a,HQD_BRIDGE_EXACT,&outx)==HQD_DENIED);
    CK(hqd_to_hqx(&a,HQD_BRIDGE_ALLOW_E,&outx)==HQD_OK && outx==HQX_ERROR);
    CK(hqd_exact_number(HQD_BALANCED7,2,&a)==HQD_OK);
    CK(hqd_to_hq7(&a,&out7)==HQD_OK && out7.mask==(1u<<5));
    for(unsigned mask=0u;mask<=HQ7_ALL;++mask) {
        old7.mask=(uint8_t)mask;
        CK(hqd_from_hq7(old7,&a)==HQD_OK);
        CK(hqd_to_hq7(&a,&out7)==HQD_OK && out7.mask==mask);
    }
    CK(hqd_from_hq7((HQ7Set){0xffu},&a)==HQD_BAD_VALUE);
    /* Legacy E cannot be quietly re-labelled as verified operation failure. */
    CK(hqd_from_hqx(HQX_ERROR,&a)==HQD_OK);
    CK(a.execution.state==HQD_EXEC_COMPLETE);
    CK(hqd_guard_proposal(&a,&allow)==HQD_OK && allow==0);
    /* Invalid status / tampered evidence, output untouched. */
    CK(hqd_exact_number(HQD_BALANCED3,1,&a)==HQD_OK);
    b=a;b.knowledge.possibilities=7u;
    CK(hqd_validate(&b)==HQD_BAD_METADATA);
    stored=(HQDAddResult){0};stored.joint=0x313131u;
    sum=stored;
    CK(hqd_add_digits(&b,&a,&sum)==HQD_BAD_METADATA);
    CK(memcmp(&sum,&stored,sizeof sum)==0);
    b=a;b.knowledge.unknown_grade=3u;
    CK(hqd_validate(&b)==HQD_BAD_METADATA);
    b=a;b.provenance.origin=(HQDOrigin)200;
    CK(hqd_validate(&b)==HQD_BAD_METADATA);
    b=a;b.execution.marker=HQD_LEGACY_E_MARKER;
    CK(hqd_validate(&b)==HQD_BAD_METADATA);
    b=a;b.data.kind=HQD_ABSENT;b.data.number=0;
    b.knowledge.possibilities=7u;b.execution.marker=HQD_LEGACY_E_MARKER;
    b.knowledge.unknown_grade=2u;
    CK(hqd_validate(&b)==HQD_BAD_METADATA);
    CK(hqd_possibilities(HQD_PURE5,0x3fu,0u,&b)==HQD_BAD_METADATA);
    CK(hqd_possibilities(HQD_PURE5,0x01u,3u,&b)==HQD_BAD_METADATA);
    CK(hqd_possibilities(HQD_PURE5,0x00u,2u,&b)==HQD_BAD_METADATA);
    CK(hqd_exact_number(HQD_KLEENE3,0,&b)==HQD_BAD_VALUE);
    CK(hqd_exact_logic((HQTruth)77,&b)==HQD_BAD_VALUE);
    CK(hqd_exact_number(HQD_BALANCED3,0,&b)==HQD_OK);
    CK(hqd_compare(&a,&b,&relations)==HQD_OK && relations==HQD_GT);
    CK(hqd_relation_truth(0u,HQD_EQ,&a)==HQD_BAD_VALUE);
    CK(hqd_add_digits(&a,&b,&sum)==HQD_OK);
    old=a;
    CK(hqd_refine(&a,&b,&a)==HQD_OK && a.knowledge.possibilities==0u);
    CK(old.data.number==1);
    return 0;
}
int main(void) {
    CK(fixtures()==0);
    CK(exhaust_domain(HQD_BALANCED3)==0);
    CK(exhaust_domain(HQD_PURE5)==0);
    CK(exhaust_domain(HQD_BALANCED7)==0);
    printf("SEPARATION_TESTS=PASS ASSERTIONS=%lu\n",assertions);
    return 0;
}
/* Additional cross-version oracles can be compiled as separate fixtures; this
 * suite intentionally keeps v1.2 additive and never edits baseline programs. */
