#include "hci_recursive.h"
#include <stdio.h>

static unsigned int checks=0u;
#define CHECK(x) do {++checks;if(!(x)){fprintf(stderr,"RECUR_FAIL line %u: %s\n",(unsigned)__LINE__,#x);return 1;}}while(0)
static void node(HCIRecNode *n,unsigned int i) {
    n->identity=(HCIIdentity){100u+i,200u+i,1u,0u,77u};
    n->kind=HCI_RECUR_INPUT;n->input_port=0u;
    n->left=(const HCIRecNode*)0;n->right=(const HCIRecNode*)0;
}
static void nand(HCIRecNode *n,const HCIRecNode *a,const HCIRecNode *b) {
    n->kind=HCI_RECUR_NAND;n->input_port=0u;n->left=a;n->right=b;
}
static void setup_xor(HCIRecNode n[6]) {
    unsigned int i;
    for(i=0u;i<6u;++i) node(&n[i],i);
    n[1].input_port=1u;
    nand(&n[2],&n[0],&n[1]);
    nand(&n[3],&n[0],&n[2]);
    nand(&n[4],&n[1],&n[2]);
    nand(&n[5],&n[3],&n[4]);
}
static void setup_parity(HCIRecNode n[11]) {
    unsigned int i;
    for(i=0u;i<11u;++i) node(&n[i],i);
    n[1].input_port=1u;n[2].input_port=2u;
    nand(&n[3],&n[0],&n[1]);
    nand(&n[4],&n[0],&n[3]);
    nand(&n[5],&n[1],&n[3]);
    nand(&n[6],&n[4],&n[5]);
    nand(&n[7],&n[6],&n[2]);
    nand(&n[8],&n[6],&n[7]);
    nand(&n[9],&n[2],&n[7]);
    nand(&n[10],&n[8],&n[9]);
}
static int test_equivalence(void) {
    HCIRecNode x[6],n[11];
    HQProgram px,pp;
    HQRef xr,pr;
    unsigned int a,b,c,i;
    HCIRecTrace trace;
    HQTruth result,expected,in[3];
    setup_xor(x);setup_parity(n);
    CHECK(hq_init(&px,2u)==HQ_OK);
    CHECK(hq_emit_xor(&px,hq_input(0u),hq_input(1u),&xr)==HQ_OK);
    CHECK(hq_export(&px,xr)==HQ_OK);
    CHECK(hq_init(&pp,3u)==HQ_OK);
    CHECK(hq_emit_xor(&pp,hq_input(0u),hq_input(1u),&xr)==HQ_OK);
    CHECK(hq_emit_xor(&pp,xr,hq_input(2u),&pr)==HQ_OK);
    CHECK(hq_export(&pp,pr)==HQ_OK);
    for(a=0u;a<3u;++a) for(b=0u;b<3u;++b) {
        in[0]=(HQTruth)a;in[1]=(HQTruth)b;
        CHECK(hci_recursive_evaluate(&x[5],in,2u,4u,&result,&trace)==HCI_OK);
        CHECK(hq_eval(&px,in,2u,&expected,1u)==HQ_OK);
        CHECK(result==expected && trace.visited==6u && trace.nand_evaluated==4u);
        CHECK(trace.cache_hits>=3u && trace.budget_used==4u);
    }
    for(a=0u;a<3u;++a)for(b=0u;b<3u;++b)for(c=0u;c<3u;++c) {
        in[0]=(HQTruth)a;in[1]=(HQTruth)b;in[2]=(HQTruth)c;
        CHECK(hci_recursive_evaluate(&n[10],in,3u,8u,&result,&trace)==HCI_OK);
        CHECK(hq_eval(&pp,in,3u,&expected,1u)==HQ_OK);
        CHECK(result==expected && trace.visited==11u && trace.nand_evaluated==8u);
    }
    for(i=0u;i<2000u;++i) {
        in[0]=(HQTruth)((i*17u)%3u);
        in[1]=(HQTruth)((i*7u+1u)%3u);
        in[2]=(HQTruth)((i*5u+2u)%3u);
        CHECK(hci_recursive_evaluate(&n[10],in,3u,8u,&result,&trace)==HCI_OK);
        CHECK(hq_eval(&pp,in,3u,&expected,1u)==HQ_OK && expected==result);
    }
    return 0;
}
static int test_invalid(void) {
    HCIRecNode x[6],chain[11];
    HCIRecTrace t={0};
    HQTruth in[2]={HQ_TRUE,HQ_UNKNOWN},v=HQ_FALSE;
    unsigned int i;
    setup_xor(x);
    t.visited=777u;
    CHECK(hci_recursive_evaluate(&x[5],in,2u,3u,&v,&t)==HCI_ERR_BUDGET);
    CHECK(v==HQ_FALSE && t.visited==777u);
    x[3].identity.graph_gen=8u;
    CHECK(hci_recursive_evaluate(&x[5],in,2u,4u,&v,&t)==HCI_ERR_STALE);
    CHECK(v==HQ_FALSE && t.visited==777u);
    x[3].identity.graph_gen=1u;
    x[3].identity.snapshot_id=99u;
    CHECK(hci_recursive_evaluate(&x[5],in,2u,4u,&v,&t)==HCI_ERR_STALE);
    x[3].identity.snapshot_id=77u;
    x[2].identity.instance_id=x[1].identity.instance_id;
    CHECK(hci_recursive_evaluate(&x[5],in,2u,4u,&v,&t)==HCI_ERR_INVALID);
    x[2].identity.instance_id=202u;
    x[2].left=&x[2];
    CHECK(hci_recursive_evaluate(&x[5],in,2u,4u,&v,&t)==HCI_ERR_INVALID);
    x[2].left=&x[0];
    x[1].input_port=3u;
    CHECK(hci_recursive_evaluate(&x[5],in,2u,4u,&v,&t)==HCI_ERR_INVALID);
    x[1].input_port=1u;
    in[0]=(HQTruth)99;
    CHECK(hci_recursive_evaluate(&x[5],in,2u,4u,&v,&t)==HCI_ERR_INVALID);
    CHECK(v==HQ_FALSE && t.visited==777u);
    in[0]=HQ_TRUE;
    CHECK(hci_recursive_evaluate(&x[5],in,0u,4u,&v,&t)==HCI_ERR_INVALID);
    CHECK(hci_recursive_evaluate(&x[5],in,2u,0u,&v,&t)==HCI_ERR_INVALID);
    CHECK(hci_recursive_evaluate(&x[5],in,2u,17u,&v,&t)==HCI_ERR_INVALID);
    CHECK(hci_recursive_evaluate(&x[5],in,2u,4u,(HQTruth*)0,&t)==HCI_ERR_NULL);
    CHECK(hci_recursive_evaluate(&x[5],in,2u,4u,&v,(HCIRecTrace*)0)==HCI_ERR_NULL);
    for(i=0u;i<11u;++i) node(&chain[i],i);
    chain[0].input_port=0u;
    for(i=1u;i<11u;++i)nand(&chain[i],&chain[i-1u],&chain[0]);
    CHECK(hci_recursive_evaluate(&chain[10],in,2u,16u,&v,&t)==HCI_ERR_CAPACITY);
    CHECK(v==HQ_FALSE && t.visited==777u);
    return 0;
}
int main(void) {
    CHECK(test_equivalence()==0);
    CHECK(test_invalid()==0);
    printf("RECURSIVE_PASS assertions=%u\n",checks);
    return 0;
}
