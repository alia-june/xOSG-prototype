#include <stdio.h>
#include <stddef.h>
#include <string.h>
static unsigned int checks=0;
#define CHECK(c) do {++checks;if(!(c)){printf("SHIM_FAIL line=%u\n",(unsigned)__LINE__);return 1;}}while(0)
int main(void) {
    unsigned char src[128],dst[128];
    size_t size,i;
    for(size=0u;size<=128u;++size) {
        for(i=0u;i<128u;++i) {src[i]=(unsigned char)(i+size);dst[i]=0x67u;}
        CHECK(memcpy(dst,src,size)==(void*)dst);
        for(i=0u;i<128u;++i) CHECK(dst[i]==(i<size?src[i]:0x67u));
        CHECK(memset(dst,0xa5,size)==(void*)dst);
        for(i=0u;i<128u;++i) CHECK(dst[i]==(i<size?0xa5u:0x67u));
    }
    printf("SHIM_PASS assertions=%u\n",checks);
    return 0;
}
