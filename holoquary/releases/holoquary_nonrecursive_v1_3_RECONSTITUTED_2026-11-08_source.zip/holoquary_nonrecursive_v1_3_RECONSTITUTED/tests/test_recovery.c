#include "hci_recovery.h"
#include <stdio.h>
#include <limits.h>

static unsigned int checks=0u;
#define REQUIRE(x) do { ++checks; if(!(x)) { fprintf(stderr,"FAIL:%u: %s\n",(unsigned)__LINE__,#x); return 1; } } while(0)

typedef struct {
    HCILogicAdapter *adapter;
    HQTruth inputs[2];
    unsigned int calls;
    unsigned int mode; /* 0 correct, 1 simulated error, 2 wrong generation, 3 invalid success */
} Fixture;
static HCIStatus reeval(const HCIFrame *origin,unsigned int next,
                         const void *context,HCIFrame *out) {
    Fixture *f=(Fixture*)context;
    HCILogicAdapter local=*f->adapter;
    (void)origin;
    ++f->calls;
    if(f->mode==1u) return HCI_ERR_SOURCE;
    local.identity.snapshot_id=next;
    if(hci_observe_logic(&local,f->inputs,2u,2u,out)!=HCI_OK) return HCI_ERR_SOURCE;
    if(f->mode==2u) ++out->identity.graph_gen;
    if(f->mode==3u) out->execution=HCI_COMPLETION_UNKNOWN;
    return HCI_OK;
}
static HCIFrame error_frame(const HCILogicAdapter *adapter) {
    HCIFrame f={0};
    HQTruth bad[2]={HQ_TRUE,(HQTruth)79};
    (void)hci_observe_logic(adapter,bad,2u,2u,&f);
    return f;
}
static int test_recovery(void) {
    HCIRecoveryStore store;
    HCIRecoveryEvent receipt,retained,prior;
    HCIRecoveryGrant grant={0};
    HQProgram p;
    HQRef gate;
    HCILogicAdapter adapter;
    HCIFrame failure,uncertain,healthy;
    Fixture fixture={0};
    unsigned int i;
    REQUIRE(hq_init(&p,2u)==HQ_OK);
    REQUIRE(hq_add_nand(&p,hq_input(0u),hq_input(1u),&gate)==HQ_OK);
    REQUIRE(hq_export(&p,gate)==HQ_OK);
    adapter.program=&p;
    adapter.identity=(HCIIdentity){5u,6u,7u,0u,11u};
    failure=error_frame(&adapter);
    REQUIRE(failure.execution==HCI_FAILED && failure.source_status!=HQ_OK);
    REQUIRE(hci_recovery_init(&store,42u,2u)==HCI_OK);
    REQUIRE(hci_recovery_record(&store,100u,&failure,HCI_ERR_INVALID,HCI_EFFECT_PURE,&receipt)==HCI_OK);
    REQUIRE(receipt.outcome==HCI_REC_FAILURE && store.count==1u);
    retained=receipt;
    fixture.adapter=&adapter;fixture.inputs[0]=HQ_TRUE;fixture.inputs[1]=HQ_FALSE;
    grant.policy_id=702u;grant.scope_id=42u;grant.parent_failure_id=100u;
    grant.exact_origin=failure.identity;grant.max_attempts=2u;grant.permit_pure_reeval=1u;
    fixture.mode=1u;
    REQUIRE(hci_recovery_attempt(&store,101u,12u,&grant,reeval,&fixture,&receipt)==HCI_OK);
    REQUIRE(receipt.outcome==HCI_REC_REEVAL_FAILED && receipt.native_error==HCI_ERR_SOURCE);
    REQUIRE(store.count==2u && fixture.calls==1u);
    fixture.mode=0u;
    REQUIRE(hci_recovery_attempt(&store,102u,13u,&grant,reeval,&fixture,&receipt)==HCI_OK);
    REQUIRE(receipt.outcome==HCI_REC_REEVAL_COMPLETED && receipt.observed.execution==HCI_COMPLETED);
    REQUIRE(receipt.observed.truth==HQ_TRUE && receipt.observed.identity.snapshot_id==13u);
    REQUIRE(store.events[0].native_error==HCI_ERR_INVALID && store.events[0].observed.execution==HCI_FAILED);
    REQUIRE(store.events[0].event_id==retained.event_id && store.count==3u && fixture.calls==2u);
    REQUIRE(hci_recovery_attempt(&store,103u,14u,&grant,reeval,&fixture,&receipt)==HCI_ERR_DENIED);
    REQUIRE(receipt.outcome==HCI_REC_BLOCKED && fixture.calls==2u && store.count==4u);
    REQUIRE(hci_recovery_attempt(&store,103u,15u,&grant,reeval,&fixture,&receipt)==HCI_ERR_INVALID);
    REQUIRE(store.count==4u);
    prior=receipt;grant.exact_origin.graph_gen++;
    REQUIRE(hci_recovery_attempt(&store,104u,16u,&grant,reeval,&fixture,&receipt)==HCI_ERR_STALE);
    REQUIRE(store.count==4u && receipt.event_id==prior.event_id);
    grant.exact_origin.graph_gen--;
    grant.scope_id=100u;
    REQUIRE(hci_recovery_attempt(&store,104u,16u,&grant,reeval,&fixture,&receipt)==HCI_ERR_INVALID);
    grant.scope_id=42u;
    REQUIRE(store.count==4u && fixture.calls==2u);
    REQUIRE(hci_recovery_record(&store,100u,&failure,HCI_ERR_INVALID,HCI_EFFECT_PURE,&receipt)==HCI_ERR_INVALID);
    REQUIRE(hci_recovery_record(&store,120u,&failure,HCI_OK,HCI_EFFECT_PURE,&receipt)==HCI_ERR_INVALID);
    REQUIRE(store.count==4u);
    REQUIRE(hci_recovery_record(&store,110u,&failure,HCI_ERR_SOURCE,HCI_EFFECT_EXTERNAL,&receipt)==HCI_OK);
    grant.parent_failure_id=110u;
    REQUIRE(hci_recovery_attempt(&store,111u,18u,&grant,reeval,&fixture,&receipt)==HCI_ERR_DENIED);
    REQUIRE(receipt.outcome==HCI_REC_BLOCKED && fixture.calls==2u);
    uncertain=failure;
    uncertain.identity.snapshot_id=19u;uncertain.execution=HCI_COMPLETION_UNKNOWN;
    REQUIRE(hci_recovery_record(&store,112u,&uncertain,HCI_OK,HCI_EFFECT_UNKNOWN,&receipt)==HCI_OK);
    grant.parent_failure_id=112u;grant.exact_origin=uncertain.identity;
    REQUIRE(hci_recovery_attempt(&store,113u,20u,&grant,reeval,&fixture,&receipt)==HCI_ERR_DENIED);
    REQUIRE(receipt.outcome==HCI_REC_BLOCKED && fixture.calls==2u);
    grant.parent_failure_id=100u;grant.exact_origin=failure.identity;
    healthy=failure;healthy.execution=HCI_COMPLETED;healthy.source_status=HQ_OK;
    REQUIRE(hci_recovery_record(&store,114u,&healthy,HCI_ERR_INVALID,HCI_EFFECT_PURE,&receipt)==HCI_ERR_INVALID);
    REQUIRE(hci_recovery_record(&store,114u,&failure,HCI_ERR_INVALID,(HCIEffect)19,&receipt)==HCI_ERR_INVALID);
    REQUIRE(hci_recovery_record(&store,114u,&failure,HCI_ERR_INVALID,HCI_EFFECT_PURE,&receipt)==HCI_OK);
    grant.parent_failure_id=114u;grant.exact_origin=failure.identity;
    fixture.mode=2u;
    REQUIRE(hci_recovery_attempt(&store,115u,21u,&grant,reeval,&fixture,&receipt)==HCI_OK);
    REQUIRE(receipt.outcome==HCI_REC_REEVAL_FAILED && receipt.native_error==HCI_ERR_INVALID);
    fixture.mode=3u;
    REQUIRE(hci_recovery_attempt(&store,116u,22u,&grant,reeval,&fixture,&receipt)==HCI_OK);
    REQUIRE(receipt.outcome==HCI_REC_REEVAL_FAILED && fixture.calls==4u);
    REQUIRE(hci_recovery_attempt(&store,117u,23u,&grant,reeval,&fixture,&receipt)==HCI_ERR_DENIED);
    REQUIRE(receipt.outcome==HCI_REC_BLOCKED && fixture.calls==4u);
    grant.max_attempts=3u;
    REQUIRE(hci_recovery_attempt(&store,118u,23u,&grant,reeval,&fixture,&receipt)==HCI_ERR_INVALID);
    grant.max_attempts=2u;
    grant.parent_failure_id=100u;
    grant.exact_origin=failure.identity;
    REQUIRE(hci_recovery_attempt(&store,119u,24u,&grant,0,&fixture,&receipt)==HCI_ERR_DENIED);
    REQUIRE(receipt.outcome==HCI_REC_BLOCKED && fixture.calls==4u);
    /* Exhaust event capacity with source failures; verify full-store atomicity. */
    while(store.count<HCI_REC_MAX_EVENTS) {
        i=300u+store.count;
        REQUIRE(hci_recovery_record(&store,i,&failure,HCI_ERR_SOURCE,HCI_EFFECT_PURE,&receipt)==HCI_OK);
    }
    prior=receipt;
    REQUIRE(hci_recovery_record(&store,999u,&failure,HCI_ERR_SOURCE,HCI_EFFECT_PURE,&receipt)==HCI_ERR_CAPACITY);
    REQUIRE(store.count==HCI_REC_MAX_EVENTS && receipt.event_id==prior.event_id);
    REQUIRE(hci_recovery_init(&store,0u,1u)==HCI_ERR_INVALID);
    REQUIRE(hci_recovery_init(&store,42u,0u)==HCI_ERR_INVALID);
    REQUIRE(hci_recovery_init(&store,42u,4u)==HCI_ERR_INVALID);
    return 0;
}
static int test_repeated(void) {
    HCIRecoveryStore s;
    HCIFrame f={0};
    HCIRecoveryEvent r;
    unsigned int i;
    f.identity=(HCIIdentity){7u,8u,1u,0u,9u};
    f.kind=HCI_LOGIC;
    f.execution=HCI_FAILED;
    f.result_kind=HCI_RESULT_NONE;
    f.input_count=2u;
    for(i=0u;i<2000u;++i) {
        REQUIRE(hci_recovery_init(&s,33u,1u)==HCI_OK);
        REQUIRE(hci_recovery_record(&s,17u,&f,HCI_ERR_SOURCE,HCI_EFFECT_PURE,&r)==HCI_OK);
        REQUIRE(s.events[0].native_error==HCI_ERR_SOURCE);
    }
    return 0;
}
int main(void) {
    REQUIRE(test_recovery()==0);
    REQUIRE(test_repeated()==0);
    printf("RECOVERY_PASS assertions=%u\n",checks);
    return 0;
}
