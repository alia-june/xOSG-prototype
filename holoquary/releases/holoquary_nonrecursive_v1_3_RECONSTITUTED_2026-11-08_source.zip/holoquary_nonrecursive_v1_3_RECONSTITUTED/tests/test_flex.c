#include "hci_flex.h"
#include "hci_recovery.h"
#include <stdio.h>
#include <string.h>
#include <float.h>

static unsigned int checks;
#define CHECK(expr) do { ++checks; if(!(expr)) {fprintf(stderr,"FLEX_FAIL line=%u %s\n",(unsigned)__LINE__,#expr);return 1;} } while(0)
static HCIIdentity id(unsigned int base,unsigned int snap,unsigned int params) {
    HCIIdentity x={base,base+100u,1u,params,snap};return x;
}
static int prepare_logic(HQProgram *p) {
    HQRef gate;
    return hq_init(p,2u)==HQ_OK &&
        hq_emit_xor(p,hq_input(0u),hq_input(1u),&gate)==HQ_OK &&
        hq_export(p,gate)==HQ_OK;
}
static int prepare_neural(DNNModel *m) {
    unsigned int dims[2]={2u,1u};
    if(!dnn_init(m,dims,1u,1u,DNN_UNIFORM)) return 0;
    m->p[0]=1.0f;m->p[1]=0.0f;m->p[2]=0.0f;
    return 1;
}
static HCIFlexPort logic_port(unsigned int n,unsigned int snap,HQTruth t) {
    HCIFlexPort p={0};
    p.type=HCI_FLEX_LOGIC;p.source=id(n,snap,0u);
    p.logic=t;p.origin=HCI_INPUT_UNATTESTED;
    return p;
}
static HCIFlexPort numeric_port(unsigned int n,unsigned int snap,float x) {
    HCIFlexPort p={0};
    p.type=HCI_FLEX_NUMERIC;p.source=id(n,snap,1u);
    p.numeric=x;p.origin=HCI_INPUT_UNATTESTED;
    return p;
}
static int test_logic_numeric_boundaries(void) {
    HQProgram graph;
    HCILogicAdapter logic;
    HCIThreshold policy[2]={{0.25f,0.75f,11u},{0.3f,0.7f,22u}};
    HCIFlexPort ports[2];
    HCIFlexSnapshot snap,unchanged;
    HCIFrame frame,old;
    unsigned int i;
    CHECK(prepare_logic(&graph));
    logic.program=&graph;logic.identity=id(20u,10u,0u);
    for(i=0u;i<6000u;++i) {
        float x=(float)(i%5u)*0.25f;
        HQTruth b=(HQTruth)(i%3u);
        HQTruth a=x<=0.25f?HQ_FALSE:x>=0.75f?HQ_TRUE:HQ_UNKNOWN;
        HQTruth expected_in[2]={a,b}, expected_out[1];
        ports[0]=numeric_port(1u,10u,x);
        ports[1]=logic_port(2u,10u,b);
        CHECK(hci_flex_capture(&snap,&logic.identity,ports,2u)==HCI_OK);
        CHECK(hci_flex_validate(&snap,&logic.identity)==HCI_OK);
        CHECK(hci_flex_eval_logic(&snap,&logic,policy,2u,2u,&frame)==HCI_OK);
        CHECK(frame.execution==HCI_COMPLETED && frame.input_origin==HCI_INPUT_CLASSIFIED);
        CHECK(frame.input_conversion_id==0u); /* mixed classified and direct logical ancestry */
        CHECK(hq_eval(&graph,expected_in,2u,expected_out,1u)==HQ_OK);
        CHECK(frame.truth==expected_out[0]);
        /* One corrupted input: no half-finished publication. */
        old=frame;
        snap.port[0].numeric=0.333f;
        CHECK(hci_flex_eval_logic(&snap,&logic,policy,2u,2u,&frame)==HCI_ERR_STALE);
        CHECK(frame.truth==old.truth && frame.identity.snapshot_id==old.identity.snapshot_id);
    }
    ports[0]=numeric_port(3u,10u,1.0f);
    ports[1]=numeric_port(4u,10u,0.0f);
    CHECK(hci_flex_capture(&snap,&logic.identity,ports,2u)==HCI_OK);
    CHECK(hci_flex_eval_logic(&snap,&logic,policy,2u,2u,&frame)==HCI_OK);
    CHECK(frame.truth==HQ_TRUE && frame.input_conversion_id==0u);
    CHECK(hci_flex_port_from_frame(&frame,&ports[0])==HCI_ERR_INVALID); /* aggregated policy mapping cannot be dropped */
    policy[1].conversion_id=11u;
    CHECK(hci_flex_eval_logic(&snap,&logic,policy,2u,2u,&frame)==HCI_OK);
    CHECK(frame.input_conversion_id==11u);
    CHECK(hci_flex_port_from_frame(&frame,&ports[0])==HCI_OK);
    CHECK(ports[0].type==HCI_FLEX_LOGIC && ports[0].origin==HCI_INPUT_CLASSIFIED);
    /* A downstream logic port inherits classified lineage, not raw-truth identity. */
    ports[1]=logic_port(5u,10u,HQ_FALSE);
    CHECK(hci_flex_capture(&snap,&logic.identity,ports,2u)==HCI_OK);
    CHECK(hci_flex_eval_logic(&snap,&logic,0,0u,2u,&frame)==HCI_OK);
    CHECK(frame.input_origin==HCI_INPUT_CLASSIFIED && frame.input_conversion_id==0u);
    CHECK(hci_flex_port_from_frame(&frame,&ports[1])==HCI_ERR_INVALID);
    ports[1]=ports[0];
    CHECK(hci_flex_capture(&snap,&logic.identity,ports,2u)==HCI_OK);
    CHECK(hci_flex_eval_logic(&snap,&logic,0,0u,2u,&frame)==HCI_OK);
    CHECK(frame.input_origin==HCI_INPUT_CLASSIFIED && frame.input_conversion_id==11u);
    policy[1].conversion_id=22u;
    ports[0]=numeric_port(3u,10u,1.0f);
    ports[1]=numeric_port(4u,10u,0.0f);
    CHECK(hci_flex_capture(&snap,&logic.identity,ports,2u)==HCI_OK);
    old=frame;
    policy[1].true_min=policy[1].false_max;
    CHECK(hci_flex_eval_logic(&snap,&logic,policy,2u,2u,&frame)==HCI_ERR_INVALID);
    CHECK(frame.truth==old.truth && frame.input_conversion_id==old.input_conversion_id);
    policy[1].true_min=0.7f;
    CHECK(hci_flex_eval_logic(&snap,&logic,0,0u,2u,&frame)==HCI_ERR_INVALID);
    unchanged=snap;
    ports[0]=numeric_port(8u,11u,0.0f);
    CHECK(hci_flex_capture(&snap,&logic.identity,ports,2u)==HCI_ERR_INVALID);
    CHECK(snap.checksum==unchanged.checksum && snap.port[0].numeric==unchanged.port[0].numeric);
    snap.target.param_gen++;
    CHECK(hci_flex_validate(&snap,&logic.identity)==HCI_ERR_STALE);
    snap=unchanged;
    snap.checksum^=1u;
    CHECK(hci_flex_validate(&snap,&logic.identity)==HCI_ERR_STALE);
    snap=unchanged;
    snap.port_count=HQ_MAX_INPUTS+1u;
    CHECK(hci_flex_validate(&snap,&logic.identity)==HCI_ERR_INVALID);
    snap=unchanged;
    ports[0]=numeric_port(8u,10u,FLT_MAX);
    ports[0].numeric*=2.0f;
    CHECK(hci_flex_capture(&snap,&logic.identity,ports,2u)==HCI_ERR_INVALID);
    ports[0]=numeric_port(8u,10u,1.0f);
    ports[0].type=(HCIFlexType)77;
    CHECK(hci_flex_capture(&snap,&logic.identity,ports,2u)==HCI_ERR_INVALID);
    return 0;
}
static int test_neural_inputs(void) {
    DNNModel m;
    HCINeuralAdapter a={0};
    HCIFrame from_nn,frame,prior;
    HCIFlexSnapshot snap;
    HCIFlexPort ports[2],p;
    unsigned int i;
    CHECK(prepare_neural(&m));
    a.model=&m;a.identity=id(41u,5u,8u);
    for(i=0u;i<3000u;++i) {
        float x[2]={i%2u?1.0f:0.0f,i%3u?0.0f:1.0f};
        ports[0]=numeric_port(11u,5u,x[0]);
        ports[1]=numeric_port(12u,5u,x[1]);
        CHECK(hci_flex_capture(&snap,&a.identity,ports,2u)==HCI_OK);
        CHECK(hci_flex_eval_neural(&snap,&a,4u,&frame)==HCI_OK);
        CHECK(frame.number==x[0] && frame.result_kind==HCI_RESULT_NUMERIC);
        CHECK(hci_flex_port_from_frame(&frame,&p)==HCI_OK && p.numeric==x[0]);
        CHECK(hci_observe_neural(&a,x,4u,&from_nn)==HCI_OK);
        CHECK(from_nn.number==frame.number);
        prior=frame;
        snap.port[1].numeric+=0.125f;
        CHECK(hci_flex_eval_neural(&snap,&a,4u,&frame)==HCI_ERR_STALE);
        CHECK(frame.number==prior.number);
        snap.port[1].numeric-=0.125f;
        CHECK(hci_flex_validate(&snap,&a.identity)==HCI_OK);
        snap.target.param_gen++;
        CHECK(hci_flex_eval_neural(&snap,&a,4u,&frame)==HCI_ERR_STALE);
    }
    a.identity.snapshot_id=6u;
    CHECK(hci_flex_validate(&snap,&a.identity)==HCI_ERR_STALE);
    return 0;
}
static int test_bound_replay(void) {
    HQProgram graph;
    HCILogicAdapter logic;
    HCIFlexPort ports[2];
    HCIFlexSnapshot snap;
    HCIFlexLogicReplay context;
    HCIRecoveryStore store;
    HCIRecoveryEvent receipt;
    HCIRecoveryGrant grant={0};
    HCIFrame failure={0},out={0};
    HCIThreshold policies[2]={{0.25f,0.75f,66u},{0.25f,0.75f,66u}};
    unsigned int before;
    CHECK(prepare_logic(&graph));
    logic.program=&graph;logic.identity=id(51u,21u,0u);
    ports[0]=numeric_port(61u,21u,1.0f);
    ports[1]=logic_port(62u,21u,HQ_FALSE);
    CHECK(hci_flex_capture(&snap,&logic.identity,ports,2u)==HCI_OK);
    context.snapshot=&snap;context.program=&graph;context.policies=policies;
    context.policy_count=2u;context.budget_left=4u;
    /* Synthetic earlier operation failed; this snapshot is caller-supplied.
     * It does not establish historical input authenticity or repair. */
    failure.identity=logic.identity;failure.kind=HCI_LOGIC;
    failure.execution=HCI_FAILED;failure.result_kind=HCI_RESULT_NONE;
    failure.source_status=HQ_ERR_VALUE;failure.input_count=2u;
    CHECK(hci_recovery_init(&store,90u,2u)==HCI_OK);
    CHECK(hci_recovery_record(&store,500u,&failure,HCI_ERR_SOURCE,HCI_EFFECT_PURE,&receipt)==HCI_OK);
    grant.policy_id=91u;grant.scope_id=90u;grant.parent_failure_id=500u;
    grant.exact_origin=failure.identity;grant.max_attempts=2u;grant.permit_pure_reeval=1u;
    CHECK(hci_recovery_attempt(&store,501u,22u,&grant,hci_flex_replay_logic,&context,&receipt)==HCI_OK);
    CHECK(receipt.outcome==HCI_REC_REEVAL_COMPLETED && receipt.observed.truth==HQ_TRUE);
    CHECK(receipt.observed.identity.snapshot_id==22u);
    CHECK(store.events[0].outcome==HCI_REC_FAILURE && store.events[0].native_error==HCI_ERR_SOURCE);
    CHECK(hci_recovery_attempt(&store,502u,23u,&grant,hci_flex_replay_logic,&context,&receipt)==HCI_ERR_DENIED);
    before=store.count;
    CHECK(hci_flex_replay_logic(&failure,0u,&context,&out)==HCI_ERR_INVALID);
    snap.port[0].numeric=0.0f;
    CHECK(hci_flex_replay_logic(&failure,24u,&context,&out)==HCI_ERR_STALE);
    CHECK(store.count==before);
    CHECK(hci_flex_capture(&snap,&logic.identity,ports,2u)==HCI_OK);
    failure.identity.graph_gen++;
    CHECK(hci_flex_replay_logic(&failure,24u,&context,&out)==HCI_ERR_STALE);
    failure.identity.graph_gen--;
    CHECK(hci_flex_replay_logic(&failure,24u,&context,&out)==HCI_OK && out.truth==HQ_TRUE);
    CHECK(out.identity.snapshot_id==24u);
    return 0;
}
int main(void) {
    CHECK(test_logic_numeric_boundaries()==0);
    CHECK(test_neural_inputs()==0);
    CHECK(test_bound_replay()==0);
    printf("FLEX_RESILIENCE_PASS assertions=%u\n",checks);
    return 0;
}
