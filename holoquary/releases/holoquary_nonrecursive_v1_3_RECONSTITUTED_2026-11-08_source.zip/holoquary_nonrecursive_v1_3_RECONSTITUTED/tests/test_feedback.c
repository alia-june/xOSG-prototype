#include "hci_feedback.h"
#include <stdio.h>

static unsigned int tests=0u;
#define CHECK(x) do { ++tests; if(!(x)) { fprintf(stderr,"FEEDBACK_FAIL line=%d assertion=%s\n", __LINE__, #x); return 1; } } while(0)

typedef struct { unsigned int verifier_id; unsigned int corruption; } Oracle;
/* The fixture is an independently specified, finite synthetic rule oracle.
 * Source IDs and receipts are NOT signatures or external-world verification. */
static HCIStatus fixture(const HCICandidate *c,const void *ctx,HCIVerification *v) {
    const Oracle *o=(const Oracle *)ctx;
    int yes=0;
    if(!o) return HCI_ERR_NULL;
    if(o->corruption==3u) return HCI_ERR_SOURCE;
    if(c->scope_id==44u && c->kind==HCI_CAND_RULE) {
        yes=(c->evidence_id==101u && c->premise_port==0u &&
             c->premise_value==HQ_TRUE && c->result_port==1u &&
             c->result_value==HQ_FALSE) ||
            (c->evidence_id==102u && c->premise_port==1u &&
             c->premise_value==HQ_FALSE && c->result_port==2u &&
             c->result_value==HQ_TRUE) ||
            (c->evidence_id==106u && c->premise_port==0u &&
             c->premise_value==HQ_TRUE && c->result_port==1u &&
             c->result_value==HQ_TRUE);
    } else if(c->scope_id==44u && c->kind==HCI_CAND_FACT) {
        yes=(c->evidence_id==103u && c->result_port==2u &&
             c->result_value==HQ_TRUE) ||
            (c->evidence_id==105u && c->result_port==2u &&
             c->result_value==HQ_FALSE);
    } else if(c->scope_id==44u && c->kind==HCI_CAND_ANTI) {
        yes=c->evidence_id==104u && c->action_code==5u &&
            c->failure_code==HCI_ERR_SOURCE;
    }
    v->verdict=c->evidence_id==902u?HCI_VERDICT_DEFER:
               yes?HCI_VERDICT_ACCEPT:HCI_VERDICT_REJECT;
    v->verifier_id=o->corruption==1u?c->proposer_id:o->verifier_id;
    v->checked_candidate_id=o->corruption==2u?c->candidate_id+1u:c->candidate_id;
    v->checked_evidence_id=c->evidence_id;
    v->proof_ref=1000u+c->evidence_id;
    return HCI_OK;
}
static HCIIdentity id(unsigned int snap) {
    HCIIdentity x={7u,107u,1u,0u,snap};return x;
}
static int prep(HQProgram *p,HCILogicAdapter *a,HCIFrame *f) {
    HQRef x;
    HQTruth in[3]={HQ_TRUE,HQ_UNKNOWN,HQ_UNKNOWN};
    if(hq_init(p,3u)!=HQ_OK ||
       hq_emit_xor(p,hq_input(0u),hq_input(2u),&x)!=HQ_OK ||
       hq_export(p,x)!=HQ_OK) return 0;
    a->program=p;a->identity=id(19u);
    return hci_observe_logic(a,in,3u,4u,f)==HCI_OK &&
           f->truth==HQ_UNKNOWN && f->execution==HCI_COMPLETED;
}
static HCICandidate candidate(const HCIFrame *f,unsigned int cid,
                              unsigned int evidence,HCICandidateKind kind) {
    HCICandidate c={0};
    c.candidate_id=cid;
    c.proposer_id=501u;
    c.source_id=100u+cid;
    c.evidence_id=evidence;
    c.scope_id=44u;
    c.observed=f->identity;
    c.kind=kind;
    c.premise_port=evidence==102u?1u:0u;
    c.premise_value=evidence==102u?HQ_FALSE:HQ_TRUE;
    c.result_port=evidence==101u || evidence==106u?1u:2u;
    c.result_value=evidence==101u || evidence==105u?HQ_FALSE:HQ_TRUE;
    c.action_code=5u;
    c.failure_code=HCI_ERR_SOURCE;
    return c;
}
static int same_recorded(const HCIFeedbackStore *a,const HCIFeedbackStore *b) {
    unsigned int i;
    if(a->scope_id!=b->scope_id || a->generation!=b->generation ||
       a->count!=b->count || a->bank.scope_id!=b->bank.scope_id ||
       a->bank.fact_count!=b->bank.fact_count ||
       a->bank.rule_count!=b->bank.rule_count) return 0;
    for(i=0u;i<a->bank.fact_count;++i) {
        const HQFact *x=&a->bank.facts[i],*y=&b->bank.facts[i];
        if(x->input_port!=y->input_port || x->value!=y->value ||
           x->source_id!=y->source_id) return 0;
    }
    for(i=0u;i<a->bank.rule_count;++i) {
        const HQRule *x=&a->bank.rules[i],*y=&b->bank.rules[i];
        if(x->premise_port!=y->premise_port ||
           x->premise_value!=y->premise_value ||
           x->result_port!=y->result_port ||
           x->result_value!=y->result_value ||
           x->source_id!=y->source_id) return 0;
    }
    for(i=0u;i<a->count;++i) {
        const HCIEvent *x=&a->events[i],*y=&b->events[i];
        if(x->candidate.candidate_id!=y->candidate.candidate_id ||
           x->outcome!=y->outcome ||
           x->generation_after!=y->generation_after ||
           x->verification.proof_ref!=y->verification.proof_ref) return 0;
    }
    return 1;
}
static int test_lifecycle(void) {
    HQProgram p;
    HCILogicAdapter a;
    HCIFrame f,bad;
    HCIFeedbackStore store,prior;
    HCICandidate c;
    HCIEvent receipt,copy;
    Oracle oracle={800u,0u};
    HQTruth in[3]={HQ_TRUE,HQ_UNKNOWN,HQ_UNKNOWN};
    CHECK(prep(&p,&a,&f));
    CHECK(hci_feedback_init(&store,44u)==HCI_OK);
    CHECK(store.count==0u && store.generation==1u && store.bank.rule_count==0u);
    CHECK(hci_feedback_bank(&store)==&store.bank);
    c=candidate(&f,1u,101u,HCI_CAND_RULE);
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_OK);
    CHECK(receipt.outcome==HCI_EVENT_ADMITTED && receipt.generation_after==2u);
    CHECK(store.count==1u && store.bank.rule_count==1u);
    CHECK(store.bank.rules[0].source_id==101u);
    CHECK(hci_observe_extended(&a,in,3u,hci_feedback_bank(&store),44u,3u,4u,&bad)==HCI_OK);
    CHECK(bad.truth==HQ_UNKNOWN && bad.disposition==HCI_STABLE);
    copy=receipt;
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_ERR_INVALID);
    CHECK(store.count==1u && store.bank.rule_count==1u &&
          receipt.generation_after==copy.generation_after);
    c=candidate(&f,2u,102u,HCI_CAND_RULE);
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_OK);
    CHECK(store.count==2u && store.bank.rule_count==2u);
    CHECK(hci_observe_extended(&a,in,3u,hci_feedback_bank(&store),44u,1u,4u,&bad)==HCI_OK);
    CHECK(bad.truth==HQ_UNKNOWN && bad.disposition==HCI_EXHAUSTED);
    CHECK(hci_observe_extended(&a,in,3u,hci_feedback_bank(&store),44u,3u,4u,&bad)==HCI_OK);
    CHECK(bad.truth==HQ_FALSE && bad.disposition==HCI_STABLE && bad.new_facts==2u);
    c=candidate(&f,3u,901u,HCI_CAND_RULE);
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_OK);
    CHECK(receipt.outcome==HCI_EVENT_REJECTED && store.bank.rule_count==2u);
    c=candidate(&f,4u,902u,HCI_CAND_FACT);
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_OK);
    CHECK(receipt.outcome==HCI_EVENT_DEFERRED && store.bank.fact_count==0u);
    c=candidate(&f,5u,106u,HCI_CAND_RULE);
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_OK);
    CHECK(receipt.outcome==HCI_EVENT_CONFLICT && store.bank.rule_count==2u);
    c=candidate(&f,6u,101u,HCI_CAND_RULE);
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_OK);
    CHECK(receipt.outcome==HCI_EVENT_REJECTED && store.bank.rule_count==2u);
    c=candidate(&f,7u,103u,HCI_CAND_FACT);
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_OK);
    CHECK(receipt.outcome==HCI_EVENT_ADMITTED && store.bank.fact_count==1u);
    c=candidate(&f,8u,105u,HCI_CAND_FACT);
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_OK);
    CHECK(receipt.outcome==HCI_EVENT_CONFLICT && store.bank.fact_count==1u);
    /* Negative feedback never enters the logic premise bank. */
    CHECK(hci_observe_extended(&a,in,3u,&store.bank,999u,3u,4u,&bad)==HCI_ERR_SOURCE);
    CHECK(bad.execution==HCI_FAILED);
    c=candidate(&bad,9u,104u,HCI_CAND_ANTI);
    CHECK(hci_feedback_submit(&store,&bad,3u,&c,fixture,&oracle,&receipt)==HCI_OK);
    CHECK(receipt.outcome==HCI_EVENT_ANTI_ADMITTED);
    CHECK(store.bank.fact_count==1u && store.bank.rule_count==2u);
    CHECK(store.count==9u && store.generation==10u);
    CHECK(hci_observe_extended(&a,in,3u,&store.bank,44u,3u,4u,&bad)==HCI_OK);
    CHECK(bad.truth==HQ_FALSE && bad.disposition==HCI_STABLE);
    /* A failed proof callback cannot partially admit or append. */
    c=candidate(&f,10u,102u,HCI_CAND_RULE);
    prior=store;oracle.corruption=3u;
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_ERR_SOURCE);
    CHECK(same_recorded(&store,&prior));
    oracle.corruption=1u;
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_ERR_INVALID);
    CHECK(same_recorded(&store,&prior));
    oracle.corruption=2u;
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_ERR_INVALID);
    CHECK(same_recorded(&store,&prior));
    oracle.corruption=0u;
    c.scope_id=45u;
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_ERR_INVALID);
    CHECK(same_recorded(&store,&prior));
    c.scope_id=44u;c.observed.snapshot_id++;
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_ERR_INVALID);
    CHECK(same_recorded(&store,&prior));
    c.observed.snapshot_id--;c.source_id=0u;
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_ERR_INVALID);
    CHECK(same_recorded(&store,&prior));
    c.source_id=111u;
    CHECK(hci_feedback_submit(&store,&f,4u,&c,fixture,&oracle,&receipt)==HCI_ERR_INVALID);
    CHECK(same_recorded(&store,&prior));
    c.kind=(HCICandidateKind)77;
    CHECK(hci_feedback_submit(&store,&f,3u,&c,fixture,&oracle,&receipt)==HCI_ERR_INVALID);
    CHECK(same_recorded(&store,&prior));
    CHECK(hci_feedback_submit(&store,&f,3u,&c,0,&oracle,&receipt)==HCI_ERR_NULL);
    CHECK(same_recorded(&store,&prior));
    return 0;
}
static int test_capacity_and_repetition(void) {
    HQProgram p;
    HCILogicAdapter a;
    HCIFrame f;
    HCIFeedbackStore s;
    HCICandidate c;
    HCIEvent event;
    Oracle oracle={800u,0u};
    unsigned int i;
    CHECK(prep(&p,&a,&f));
    for(i=0u;i<4000u;++i) {
        CHECK(hci_feedback_init(&s,44u)==HCI_OK);
        c=candidate(&f,1u,101u,HCI_CAND_RULE);
        CHECK(hci_feedback_submit(&s,&f,3u,&c,fixture,&oracle,&event)==HCI_OK);
        c=candidate(&f,2u,102u,HCI_CAND_RULE);
        CHECK(hci_feedback_submit(&s,&f,3u,&c,fixture,&oracle,&event)==HCI_OK);
        CHECK(s.bank.rule_count==2u && s.count==2u);
    }
    CHECK(hci_feedback_init(&s,44u)==HCI_OK);
    for(i=0u;i<HCI_MAX_FEEDBACK_EVENTS;++i) {
        c=candidate(&f,i+1u,901u,HCI_CAND_RULE);
        CHECK(hci_feedback_submit(&s,&f,3u,&c,fixture,&oracle,&event)==HCI_OK);
        CHECK(event.outcome==HCI_EVENT_REJECTED);
    }
    c=candidate(&f,100u,101u,HCI_CAND_RULE);
    CHECK(hci_feedback_submit(&s,&f,3u,&c,fixture,&oracle,&event)==HCI_ERR_CAPACITY);
    CHECK(s.count==HCI_MAX_FEEDBACK_EVENTS && s.bank.rule_count==0u);
    CHECK(hci_feedback_init(&s,0u)==HCI_ERR_INVALID);
    return 0;
}
int main(void) {
    CHECK(test_lifecycle()==0);
    CHECK(test_capacity_and_repetition()==0);
    printf("FEEDBACK_PASS assertions=%u\n",tests);
    return 0;
}
