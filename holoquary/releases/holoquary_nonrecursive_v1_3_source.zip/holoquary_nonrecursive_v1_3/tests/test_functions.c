#include "hqd_functions.h"
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
static unsigned long checks=0ul;
#define CK(x) do {++checks;if(!(x)){fprintf(stderr,"V13_FAIL line=%d assertion=%s\n",__LINE__,#x);return 1;}}while(0)
static HQDRecord mk(HQDDomain d,unsigned mask,unsigned grade)
{
    HQDRecord r;
    if(hqd_possibilities(d,mask,grade,&r)!=HQD_OK) {fprintf(stderr,"BAD_FIXTURE\n");}
    return r;
}
static unsigned grade_for(unsigned m){return m && (m&(m-1u)) ? 2u:0u;}
static HQTruth ref_not(HQTruth a){return a==HQ_FALSE?HQ_TRUE:a==HQ_TRUE?HQ_FALSE:HQ_UNKNOWN;}
static HQTruth ref_and(HQTruth a,HQTruth b){return a==HQ_FALSE||b==HQ_FALSE?HQ_FALSE:a==HQ_TRUE&&b==HQ_TRUE?HQ_TRUE:HQ_UNKNOWN;}
static HQTruth ref_or(HQTruth a,HQTruth b){return a==HQ_TRUE||b==HQ_TRUE?HQ_TRUE:a==HQ_FALSE&&b==HQ_FALSE?HQ_FALSE:HQ_UNKNOWN;}
static HQTruth ref_xor(HQTruth a,HQTruth b){return a==HQ_UNKNOWN||b==HQ_UNKNOWN?HQ_UNKNOWN:a==b?HQ_FALSE:HQ_TRUE;}
static HQTruth ref_logic(HQDNLogicOp op,HQTruth a,HQTruth b,HQTruth c)
{
    switch(op) {
    case HQDN_NOT: return ref_not(a);
    case HQDN_AND: return ref_and(a,b);
    case HQDN_OR: return ref_or(a,b);
    case HQDN_XOR: return ref_xor(a,b);
    case HQDN_IMPLIES: return ref_or(ref_not(a),b);
    case HQDN_EQUIV: return ref_not(ref_xor(a,b));
    case HQDN_MAJORITY:
        if((a==HQ_TRUE)+(b==HQ_TRUE)+(c==HQ_TRUE)>=2) return HQ_TRUE;
        if((a==HQ_FALSE)+(b==HQ_FALSE)+(c==HQ_FALSE)>=2) return HQ_FALSE;
        return HQ_UNKNOWN;
    default: return HQ_UNKNOWN;
    }
}
static unsigned expect_logic(HQDNLogicOp op,unsigned am,unsigned bm,unsigned cm)
{
    unsigned result=0u;
    for(int a=0;a<3;++a)if(am&(1u<<a))
      for(int b=0;b<(op==HQDN_NOT?1:3);++b)
        if(op==HQDN_NOT || (bm&(1u<<b)))
          for(int c=0;c<(op==HQDN_MAJORITY?3:1);++c)
            if(op!=HQDN_MAJORITY || (cm&(1u<<c)))
              result|=1u<<ref_logic(op,(HQTruth)a,(HQTruth)b,(HQTruth)c);
    return result;
}
static int basic_logic(void)
{
    HQDRecord o,saved;
    for(int op=0;op<=HQDN_MAJORITY;++op)
      for(unsigned am=0;am<8u;++am) {
        HQDRecord a=mk(HQD_KLEENE3,am,grade_for(am));
        for(unsigned bm=0;bm<(op==HQDN_NOT?1u:8u);++bm) {
          HQDRecord b=mk(HQD_KLEENE3,bm,grade_for(bm));
          for(unsigned cm=0;cm<(op==HQDN_MAJORITY?8u:1u);++cm) {
            HQDRecord c=mk(HQD_KLEENE3,cm,grade_for(cm));
            CK(hqdn_logic((HQDNLogicOp)op,&a,op==HQDN_NOT?0:&b,
                op==HQDN_MAJORITY?&c:0,&o)==HQDN_OK);
            CK(o.knowledge.possibilities==expect_logic((HQDNLogicOp)op,am,bm,cm));
            CK(hqd_validate(&o)==HQD_OK);
            CK(o.provenance.origin==HQD_ORIGIN_DERIVED);
          }
        }
      }
    HQDRecord t=mk(HQD_KLEENE3,1u<<HQ_TRUE,0u);
    HQDRecord f=mk(HQD_KLEENE3,1u<<HQ_FALSE,0u);
    HQDRecord u=mk(HQD_KLEENE3,1u<<HQ_UNKNOWN,0u);
    CK(hqdn_logic(HQDN_AND,&t,&u,0,&o)==HQDN_OK && o.data.logic==HQ_UNKNOWN);
    CK(o.data.kind==HQD_LOGIC);
    HQDRecord epistemic=mk(HQD_KLEENE3,(1u<<HQ_FALSE)|(1u<<HQ_TRUE),3u);
    CK(hqdn_logic(HQDN_AND,&t,&epistemic,0,&o)==HQDN_OK);
    CK(o.data.kind==HQD_ABSENT && o.knowledge.possibilities==3u);
    CK(hqdn_select(&f,&t,&epistemic,&o)==HQDN_OK);
    CK(o.data.kind==HQD_ABSENT && o.knowledge.possibilities==3u);
    CK(hqdn_select(&f,&t,&u,&o)==HQDN_OK);
    CK(o.data.kind==HQD_LOGIC && o.data.logic==HQ_UNKNOWN);
    CK(hqdn_logic(HQDN_MAJORITY,&t,&t,&u,&o)==HQDN_OK && o.data.logic==HQ_TRUE);
    CK(hqdn_guard(&t,&t,&u,&o)==HQDN_OK && o.data.logic==HQ_UNKNOWN);
    CK(hqdn_guard(&t,&f,&u,&o)==HQDN_OK && o.data.logic==HQ_FALSE);
    CK(hqd_guard_proposal(&o,(int[]){77})==HQD_OK);
    saved=o;
    CK(hqdn_logic((HQDNLogicOp)99,&t,&f,0,&o)==HQDN_INVALID);
    CK(memcmp(&saved,&o,sizeof o)==0);
    HQDRecord num=mk(HQD_BALANCED3,2u,0u);
    CK(hqdn_logic(HQDN_AND,&num,&f,0,&o)==HQDN_DOMAIN);
    CK(memcmp(&saved,&o,sizeof o)==0);
    HQDRecord failed=u;
    failed.data.kind=HQD_ABSENT;
    failed.data.logic=HQ_FALSE;
    failed.knowledge.possibilities=7u;
    failed.execution.state=HQD_EXEC_FAILED;
    failed.execution.error_code=19u;
    CK(hqd_validate(&failed)==HQD_OK);
    CK(hqdn_logic(HQDN_AND,&f,&failed,0,&o)==HQDN_DENIED);
    CK(memcmp(&saved,&o,sizeof o)==0);
    HQDRecord legacy;
    CK(hqd_from_hqx(HQX_ERROR,&legacy)==HQD_OK);
    CK(hqdn_logic(HQDN_OR,&t,&legacy,0,&o)==HQDN_DENIED);
    CK(memcmp(&saved,&o,sizeof o)==0);
    return 0;
}
static int reference_select(unsigned left,unsigned right,unsigned select,HQDDomain d)
{
    unsigned result=0u;
    if(select&(1u<<HQ_FALSE)) result|=left;
    if(select&(1u<<HQ_TRUE)) result|=right;
    if(select&(1u<<HQ_UNKNOWN)) {
        if(d!=HQD_KLEENE3) result|=left|right;
        else for(int a=0;a<3;++a)if(left&(1u<<a))
          for(int b=0;b<3;++b)if(right&(1u<<b)) {
            int z=(a==b && a!=(int)HQ_UNKNOWN)?a:HQ_UNKNOWN;
            result|=1u<<(unsigned)z;
          }
    }
    return (int)result;
}
static int test_select(HQDDomain d,unsigned n)
{
    HQDRecord o;
    for(unsigned am=0;am<n;++am) {
      HQDRecord a=mk(d,am,grade_for(am));
      for(unsigned bm=0;bm<n;++bm) {
        HQDRecord b=mk(d,bm,grade_for(bm));
        for(unsigned sm=0;sm<8u;++sm) {
          HQDRecord sel=mk(HQD_KLEENE3,sm,grade_for(sm));
          CK(hqdn_select(&a,&b,&sel,&o)==HQDN_OK);
          CK(o.knowledge.possibilities==(unsigned)reference_select(am,bm,sm,d));
          CK(hqd_validate(&o)==HQD_OK);
          CK(o.domain==d);
        }
      }
    }
    return 0;
}
static int test_compare(HQDDomain d,int lo,int hi)
{
    const unsigned n=1u<<(unsigned)(hi-lo+1);
    for(unsigned am=0;am<n;++am) {
      HQDRecord a=mk(d,am,grade_for(am));
      for(unsigned bm=0;bm<n;++bm) {
        HQDRecord b=mk(d,bm,grade_for(bm));
        for(int rel=HQD_LT;rel<=HQD_GT;rel*=2) {
          unsigned expected=0;
          for(int ai=lo;ai<=hi;++ai)if(am&(1u<<(ai-lo)))
            for(int bi=lo;bi<=hi;++bi)if(bm&(1u<<(bi-lo))) {
              int relation=ai<bi?HQD_LT:ai==bi?HQD_EQ:HQD_GT;
              expected|=1u<<(relation==rel?HQ_TRUE:HQ_FALSE);
            }
          HQDRecord out;
          CK(hqdn_compare_set(&a,&b,(HQDRelation)rel,&out)==HQDN_OK);
          CK(out.knowledge.possibilities==expected);
          CK(out.data.kind==(expected && !(expected&(expected-1u))?HQD_LOGIC:HQD_ABSENT));
        }
      }
    }
    return 0;
}
static uint32_t prng_state=0x31415926u;
static unsigned next_random(void)
{
    prng_state ^= prng_state << 13;
    prng_state ^= prng_state >> 17;
    prng_state ^= prng_state << 5;
    return prng_state;
}
static unsigned ref_between(unsigned vm,unsigned lm,unsigned hm,int lo,int hi)
{
    unsigned m=0;
    for(int x=lo;x<=hi;++x)if(vm&(1u<<(x-lo)))
      for(int low=lo;low<=hi;++low)if(lm&(1u<<(low-lo)))
        for(int high=lo;high<=hi;++high)if(hm&(1u<<(high-lo)))
          m|=1u<<((low<=x && x<=high)?HQ_TRUE:HQ_FALSE);
    return m;
}
static int test_between(HQDDomain d,int lo,int hi,int sampled)
{
    unsigned n=1u<<(unsigned)(hi-lo+1);
    unsigned trials=sampled?12000u:n*n*n;
    for(unsigned idx=0;idx<trials;++idx) {
       unsigned vm=sampled?next_random()%n:idx%n;
       unsigned lm=sampled?next_random()%n:(idx/n)%n;
       unsigned hm=sampled?next_random()%n:idx/(n*n);
       HQDRecord v=mk(d,vm,grade_for(vm));
       HQDRecord l=mk(d,lm,grade_for(lm));
       HQDRecord h=mk(d,hm,grade_for(hm));
       HQDRecord actual;
       CK(hqdn_between(&v,&l,&h,&actual)==HQDN_OK);
       CK(actual.knowledge.possibilities==ref_between(vm,lm,hm,lo,hi));
       CK(hqd_validate(&actual)==HQD_OK);
    }
    return 0;
}
static int witness_case(void)
{
    /* X can be 0 or 1. Predicate X>=1 is separately possible, X<=0 is
     * separately possible, but X cannot be BETWEEN(1,0) for any completion. */
    HQDRecord x=mk(HQD_BALANCED3,6u,2u);
    HQDRecord low=mk(HQD_BALANCED3,4u,0u);
    HQDRecord high=mk(HQD_BALANCED3,2u,0u);
    HQDRecord range;
    CK(hqdn_between(&x,&low,&high,&range)==HQDN_OK);
    CK(range.data.kind==HQD_LOGIC && range.data.logic==HQ_FALSE);
    /* Epistemic status belongs in knowledge, not a fake Kleene U. */
    HQDRecord equal=mk(HQD_BALANCED3,6u,2u);
    HQDRecord condition;
    CK(hqdn_compare_set(&equal,&high,HQD_EQ,&condition)==HQDN_OK);
    CK(condition.data.kind==HQD_ABSENT && condition.knowledge.possibilities==3u);
    return 0;
}
static int transactions(void)
{
    HQDRecord f=mk(HQD_KLEENE3,1u<<HQ_FALSE,0);
    HQDRecord t=mk(HQD_KLEENE3,1u<<HQ_TRUE,0);
    HQDRecord u=mk(HQD_KLEENE3,1u<<HQ_UNKNOWN,0);
    HQDRecord zero=mk(HQD_BALANCED3,2u,0);
    HQDRecord plus=mk(HQD_BALANCED3,4u,0);
    HQDRecord partial=mk(HQD_BALANCED3,6u,2u);
    HQDNCell c1,c2,c3;
    HQDNReceipt rec[HQDN_MAX_TRANSACTION],prior[HQDN_MAX_TRANSACTION];
    HQDRecord readback,stored;
    uint32_t generation=0u;
    CK(hqdn_cell_init(&c1,11u,&zero)==HQDN_OK);
    CK(hqdn_cell_init(&c2,12u,&t)==HQDN_OK);
    CK(hqdn_cell_init(&c3,13u,&partial)==HQDN_OK);
    CK(hqdn_cell_read(&c1,&readback,&generation)==HQDN_OK);
    CK(generation==1u && readback.data.kind==HQD_NUMBER && readback.data.number==0);
    HQDNTick ticks[3]={{&c1,1u,&t,&plus},{&c2,1u,&f,&f},{&c3,1u,&u,&plus}};
    CK(hqdn_tick_transaction(ticks,3u,rec)==HQDN_OK);
    CK(c1.state.data.number==1 && c1.generation==2u);
    CK(c2.state.data.logic==HQ_TRUE && c2.generation==2u);
    CK(c3.state.knowledge.possibilities==6u && c3.generation==2u);
    CK(rec[0].prior_possibilities==2u && rec[0].resulting_possibilities==4u);
    CK(rec[1].instance_id==12u && rec[1].resulting_generation==2u);
    CK(rec[2].prior_possibilities==6u && rec[2].resulting_possibilities==6u);
    CK(rec[0].resulting_generation==2u);
    HQDNCell before1=c1,before2=c2,before3=c3;
    memset(rec,0x6a,sizeof rec);
    memcpy(prior,rec,sizeof rec);
    ticks[0].expected_generation=2u;
    ticks[1].expected_generation=1u;
    ticks[2].expected_generation=2u;
    CK(hqdn_tick_transaction(ticks,3u,rec)==HQDN_STALE);
    CK(memcmp(&before1,&c1,sizeof c1)==0 && memcmp(&before2,&c2,sizeof c2)==0);
    CK(memcmp(&before3,&c3,sizeof c3)==0 && memcmp(prior,rec,sizeof rec)==0);
    ticks[1].expected_generation=2u;
    ticks[2].write_value=&t; /* third tick fails after earlier preflight */
    CK(hqdn_tick_transaction(ticks,3u,rec)==HQDN_DOMAIN);
    CK(memcmp(&before1,&c1,sizeof c1)==0 && memcmp(prior,rec,sizeof rec)==0);
    ticks[2].write_value=&zero;
    ticks[1].cell=&c1;
    CK(hqdn_tick_transaction(ticks,3u,rec)==HQDN_DUPLICATE);
    CK(memcmp(&before1,&c1,sizeof c1)==0 && memcmp(prior,rec,sizeof rec)==0);
    ticks[1].cell=&c2;
    c2.instance_id=c1.instance_id;
    CK(hqdn_tick_transaction(ticks,3u,rec)==HQDN_DUPLICATE);
    c2=before2;
    ticks[1].write_value=&t;
    c3.generation=UINT32_MAX;
    ticks[2].expected_generation=UINT32_MAX;
    CK(hqdn_tick_transaction(ticks,3u,rec)==HQDN_EXHAUSTED);
    c3=before3;
    ticks[2].expected_generation=2u;
    ticks[0].selector=&u;
    ticks[0].write_value=&zero;
    CK(hqdn_tick_transaction(ticks,3u,rec)==HQDN_OK);
    CK(c1.state.data.kind==HQD_ABSENT && c1.state.knowledge.possibilities==6u);
    CK(c1.state.provenance.origin==HQD_ORIGIN_DERIVED);
    CK(c3.state.data.number==0 && c3.generation==3u);
    /* Strict separation: arbitrary grade must not change arithmetic result. */
    HQDRecord p=mk(HQD_BALANCED3,7u,1u),q=mk(HQD_BALANCED3,7u,3u);
    HQDRecord a,b;
    CK(hqdn_select(&p,&q,&u,&a)==HQDN_OK);
    q.knowledge.unknown_grade=2u;
    CK(hqdn_select(&p,&q,&u,&b)==HQDN_OK);
    CK(a.knowledge.possibilities==b.knowledge.possibilities);
    /* invalid source / legacy E even for definite hold */
    HQDRecord marker;
    CK(hqd_from_hq5((HQ5Value){HQ5_DOMAIN_TERNARY_UE,HQ5_E},&marker)==HQD_OK);
    ticks[0].expected_generation=3u; ticks[0].selector=&f; ticks[0].write_value=&marker;
    before1=c1;
    memcpy(prior,rec,sizeof rec);
    CK(hqdn_tick_transaction(ticks,3u,rec)==HQDN_DENIED);
    CK(memcmp(&before1,&c1,sizeof c1)==0 && memcmp(prior,rec,sizeof rec)==0);
    /* Exact false HOLD preserves source metadata and does not authorize write. */
    ticks[0].write_value=&plus;
    HQDRecord prevstate=c1.state;
    CK(hqdn_tick_transaction(ticks,1u,rec)==HQDN_OK);
    CK(c1.generation==4u && memcmp(&prevstate,&c1.state,sizeof prevstate)==0);
    /* Receipts are diagnostic only; no independent verification. */
    stored=c1.state;
    c1.state.execution.state=HQD_EXEC_FAILED;
    c1.state.execution.error_code=7u;
    CK(hqdn_cell_read(&c1,&readback,&generation)==HQDN_DENIED);
    c1.state=stored;
    CK(hqdn_cell_read(&c1,0,&generation)==HQDN_NULL);
    CK(hqdn_tick_transaction(ticks,0u,rec)==HQDN_INVALID);
    CK(hqdn_tick_transaction(ticks,HQDN_MAX_TRANSACTION+1u,rec)==HQDN_INVALID);
    return 0;
}
int main(void)
{
    if(basic_logic() || test_select(HQD_KLEENE3,8u) ||
       test_select(HQD_BALANCED3,8u) || test_select(HQD_PURE5,32u) ||
       test_select(HQD_BALANCED7,128u) ||
       test_compare(HQD_BALANCED3,-1,1) ||
       test_compare(HQD_PURE5,0,4) ||
       test_compare(HQD_BALANCED7,-3,3) ||
       test_between(HQD_BALANCED3,-1,1,0) ||
       test_between(HQD_PURE5,0,4,0) ||
       test_between(HQD_BALANCED7,-3,3,1) ||
       witness_case() || transactions()) return 1;
    printf("NONRECURSIVE_FUNCTIONS_PASS assertions=%lu\n",checks);
    return 0;
}
