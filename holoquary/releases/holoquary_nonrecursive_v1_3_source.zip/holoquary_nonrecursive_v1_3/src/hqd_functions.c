#include "hqd_functions.h"
#include <limits.h>

static HQDNStatus convert(HQDStatus s)
{
    switch(s) {
    case HQD_OK: return HQDN_OK;
    case HQD_NULL: return HQDN_NULL;
    case HQD_BAD_DOMAIN: return HQDN_DOMAIN;
    case HQD_DENIED: return HQDN_DENIED;
    default: return HQDN_INVALID;
    }
}
static HQDNStatus operand(const HQDRecord *r)
{
    HQDStatus s=hqd_validate(r);
    if(s!=HQD_OK) return convert(s);
    if(r->execution.state!=HQD_EXEC_COMPLETE ||
       r->execution.marker!=HQD_NO_MARKER) return HQDN_DENIED;
    return HQDN_OK;
}
static HQDNStatus output(HQDDomain d, unsigned mask, HQDRecord *out)
{
    HQDRecord staged;
    HQDStatus s=hqd_possibilities(d,mask,0u,&staged);
    if(s!=HQD_OK) return convert(s);
    staged.provenance.origin=HQD_ORIGIN_DERIVED;
    *out=staged;
    return HQDN_OK;
}
static HQTruth knand(HQTruth a,HQTruth b)
{
    HQTruth r=HQ_UNKNOWN;
    (void)hq_nand(a,b,&r);
    return r;
}
static HQTruth knot(HQTruth a) {return knand(a,a);}
static HQTruth kand(HQTruth a,HQTruth b)
{
    HQTruth n=knand(a,b); return knand(n,n);
}
static HQTruth kor(HQTruth a,HQTruth b)
{ return knand(knot(a),knot(b)); }
static HQTruth kxor(HQTruth a,HQTruth b)
{
    HQTruth t=knand(a,b);
    return knand(knand(a,t),knand(b,t));
}
static HQTruth kmux(HQTruth a,HQTruth b,HQTruth selector)
{
    if(selector==HQ_FALSE) return a;
    if(selector==HQ_TRUE) return b;
    /* consensus extension, defined by the original v0.8 MUX contract */
    if(a==b && a!=HQ_UNKNOWN) return a;
    return HQ_UNKNOWN;
}
static HQTruth apply(HQDNLogicOp op,HQTruth a,HQTruth b,HQTruth c)
{
    switch(op) {
    case HQDN_NOT: return knot(a);
    case HQDN_AND: return kand(a,b);
    case HQDN_OR: return kor(a,b);
    case HQDN_XOR: return kxor(a,b);
    case HQDN_IMPLIES: return kor(knot(a),b);
    case HQDN_EQUIV: return knot(kxor(a,b));
    case HQDN_MAJORITY: return kor(kor(kand(a,b),kand(a,c)),kand(b,c));
    default: return HQ_UNKNOWN;
    }
}
HQDNStatus hqdn_logic(HQDNLogicOp op,const HQDRecord *a,
                      const HQDRecord *b,const HQDRecord *c,HQDRecord *out)
{
    HQDNStatus s;
    unsigned m=0u;
    if(!a || !out) return HQDN_NULL;
    if(op>HQDN_MAJORITY || op<HQDN_NOT) return HQDN_INVALID;
    if((s=operand(a))!=HQDN_OK) return s;
    if(a->domain!=HQD_KLEENE3) return HQDN_DOMAIN;
    if(op!=HQDN_NOT) {
        if(!b) return HQDN_NULL;
        if((s=operand(b))!=HQDN_OK) return s;
        if(b->domain!=HQD_KLEENE3) return HQDN_DOMAIN;
    }
    if(op==HQDN_MAJORITY) {
        if(!c) return HQDN_NULL;
        if((s=operand(c))!=HQDN_OK) return s;
        if(c->domain!=HQD_KLEENE3) return HQDN_DOMAIN;
    }
    for(int ai=0;ai<3;++ai) if(a->knowledge.possibilities & (1u<<ai)) {
        int bmax=op==HQDN_NOT?1:3;
        for(int bi=0;bi<bmax;++bi) if(op==HQDN_NOT ||
                           (b->knowledge.possibilities & (1u<<bi))) {
            int cmax=op==HQDN_MAJORITY?3:1;
            for(int ci=0;ci<cmax;++ci) if(op!=HQDN_MAJORITY ||
                           (c->knowledge.possibilities & (1u<<ci))) {
                HQTruth v=apply(op,(HQTruth)ai,(HQTruth)bi,(HQTruth)ci);
                m|=1u << (unsigned)v;
            }
        }
    }
    return output(HQD_KLEENE3,m,out);
}
HQDNStatus hqdn_compare_set(const HQDRecord *a,const HQDRecord *b,
                            HQDRelation relation,HQDRecord *out)
{
    HQDNStatus s;
    uint8_t rel=0u;
    unsigned m=0u;
    if(!a || !b || !out) return HQDN_NULL;
    if(relation!=HQD_LT && relation!=HQD_EQ && relation!=HQD_GT)
        return HQDN_INVALID;
    if((s=operand(a))!=HQDN_OK || (s=operand(b))!=HQDN_OK) return s;
    if(a->domain!=b->domain) return HQDN_DOMAIN;
    if(a->domain==HQD_KLEENE3) return HQDN_DOMAIN;
    if((s=convert(hqd_compare(a,b,&rel)))!=HQDN_OK) return s;
    if(rel&relation) m|=1u<<HQ_TRUE;
    if(rel & (unsigned)~relation) m|=1u<<HQ_FALSE;
    return output(HQD_KLEENE3,m,out);
}
HQDNStatus hqdn_between(const HQDRecord *value,const HQDRecord *lower,
                        const HQDRecord *upper,HQDRecord *out)
{
    HQDNStatus s;
    unsigned result=0u;
    int lo,hi;
    if(!value || !lower || !upper || !out) return HQDN_NULL;
    if((s=operand(value))!=HQDN_OK ||
       (s=operand(lower))!=HQDN_OK ||
       (s=operand(upper))!=HQDN_OK) return s;
    if(value->domain!=lower->domain || value->domain!=upper->domain)
        return HQDN_DOMAIN;
    if(value->domain==HQD_KLEENE3) return HQDN_DOMAIN;
    switch(value->domain) {
    case HQD_BALANCED3: lo=-1;hi=1;break;
    case HQD_PURE5: lo=0;hi=4;break;
    case HQD_BALANCED7: lo=-3;hi=3;break;
    default: return HQDN_DOMAIN;
    }
    for(int x=lo;x<=hi;++x) if(value->knowledge.possibilities & (1u<<(x-lo)))
      for(int low=lo;low<=hi;++low) if(lower->knowledge.possibilities & (1u<<(low-lo)))
        for(int high=lo;high<=hi;++high) if(upper->knowledge.possibilities & (1u<<(high-lo)))
          result|=1u<<((low<=x && x<=high)?HQ_TRUE:HQ_FALSE);
    return output(HQD_KLEENE3,result,out);
}
HQDNStatus hqdn_select(const HQDRecord *left,const HQDRecord *right,
                       const HQDRecord *selector,HQDRecord *out)
{
    HQDNStatus s;
    unsigned m=0u;
    if(!left || !right || !selector || !out) return HQDN_NULL;
    if((s=operand(left))!=HQDN_OK ||
       (s=operand(right))!=HQDN_OK ||
       (s=operand(selector))!=HQDN_OK) return s;
    if(left->domain!=right->domain) return HQDN_DOMAIN;
    if(selector->domain!=HQD_KLEENE3) return HQDN_DOMAIN;
    if(selector->knowledge.possibilities & (1u<<HQ_FALSE))
        m|=left->knowledge.possibilities;
    if(selector->knowledge.possibilities & (1u<<HQ_TRUE))
        m|=right->knowledge.possibilities;
    if(selector->knowledge.possibilities & (1u<<HQ_UNKNOWN)) {
        if(left->domain==HQD_KLEENE3) {
            for(int x=0;x<3;++x) if(left->knowledge.possibilities&(1u<<x))
              for(int y=0;y<3;++y) if(right->knowledge.possibilities&(1u<<y))
                m|=1u << (unsigned)kmux((HQTruth)x,(HQTruth)y,HQ_UNKNOWN);
        } else {
            /* Unknown selector leaves both numerical branches possible. */
            m|=left->knowledge.possibilities|right->knowledge.possibilities;
        }
    }
    return output(left->domain,m,out);
}
HQDNStatus hqdn_guard(const HQDRecord *data,const HQDRecord *key,
                      const HQDRecord *permission,HQDRecord *out)
{
    HQDNStatus s;
    HQDRecord intermediate;
    if(!data || !key || !permission || !out) return HQDN_NULL;
    if((s=hqdn_logic(HQDN_AND,data,key,0,&intermediate))!=HQDN_OK) return s;
    return hqdn_logic(HQDN_AND,&intermediate,permission,0,out);
}
HQDNStatus hqdn_cell_init(HQDNCell *cell,uint32_t instance_id,
                           const HQDRecord *initial)
{
    HQDNStatus s;
    if(!cell || !initial) return HQDN_NULL;
    if(!instance_id) return HQDN_INVALID;
    if((s=operand(initial))!=HQDN_OK) return s;
    HQDNCell next;
    next.instance_id=instance_id;
    next.generation=1u;
    next.state=*initial;
    *cell=next;
    return HQDN_OK;
}
HQDNStatus hqdn_cell_read(const HQDNCell *cell,HQDRecord *out,
                           uint32_t *out_generation)
{
    HQDNStatus s;
    if(!cell || !out || !out_generation) return HQDN_NULL;
    if(!cell->instance_id || cell->generation==0u) return HQDN_INVALID;
    if((s=operand(&cell->state))!=HQDN_OK) return s;
    *out=cell->state;
    *out_generation=cell->generation;
    return HQDN_OK;
}
HQDNStatus hqdn_tick_transaction(const HQDNTick *ticks,unsigned count,
                                  HQDNReceipt *receipts)
{
    HQDRecord staged[HQDN_MAX_TRANSACTION];
    HQDNReceipt staging_receipts[HQDN_MAX_TRANSACTION];
    HQDNStatus s;
    if(!ticks || !receipts) return HQDN_NULL;
    if(count==0u || count>HQDN_MAX_TRANSACTION) return HQDN_INVALID;
    for(unsigned i=0;i<count;++i) {
        const HQDNTick *t=&ticks[i];
        if(!t->cell || !t->selector || !t->write_value) return HQDN_NULL;
        if(!t->cell->instance_id || !t->cell->generation) return HQDN_INVALID;
        if(t->expected_generation!=t->cell->generation) return HQDN_STALE;
        if(t->cell->generation==UINT32_MAX) return HQDN_EXHAUSTED;
        for(unsigned j=0;j<i;++j)
            if(t->cell==ticks[j].cell ||
               t->cell->instance_id==ticks[j].cell->instance_id)
                return HQDN_DUPLICATE;
        if((s=operand(&t->cell->state))!=HQDN_OK) return s;
        if((s=operand(t->selector))!=HQDN_OK) return s;
        if((s=operand(t->write_value))!=HQDN_OK) return s;
        if(t->write_value->domain!=t->cell->state.domain) return HQDN_DOMAIN;
        if((s=hqdn_select(&t->cell->state,t->write_value,t->selector,
                          &staged[i]))!=HQDN_OK) return s;
        /* A definite hold/write transports the corresponding record's
         * metadata without asserting source authority or deriving evidence. */
        if(t->selector->data.kind==HQD_LOGIC &&
           t->selector->domain==HQD_KLEENE3 &&
           t->selector->data.logic==HQ_FALSE) staged[i]=t->cell->state;
        if(t->selector->data.kind==HQD_LOGIC &&
           t->selector->domain==HQD_KLEENE3 &&
           t->selector->data.logic==HQ_TRUE) staged[i]=*t->write_value;
        staging_receipts[i].instance_id=t->cell->instance_id;
        staging_receipts[i].previous_generation=t->cell->generation;
        staging_receipts[i].resulting_generation=t->cell->generation+1u;
        staging_receipts[i].domain=staged[i].domain;
        staging_receipts[i].prior_possibilities=t->cell->state.knowledge.possibilities;
        staging_receipts[i].resulting_possibilities=staged[i].knowledge.possibilities;
    }
    for(unsigned i=0;i<count;++i) {
        ticks[i].cell->state=staged[i];
        ticks[i].cell->generation=staging_receipts[i].resulting_generation;
        receipts[i]=staging_receipts[i];
    }
    return HQDN_OK;
}
