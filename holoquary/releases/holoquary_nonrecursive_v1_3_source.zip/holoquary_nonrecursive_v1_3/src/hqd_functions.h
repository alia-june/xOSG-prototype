#ifndef HQD_FUNCTIONS_H
#define HQD_FUNCTIONS_H
/* v1.3 candidate: nonrecursive higher functions and transactionally ticked cells
 * over v1.2 separated computational data and metadata.
 * Source IDs, guards, and receipts do not grant authority or authentication. */
#include "hqd_separation.h"
#include <stdint.h>

typedef enum {
    HQDN_OK=0, HQDN_NULL, HQDN_INVALID, HQDN_DOMAIN, HQDN_DENIED,
    HQDN_STALE, HQDN_EXHAUSTED, HQDN_DUPLICATE
} HQDNStatus;
typedef enum {
    HQDN_NOT=0, HQDN_AND, HQDN_OR, HQDN_XOR,
    HQDN_IMPLIES, HQDN_EQUIV, HQDN_MAJORITY
} HQDNLogicOp;

/* Exact Kleene UNKNOWN is processed as a logical datum. Epistemic sets of
 * possible Kleene symbols are enumerated independently, not collapsed to U.
 * For MAJORITY, c is required; for binary functions it is ignored. */
HQDNStatus hqdn_logic(HQDNLogicOp op, const HQDRecord *a,
                       const HQDRecord *b, const HQDRecord *c,
                       HQDRecord *out);
/* Reports an epistemic set of possible TRUE/FALSE results, NOT an exact
 * Kleene U. Contradictory input produces an empty possible-value set. */
HQDNStatus hqdn_compare_set(const HQDRecord *a, const HQDRecord *b,
                             HQDRelation relation, HQDRecord *out);
/* Inclusive range check: evaluate the SAME value completion against both
 * bounds in one operation. Combining independent compare truth masks would
 * lose this local correlation and may introduce a spurious TRUE. The three
 * provided operand records are otherwise independently completed. */
HQDNStatus hqdn_between(const HQDRecord *value, const HQDRecord *lower,
                          const HQDRecord *upper, HQDRecord *out);
/* Selector is a KLEENE3 record. FALSE chooses left; TRUE chooses right.
 * Logical U uses consensus Kleene MUX for KLEENE3 branches. Numeric U
 * unions both branches' mathematical possibility sets. Selector epistemic
 * possibilities are enumerated independently. All inputs validated, even
 * branches that a definite selector would not choose. */
HQDNStatus hqdn_select(const HQDRecord *left, const HQDRecord *right,
                        const HQDRecord *selector, HQDRecord *out);
/* Diagnostics only; NOT an access-control authorization or physical lock. */
HQDNStatus hqdn_guard(const HQDRecord *data, const HQDRecord *key,
                       const HQDRecord *permission, HQDRecord *out);

#define HQDN_MAX_TRANSACTION 4u
typedef struct {
    uint32_t instance_id;
    uint32_t generation;
    HQDRecord state;
} HQDNCell;
typedef struct {
    HQDNCell *cell;
    uint32_t expected_generation;
    const HQDRecord *selector;
    const HQDRecord *write_value;
} HQDNTick;
typedef struct {
    uint32_t instance_id;
    uint32_t previous_generation;
    uint32_t resulting_generation;
    HQDDomain domain;
    uint16_t prior_possibilities;
    uint16_t resulting_possibilities;
} HQDNReceipt;
HQDNStatus hqdn_cell_init(HQDNCell *cell, uint32_t instance_id,
                           const HQDRecord *initial);
HQDNStatus hqdn_cell_read(const HQDNCell *cell, HQDRecord *out,
                           uint32_t *out_generation);
/* Preflight all cells; calculate all replacements; commit only on success.
 * Aliasing between cells, input records, tick array and receipt storage is
 * unsupported; duplicated instance IDs/pointers are rejected. Single-thread.
 * This is failure atomic within one C invocation, NOT crash atomic/durable. */
HQDNStatus hqdn_tick_transaction(const HQDNTick *ticks, unsigned count,
                                   HQDNReceipt *receipts);
#endif
