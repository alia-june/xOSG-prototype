#include "hqd_functions.h"
#include <stdio.h>
int main(void)
{
    HQDRecord zero,plus,logical_unknown,selector,selected,partial,known;
    HQDRecord lf,lt,logical_set,logical_u,lower,upper,witness,range;
    HQDNCell memory;
    HQDNTick tick;
    HQDNReceipt receipt;
    if(hqd_exact_number(HQD_BALANCED3,0,&zero)!=HQD_OK ||
       hqd_exact_number(HQD_BALANCED3,1,&plus)!=HQD_OK ||
       hqd_exact_logic(HQ_UNKNOWN,&logical_unknown)!=HQD_OK ||
       hqd_possibilities(HQD_KLEENE3,3u,2u,&selector)!=HQD_OK ||
       hqd_exact_logic(HQ_FALSE,&lf)!=HQD_OK ||
       hqd_exact_logic(HQ_TRUE,&lt)!=HQD_OK ||
       hqdn_select(&lf,&lt,&selector,&logical_set)!=HQDN_OK ||
       hqdn_select(&lf,&lt,&logical_unknown,&logical_u)!=HQDN_OK ||
       hqdn_select(&zero,&plus,&selector,&selected)!=HQDN_OK ||
       hqdn_select(&zero,&plus,&logical_unknown,&partial)!=HQDN_OK ||
       hqdn_cell_init(&memory,100u,&zero)!=HQDN_OK ||
       hqd_possibilities(HQD_BALANCED3,6u,2u,&witness)!=HQD_OK ||
       hqd_exact_number(HQD_BALANCED3,1,&lower)!=HQD_OK ||
       hqd_exact_number(HQD_BALANCED3,0,&upper)!=HQD_OK ||
       hqdn_between(&witness,&lower,&upper,&range)!=HQDN_OK) return 1;
    tick.cell=&memory;tick.expected_generation=1u;
    tick.selector=&logical_unknown;tick.write_value=&plus;
    if(hqdn_tick_transaction(&tick,1u,&receipt)!=HQDN_OK ||
       hqdn_compare_set(&zero,&plus,HQD_LT,&known)!=HQDN_OK) return 1;
    printf("CONDITION_SET F/T -> NUMERIC MASK %u; KLEENE U -> NUMERIC MASK %u\n",
           (unsigned)selected.knowledge.possibilities,
           (unsigned)partial.knowledge.possibilities);
    printf("KLEENE CONTROL F/T => epistemic mask=%u; KLEENE control U => exact logical U=%d\n",
           (unsigned)logical_set.knowledge.possibilities,
           logical_u.data.kind==HQD_LOGIC && logical_u.data.logic==HQ_UNKNOWN);
    printf("TRANSACTION: instance=%u generation=%u->%u result_mask=%u\n",
           receipt.instance_id,receipt.previous_generation,
           receipt.resulting_generation,receipt.resulting_possibilities);
    printf("CORRELATED BETWEEN: {0,+1} between [+1,0] => exact FALSE=%d\n",
           range.data.kind==HQD_LOGIC && range.data.logic==HQ_FALSE);
    printf("COMPARE 0<+1: KLEENE DATA=%d logical_value=%d\n",
           known.data.kind==HQD_LOGIC,(int)known.data.logic);
    return 0;
}
