# v1.3 — Nonrecursive higher-function and transactional state plan

**Provenance:** m.A.R.S. directed continuing Holoquary's existing pre-recursion computational/logic foundation while deferring cross-Sisterhood/UPTI/SSMI adaptation. The implementation design and test methods are assistant-generated candidate work. No canonical lock is asserted.

## Selected scope

1. Preserve v1.2 separated `HQDRecord` (computational datum / possible-value set / execution / provenance).
2. Add explicit, named higher logical operations without constructing a recursive runtime.
3. Distinguish exact logical UNKNOWN from epistemic sets of possible Kleene symbols. Preserve invalid/error denial.
4. Add a nonrecursive inclusive range check which reuses the *same numerical completion* in both comparisons.
5. Add a bounded (up to four cells) caller-owned memory tick with an all-or-nothing **function-level** commit, guarded by instance ID and generation.
6. Test the new semantics independently; rerun preserved kernels and legacy suites; package a manifest-checked source release.

## Deliberately excluded

- No changes to original NAND, neural, LESSONS, BLOCK7, v1.2 separation or UPTI code.
- No NINE/FIFTEEN activation, U1/U2/U3 meaning, general unknown-variable aliasing, general graph recursion, physically atomic memory, durable journal, cryptographic verification or sender authorization.
- No new authority for logic guards, return receipts, source identity fields or provenance labels.

## Gates

- Only documented source files differ from v1.2, plus additive files.
- Contradiction is the empty possibility set; numerical zero is an exact domain value.
- KLEENE UNKNOWN is a logical datum; epistemic uncertainty is a set of possible logical values.
- Rejected operations do not publish partial output or partially advance any memory cell under the trusted single-threaded caller contract.
- Reproducible compiler/test/build receipts, package checksum verification.
